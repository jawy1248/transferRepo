function [lowbnd,upbnd,warn_flags,wp_indx] = ami_findpeak(H_comp,ws,num_pts,np,lam_prev);
%
% [lowbnd,lowbnd] = ami_findpeak(H_comp,num_pts,lam_prev);
%
% Function which identifies the data near the peak of an FRF for use in fitting
%
% Matt Allen  -  June, 2004
%

% Initialize warnings
warn_flags = [0,0];
    % warn_flags(1) ~= 0 => edge hit when finding the peak data.
    % warn_flags(2) => Problems finding peak near lam_prev - see below

%if strcmp(input('SaveFPdata?','s'),'y'); save fp_debug.mat; end
    
% If lam_prev is available, use it to identify the area to search.
err_flg = 0;
if ~isempty(lam_prev) & num_pts ~= 0;
    % First search within 2 Bandwidths
    bws = 2;
    peak_band = find(ws > imag(lam_prev)-bws*abs(real(lam_prev)) & ...
        ws < imag(lam_prev)+bws*abs(real(lam_prev)));
    [abs_max,wp_indx] = max(H_comp(peak_band));
        % Try 3 BW if an error occurs
        if isempty(peak_band); err_flg = 1; elseif wp_indx == length(peak_band); err_flg = 1; end
        if err_flg
            err_flg = 0;
            warn_flags(2) = 3; % more than 2 BW needed to find peak
            bws = 3;
			peak_band = find(ws > imag(lam_prev)-bws*abs(real(lam_prev)) & ...
			    ws < imag(lam_prev)+bws*abs(real(lam_prev)));
			[abs_max,wp_indx] = max(H_comp(peak_band));
            if isempty(peak_band); err_flg = 1; elseif wp_indx == length(peak_band); err_flg = 1; end
            if err_flg % still on the edge
                if isempty(peak_band);
                    disp('Warning: No frequency lines found within 3 BW of eigenvalue - Trying 5 BW');
                elseif wp_indx == length(peak_band)
                    disp('Warning: Peak on edge of 3 BW of data - Trying 5 BW');            
                end
                    % TRY 5 BWs
                    err_flg = 0;
                    warn_flags(2) = 5;
                    bws = 5;
					peak_band = find(ws > imag(lam_prev)-bws*abs(real(lam_prev)) & ...
					    ws < imag(lam_prev)+bws*abs(real(lam_prev)));
					[abs_max,wp_indx] = max(H_comp(peak_band));
                if isempty(peak_band);
                    warning('No peak found within 5 BW of eigenvalues - Taking entire FRF');
                    [abs_max,wp_indx] = max(H_comp);
                    warn_flags(2) = inf;
                end
            end
        end
    wp_indx = find(H_comp == abs_max);
else
    [abs_max,wp_indx] = max(H_comp);
end

% Define which data points to use:
if num_pts < 1 & num_pts ~= 0;
    % Uses a custom number of points based on TF magnitude
	level = num_pts; % if num_pts is less than 1 it's the level desired
    
    kk = wp_indx;
	while abs((H_comp(kk))) > abs(level*(H_comp(wp_indx))) | ...
            mean(abs((H_comp([kk:1:kk+np])))) > abs(level*(H_comp(wp_indx)));
        kk = kk + 1;
        if kk > length(H_comp);  % Checks for Edge of Data
            kk = length(H_comp);
            warn_flags(1) = 1;
            break
        end
        if kk+np > length(H_comp); break; end
	end
	upbnd = kk;
    
	kk = wp_indx;
    while abs((H_comp(kk))) > abs(level*(H_comp(wp_indx))) | ...
            mean(abs((H_comp(kk:-1:kk-np)))) > abs(level*(H_comp(wp_indx)));
        kk = kk - 1;
        if kk < 1;  % Checks for Edge of Data
            kk = 1;
            break
            warn_flags(1) = 1;
        end
        if kk-np < 1; np = 0; break; end
	end
	lowbnd = kk;
    
elseif num_pts == 0; % use all points
    % Band contains all data
    lowbnd = 1;
    upbnd = length(H_comp);
    
else % Number of points num_pts > 1
    % Uses number of points specified
     if wp_indx-num_pts < 1; % check for edge
         lowbnd = 1;
     else
         lowbnd = wp_indx-num_pts;
     end
     if wp_indx+num_pts > length(H_comp);  % check for edge
         upbnd = length(H_comp);
     else
         upbnd = wp_indx+num_pts;
     end
end

if ws(lowbnd)==0; % check for zero frequency on low band - can't use it later.
    lowbnd=lowbnd+1;
end

        % Define a minimum bandwidth based on the average zeta.  If fewer points
        % are taken than needed to span half this BW, take more.
        % Previously, seven points was taken as the minimum.
%         dw = w(2)-w(1); zref = 0.0005;
%         if (half_plus-half_minus) < zref*w(wp_indx)/dw;
%             lowbnd = wp_indx - round(0.5*zref*w(wp_indx)/dw);
%             upbnd = wp_indx + round(0.5*zref*w(wp_indx)/dw);
%             disp(['Too few points, ', num2str(half_plus-half_minus), ' Points requested. ',...
%                     num2str(upbnd-lowbnd),' Points Used.']);
%             if half_plus-half_minus < 4;
%                 lowbnd = wp_indx-2; upbnd = wp_indx+2;
%                 disp(['Min BW fails, ', num2str(half_plus-half_minus), ' Points requested. ',...
%                     num2str(upbnd-lowbnd),' Points Used.']);
%             end
%             if lowbnd < 1; % check for edge
%                 lowbnd = 1;
%             end
%             if upbnd > length(X_comp);  % check for edge
%                 upbnd = length(X_comp);
%             end
%         end
        
%     elseif SuborIsol == 2;
%         % Alternate procedure, find all points such that the magnitude exceeds 0.5*peak FRF
%         % This should overcome one-sidedness by taking all points in the interval in which
%         % any point exceeds level*max(abs(X))
%         
%         inds = find(abs(X_comp) > level*max(abs(X_comp)));
%         lowbnd = min(inds); upbnd = max(inds); 
%     end

% if abs_man == 1;
%     % This Flag Signals AMI to let the user define a fitting band
%     def_limits_str = ['[',num2str(w(lowbnd)),',',num2str(w(upbnd)),']'];
% 	disp(['Default Fitting Band: ',def_limits_str,' ', 'Freq Units']);
% 	fit_limits = input(['What band would you like to Fit ( d or Freq Units)? '],'s');
% 	
% 	if fit_limits == 'd' | fit_limits == 'D';
%         % Don't do anything--Keep upbnd, lowbnd;
% 	else
%         fit_limits = eval(fit_limits);
%         lowbnd = floor(fit_limits(1)/(w(2)-w(1)));
%         upbnd = ceil(fit_limits(end)/(w(2)-w(1)));
%         disp(['Band Used: ',num2str([w(lowbnd) w(upbnd)])]);
% 	end
% end