function [] = Mult_NP_MIMO(Xw,Xw_fit,Refs,SubplotHandle,varargin);

% function [] = Mult_NP_MIMO(Xw,Xw_fit,Refs,SubplotHandle);
% 
% Creates Nyquist Plot of Fitted Versus Actual Data
% Refs = [Nref x 2] matrix of references
%       Each row gives the [Input,Output] DOF of the references

% Check Size Compatibilities
[a,b,c] = size(Xw);
%	if b>a; Xw = permute(Xw,[2 1 3]); [a,b,c] = size(Xw); end
if ~isempty(Xw_fit);
	[d,e,f] = size(Xw_fit);
%	if d>c; Xw_fit = permute(Xw_fit,[2 1 3]); [c,d,e] = size(Xw_fit); end
    if b~=e | c~=f;
        disp('Warning: Sizes Not Compatible for Mult_NP_MIMO');
        disp('Size Xw:');
        size(Xw)
        disp('Size Xw_fit');
        size(Xw_fit)
    end
end
if ~isempty(varargin)
    peak_band = varargin{1};
else
    peak_band = [];
end
N = size(Refs,1);
    if size(Refs,2) ~= 2; error('Refs has wrong dimensions'); end

h = subplot(SubplotHandle);
    cols = get(h,'ColorOrder');
    if size(cols,1) < N;
        Ncol = size(cols,1);
        cols((Ncol+1):N,:) = jet(N-Ncol);
    end
plot(0,0);
for ii = 1:1:N;
    line(real(Xw(:,Refs(ii,:))), imag(Xw(:,Refs(ii,:))),'Color',cols(ii,:));
    if ~isempty(peak_band);
        line(real(Xw(peak_band,Refs(ii,:))), imag(Xw(peak_band,Refs(ii,:))),'Color',cols(ii,:),...
            'Color',cols(ii,:),'LineStyle', 'none','Marker', '.');
    end
end
if ~isempty(Xw_fit);
	for ii = 1:1:N;
        line(real(Xw_fit(:,Refs(ii,:))), imag(Xw_fit(:,Refs(ii,:))),'Color',cols(ii,:),...
            'LineStyle', ':','Marker', '*');
	end
end
% Default Title and Labels
title('Nyquist Plot of Refs: Data-(solid) vs. Fit-(dotted)');
xlabel('Real'); ylabel('Imag');


