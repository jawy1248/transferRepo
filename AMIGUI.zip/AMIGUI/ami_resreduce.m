function [A_fit_out,SR,varargout] = ami_resreduce(A_fit,mode_params)

global AMISET AMIDATA AMIMODES

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SVD Analysis to filter out only a specific mode.
A_fit_out = zeros(size(A_fit));
A_fit = permute(A_fit,[2,3,1]);
for k = 1:size(A_fit,3)
    [U,S,V] = svd(A_fit(:,:,k),0);
    SR = diag(S)/S(1,1);

    % Rank1 (non-symmetric) Alternative, keep first column of the decomposition only!
        A_temp = U(:,1)*S(1,1)*(V(:,1)'); % For complex data, use conjugate transpose!!!
        A_fit_out(k,:,:) = ipermute(A_temp,[2,3,1]);

    % Method that enforces reciprocity
        if strcmp(AMISET.ResReduce,'phi')
            al_1 = sqrt((U(AMISET.Ps,1)'*(V(:,1)*S(1,1)))/...
                (mode_params(k,3)*U(AMISET.Ps,1)'*U(AMISET.Ps,1)));
            Phi_fit(:,k) = U(:,1)*al_1;
            % Find new X_fit, A_fit that enforce reciprocity
            A_fit_recip = mode_params(k,3)*Phi_fit*(Phi_fit(AMISET.Ps).');
                A_fit_out(k,:,:) = permute(A_fit_recip,[3,1,2]);
        end
end

if nargout > 3 & strcmp(AMISET.ResReduce,'phi')
    varargout = Phi_fit;
end