function [mode_params,A_fit]=ssi_fd_amig(Hpeak,wpeak,Nm_out,SubOrIsol,varargin)
%
% Polyreference, Frequency-Domain Stochastic Subspace Algorithm based on:
% 	"Continous Time Frequency Domain Subspace System Identification"
% 	By: Peter Van Overschee and Bart De Moor
% 	ftp.esat.kuleuven.ac.be/pub/SISTA/vanoverschee/reports/freqdom2.ps.Z
% Programed by Matt Allen, Feb. 28, 2004
%
% [mode_params,A_fit_out,X_fit,conv_data]=SSI_FD_ami(H,H_comp,ws,Nmodes,CF_set)
%
%   where:  mode_params=[{wn_fit} {z_fit} {lam_fit}];
%
% The program takes the following as necessary inputs:
%   H         = Array of FRFS where size(H) = [Nf, No, Ni]
%   H_comp    = comp_FRF(H), composite FRF of H, used for identifying peak data.
%   ws        = frequency vector for H and H_comp (radians/s)
%   Nmodes    = number of modes to be fit
%
% CF_set defines options for this m-file:
%   CF_set    = {num_pts, TF_type, SuborIsol, np, max_iter, lam_guess, model, consist_A, Ps}
%               This is a cell array, so [] can be used to select default options
%
% 	num_pts   = Number of points on each side of max(abs(X)) to use
%               during subtraction and isolation stages.
%               If num_pts < 1 it is interpreted as a level and all
%               points such that abs(X) > level*max(abs(X)) are taken
% 	TF_type   = Defines the Transfer Function Units, for example,
%               1 = Displacement over Force
%               2 = Acceleration over Force
%               3 = Velocity over Force
% 	SuborIsol = Flag which tells cf_lin whether this is the subtraction
%               stage or isolation stage.  Needed for defining which
%               points to use in the fit.  1 - Subtraction, 2 - Isolation
% 	np        = Number of sequential points which must be below a given
%               level when identifying the peak data.
%   max_iter  = Maximum number of iterations when refining RFP weighing.
% 	lam_guess = An initial guess at Lambda, used to tell the algorithm
%               where to look for the peak that you want to fit.  The algorithm
%               uses the natural frequency and bandwidth to define a search location.
% 	model   =   0 - An FRF model is created
%               1 - Model creation is skipped.
%   consist_A = The basic RFP algorithm returns residue matrices which may have rank > 1.
%               This flag tells the algorithm whether to return raw or consistent residues.
%               0 - raw residues are returned, where rank([{A_1} {A_2} ...]) may be > 1.
%               1 - residues are processed so that [A] = {phi}*({psi}.') is returned
%               2 - reciprocal residues are returned, [A] = {phi}*{phi(DPs)}.'
%   Ps        = Indecies for drive points.  (see previous).  These must be supplied if
%               reciprocal residues are desired.
%   Nex       = Number of extra numerator terms to include in the fit.  One term is used
%               by default if this is blank.

global AMIDATA AMISET AMIMODES

% Define Sizes
	Nf = AMIDATA.Nf;
	Ni = AMIDATA.Ni;
    No = AMIDATA.No;
	NoNi = No*Ni;
	Nfpeak = length(wpeak);
    
% Convert # modes to denominator order + 1
    % Note, Nm_out is the number that we would like returned
    nb = Nm_out*2;
   
% 	% CUT THIS LATER, Load data:
% 	% ####################################################################################
%         clear all; close all;
%         Nm_out = 2;
%         nb = Nm_out*2;
%         
% 		infname = 'SSP_alldata_rect_V1.mat';
% 	%	eval(['load ',infname,' ws H Ps']);
% 	%	H = H(1:700,:,:);
% 	%	Ni = size(H,3); No = size(H,2);
% 	%	ws = ws(1:700).';
%         eval(['load ',infname,' wtd H_tdn Ps']); % ws H
% 		H = H_tdn(:,:,:); % H = H(1:700,:,:);
% 		Ni = size(H,3); No = size(H,2);
% 		ws = wtd.';%ws(1:700).';
%         
%         band_ind = find(ws > 35 & ws < 65);
%         Hpeak = H(band_ind,:,:);
%         wpeak = ws(band_ind);
%         consist_A = 0;
%         model = 0;
%         
%         TF_type = 3;
%         
%         % Define Sizes
% 		Nf = length(ws);
% 		Nfpeak = length(wpeak);
% 		Ni = size(H,3); No = size(H,2);
% 		NoNi = No*Ni;
% 	
% 	% #####################################################################################

Hpeak = mimo2simo_rs(Hpeak); % for easy conversion - Could use Hdm.m and eliminate this.
if ~isempty(AMISET.Ts); % Discrete-time
    wpeak_sc = -i*ln(i*wpeak)/AMISET.Ts;
else
    wpeak_sc = wpeak;
end

% Convert to Displacement
    if strcmp(AMISET.DVA,'D'); % Displacement Data
        % Hpeak = Hpeak;
    elseif strcmp(AMISET.DVA,'V'); % Velocity Data
        % Convert Velocity/Force TF to Displacement
        % Change of variables, Scale factor must be included when integrating
        % Note that this is equiavent to re-deriving the SDOF algorithm for acceleration.
        for ii = 1:1:NoNi;
            Hpeak(:,ii) = (Hpeak(:,ii)./(i*wpeak_sc));
        end
    elseif strcmp(AMISET.DVA,'A');
        % Convert Acceleration/Force TF to Displacement
        % Change of variables, Scale factor must be included when integrating
        % Note that this is equiavent to re-deriving the SDOF algorithm for acceleration.
        for ii = 1:1:NoNi
            Hpeak(:,ii) = (Hpeak(:,ii)./(-wpeak_sc.^2));
        end
    else
        error('Unrecognized TF Type');
    end
    clear wpeak_sc

Hpeak = simo2mimo_rs(Hpeak,Ni);

% Begin Algorithm
Hpeak = permute(Hpeak,[2,3,1]); % Put in classical form

% Condition Data to avoid Numerical Difficulty %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if isempty(AMISET.Ts);
	% Scale the Transfer function by the average value.
		sf_x = mean(mean(mean(abs(Hpeak))));
		Hpeak = Hpeak/sf_x;
	% Scale w by average value
		sf_w = mean(wpeak);
		wpeak = wpeak/sf_w;
else
    sf_x = 1; sf_w = 1;
end

% Beginning of SSI algorithm
% note nb = i in the paper, the number of block rows in the following matrices
% tic
Hc = zeros(nb*No,Nfpeak*Ni); Ic = zeros(nb*Ni,Nfpeak*Ni);
for r = 1:nb
    for f = 1:Nfpeak
        Hc([No*(r-1)+1:No*r],[Ni*(f-1)+1:Ni*f]) = Hpeak(:,:,f)*(i*wpeak(f))^(r-1);
        Ic([Ni*(r-1)+1:Ni*r],[Ni*(f-1)+1:Ni*f]) = eye(Ni)*(i*wpeak(f))^(r-1);
    end
end
Hs = [real(Hc), imag(Hc)];
Is = [real(Ic), imag(Ic)];
%t_form = toc

%tic
HoIp = Hs*(eye(2*Nfpeak*Ni) - Is.'*((Is*Is.')\Is));
%t_project = toc

%tic
[U,S,V] = svd(HoIp,0);
    % Retain only the singular values corresponding to the number of modes we want.
    U1 = U(:,1:2*Nm_out);
    S1 = S(1:2*Nm_out,1:2*Nm_out);
    V1 = V(:,1:2*Nm_out);
%t_svd = toc
%disp('Max Order, Order Retained');
%[size(S) size(S1)]
%figure(500); plot(diag(S),'.');

%tic
	G = U1*sqrt(S1);
	C = G(1:No,:);
	A = G(1:end-No,:)\G(No+1:end,:);
    % Could this be modified to use something more like the ERA formula
    % Would that improve performance for small 'nb' - more like a least squares algorithm.
%t_AC = toc  

Lc = zeros(No*Nfpeak,Ni); Mc = zeros(No*Nfpeak,size(A,1)+No);
for f = 1:Nfpeak
    Lc(No*(f-1)+1:No*f,:) = Hpeak(:,:,f);
    Mc(No*(f-1)+1:No*f,:) = [C*inv(i*wpeak(f)*eye(size(A)) - A), eye(No)];
end
BD = [real(Mc); imag(Mc)]\[real(Lc); imag(Lc)];
    
B = BD(1:size(A,1),:);
D = BD(size(A,1)+1:end,:);

[M,lam] = eig(A);
lam_fit = diag(lam);

    % Sort Eigenvalues
    [junk,sind] = sort(abs(lam_fit) + (min(abs(lam_fit))*1e-6)*(imag(lam_fit)<0));
    lam_fit = lam_fit(sind);
    M = M(:,sind);
    Minv = inv(M);

% Rescale Modal Properties: ################ VIP ##################
	lam_fit = lam_fit(1:2:end)*sf_w; % now lam_fit no longer contains conjugates
    Nmout = length(lam_fit);
    %L_fit = L_fit*sqrt(sf_w*sf_x); % Is this correct?  Both mode vector and part. factor should be
        % scaled by sqrt(scale factor for residue)
    %Phi_fit = C*M*sqrt(sf_w*sf_x);
    %Phi_fit = Phi_fit(:,1:2:end);
    for r = 1:length(lam_fit);
        A_fit(:,:,r) = C*M(:,2*r-1)*Minv(2*r-1,:)*B;
    end
    A_fit = A_fit*sf_w*sf_x;
    A_fit = permute(A_fit,[3,1,2]); % normal 'mimo' form

	% % Rescale Transfer Function % could cut this out?
	% 	Hpeak = Hpeak*sf_x; wpeak = wpeak*sf_w;
    
    mode_params = [abs(lam_fit) -real(lam_fit)./abs(lam_fit) lam_fit];
