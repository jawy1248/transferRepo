function [] = AMIG_MainPlot(PlotWhat,fit_band,PType)
% (w,pfsf,fit_band,AMIDATA.X,Xw_comp,X_fit,A_fit,N_fit,X_fit_FR,AMISET,curr_m
% ode,curr_step,ylims,title_str,sub_or_isol);
% Function which plots data at individual subtraction or isolation steps
% as part of the AMI algorithm
%
% Assumes that the data to compare against is in AMIDATA.X, AMIDATA.Xc
% 
% Matt Allen - Oct 17, 2005 - beginning creation of GUI driven AMI

global AMIDATA AMIDISPLAY AMISET AMIMODES
% disp('Saving Debug Data'); save debugdata.mat
% COMPOSITE PLOT:
axes(AMIDISPLAY.hmainS1)
switch lower(PType);
    case 'init'
        hls(1) = semilogy(AMIDATA.wsplot,AMIDATA.Hc,'b-');  grid on;
        set(gca,'Ylim',AMIDISPLAY.YLim);
    case 'sub'
        hls(1) = semilogy(AMIDATA.wsplot,AMIDATA.Hc,'Color',0.3*[1,1,1]);  hold on;  grid on;
        hls(2) = line(AMIDATA.wsplot,AMIDATA.Xc,'Color','b','LineStyle','-'); 
        hls(3) = line(AMIDATA.wsplot,comp_FRF(sum(AMIMODES.(PlotWhat).X_fit,4)),'Marker','.','LineStyle',':','color',[0,0.5,0]);
        hls(4) = line(AMIDATA.wsplot(fit_band),AMIDATA.Xc(fit_band),'Color','r','Marker','.','LineStyle','none');
        hls(5) = line(AMIDATA.wsplot,comp_FRF(AMIDATA.X-sum(AMIMODES.(PlotWhat).X_fit,4)),'color',[1,0.3,0.3]);
        set(gca,'Ylim',AMIDISPLAY.YLim); hold off;
        legend('Data','Subtraction Residual','Fit','Peak','Residual-Fit');
    case 'isol'
        if strcmpi(AMISET.LRUR,'on') && isfield(AMIMODES,'X_LRUR');
            X_fit = sum(AMIMODES.(PlotWhat).X_fit,4)+AMIMODES.X_LRUR_MIR;
        else
            X_fit = sum(AMIMODES.(PlotWhat).X_fit,4);
        end
%         hls(1) = semilogy(AMIDATA.wsplot_MIR, AMIDATA.Hc(AMIMODES.Isol.mir_band),...
%             'Color',0.3*[1,1,1]);  hold on;  grid on;
        hls(1) = semilogy(AMIDATA.wsplot, AMIDATA.Hc,'Color',0.3*[1,1,1]);  hold on;  grid on;
        hls(2) = line(AMIDATA.wsplot_MIR, AMIDATA.Xc,'Color','b','LineStyle','-'); 
        hls(3) = line(AMIDATA.wsplot_MIR, comp_FRF(X_fit),'Marker','.','LineStyle',':','color',[0,0.5,0]);
        hls(4) = line(AMIDATA.wsplot_MIR(fit_band), AMIDATA.Xc(fit_band),'Color','r','Marker','.','LineStyle','none');
        hls(5) = line(AMIDATA.wsplot_MIR, comp_FRF(AMIDATA.X - X_fit),'color',[1,0.1,0.1]);
        set(gca,'Ylim',AMIDISPLAY.YLim); hold off;
        legend('Data','Isolation Residual','Fit','Peak','Residual-Fit');
    case 'afterisol'
        if strcmpi(AMISET.LRUR,'on') && isfield(AMIMODES,'X_LRUR');
            X_fit = sum(AMIMODES.X_model,4)+AMIMODES.X_LRUR;
        else
            X_fit = sum(AMIMODES.X_model,4);
        end
        hls(1) = semilogy(AMIDATA.wsplot, AMIDATA.Hc,'Color',0.3*[1,1,1]);  hold on;  grid on;
        % line(AMIDATA.wsplot, AMIDATA.Xc,'Color','b','LineStyle','-'); 
        hls(2) = line(AMIDATA.wsplot, comp_FRF(X_fit),'Marker','.','LineStyle',':','color',[0,0.5,0]);
        hls(3) = line(AMIDATA.wsplot, comp_FRF(AMIDATA.H - X_fit),'color',[1,0.1,0.1]);
        set(gca,'Ylim',AMIDISPLAY.YLim); hold off;
        legend('Data','Fit','Data-Fit');
end
title(['\bf',AMIDISPLAY.title_str]);
xlabel(['\bfFrequency (',AMISET.flabel,')']);
set(hls,'LineWidth',2);

% Nyquist Plot:
axes(AMIDISPLAY.hmainS2)
switch lower(PType)
    case 'init'
        Hs = LMS_sum_FRFs(AMIDATA.H);
        plot(real(Hs),imag(Hs));
        title('\bfComplex Sum(abs) FRFs'); xlabel('\bfRe\{H(\omega)\}'); ylabel('\bfIm\{H(\omega)\}');
    case 'sub'
        cla(AMIDISPLAY.hmainS2);
        mult_cnplot(AMIDATA.wsplot,AMIDATA.X,AMIMODES.(PlotWhat).X_fit,...
            AMIMODES.(PlotWhat).A_fit,AMIDISPLAY.hmainS2,fit_band);
        title('\bfCNPs for Each Mode');
    case 'isol'
        if strcmpi(AMISET.LRUR,'on') && isfield(AMIMODES,'X_LRUR');
            X_fit = AMIMODES.(PlotWhat).X_fit+AMIMODES.X_LRUR_MIR(:,:,:,ones(size(AMIMODES.(PlotWhat).X_fit,4)));
        else
            X_fit = AMIMODES.(PlotWhat).X_fit;
        end
        cla(AMIDISPLAY.hmainS2);
        mult_cnplot(AMIDATA.wsplot_MIR,AMIDATA.X,X_fit,...
            AMIMODES.(PlotWhat).A_fit,AMIDISPLAY.hmainS2,fit_band);
        title('\bfCNPs for Each Mode');
    case 'afterisol'
        Hs = LMS_sum_FRFs(AMIDATA.H);
        if strcmpi(AMISET.LRUR,'on') && isfield(AMIMODES,'X_LRUR');
            X_fit = sum(AMIMODES.X_model,4)+AMIMODES.X_LRUR;
        else
            X_fit = sum(AMIMODES.X_model,4);
        end
        Hs_fit = LMS_sum_FRFs(X_fit);
        plot(real(Hs),imag(Hs),real(Hs_fit),imag(Hs_fit),'.:');
        title('\bfComplex Sum(abs) FRFs'); xlabel('\bfRe\{H(\omega)\}'); ylabel('\bfIm\{H(\omega)\}');
        legend('Data','Fit');
end