function [] = ami_isolate
% Isolation stage for AMI algorithm

global AMIDATA AMIDISPLAY AMISET AMIMODES

if isempty(AMIMODES.mode_store)
    set(AMIDISPLAY.displaytext, 'String', 'You must identify at least one mode first. Start by running Automatic or Manual Sutraction.');
    return
end

% Clear out any buttons that may not have been cleared (due to errors)
try; delete(AMIDISPLAY.hyes); end
try; delete(AMIDISPLAY.hno); end
try; delete(AMIDISPLAY.hzero); end
try; delete(AMIDISPLAY.hdiscard); end
try; delete(AMIDISPLAY.hbandsel); end
try; delete(AMIDISPLAY.horder); end
try; delete(AMIDISPLAY.hquitsub); end


t0 = clock; t_print = clock;

    % Find the number of modes identified so far
    orig_modes = size(AMIMODES.mode_store,1);
    
    % Reset option to view isolation steps
    AMISET.ShowIsolStepsTemp = AMISET.ShowIsolSteps;
    
% Begin creating Isolation residual - various settings supported

%     % bovlap = 'y'; % This feature not yet implemented
    if strcmp(AMISET.BandMode,'fixed') %& strcmp(bovlap,'y');
       disp('Bands for Identified Modes'); disp(AMIMODES.m_bands)
        AMIMODES.Isol.mir_band = [];
        for k = 1:max(AMIMODES.mode_store(:,4))
            k_s = find(AMIMODES.mode_store(:,4) == k);
            AMIMODES.Isol.mir_band = [AMIMODES.Isol.mir_band, ...
                AMIMODES.m_bands(k_s(1),1):AMIMODES.m_bands(k_s(1),2)];
        end
        AMIMODES.Isol.mir_band = unique(sort(AMIMODES.Isol.mir_band));
        if strcmp(AMISET.LM,'off')
            if isempty(AMISET.Ts) % C-time
                if AMISET.OMA
                AMIMODES.X_model = csd_model(AMIMODES.mode_store(:,3),AMIMODES.A_store,...
                    AMIMODES.B_store,AMIDATA.ws(AMIMODES.Isol.mir_band),AMISET.DVA,'i');
                else
                AMIMODES.X_model = ss_model(AMIMODES.mode_store(:,3),AMIMODES.A_store,...
                    AMIDATA.ws(AMIMODES.Isol.mir_band),AMISET.DVA,'i');
                end
            else % discrete time
                AMIMODES.X_model = ss_model(exp(AMIMODES.mode_store(:,3)*AMISET.Ts),AMIMODES.A_store,...
                    AMIDATA.zs(AMIMODES.Isol.mir_band),AMISET.DVA,'i');
                AMIMODES.X_model = Hdm(AMIMODES.X_model,(i*AMIDATA.zs(AMIMODES.Isol.mir_band)));
            end
        end

%     elseif 0;%strcmp(AMISET.BandMode,'fixed') & strcmp(bovlap,'n')
%         % Non-overlapping bands - this feature not yet implemented
%         save ms_debugdata.mat
%         AMIMODES.Isol.mir_band = [];
%         % Check for overlap
%         [lb_sort, lbsi] = sort(AMIMODES.m_bands(:,1));
%         for k = 1:max(AMIMODES.mode_store(:,4))
%             %
%         end
% 
    else
        AMIMODES.Isol.mir_band = [1:length(AMIDATA.ws)];
    end

% #########################################################################
% Mode Isolation and Refinement stage
% #########################################################################
set(AMIDISPLAY.displaytext, 'String','Mode Isolation and Refinement');
    try; AMIDATA = rmfield(AMIDATA,{'X','Xc'}); end
    % Remove Subtraction residual if it exists
if strcmp(AMISET.LM,'off')
    AMIDATA.X_sum = sum(AMIMODES.X_model,4);
else % large model mode
    if isempty(AMISET.Ts); % Continuous Time model
        if AMISET.OMA
        AMIDATA.X_sum = csd_model(AMIMODES.mode_store(:,3),AMIMODES.A_store,...
            AMIMODES.B_store,AMIDATA.ws(AMIMODES.Isol.mir_band),AMISET.DVA,'s');
        else
        AMIDATA.X_sum = ss_model(AMIMODES.mode_store(:,3),AMIMODES.A_store,...
            AMIDATA.ws(AMIMODES.Isol.mir_band),AMISET.DVA,'s');
        end
    else % discrete time
        AMIDATA.X_sum = ss_model(exp(AMIMODES.mode_store(:,3)*AMISET.Ts),AMIMODES.A_store,...
            AMIDATA.zs(AMIMODES.Isol.mir_band),AMISET.DVA,'s');
        AMIDATA.X_sum = Hdm(AMIDATA.X_sum,(i*AMIDATA.zs(AMIMODES.Isol.mir_band)));
    end
end

AMIDATA.X_MIR = AMIDATA.H(AMIMODES.Isol.mir_band,:,:);
if isfield(AMIMODES,'X_LRUR');
    AMIMODES.X_LRUR_MIR = AMIMODES.X_LRUR(AMIMODES.Isol.mir_band,:,:);
    AMIDATA.X_MIR = AMIDATA.X_MIR - AMIMODES.X_LRUR(AMIMODES.Isol.mir_band,:,:);
end
if ~isempty(AMISET.Ts); % Fit Discrete-time model
    AMIDATA.wsplot_MIR = AMIDATA.ws(AMIMODES.Isol.mir_band)/AMISET.FreqScale;
	AMIDATA.ws_MIR = AMIDATA.zs(AMIMODES.Isol.mir_band);
else
    AMIDATA.ws_MIR = AMIDATA.ws(AMIMODES.Isol.mir_band);
    AMIDATA.wsplot_MIR = AMIDATA.ws_MIR/AMISET.FreqScale;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% NOTE: !!!!!
% All actions in the isolation stage on AMIDATA.X and AMIDATA.X_model
% use the isolation residual in the band: AMIMODES.Isol.mir_band

n = 0; AMIMODES.Isol.pchng = 1;
isol_tol = 1e-5;
    % set up variables to store convergence results.
	wn_conv = zeros(size(AMIMODES.mode_store,1),AMISET.IsolIter);
	z_conv = zeros(size(AMIMODES.mode_store,1),AMISET.IsolIter);
	eig_conv = zeros(size(AMIMODES.mode_store,1),AMISET.IsolIter);
	A_conv = zeros(size(AMIMODES.A_store,1),size(AMIMODES.A_store,2),...
        size(AMIMODES.A_store,3),AMISET.IsolIter);
    
while (n <= AMISET.IsolIter && AMIMODES.Isol.pchng > isol_tol);
    n = n+1;

  for isol_step = 1:max(AMIMODES.mode_store(:,4))     % This full loop contains one isolation step
      m_inds = find(AMIMODES.mode_store(:,4) == isol_step); % finds all modes identified in a step.
      n_fit = length(m_inds);
      
      % Form isolation residual
      if strcmp(AMISET.LM,'off')
          X_sub = AMIDATA.X_sum - sum(AMIMODES.X_model(:,:,:,m_inds),4);
      else
        if isempty(AMISET.Ts); % Fit continuous-time model
            if AMISET.OMA
            X_sub = AMIDATA.X_sum - csd_model(AMIMODES.mode_store(m_inds,3),AMIMODES.A_store(m_inds,:,:),...
                AMIMODES.B_store(m_inds,:,:),AMIDATA.ws(AMIMODES.Isol.mir_band),AMISET.DVA,'s');
            else
            X_sub = AMIDATA.X_sum - ss_model(AMIMODES.mode_store(m_inds,3),...
                AMIMODES.A_store(m_inds,:,:),AMIDATA.ws(AMIMODES.Isol.mir_band),AMISET.DVA,'s');
            end
        else % Discrete Time:
            Xtemp = ss_model(exp(AMIMODES.mode_store(m_inds,3)*AMISET.Ts),...
                AMIMODES.A_store(m_inds,:,:),AMIDATA.zs(AMIMODES.Isol.mir_band),AMISET.DVA,'s');
            Xtemp = Hdm(Xtemp,(i*AMIDATA.zs(AMIMODES.Isol.mir_band)));
            X_sub = AMIDATA.X_sum - Xtemp; clear Xtemp
        end

      end
      if isfield(AMIMODES,'X_LRUR_MIR'); % skip on 1st isolation step % strcmp(AMISET.LRUR,'on') && 
          AMIDATA.X = AMIDATA.X_MIR - X_sub; % - AMIMODES.X_LRUR_MIR
      else
          AMIDATA.X = AMIDATA.X_MIR - X_sub;
      end
      AMIDATA.Xc = comp_FRF(AMIDATA.X);
        
        % Identify Peak Data
            if strcmp(AMISET.BandMode,'fixed');
                AMIMODES.IsolStep.NumPoints = 0; % use all points in band passed in.
                AMIMODES.IsolStep.SrchBand = [find(AMIMODES.Isol.mir_band == AMIMODES.m_bands(m_inds(1),1)):...
                    find(AMIMODES.Isol.mir_band == AMIMODES.m_bands(m_inds(1),2))];
            else
                AMIMODES.IsolStep.NumPoints = AMISET.NumPointsIsol;% % Passed in where AMISET.NumPoints goes--AMI uses points above level
                    % Dr. Ginsberg found that 0.5 worked best in his paper for IMAC 2003
                AMIMODES.IsolStep.SrchBand = [1:length(AMIDATA.ws)];
            end
        
            % Tell AMI old Lambda to search in the same location.
                %lam_prev = AMIMODES.mode_store(m_inds(1),3);
                lam_prev = max(real(AMIMODES.mode_store(m_inds,3))) + ...
                    i*mean(imag(AMIMODES.mode_store(m_inds,3)));
            [lowbnd,upbnd,warn_flags,wp_indx] = ami_findpeak(AMIDATA.Xc(AMIMODES.IsolStep.SrchBand),...
                AMIDATA.ws(AMIMODES.IsolStep.SrchBand),AMIMODES.IsolStep.NumPoints,AMISET.NoisePoints,lam_prev);
            lowbnd = AMIMODES.IsolStep.SrchBand(lowbnd); upbnd = AMIMODES.IsolStep.SrchBand(upbnd);
            AMIMODES.IsolStep.lbub = [lowbnd,upbnd];
            
            % Create Arrays of peak data
            wpeak = AMIDATA.ws_MIR(lowbnd:upbnd);
            if isempty(AMISET.Ts) % C-time model
                Hpeak = AMIDATA.X([lowbnd:upbnd],:,:);
            else
                Hpeak = Hdm(AMIDATA.X([lowbnd:upbnd],:,:),(i*wpeak).^-1);
                % multiply by z^-1 so a 1/z-lambda model can be fit.
            end

        if n_fit == 1;
            if AMISET.SDOFAlg == 1; % Use cf_etrue_simo algorithm - no numerator terms allowed.
                % Single mode fit using least squares algorithm
                if isol_step == 1; set(AMIDISPLAY.displaytext, 'String','Using CF_etrue Algorithm'); end
                [AMIMODES.IsolStep.mode_params,A_fit_Rf] = cf_msa(Hpeak,wpeak,'isol');

            elseif AMISET.SDOFAlg == 0; % Use RFP_MATTtls_ami or it's variants
                % Single mode fit using least squares algorithm
                if AMISET.OMA
                    [AMIMODES.IsolStep.mode_params,A_fit_Rf,B_fit_Rf] = rfpm(Hpeak,wpeak,1,'isol'); 
                else
                    [AMIMODES.IsolStep.mode_params,A_fit_Rf] = rfpm(Hpeak,wpeak,1,'isol');      
                end
            elseif AMISET.SDOFAlg == 2; % Use RFP_MRealtls_ami or it's variants
                [AMIMODES.IsolStep.mode_params,A_fit_Rf] = rfpm_real(Hpeak,wpeak,1,'isol');
            end

        else
            % Multi-mode Fit using SSI-FD Algorithm
            [AMIMODES.IsolStep.mode_params,AMIMODES.IsolStep.A_fit] = ssi_fd_amig(Hpeak,wpeak,n_fit,'isol',lam_prev);

        end
        
        if ~isempty(AMISET.Ts); % Discrete-time model
            lamz = AMIMODES.IsolStep.mode_params(:,3);
            lamc = ln(lamz)/AMISET.Ts;
            AMIMODES.IsolStep.mode_params = [abs(lamc), -real(lamc)./abs(lamc), lamc];
        end
        
        if n_fit == 1;
            if strcmpi(AMISET.ResReduce,'r1')
                % Process Residues (A_fit) to determine the number of modes active:
                [AMIMODES.IsolStep.A_fit,AMIMODES.IsolStep.SR] = ami_resreduce(A_fit_Rf,AMIMODES.IsolStep.mode_params);
                if AMISET.OMA
                    [AMIMODES.IsolStep.B_fit,AMIMODES.IsolStep.SR] = ami_resreduce(B_fit_Rf,AMIMODES.IsolStep.mode_params);
                end
                if length(AMIMODES.IsolStep.SR) == 1; AMIMODES.IsolStep.SR(2,1) = 0; end
            else
                AMIMODES.IsolStep.A_fit = A_fit_Rf;
                if AMISET.OMA
                    AMIMODES.IsolStep.B_fit = B_fit_Rf;
                end
            end
        end
        
        % Form Model from identified parameters
        if ~isempty(AMISET.Ts); % Discrete-time model
            AMIMODES.IsolStep.X_fit = ss_model(exp(AMIMODES.IsolStep.mode_params(:,3)*AMISET.Ts),...
                AMIMODES.IsolStep.A_fit, AMIDATA.ws_MIR, AMISET.DVA, 'i');
            AMIMODES.IsolStep.X_fit = Hdm(AMIMODES.IsolStep.X_fit,(i*AMIDATA.ws_MIR));
        else
            if AMISET.OMA % IT SEEMS THAT THIS SHOULD HAVE A SWITCH FOR LM MODE!??
                AMIMODES.IsolStep.X_fit = csd_model(AMIMODES.IsolStep.mode_params(:,3),...
                    AMIMODES.IsolStep.A_fit, AMIMODES.IsolStep.B_fit, AMIDATA.ws_MIR, AMISET.DVA, 'i');
            else
                AMIMODES.IsolStep.X_fit = ss_model(AMIMODES.IsolStep.mode_params(:,3),...
                    AMIMODES.IsolStep.A_fit, AMIDATA.ws_MIR, AMISET.DVA, 'i');
            end
        end
        % Optional step by step plotting
        if AMISET.ShowIsolStepsTemp == 'y'
            % save ami_debugdata.mat
            lbm = AMIMODES.IsolStep.lbub(1); ubm = AMIMODES.IsolStep.lbub(2);

			% Send to plotting function
            AMIDISPLAY.title_str = ['Isolation Stage: Modes # ', num2str(m_inds.'), ', From MDOF'];
            AMIG_MainPlot('IsolStep',[lbm:ubm],'isol')    
            set(AMIDISPLAY.displaytext, 'String','Continue Showing Isolation Steps?');
            AMIDISPLAY.hyes = uicontrol('Parent',AMIDISPLAY.hmain, ...
                'Units','normalized', ...
                'Position',[0.85 0.1 0.03 0.075], ...
                'Callback','global AMIDATA; AMIDATA.showisolsteps = ''y''; global AMIDISPLAY; set(AMIDISPLAY.hyes,''UserData'',''done''),', ...
                'String','Yes', ...
                'Tag','Zero');
                AMIDISPLAY.hno = uicontrol('Parent',AMIDISPLAY.hmain, ...
                'Units','normalized', ...
                'Position',[0.91 0.1 0.03 0.075], ...
                'Callback','global AMIDATA; AMIDATA.showisolsteps = ''n''; global AMIDISPLAY; set(AMIDISPLAY.hyes,''UserData'',''done''),', ...
                'String','No', ...
                'Tag','Zero');
            waitfor(AMIDISPLAY.hyes,'UserData','done');
            show_isol_steps = AMIDATA.showisolsteps;
            delete(AMIDISPLAY.hyes);
            delete(AMIDISPLAY.hno);
        end
        
    % Update parameters
    for k = 1:n_fit;
        if strcmp(AMISET.LM,'off')
            AMIMODES.X_model(:,:,:,m_inds(k)) = AMIMODES.IsolStep.X_fit(:,:,:,k);
            % Note, close modes may switch places doing it this way
        end
        AMIMODES.mode_store(m_inds(k),:) = [AMIMODES.IsolStep.mode_params(k,:), isol_step];
        AMIMODES.A_store(m_inds(k),[1:size(AMIMODES.IsolStep.A_fit,2)],...
            [1:size(AMIMODES.IsolStep.A_fit,3)]) = AMIMODES.IsolStep.A_fit(k,:,:);
        if AMISET.OMA
        AMIMODES.B_store(m_inds(k),[1:size(AMIMODES.IsolStep.B_fit,2)],...
            [1:size(AMIMODES.IsolStep.B_fit,3)]) = AMIMODES.IsolStep.B_fit(k,:,:);
        end
        %Phi_store(:,m_inds(k)) = Phi_fit;
    end
    
    % Form a new sum of models
    if strcmp(AMISET.LM,'off')
        AMIDATA.X_sum = sum(AMIMODES.X_model,4); % ?? faster to add X_sub and the new AMIMODES.X_model?
    else
        if isempty(AMISET.Ts); % Fit continuous-time model
            if AMISET.OMA
            AMIDATA.X_sum = X_sub + csd_model(AMIMODES.mode_store(m_inds,3),...
                AMIMODES.A_store(m_inds,:,:),AMIMODES.B_store(m_inds,:,:),AMIDATA.ws_MIR,AMISET.DVA,'s');
            else
            AMIDATA.X_sum = X_sub + ss_model(AMIMODES.mode_store(m_inds,3),...
                AMIMODES.A_store(m_inds,:,:),AMIDATA.ws_MIR,AMISET.DVA,'s');
            end
        else
            Xtemp = ss_model(exp(AMIMODES.mode_store(m_inds,3)*AMISET.Ts),...
                AMIMODES.A_store(m_inds,:,:),AMIDATA.ws_MIR,AMISET.DVA,'s');
            Xtemp = Hdm(Xtemp,(i*AMIDATA.ws_MIR));
            AMIDATA.X_sum = X_sub + Xtemp; clear Xtemp
        end
    end  
    
end % End of a single isolation loop over all modes - isol_step

% % #################### Find LRUR ##############################################
% if strcmpi(AMISET.LRUR,'on');
%     X_s_lrur = ss_model(AMIMODES.mode_store(:,3),...
%         AMIMODES.A_store,AMIDATA.ws,AMISET.DVA,'s');
%     if ~isfield(AMIMODES,'X_LRUR'); % Initiate LRUR on first pass through Isolation
%         AMIMODES.LRUR = find_ur_ami(AMIDATA.H-X_s_lrur,AMIDATA.ws,AMISET.LRUR_dfrac);
%     else 
%         AMIMODES.LRUR = find_ur_ami(AMIDATA.H-X_s_lrur-AMIMODES.X_LRUR,...
%             AMIDATA.ws,AMISET.LRUR_dfrac);
%     end
%     % Update X_LRUR and form subtraction residual
% %     AMIMODES.LRUR(1,:,:) = 0; % discard lower - isn't working?
%     AMIMODES.X_LRUR = ss_model([],[],AMIDATA.ws,AMISET.DVA,'s',AMIMODES.LRUR);
%     AMIMODES.X_LRUR_MIR = ss_model([],[],AMIDATA.ws_MIR,AMISET.DVA,'s',AMIMODES.LRUR);
% end

% Display Mode Parameters During Isolation Stage
if n < AMISET.IsolIter & etime(clock,t_print) > 30; %n/10 == floor(n/10);
    fprintf(['Results after %g Iterations\nMode: \t ',AMISET.fl2,'n = \t zeta = \t lambda = \t norm(A) \n'],n);
        for ii = 1:1:size(AMIMODES.mode_store,1)
        fprintf('%g \t %8.5g \t %8.5g \t %8.5g + i*%8.5g %8.5g \t\n',ii,...
           AMIMODES.mode_store(ii,1)/AMISET.FreqScale, AMIMODES.mode_store(ii,2),...
           real(AMIMODES.mode_store(ii,3)), imag(AMIMODES.mode_store(ii,3)),...
           norm(mimo2simo_rs(AMIMODES.A_store(ii,:))));
        end
    t_print = clock;
end 
  % Watch Convergence:
  wn_conv(1:size(AMIMODES.mode_store,1),n) = AMIMODES.mode_store(:,1);
  z_conv(1:size(AMIMODES.mode_store,1),n) = AMIMODES.mode_store(:,2);
  eig_conv(1:size(AMIMODES.mode_store,1),n) = AMIMODES.mode_store(:,3);
  A_conv(1:size(AMIMODES.mode_store,1),:,:,n) = AMIMODES.A_store;
  
  % Calculate percent change in eigenvalues
  if n > 1;
      one_to_nm = [1:size(AMIMODES.mode_store,1)];
      repchng = max(real(eig_conv(one_to_nm,n) - eig_conv(one_to_nm,n-1))./real(eig_conv(one_to_nm,n)));
      impchng = max(imag(eig_conv(one_to_nm,n) - eig_conv(one_to_nm,n-1))./imag(eig_conv(one_to_nm,n)));
%       AMIMODES.Isol.pchng = max(abs([repchng, impchng]));
      if AMISET.SDOFAlg == 2; % Real modes
          reApchng = 0;
      else
          reApchng = max(max(max(real(A_conv(one_to_nm,:,:,n) - A_conv(one_to_nm,:,:,n-1))./...
              real(A_conv(one_to_nm,:,:,n)))));
      end
      imApchng = max(max(max(imag(A_conv(one_to_nm,:,:,n) - A_conv(one_to_nm,:,:,n-1))./...
          imag(A_conv(one_to_nm,:,:,n)))));
      AMIMODES.Isol.pchng = max(abs([repchng, impchng, reApchng, imApchng]));
  end
  
end % end of While loop - MIR complete
wn_conv = wn_conv(:,1:n); z_conv = z_conv(:,1:n);
eig_conv = eig_conv(:,1:n); A_conv = A_conv(:,:,:,1:n);

if AMIMODES.Isol.pchng < isol_tol
    x = sprintf(['Mode Isolation Complete - Minimum Change Reached in ',num2str(n),' iterations']);
    set(AMIDISPLAY.displaytext, 'String',x);
else
    y = sprintf(['Ceasing Mode Isolation - Maximum # of Iterations Reached: ',num2str(n),' iterations']);
    set(AMIDISPLAY.displaytext, 'String', y);
end

% #########################################################################
% MIR Complete - clear variables
AMIDATA = rmfield(AMIDATA,{'X_sum','X_MIR','ws_MIR','wsplot_MIR','X','Xc'});
AMIMODES = rmfield(AMIMODES,'IsolStep');
AMIMODES = rmfield(AMIMODES,'Isol');

% Create new model if fixed bands were used or 'LargeModel = on'
    if strcmp(AMISET.BandMode,'fixed') | ~strcmp(AMISET.LM,'off');
        if ~strcmp(AMISET.LM,'off') % large model mode
            if isempty(AMISET.Ts) % Continuous Time Model
                if AMISET.OMA
                AMIMODES.X_model = csd_model(AMIMODES.mode_store(:,3),...
                    AMIMODES.A_store,AMIMODES.B_store,AMIDATA.ws,AMISET.DVA,'s');
                else
                AMIMODES.X_model = ss_model(AMIMODES.mode_store(:,3),...
                    AMIMODES.A_store,AMIDATA.ws,AMISET.DVA,'s');
                end
            else % discrete time
                AMIMODES.X_model = ss_model(exp(AMIMODES.mode_store(:,3)*AMISET.Ts),...
                    AMIMODES.A_store,AMIDATA.zs,AMISET.DVA,'s');
                AMIMODES.X_model = Hdm(AMIMODES.X_model,(i*AMIDATA.zs));
            end
        else
            if prod(size(AMIDATA.H))*size(AMIMODES.mode_store,1)*16 > 1e7*16
                warning('You may run out of memory - switch to Large Model mode');
            end
%         if prod(size(AMIDATA.H))*size(AMIMODES.mode_store,1)*16 < max_mem;
            % Form models of each mode's contribution.
            if isempty(AMISET.Ts) % Continuous Time
                if AMISET.OMA
                AMIMODES.X_model = csd_model(AMIMODES.mode_store(:,3),...
                    AMIMODES.A_store,AMIMODES.B_store,AMIDATA.ws,AMISET.DVA,'i');
                else
                AMIMODES.X_model = ss_model(AMIMODES.mode_store(:,3),...
                    AMIMODES.A_store,AMIDATA.ws,AMISET.DVA,'i');
                end
            else
                AMIMODES.X_model = ss_model(exp(AMIMODES.mode_store(:,3)*AMISET.Ts),...
                    AMIMODES.A_store,AMIDATA.zs,AMISET.DVA,'i');
                AMIMODES.X_model = Hdm(AMIMODES.X_model,(i*AMIDATA.zs));
            end
%         else
%             % Not enough memory, form sum of fits only.
%             AMIMODES.X_model = ss_model(AMIMODES.mode_store(:,3),...
%                  AMIMODES.A_store,AMIDATA.ws,AMISET.DVA,'s');
%         end
        end
    else
        % Model already created is sufficient - in other words:
        % AMIDATA.w_MIR = AMIDATA.ws
    end
	% AMIDATA.X_res_MIR = AMIDATA.H - sum(AMIMODES.X_model,4); % original data minus the sum of modes
    
% Sort Modes by ascending wn
	[sort_w, indx]=sort(AMIMODES.mode_store(:,1));
    % DO I NEED THE LOOP??
	for ii = 1:1:length(indx);
        mode_store_sort(ii,:) = AMIMODES.mode_store(indx(ii),:);
        A_store_sort(ii,[1:size(AMIMODES.A_store,2)],[1:size(AMIMODES.A_store,3)]) = ...
            AMIMODES.A_store(indx(ii),:,:);
        if AMISET.OMA
        B_store_sort(ii,[1:size(AMIMODES.B_store,2)],[1:size(AMIMODES.B_store,3)]) = ...
            AMIMODES.B_store(indx(ii),:,:);
        end
        m_bands_sort(ii,:) = AMIMODES.m_bands(indx(ii),:);
	end
	AMIMODES.mode_store = mode_store_sort;
	AMIMODES.A_store = A_store_sort;
    if AMISET.OMA
        AMIMODES.B_store = B_store_sort;
    end
    AMIMODES.m_bands = m_bands_sort;
    if size(AMIMODES.X_model,4) > 1; % sort models if LM model mode is off
        AMIMODES.X_model = AMIMODES.X_model(:,:,:,indx);
    end

%######################## End Modal fit and refinement ###################

% Print the Results to the screen
fprintf(['Results: \n']);
fprintf(['Results after %g Iterations\nMode: \t ',AMISET.fl2,'n = \t zeta = \t lambda = \t norm(A) \t group # \n'],n);
for ii = 1:1:size(AMIMODES.mode_store,1)
   fprintf('%g \t %8.5g \t %8.5g \t %8.5g + i*%8.5g \t %8.5g \t %g\n',ii,AMIMODES.mode_store(ii,1)/AMISET.FreqScale,...
       AMIMODES.mode_store(ii,2),real(AMIMODES.mode_store(ii,3)), imag(AMIMODES.mode_store(ii,3)),norm(mimo2simo_rs(AMIMODES.A_store(ii,:))),...
       AMIMODES.mode_store(ii,4));
end

conv_its = size(wn_conv,2);

elapsed_time = etime(clock,t0)

% Convergence figures
if (AMISET.FigDisp == 2 || AMISET.FigDisp == 1) && AMISET.IsolIter > 0;
    
% 	H = figure; set(H,'Units','normalized','Position',[.25 .05 .5 .85]);
% 	subplot(3,1,1);
% 	plot((ones(orig_modes,1)*[1:conv_its]).',wn_conv.'/AMISET.FreqScale); grid;
% 	title('Convergence of \omega_n, \zeta, A_r, A_i');
% 	ylabel('\omega_n');
% 	subplot(3,1,2);
% 	plot((ones(orig_modes,1)*[1:conv_its]).',z_conv.'); grid;
% 	ylabel('\zeta');
% 	subplot(3,1,3);
% 	plot((ones(orig_modes,1)*[1:conv_its]).',real(A_conv.'),...
%         (ones(orig_modes,1)*[1:conv_its]).',imag(A_conv.'),'-.'); grid;
% 	ylabel('A Coeff: Re(A)-solid Im(A)-dashed');
% 	xlabel('Iteration');
	try
        % Convergence figure #2--Errors
        %wn_conv_s = 0; z_conv_s = 0; A_conv_s = 0;
		for jj = 1:1:size(AMIMODES.mode_store,1)   % Find x_conv_s, the deviations from average.
            wn_conv_s(jj,1:conv_its) = wn_conv(jj,1:conv_its)/(wn_conv(jj,end));
            z_conv_s(jj,1:conv_its) = z_conv(jj,1:conv_its)/(z_conv(jj,end));
        end
		H = figure(48); set(H,'Units','normalized','Position',[.25 .05 .5 .85]);
		subplot(2,1,1);
		plot((ones(orig_modes,1)*[1:conv_its]).',wn_conv_s.'); grid;
        for nm = 1:size(wn_conv_s,1);
            text(1,wn_conv_s(nm,1),num2str(wn_conv(nm,end)/AMISET.FreqScale));
        end
		title(['Convergence of \omega_n, \zeta, A_r, A_i']);
		ylabel('\omega_n / \omega_n_,_a_v_g');
		subplot(2,1,2);
		plot((ones(orig_modes,1)*[1:conv_its]).',z_conv_s.'); grid;
        for nm = 1:size(z_conv_s,1);
            text(1,z_conv_s(nm,1),num2str(wn_conv(nm,end)/AMISET.FreqScale));
        end
		ylabel('\zeta / \zeta_a_v_g');
	catch
        warning('Error Plotting Convergence Figure:  data saved in msdebugdata.mat');
        save msdebugdata.mat
	end
    
%     % Residual Figure
    AMIDISPLAY.title_str = 'Composite of Residual After Mode Isolation & Refinement';
    AMIG_MainPlot([],[],'AfterIsol');

end

AMIMODES.Status.Isol = 'current';
