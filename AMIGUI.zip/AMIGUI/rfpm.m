function [mode_params,A_fit,varargout] = rfpm(Hpeak,wpeak,Nmodes,varargin)
%
% [mode_params,A_fit,varargout] = rfpm(Hpeak,wpeak,Nmodes,varargin)
%
% Rational Fraction Polynomial Algorithm based on:
% 	"A Global, Single-Input-Multi-Output (SIMO) Implementation of the Algorithm of Mode Isolation 
%   and Applications to Analytical and Experimental Data," Matthew S. Allen and Jerry H. Ginsberg,
%   Mechanical Systems and Signal processing.  Also see MSA's PhD thesis,
%   Sec. 2.2.1, pp 24-28.
%       Written by Matt Allen, 2005
%
%   This version is primarily intended for use within the AMI algorithm.
%   More documentation probably needed...
%
% 2010-06-08 Modified MSA to accept either FRFs or output-only spectra.
% To use this with OMA data, pass as shown above and set:
%   AMISET.OMA = true;
%   Hpeak = Gyy_peak, Nmodes=1;
%

global AMIDATA AMISET

% Define Sizes
	Ni = AMIDATA.Ni;
    No = AMIDATA.No;
	NoNi = No*Ni;
	
    Nfpeak = length(wpeak);
    
    Hpeak = mimo2simo_rs(Hpeak);

% Convert # modes to denominator order + 1
if AMISET.OMA
    if Nmodes ~=1; error('OMA Not written for > 1 mode yet!'); end
	Nd = 2*Nmodes+1;
    Nn = 4; % manually set for now for SDOF
else % EMA
	Nd = 2*Nmodes+1;
    Nn = Nd-1+AMISET.NumeratorTerms; % Numerator Order
end
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%     % CUT THIS LATER, Load data:
%     clear all; close all;
%     Nmodes = 3;
% 	  n = 2*Nmodes;
%         Nd = n+1;
%     Ne = 1; % Extra numerator Terms
%         Nn = Nd - 1 + Ne; % Numerator Order
%     max_iter = 3;
%     
% 	infname = 'SSP_alldata_rect_3modes.mat';
% 	eval(['load ',infname,' ws H Ps']);
% 	H = H(1:700,:,:);
% 	Ni = size(H,3); No = size(H,2);
% 	ws = ws(1:700).';
%     
%     band_ind = find(ws > 0 & ws < 60);
%     Hpeak = H(band_ind,:,:);
%     Hpeak = mimo2simo_rs(Hpeak);
%     wpeak = ws(band_ind);
% 
%     TF_type = 3;
%     consist_A = 0;
%     model = 0;
%     
% 	% Define Sizes
% 	Nf = length(ws);
%     Nfpeak = length(wpeak);
% 	Ni = size(H,3); No = size(H,2);
% 	NoNi = size(Hpeak,2);
%         
% 	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if ~isempty(AMISET.Ts); % Discrete-time
    wpeak_sc = -i*ln(i*wpeak)/AMISET.Ts;
    % if a disrete-time model is used, then wpeak passed in actually gives
    % the -i*z for z-values corresponding to those omegas. z = e^(i*omega*dt)
else
    wpeak_sc = wpeak;
end

if AMISET.OMA % OMA Data (Hpeak is actually Gyy)
    if strcmp(AMISET.DVA,'D'); % Displacement Data
        % Hpeak = Hpeak;
    elseif strcmp(AMISET.DVA,'V'); % Velocity Data
        % Convert Velocity Spectra to Displacement
        for ii = 1:1:NoNi;
            Hpeak(:,ii) = (Hpeak(:,ii)./(-wpeak_sc.^2));
        end
    elseif strcmp(AMISET.DVA,'A');
        % Convert Acceleration Spectra to Displacement
        for ii = 1:1:NoNi
            Hpeak(:,ii) = (Hpeak(:,ii)./(wpeak_sc.^4));
        end
    else
        error('Unrecognized TF Type');
    end
else
    if strcmp(AMISET.DVA,'D'); % Displacement Data
        % Hpeak = Hpeak;
    elseif strcmp(AMISET.DVA,'V'); % Velocity Data
        % Convert Velocity/Force TF to Displacement
        % Change of variables, Scale factor must be included when integrating
        % Note that this is equiavent to re-deriving the SDOF algorithm for acceleration.
        for ii = 1:1:NoNi;
            Hpeak(:,ii) = (Hpeak(:,ii)./(i*wpeak_sc));
        end
    elseif strcmp(AMISET.DVA,'A');
        % Convert Acceleration/Force TF to Displacement
        % Change of variables, Scale factor must be included when integrating
        % Note that this is equiavent to re-deriving the SDOF algorithm for acceleration.
        for ii = 1:1:NoNi
            Hpeak(:,ii) = (Hpeak(:,ii)./(-wpeak_sc.^2));
        end
    else
        error('Unrecognized TF Type');
    end
end
clear wpeak_sc
    
% Condition Data to avoid Numerical Difficulty %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if isempty(AMISET.Ts);
    % Scale the Transfer function by the average value.
		sf_x = mean(mean(abs(Hpeak)));
		Hpeak = Hpeak/sf_x;
	% Scale w by average value
		sf_w = mean(wpeak);
		wpeak = wpeak/sf_w;
else % don't scale for discrete time
    sf_x = 1; sf_w = 1;
end
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Iterate to improve weighting
	% Initial Weighing and polynomials
%        poly = [];
%        for r = 1:Nd
%            poly = [poly (i*wpeak).^(r-1)];
%        end

    % Form Omega Vectors
    if AMISET.OMA % OMA on
        Omega_Nd  = zeros(Nfpeak,Nd);
        for s = 1:Nd;
            Omega_Nd(:,s) = (i*wpeak).^(2*(s-1));
        end
        Omega_Nn  = zeros(Nfpeak,Nn);
        for s = 1:Nn;
            Omega_Nn(:,s) = (i*wpeak).^(s-1);
        end       
    else % Standard EMA
        Omega = zeros(Nfpeak,max(Nd,Nn));
        for s = 1:max(Nd,Nn);
            Omega(:,s) = (i*wpeak).^(s-1);
        end
        Omega_Nd = Omega(:,[1:Nd]);
        Omega_Nn = Omega(:,[1:Nn]);
        %Omega_mat = zeros(max(Nd,Nn),max(Nd,Nn),Nfpeak);
        %for f = 1:Nfpeak
        %    Omega_mat(:,:,f) = Omega(f,:)'*Omega(f,:);
        %end
        %Omega_B = Omega_mat(1:Nd,1:Nn,:);
    end

%Dlam = 1; its = 0;
%while Dlam > 1e-10
%    its = its+1;
%    if its > max_iter; its = its-1; break; end 
        
    % Find scale factor W(w) for next iteration
%    if its > 1;
%        W = abs(poly*alph).^-1;
%    else
        W = ones(size(wpeak));
        %    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% THIS COULD BE SPED UP BY FORMING C FIRST AND USING KRON TO FORM A AND B FROM IT.

%tic
    % Form A Matrix
    Am = zeros(Nd,Nd);
    for f = 1:Nfpeak
        Am = Am + abs(W(f))^2*(Hpeak(f,:)*(Hpeak(f,:)'))*Omega_Nd(f,:)'*Omega_Nd(f,:);
    end
    Am = real(Am);
        % This operation is very fast
%t_A = toc
%tic
    % Form B Matrix
    Bm = zeros(Nd,Nn*NoNi);
    for s = 1:Nn
        Bsum = zeros(Nd,NoNi);
        for f = 1:Nfpeak
            Bsum = Bsum - real((abs(W(f))^2*(Omega_Nd(f,:)'))*(conj(Hpeak(f,:))*Omega_Nn(f,s)));
        end
        Bm(:,[NoNi*(s-1)+1:No*Ni*s]) = Bsum;
    end
    %Bm = -real(Bm);
        % Considerable effort here.
%t_B = toc
%tic
%    % Form B Matrix
%    Bm = zeros(Nd,Nn*NoNi);
%    for f = 1:Nfpeak
%        Bm = Bm - real(kron(abs(W(f))^2*Omega_B(:,:,f),conj(Hpeak(f,:))));
%    end
%    %Bm = -real(Bm);
%        % This method is considerably slower? why?
%t_B2 = toc

%tic
    % Compute inv(Cprime)
    Cp = zeros(Nn,Nn);
    for f = 1:Nfpeak
        Cp = Cp + abs(W(f))^2*Omega_Nn(f,:)'*Omega_Nn(f,:);
    end
    Cp = real(Cp);
    Cpi = inv(Cp);
        % This computation is very fast

    % Expand Cprime to Cm
    Inoni = spdiags(ones(NoNi,1),0,NoNi,NoNi);
    Cminv = kron(Cpi,Inoni);
        % This is pretty well optimized
%t_C = toc
%tic
    M = Am-Bm*Cminv*(Bm');
%t_M = toc
%t_RST = t_omega + t_A + t_B + t_C + t_M

%   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 	% LS Solution (highest denominator coefficient constrained to one)
%     al_ls = [-M(1:Nd-1,1:Nd-1)\M(1:Nd-1,Nd); 1];
%     if AMISET.OMA % OMA on
%  		den_reg = fliplr(al_ls.');
%         % Add in zero terms in the denominator polynomial.
%             den_exp = zeros(1,2*(length(den_reg)-1)+1);
%             for k = 1:1:length(den_reg);
%                 den_exp(2*(k-1)+1) = den_reg(k);
%             end
%     else % EMA
% 		den_exp = fliplr(al_ls.');		
%     end
%     % lam_fit_ls = roots(den_exp); % done below by RFP_extract_residues
%     alph = al_ls; % uncomment to use this below
%     den = den_exp;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	% Mixed LS-TLS solution
    [EvM,lm] = eig(M);
    lm = diag(lm);
    al_lstls = EvM(:,(abs(lm) == min(abs(lm))));
        if size(al_lstls,2) > 1;
            warning('Two minimum eigenvalues in TLS Solution, using first');
            al_lstls = al_lstls(:,1);
        end
    if AMISET.OMA % OMA on, expand to full polynomial coeff.
 		den_lstls_reg = fliplr(al_lstls.');
            den_lstls_exp = zeros(1,2*(length(den_lstls_reg)-1)+1);
            for k = 1:1:length(den_lstls_reg);
                den_lstls_exp(2*(k-1)+1) = den_lstls_reg(k);
            end
%         % Choose, LS-TLS solution, affects weighting as well
%         alph = al_lstls; % alph = al_ls
%         den = den_lstls_exp;
    else
 		den_lstls_exp = fliplr(al_lstls.');
    end
    % lam_fit_lstls = roots(den_lstls_exp); % done below by RFP_extract_residues.m
    alph = al_lstls;
    den = den_lstls_exp;
%         % Sort Eigenvalues
%         [junk,sind] = sort(abs(lam_fit) + (min(abs(lam_fit))*0.01)*(imag(lam_fit)<0));
%         lam_fit = lam_fit(sind);
        
%    % Monitor Convergence
%        lfi(:,its) = lam_fit;
%        if its > 1;
%            Dlam = max(abs(lam_fit - lfi(:,its-1)));
%        end
        
%end % End of Iteration %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%its

    % Find numerator coefficients, and Residues
	bet = zeros(Nn*NoNi);
    bet = -Cminv*(Bm')*alph;
    bet = reshape(bet,NoNi,Nn).';
    % Use denominator polynomial to extract residues
    [A_conj_mat, ExPoly_mat, lam_sort] = RFP_extract_residues(den,bet([end:-1:1],:));
    
    % Rescale Modal Properties:
    if AMISET.OMA % OMA on, post process accordingly.
        % Find lambda and the corresp. A as well as -lam and B
        % VALID FOR SDOF FIT ONLY!!!
        lam_ind = find(real(lam_sort) < 0 & imag(lam_sort) > 0,1);
            if isempty(lam_ind); % the logic here is not optimized!!
                lam_ind = 1;
                warning('Algorithm to determine which eig to select failed.');
            end
        A_fit = A_conj_mat(lam_ind,:)*sf_w*sf_x;
        nlam_ind = find(abs(lam_sort(lam_ind)+lam_sort)<0.001*min(abs(lam_sort)));
            if isempty(nlam_ind); % the logic here is not optimized!!
                nlam_ind = 2;
                warning('Algorithm to determine which negative eig to select failed.');
            end
        B_fit = A_conj_mat(nlam_ind,:)*sf_w*sf_x;
        lam_fit = lam_sort(lam_ind)*sf_w;
        A_fit = simo2mimo_rs(A_fit,Ni); B_fit = simo2mimo_rs(B_fit,Ni);
        if AMISET.OMARealRes
            %Things work better without the imaginary parts of A/B
            A_fit = real(A_fit); B_fit = real(B_fit);
        end
        varargout{1} = B_fit;
    else
        [A_conj_mat, ExPoly_mat, lam_sort] = RFP_extract_residues(den,bet([end:-1:1],:));
        lam_fit = lam_sort(1:2:end)*sf_w; % now lam_fit no longer contains conjugates
            % Check
            Ch_Aconj = norm(imag(A_conj_mat(1:2:end,:)+A_conj_mat(2:2:end,:)));
            if Ch_Aconj > 1000*eps;
                disp('Warning: Residues are not conjugates!');
            end
        A_fit = A_conj_mat(1:2:end,:)*sf_w*sf_x;
        A_fit = simo2mimo_rs(A_fit,Ni);
    end

mode_params = [abs(lam_fit) -real(lam_fit)./abs(lam_fit) lam_fit];
    
if nargout > 3;
    all_data = [];
    S = whos;
    for k = 1:length(S)
        if ~strcmpi(S(k).name,'all_data')
            eval(['all_data.',S(k).name,' = ',S(k).name,';']);
        end
    end
    varargout{2} = all_data;
end