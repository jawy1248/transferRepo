function [H] = Hdm(H,wvec);
% Function that multiplies a set of FRF data by a vector - for example a
% frequency vector to differentiate.
%   
% [Hdotmult] = Hdm(H,wvec);
% Hdotmult = H(:,m,n).*wvec for all m and n
%
% Matt Allen, 2008
%

[Nf,No,Ni,Nm] = size(H);

wvec = wvec(:); % force column vector

if length(wvec) ~= Nf;
    error('Frequency Vector is not the right size');
end

for m = 1:No
    for n = 1:Ni
        for p = 1:Nm
            H(:,m,n,p) = H(:,m,n,p).*wvec;
        end
    end
end
