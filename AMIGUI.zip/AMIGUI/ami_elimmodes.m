function [] = ami_elimmodes(varargin)
% Manual elimination of modes from AMIMODES database

global AMIDATA AMISET AMIMODES AMIDISPLAY

if ~strcmp(AMIMODES.Status.Isol,'current')
    set(AMIDISPLAY.displaytext, 'String', 'You need to isolate first. Starting isolation now...');
    ami_isolate
end
% Display modes so far:
fprintf(['Current Mode List:\nMode: \t ',AMISET.fl2,'n = \t zeta = \t lambda = \t norm(A) \t group # \n']);
for ii = 1:1:size(AMIMODES.mode_store,1)
   fprintf('%g \t %8.5g \t %8.5g \t %8.5g + i*%8.5g \t %8.5g \t %g\n',ii,AMIMODES.mode_store(ii,1)/AMISET.FreqScale,...
       AMIMODES.mode_store(ii,2),real(AMIMODES.mode_store(ii,3)), imag(AMIMODES.mode_store(ii,3)),...
       norm(mimo2simo_rs(AMIMODES.A_store(ii,:))),AMIMODES.mode_store(ii,4));
end

set(AMIDISPLAY.displaytext, 'String', 'Which modes do you want to discard (ex. [1,5,8])?');
        AMIDISPLAY.hdiscard = uicontrol('Parent',AMIDISPLAY.hmain, ...
        'Style', 'Edit',...
        'Units','normalized', ...
        'Position',[0.83 0.11 0.087 0.060], ...
        'Callback',' ;global AMIDISPLAY; set(AMIDISPLAY.hdiscard,''UserData'',''done''),', ...
        'Tag','Zero');
AMIDISPLAY.hyes = uicontrol('Parent',AMIDISPLAY.hmain, ...
        'Units','normalized', ...
        'Position',[0.925 0.11 0.03 0.060], ...
        'Callback','global AMIDISPLAY; set(AMIDISPLAY.hyes,''UserData'',''done''),', ...
        'String','Go', ...
        'Tag','Zero');
        waitfor(AMIDISPLAY.hyes,'UserData','done');
% Input the modes to be eliminated.
try
    m_elim = get(AMIDISPLAY.hdiscard, 'String');
    m_elim = eval(m_elim);
    m_elim = round(m_elim);
    % Check that a resonable command has been input.
    if min(m_elim) <= 0
        error('Invalid entry for modes to eliminate. Type a number of an expression that can be evaluated.');
    end
    if max(m_elim) > size(AMIMODES.mode_store,1)
        error('Requested eliminating a mode that doesn''t exist.');
    end
catch
    set(AMIDISPLAY.displaytext, 'String', 'Invalid entry for modes to eliminate, Type a number of an expression that can be evaluated. Click "AutoSub" to try again.');
    delete(AMIDISPLAY.hdiscard); delete(AMIDISPLAY.hyes);
    error('Invalid entry for modes to eliminate. Type a number of an expression that can be evaluated.');
end
delete(AMIDISPLAY.hdiscard); delete(AMIDISPLAY.hyes);
m_keep = setdiff([1:size(AMIMODES.mode_store,1)],m_elim);
x = sprintf(['Eliminating modes: ', num2str(m_elim)]);
set(AMIDISPLAY.displaytext, 'String', x);
    % Eliminate modes
    ms_elim = AMIMODES.mode_store(m_elim,:);
    As_elim = AMIMODES.A_store(m_elim,:,:);

    AMIMODES.mode_store = AMIMODES.mode_store(m_keep,:);
    AMIMODES.A_store = AMIMODES.A_store(m_keep,:,:);
    if AMISET.OMA
        AMIMODES.B_store = AMIMODES.B_store(m_keep,:,:);
    end
    AMIMODES.m_bands = AMIMODES.m_bands(m_keep,:);
        % Renumber groups
        g_num = 1;
        for k = 1:max(AMIMODES.mode_store(:,4))
            c_inds = find(AMIMODES.mode_store(:,4) == k);
            % renumber
            AMIMODES.mode_store(c_inds,4) = g_num*ones(length(c_inds),1);
            if ~isempty(c_inds); % increment only if the group was not empty
                g_num = g_num + 1;
            end
        end
    AMIMODES.CurrSub.curr_mode = AMIMODES.CurrSub.curr_mode - length(m_elim);
    AMIMODES.CurrSub.curr_step = max(AMIMODES.mode_store(:,4)) + 1;

    % Model Elimination depends on Band Mode
    if strcmp(AMISET.LM,'off')
%             AMIDATA.X_res_MIR = AMIDATA.X_res_MIR + sum(AMIMODES.X_model(:,:,:,m_elim),4);
        AMIMODES.X_model = AMIMODES.X_model(:,:,:,m_keep);
    else
        % Models not saved
        if isempty(AMISET.Ts) % C-time
            if AMISET.OMA
            AMIMODES.X_model = AMIMODES.X_model - csd_model(AMIMODES.mode_store(:,3),...
                AMIMODES.A_store,AMIMODES.B_store,AMIDATA.ws,AMISET.DVA,'s');
            else
            AMIMODES.X_model = AMIMODES.X_model - ss_model(ms_elim(:,3),...
                As_elim,AMIDATA.ws,AMISET.DVA,'s');
            end
        else % Discrete Time
            AMIMODES.X_model = AMIMODES.X_model - Hdm(ss_model(...
                exp(ms_elim(:,3)*AMISET.Ts),...
                As_elim,AMIDATA.zs,AMISET.DVA,'s'),(i*AMIDATA.zs));
        end
%             AMIDATA.X_res_MIR = AMIDATA.H - ss_model(AMIMODES.mode_store(:,3),...
%                 AMIMODES.A_store,AMIDATA.ws,AMISET.DVA,'s');
    end

    % Refresh Plot
    AMIG_MainPlot([],[],'AfterIsol');
% end
