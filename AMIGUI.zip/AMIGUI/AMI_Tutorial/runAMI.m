%% Tutorial for running AMI with roving hammer test data on free-free beam
% M.S. Allen and R.J. Kuether
% December, 2011

clear all; close all; 

% load('ffbeam_17_Hjp')   % FRF data from SIMO test on free-free beam.
load('ffbeam_20input_MIMO')   % FRF data from MIMO test on free-free beam.

global AMISET       % Initialize options as global variable
AMISET = AMIG_def_opts; % Set default options

% Can change specific options manually, see AMIG_def_opts.m for details
AMISET.FRF_RF = 10; %this sets minimal reduction factor, used to prompt higher order fit
AMISET.AutoSubLevel = 0.5;
AMISET.DVA = 'A'; % this tells AMI that the data is acceleration/force FRFs
AMISET.LM = 'on'; % this makes the file smaller if you save the AMI fit.

ws = 2*pi*fs;     % Convert from Hz to rad/s 
ami(H,ws,AMISET)  % where H is the Nf by No FRF matrix and ws is the frequency vector in radians per second.

% Modal Data
global AMIMODES % brings AMI�s variables into the workspace
% wn = AMIMODES.mode_store(:,1)       % Natural frequencies, rad/s
% zt = AMIMODES.mode_store(:,2)       % Damping ratios
% res = -2*real(diag(conj(AMIMODES.mode_store(:,3)))*AMIMODES.A_store(:,:,1)); % Residue vector
% 
% % Plot Mode Shapes for FF Beam with 17 Points:
% if size(H,2)==17;
%     figure(4)
%     plot([1:17],res,'.-'); grid on;
%     title('Mode Shapes');
%     xlabel('Point # along Beam'); ylabel('Displacement');
% end