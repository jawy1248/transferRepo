function [] = ami_save(varargin);
% Save Data so one can restart AMI.
%

global AMIMODES AMIDISPLAY AMIDATA AMISET

[filename, pathname] = uiputfile('AMI_Ident_Results.mat', ...
    'Save AMI Restart File');

save([pathname,filename],'AMIMODES','AMIDISPLAY','AMIDATA','AMISET');

disp('Use ami_restart.m to start ami again with this data.');