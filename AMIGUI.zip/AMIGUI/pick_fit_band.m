function [] = pick_fit_band;

global AMIMODES AMIDATA

pfb_done = 'n';
while strcmp(pfb_done,'n');
    [fit_limits,hp] = ginput(2);
    fit_limits = sort(fit_limits);
    AMIMODES.SDOFSub.lbub(1) = min(find(AMIDATA.wsplot > fit_limits(1)));
    AMIMODES.SDOFSub.lbub(2) = max(find(AMIDATA.wsplot < fit_limits(2)));
    if AMIMODES.SDOFSub.lbub(2) - AMIMODES.SDOFSub.lbub(1) < 2;
        pfb_done = 'n';
        disp('Insufficient Number of Points in Fit Band, Try again');
    else
        pfb_done = 'y';
    end
end

