function [] = pick_zero_band;

global AMIDISPLAY

[zero_limits,hp] = ginput(2);
AMIDISPLAY.zero_limits = sort(zero_limits);
end

