function [] = ami_restart(varargin);
% Restart AMI
%
% ami_restart - interactively choose restart *.mat file
%
% ami_restart('restart_file.mat'); - restart using the specified file.
%
% MS Allen May, 2008

if nargin > 0;
    file_path_and_name = varargin{1};
else
    [filename,pathname] = uigetfile('*.mat', 'Locate the Restart File');
    file_path_and_name = [pathname,filename];
end

load(file_path_and_name,'AMIMODES','AMISET','AMIDATA','AMIDISPLAY');

ami_setup_display

global AMIMODES AMIDISPLAY AMIDATA AMISET

% Show Subtraction Residual after last step
AMIDISPLAY.title_str = 'Composite of Residual and Original Data';
AMIG_MainPlot([],[],'AfterIsol');

