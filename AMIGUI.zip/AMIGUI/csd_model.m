function [G_fit] = csd_model(lam_fit,A_fit,B_fit,ws,FRF_type,varargin)
% [G_fit] = csd_model(lam,A_fit,B_fit,ws,FRF_type,sum_flag)
%
% Function which creates an FRF model of the modes described by 'lam',
% 'A_fit' and 'B_fit'.  Optimized for fast processing.
%
% Theory: Brincker, R., Zhang, L., and Andersen, P., �Modal Identification 
% from Ambient Response Using Frequency Domain Decomposition,� IMAC 18, 
% San Antonio, TX, February 7-10, 2000.
%
% 'lam_fit' is a column of eigenvalues, excluding complex conjugates
% 'A_fit' is an array of residues of size [N,No,Ni] where N is the number
%       of modes, No the number of outputs and Ni the number of inputs.
% 'B_fit' are the additional residues for the CSD model (see ref).
% 'ws' is the frequency vector for the FRF
% 'FRF_type' is a flag indicating the type of FRF
%       1 - Displacement/Force
%       2 - Acceleration/Force
%       3 - Velocity/Force
%
% [G_fit] = ss_model(lam,A_fit,ws,FRF_type,sum_flag)
%   Optional paramter, sum_flag tells whether to return the sum of modal FRFs, 
%   or individual FRFs.  sum_flag = 
%       's' - Returns the sum of modal FRFs, (G_fit is up to three dimensional)
%       'i' - Returns individual modal FRFs, (G_fit is four dimensional)
%           so that:  G_fit(:,:,:,r) is the rth modal FRF.
%
% Created based on ss_model by Matt Allen, 2010-06-08
%

[a,b] = size(ws);
    if b>a;
        ws = ws.';
        [a,b] = size(ws);
    end % Assure that ws is a column
    if b>1; warning('ws was not a column vector'); end

if ~isempty(varargin)
    sum_flag = lower(varargin{1});
else
    sum_flag = 's'; % Default is to return the sum of modal FRFs
end

if nargin > 6;
    Pex = varargin{2};
else
    Pex = [];
end

[Na,No,Ni] = size(A_fit);
N = length(lam_fit);
	if Na ~= N
        warning('Sizes of A_fit and lam_fit are not the same, minimum used');
        N = min([N,Na]);
    end

% Allow for FRF_type to be a character or number
if ischar(FRF_type);
    if strcmp(upper(FRF_type),'D'); FRF_type = 1;
    elseif strcmp(upper(FRF_type),'A'); FRF_type = 2;
    elseif strcmp(upper(FRF_type),'V'); FRF_type = 3;
    else
        error(['Unrecognized FRF type: ',num2str(FRF_type)]);
    end
end

% if ~isempty(lam_fit) && ~isempty(A_fit); % find out of band terms only.
    A_fit = mimo2simo_rs(A_fit); % Reshape for easy processing
    B_fit = mimo2simo_rs(B_fit); % Reshape for easy processing
    if sum_flag == 'i' % pre-allocate for G_fit if using individual models.
        G_fit = zeros(length(ws),No*Ni,N);
    end
    for k = 1:N
        % Form model for one mode.
        if FRF_type == 1; % Displacement
            G_mode = (i*ws-lam_fit(k)).^-1*A_fit(k,:) + ...
                (i*ws-conj(lam_fit(k))).^-1*conj(A_fit(k,:)) + ...
                (i*ws+lam_fit(k)).^-1*B_fit(k,:) + ...
                (i*ws+conj(lam_fit(k))).^-1*conj(B_fit(k,:));
        elseif FRF_type == 2; % Acceleration Spectra
            G_mode = ((ws.^4).*(i*ws-lam_fit(k)).^-1)*A_fit(k,:) + ...
                ((ws.^4).*(i*ws-conj(lam_fit(k))).^-1)*conj(A_fit(k,:)) + ...
                ((ws.^4).*(i*ws+lam_fit(k)).^-1)*B_fit(k,:) + ...
                ((ws.^4).*(i*ws+conj(lam_fit(k))).^-1)*conj(B_fit(k,:));
        elseif FRF_type == 3; % Velocity Transfer Function
            G_mode = ((-ws.^2).*(i*ws-lam_fit(k)).^-1)*A_fit(k,:) + ...
                ((-ws.^2).*(i*ws-conj(lam_fit(k))).^-1)*conj(A_fit(k,:)) + ...
                ((-ws.^2).*(i*ws+lam_fit(k)).^-1)*B_fit(k,:) + ...
                ((-ws.^2).*(i*ws+conj(lam_fit(k))).^-1)*conj(B_fit(k,:));
        end
        % Put the model to G_fit
        if sum_flag == 's';
            if k == 1;
                G_fit = G_mode;
            else
                G_fit = G_fit+G_mode;
            end
        else % Storing individual models for each mode
            G_fit(:,:,k) = G_mode;
        end
    end

%     
% else
%     G_fit = zeros(length(ws),No*Ni);
% end

% % Find residual terms
% if ~isempty(Pex);
%     Pex = mimo2simo_rs(Pex);
%     if size(Pex,1) ~= 2
%         Pex(2,:,:) = 0; % No UR included
%     end
%     P_fit = zeros(length(ws),No*Ni);
%     if FRF_type == 1; % Displacement
%         P_fit = P_fit + (i*ws).^-2*Pex(1,:) + Pex(2*ones(size(ws)),:);
%     elseif FRF_type == 2; % Acceleration Transfer Function
%         P_fit = P_fit + Pex(ones(size(ws)),:) + (i*ws).^2*Pex(2,:);
%     elseif FRF_type == 3; % Velocity Transfer Function
%         P_fit = P_fit + (i*ws).^-1*Pex(1,:) + (i*ws)*Pex(2,:);
%     else
%         error('Unrecognized FRF type'); FRF_type
%     end
%     
%     G_fit = G_fit + P_fit;
%     
% end

% Reshape
G_fit = simo2mimo_rs(G_fit,Ni);

