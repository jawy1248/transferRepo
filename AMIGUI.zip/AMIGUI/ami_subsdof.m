function [] = ami_subsdof(ManOrAutoOrInband);
% Subtraction step in AMI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% NOTE: Make this the manual sub function also:  ami_subsdof('man');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global AMIDATA AMIDISPLAY AMISET AMIMODES

AMIMODES.SDOFSub.unreas_flag = 0; % A 1 is obtained later if unreasonable results are obtained.

% Identify peak data for the curve fit
    if strcmp(ManOrAutoOrInband,'man');
        % Update Display
        AMIDISPLAY.title_str = 'Composite of Residual and Original Data';
        if strcmp(AMIMODES.Status.Isol,'current');
            AMIG_MainPlot([],[],'AfterIsol');
        else
            % Don't do anything - plot should be current.
        end
        
        % Add button to start choosing fit band limits once you're ready.
        set(AMIDISPLAY.displaytext, 'String', 'Click on the ''BandSel'' button when you are ready to select the fitting band, then click on the plot at the upper and lower limits you want to fit.');

        AMIDISPLAY.hbandsel = uicontrol('Parent',AMIDISPLAY.hmain, ...
            'Units','normalized', ...
            'Position',[.86 0.0263 0.066 0.056], ...
            'Callback','pick_fit_band; global AMIDISPLAY; set(AMIDISPLAY.hbandsel,''UserData'',''done''),', ...
            'String','BandSel', ...
            'Tag','Zero');
        waitfor(AMIDISPLAY.hbandsel,'UserData','done');
        delete(AMIDISPLAY.hbandsel);
        AMIDISPLAY.hbandsel = [];
        lowbnd = AMIMODES.SDOFSub.lbub(1); upbnd = AMIMODES.SDOFSub.lbub(2);
    else
        [lowbnd,upbnd,warn_flags,wp_indx] = ami_findpeak(AMIDATA.Xc,AMIDATA.ws,...
            AMIMODES.CurrSub.NumPoints,AMISET.NoisePoints,[]);AMIMODES
        AMIMODES.SDOFSub.lbub = [lowbnd,upbnd];
    end
    if strcmp(ManOrAutoOrInband,'inband');
        % Update Display
        AMIDISPLAY.title_str = 'Composite of Residual and Original Data';
        if strcmp(AMIMODES.Status.Isol,'current');
            AMIG_MainPlot([],[],'AfterIsol');
        else
            % Don't do anything - plot should be current.
        end
        
        % Add button to start choosing fit band limits once you're ready.
        set(AMIDISPLAY.displaytext, 'String', 'Input the frequency range (ex. 600,675) you would like to search for modes in.');

        AMIDISPLAY.hinband = uicontrol('Parent',AMIDISPLAY.hmain, ...
            'Style', 'Edit',...
            'Units','normalized', ...
            'Position',[0.878 0.1 0.03 0.075], ...
            'Callback',' ;global AMIDISPLAY; set(AMIDISPLAY.hinband,''UserData'',''done''),', ...
            'Tag','Zero');
        waitfor(AMIDISPLAY.hinband,'UserData','done');
        delete(AMIDISPLAY.hinband);
        Freq_range = get(AMIDISPLAY.hinband, 'String');
        Freq_range = str2num(Freq_range);
    end
    % Create Arrays of peak data
    Hpeak = AMIDATA.X([lowbnd:upbnd],:,:);
    if ~isempty(AMISET.Ts); % Fit Discrete-time model
        wpeak = AMIDATA.zs(lowbnd:upbnd);
        Hpeak = Hdm(Hpeak,(i*wpeak).^-1);
    else
        wpeak = AMIDATA.ws(lowbnd:upbnd);
    end
try
    if AMISET.SDOFAlg == 1; % Use cf_etrue_simo algorithm - no numerator terms allowed.
        set(AMIDISPLAY.displaytext,'String', 'Using CF_etrue algorithm');
        [mode_params,A_fit_Rf] = cf_msa(Hpeak,wpeak,'sub');

    elseif AMISET.SDOFAlg == 0; % Use RFP_MATTtls_ami or it's variants
        if AMISET.OMA
            [mode_params,A_fit_Rf,B_fit_Rf] = rfpm(Hpeak,wpeak,1,'sub');
        else
            [mode_params,A_fit_Rf] = rfpm(Hpeak,wpeak,1,'sub');
        end
	elseif AMISET.SDOFAlg == 2; % Use RFP_MRealtls_ami or it's variants
         [mode_params,A_fit_Rf] = rfpm_real(Hpeak,wpeak,1,'sub');
%             AMIMODES.SDOFSub.mode_params = mode_params;
%          % Process Residues (A_fit) to determine the number of modes active:
%             [AMIMODES.SDOFSub.A_fit,AMIMODES.SDOFSub.SR] = ami_resreduce(A_fit_Rf);
%                 if length(AMIMODES.SDOFSub.SR) == 1; AMIMODES.SDOFSub.SR(2,1) = 0; end
%             AMIMODES.SDOFSub.X_fit = ss_model(mode_params(1,3),AMIMODES.SDOFSub.A_fit,...
%                 AMIDATA.ws,AMISET.DVA,'s');
%             AMIMODES.SDOFSub.X_fit_Rf = ss_model(mode_params(1,3),A_fit_Rf,...
%                 AMIDATA.ws,AMISET.DVA,'s');
    end

    % Process Residues (A_fit) to determine the number of modes active:
    if AMISET.OMA
        [AMIMODES.SDOFSub.B_fit,AMIMODES.SDOFSub.SR_B] = ami_resreduce(B_fit_Rf,mode_params);
    end
    [AMIMODES.SDOFSub.A_fit,AMIMODES.SDOFSub.SR] = ami_resreduce(A_fit_Rf,mode_params);
    
        if length(AMIMODES.SDOFSub.SR) == 1; AMIMODES.SDOFSub.SR(2,1) = 0; end
    
	if isempty(AMISET.Ts) % C-time model
        if AMISET.OMA
            AMIMODES.SDOFSub.X_fit = csd_model(mode_params(1,3),AMIMODES.SDOFSub.A_fit,...
                AMIMODES.SDOFSub.B_fit,AMIDATA.ws,AMISET.DVA,'s');
            AMIMODES.SDOFSub.X_fit_Rf = csd_model(mode_params(1,3),A_fit_Rf,B_fit_Rf,...
                AMIDATA.ws,AMISET.DVA,'s');
        else
            AMIMODES.SDOFSub.X_fit = ss_model(mode_params(1,3),AMIMODES.SDOFSub.A_fit,...
                AMIDATA.ws,AMISET.DVA,'s');
            AMIMODES.SDOFSub.X_fit_Rf = ss_model(mode_params(1,3),A_fit_Rf,...
                AMIDATA.ws,AMISET.DVA,'s');
        end
    else % Discrete-time Model
        lamz = mode_params(1,3);
        lamc = ln(mode_params(1,3))/AMISET.Ts;
        mode_params = [abs(lamc), -real(lamc)/abs(lamc), lamc];

        AMIMODES.SDOFSub.X_fit = ss_model(lamz,AMIMODES.SDOFSub.A_fit,...
            AMIDATA.zs,AMISET.DVA,'s');
        AMIMODES.SDOFSub.X_fit = Hdm(AMIMODES.SDOFSub.X_fit,(i*AMIDATA.zs));
        AMIMODES.SDOFSub.X_fit_Rf = ss_model(lamz,A_fit_Rf,...
            AMIDATA.zs,AMISET.DVA,'s');
        AMIMODES.SDOFSub.X_fit_Rf = Hdm(AMIMODES.SDOFSub.X_fit_Rf,(i*AMIDATA.zs));
    end 
    AMIMODES.SDOFSub.mode_params = mode_params;
%     save(['cfdebug_',num2str(AMIMODES.CurrSub.curr_mode),'.mat']);
    
catch
    disp(['Error Curve Fitting in Band: ',num2str(min(wpeak)),' to ',num2str(max(wpeak))]);
    error('Aborted due to error curve fitting.  Try skipping that frequency range??');
%     % if a curve fitting error occurs - print the error and use zeros for
%     % the identified modal parameters:
%     lasterr
%     mode_params = [0,0,0];
%         AMIMODES.SDOFSub.mode_params = mode_params;
%     AMIMODES.SDOFSub.A_fit = zeros(size(AMIDATA.X(1,:,:)));
%     AMIMODES.SDOFSub.SR = [1,0];
%     AMIMODES.SDOFSub.X_fit = zeros(size(AMIDATA.X));
%     AMIMODES.SDOFSub.X_fit_Rf = zeros(size(AMIDATA.X));
%     AMIMODES.SDOFSub.lbub = [1; 2];
end

% Find the closest of the already identified modes for logic checks later
if AMIMODES.CurrSub.curr_step > 1;
    closest_mode = find(abs(AMIMODES.mode_store(:,1)-mode_params(1)) == ...
        min(abs(AMIMODES.mode_store(:,1)-mode_params(1))));
    clm_params = AMIMODES.mode_store(closest_mode,:);
end

% Check to see how much this mode has reduced the data near its resonance.
    lb = AMIMODES.SDOFSub.lbub(1); ub = AMIMODES.SDOFSub.lbub(2);
        fit_band = [lb:ub];
    AMIMODES.SDOFSub.fit_band = fit_band;
    db = round((ub-lb)/2); lb = lb - db; ub = ub + db;
        if lb < 1; lb = 1; end
        if ub > length(AMIDATA.Xc); ub = length(AMIDATA.Xc); end
    AMIMODES.SDOFSub.frf_redfact = max(AMIDATA.Xc(lb:ub,:)) / ...
        max(comp_FRF(abs(AMIDATA.X(lb:ub,:,:)-AMIMODES.SDOFSub.X_fit(lb:ub,:,:))));
    AMIMODES.SDOFSub.frf_rf_full = max(AMIDATA.Xc(lb:ub,:)) / ...
        max(comp_FRF(abs(AMIDATA.X(lb:ub,:,:)-AMIMODES.SDOFSub.X_fit_Rf(lb:ub,:,:))));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% If Statements which Check to see if curve fit results are reasonable
    
    % Check for overlapping fitting bands and advise the user
    overlap_msg = [];
    if strcmp(AMISET.BandMode,'fixed') & isfield(AMIMODES,'m_bands')
        for k = 1:size(AMIMODES.m_bands,1);
            if length(intersect([lowbnd:upbnd],[AMIMODES.m_bands(k,1):AMIMODES.m_bands(k,2)])) > 1;
                overlap_msg = ['Frequency band selected to fit this mode overlaps the band for a previous mode.\n',...
                    'This may result in a failure to converge during mode isolation.\n',...
                    'Try using a narrower frequency band for this mode, or use a MDOF fit \n',...
                    'to identify modes whose half power bandwidths overlap significantly.\n',...
                    'Current Overlaps with Mode at:  ', AMISET.fl2, 'n = ',...
                    num2str(AMIMODES.mode_store(k,1)/AMISET.FreqScale),' \n'];
            end
        end
    end

if mode_params(1) < 0 || mode_params(1) > max(AMIDATA.ws) || mode_params(2) < 0 || ...
        mode_params(2) >= 1 || sum(isnan(mode_params)) > 0 || ~isempty(overlap_msg);

    AMIMODES.SDOFSub.unreas_flag = 1;

    % Warn user of Unreasonable Results
    fit_warnings = ['*********************Fit Warnings:**********************\n'];
    if mode_params(1) < min(AMIDATA.ws) | mode_params(1) > max(AMIDATA.ws)
        fit_warnings = [fit_warnings, 'Natural Frequency outside of frequency band\n'];
    end
    if mode_params(2) < 0
        fit_warnings = [fit_warnings, 'Unstable Mode\n'];
    end
    if mode_params(2) >= 1
        fit_warnings = [fit_warnings, 'Overdamped Mode\n'];
    end
    if sum(isnan(mode_params)) > 0
        fit_warnings = [fit_warnings, 'Fit Algorithm Returned NAN\n'];
    end
    if ~isempty(overlap_msg)
        fit_warnings = [fit_warnings, overlap_msg];
    end
    fit_warnings = [fit_warnings, '********************************************************\n'];
    AMIMODES.SDOFSub.fit_warnings = fit_warnings;

end % End check of results%%%%%%%%%%%%%%%

