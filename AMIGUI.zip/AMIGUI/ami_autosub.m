function [] = ami_autosub(ManOrAutoOrInband)
% Automatic subtraction stage for AMI

global AMIDATA AMIDISPLAY AMISET AMIMODES

% ######################## Subtraction Stage ###############################

% Working Data for Subtraction
if ~isfield(AMIMODES,'mode_store');
    AMIDATA.X = AMIDATA.H;
else
    if strcmp(AMISET.LM,'off')
        AMIDATA.X = AMIDATA.H - sum(AMIMODES.X_model,4);
    else
        if isempty(AMISET.Ts) % C-time model 
            AMIDATA.X = AMIDATA.H - ss_model(AMIMODES.mode_store(:,3),...
                AMIMODES.A_store,AMIDATA.ws,AMISET.DVA,'s');
        else % Discrete Time
            Xtemp = ss_model(exp(AMIMODES.mode_store(:,3)*AMISET.Ts),...
                AMIMODES.A_store,AMIDATA.zs,AMISET.DVA,'s');
            Xtemp = Hdm(Xtemp,(i*AMIDATA.zs));
            AMIDATA.X = AMIDATA.H - Xtemp; clear Xtemp
        end
    end
end
AMIDATA.Xc = comp_FRF(AMIDATA.X);

% Mode Identification & Subtraction Stage
set(AMIDISPLAY.displaytext, 'String','Mode Identification & Subtraction Stage');

% The algorithm runs automatically until the FRF is reduced to
% the noise parameter, then it begins prompting the user.
cont_sub = 'y'; AMIMODES.zero_pts = []; user_zero_band = [];
while cont_sub == 'y';
    
    AMIMODES.CurrSub.NumPoints = AMISET.NumPoints; % Set this for all subtraction steps
    
    if strcmp(ManOrAutoOrInband,'man');
        ami_subsdof('man');
        % Manual mode prompts the user to select a band around each peak.
    elseif strcmp(ManOrAutoOrInband,'auto');
        ami_subsdof('auto');
        % Automatic mode always fits the highest peak, then progresses the
        % the next peak.  The only way to skip data is to zero it.
    else 
        ami_subsdof('inband');
    end
    
    % PLOTTING:  Transfer Function versus fit
    if AMISET.FigDisp == 1;
        
        % Send to plotting function
        AMIDISPLAY.title_str = ['Semi-Auto Subtraction Mode # ', num2str(AMIMODES.CurrSub.curr_mode), ...
            ', Freq. = ', num2str(AMIMODES.SDOFSub.mode_params(1)/AMISET.FreqScale,4.2), ...
            ' ',AMISET.flabel, ' ,  \zeta = ', num2str(AMIMODES.SDOFSub.mode_params(2),3)];
        AMIG_MainPlot('SDOFSub',AMIMODES.SDOFSub.fit_band,'sub');
        drawnow
        
        % Save Data for the figure
        if strcmp(AMISET.SaveSub,'y');
            Xfc = comp_FRF(X_fit); XfcRf = comp_FRF(X_fit_Rf);  XwmXfc = comp_FRF(AMIDATA.X-X_fit);
                Xwcn = mfrfcond(AMIDATA.X,A_fit); Xfcn = mfrfcond(X_fit,A_fit);
            XDOF = 'SDOF';
            eval(['save ',AMISET.SaveSubName,'_',num2str(n_sub_figs),'.mat AMISET ',...
                    'mode_params A_fit mode_store A_store XDOF Xwcn Xfcn '...
                    'fit_band AMIDATA Xfc XfcRf XwmXfc']);
            n_sub_figs = n_sub_figs + 1;
        end
    end
    
    % Prompt User and Look for Additional Modes--Interactuve mode
     if max(AMIDATA.Xc) < AMISET.AutoSubLevel*max(AMIDATA.Hc) | AMIMODES.SDOFSub.unreas_flag | AMIMODES.SDOFSub.SR(2) > ...
             AMISET.Smin | AMIMODES.SDOFSub.frf_redfact < AMISET.FRF_RF
        fprintf(['Good Modes So Far:\nMode: \t ',AMISET.fl2,'n = \t zeta = \t lambda = \n']);
		for ii = 1:1:(AMIMODES.CurrSub.curr_mode-1)
            fprintf('%g \t %8.5g \t %8.5g \t %8.5g + i*%8.5g \n',ii,AMIMODES.mode_store(ii,1)/AMISET.FreqScale,...
                AMIMODES.mode_store(ii,2),real(AMIMODES.mode_store(ii,3)), imag(AMIMODES.mode_store(ii,3)));
		end
        fprintf('Current Mode:\n');
        fprintf('%g \t %8.5g \t %8.5g \t %8.5g + i*%8.5g \n',AMIMODES.CurrSub.curr_mode,...
            AMIMODES.SDOFSub.mode_params(1)/AMISET.FreqScale, AMIMODES.SDOFSub.mode_params(2),...
            real(AMIMODES.SDOFSub.mode_params(3)), imag(AMIMODES.SDOFSub.mode_params(3)));
        
        if AMIMODES.SDOFSub.unreas_flag; fprintf(AMIMODES.SDOFSub.fit_warnings); end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Give the user the option of fitting 2 or more modes here if the mode
        %  has not reduced the data much near it's natural frequency,
        if (AMIMODES.SDOFSub.frf_redfact < AMISET.FRF_RF || AMIMODES.SDOFSub.SR(2) > AMISET.Smin) && ...
                ~AMISET.OMA; % Hybrid algorithm disabled for OMA data - don't have an MDOF fitter yet.
            set(AMIDISPLAY.displaytext,'String','Current mode has not reduced the FRF Substantially,or a second singular value may be significant.');
            disp(['     RFtotal = ',num2str(max(AMIDATA.Xc)/max(AMIDATA.Hc))...
              ', RF_SDOF = ', num2str(AMIMODES.SDOFSub.frf_redfact),' RF_SDOF_full = ',num2str(AMIMODES.SDOFSub.frf_rf_full)])
            disp('     Singular Value Ratios Sj/S1');
            disp(['     ',num2str(AMIMODES.SDOFSub.SR.')]);
            
            % Manual, Automatic or In Band mode
            if strcmp(AMISET.AutoMode,'manual');
                set(AMIDISPLAY.displaytext, 'String','Do you want to try a higher order fit?');
                AMIDISPLAY.hyes = uicontrol('Parent',AMIDISPLAY.hmain, ...
                'Units','normalized', ...
                'Position',[0.85 0.1 0.03 0.075], ...
                'Callback','global AMIDATA; AMIDATA.tryHighOrd = ''y''; global AMIDISPLAY; set(AMIDISPLAY.hyes,''UserData'',''done''),', ...
                'String','Yes', ...
                'Tag','Zero');
                AMIDISPLAY.hno = uicontrol('Parent',AMIDISPLAY.hmain, ...
                'Units','normalized', ...
                'Position',[0.91 0.1 0.03 0.075], ...
                'Callback','global AMIDATA; AMIDATA.tryHighOrd = ''n''; global AMIDISPLAY; set(AMIDISPLAY.hyes,''UserData'',''done''),', ...
                'String','No', ...
                'Tag','Zero');
            waitfor(AMIDISPLAY.hyes,'UserData','done');
            try_higher_order = AMIDATA.tryHighOrd;
            else
            end
            delete(AMIDISPLAY.hyes);
            delete(AMIDISPLAY.hno);
            
            switch try_higher_order;
            % TRY a 2nd order fit if a SDOF fit fails to reduce the data to noise    
            case 'y'; keep_mode = 'n'; % keep_mode = 'n' throws out the SDOF fit
                set(AMIDISPLAY.displaytext, 'String', 'Order to try (2 or 3 typical)?');
                    AMIDISPLAY.horder = uicontrol('Parent',AMIDISPLAY.hmain, ...
                    'Style', 'Edit',...
                    'Units','normalized', ...
                    'Position',[0.878 0.1 0.03 0.075], ...
                    'Callback',' ;global AMIDISPLAY; set(AMIDISPLAY.horder,''UserData'',''done''),', ...
                    'Tag','Zero');
                    waitfor(AMIDISPLAY.horder,'UserData','done');
                if strcmp(AMISET.AutoMode,'manual');
                    try
                        N_dof = get(AMIDISPLAY.horder, 'String');
                        N_dof = str2num(N_dof);
                        N_dof = round(N_dof);
                        if N_dof <= 0; error('Number of Modes must be Postive'); end
                    catch
                        set(AMIDISPLAY.displaytext, 'String', 'Invalid Entry, Type a Number.  Hit "AutoSub" to start again.');
                        error('Invalid Entry, Type a Number.  Hit "AutoSub" to start again.');
                    end
                else
                    N_dof = sum(AMIMODES.SDOFSub.SR > AMISET.Smin);
                end
                delete(AMIDISPLAY.horder);
                if strcmp(AMISET.AutoMode,'inband');
                    set(AMIDISPLAY.displaytext, 'String', 'What frequency range do you want to look in?');
                    % This isn't working yet - MSA added the end below to
                    % fix this not running.
                end
                AMIMODES.MDOFSub.N_dof = N_dof;
                    
                    AMIMODES.MDOFSub.lbub = AMIMODES.SDOFSub.lbub;
                    lowbnd = AMIMODES.MDOFSub.lbub(1); upbnd = AMIMODES.MDOFSub.lbub(2);
                    
                    % Create Arrays of peak data
                    Hpeak = AMIDATA.X([lowbnd:upbnd],:,:);
                    wpeak = AMIDATA.ws(lowbnd:upbnd);
                    if ~isempty(AMISET.Ts); % Fit Discrete-time model
                        wpeak = AMIDATA.zs(lowbnd:upbnd);
                        Hpeak = Hdm(Hpeak,(i*wpeak).^-1); % i*wpeak = z
                    end                
                [AMIMODES.MDOFSub.mode_params,AMIMODES.MDOFSub.A_fit] = ...
                    ssi_fd_amig(Hpeak,wpeak,N_dof,'sub');
                    if ~isempty(AMISET.Ts); % Discrete-time model
                        lamz = AMIMODES.MDOFSub.mode_params(:,3);
                        lamc = ln(lamz)/AMISET.Ts;
                        AMIMODES.MDOFSub.mode_params = [abs(lamc), -real(lamc)./abs(lamc), lamc];

                    	AMIMODES.MDOFSub.X_fit = ss_model(lamz,...
                            AMIMODES.MDOFSub.A_fit,AMIDATA.zs,AMISET.DVA,'i');
                        AMIMODES.MDOFSub.X_fit = Hdm(AMIMODES.MDOFSub.X_fit,(i*AMIDATA.zs));
                    else
                    	AMIMODES.MDOFSub.X_fit = ss_model(AMIMODES.MDOFSub.mode_params(:,3),...
                            AMIMODES.MDOFSub.A_fit,AMIDATA.ws,AMISET.DVA,'i');
                    end
                
                % Identify fit band
                AMIMODES.MDOFSub.fit_band = [AMIMODES.MDOFSub.lbub(1):AMIMODES.MDOFSub.lbub(2)];
                
                N_fit = size(AMIMODES.MDOFSub.mode_params,1);
                % Display MDOF Parameters: #######
                fprintf(['MDOF Mode Parameters, ',num2str(N_fit),' DOF:\n']);
                for ii = 1:1:N_fit
                    fprintf('%g \t %8.5g \t %8.5g \t %8.5g + i*%8.5g \n',ii,...
                        AMIMODES.MDOFSub.mode_params(ii,1)/AMISET.FreqScale,...
                        AMIMODES.MDOFSub.mode_params(ii,2),real(AMIMODES.MDOFSub.mode_params(ii,3)),...
                        imag(AMIMODES.MDOFSub.mode_params(ii,3)));
		        end
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % PLOTTING:  Transfer Function versus fit
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                if AMISET.FigDisp == 1;
                    
                    % Send to plotting function
                    AMIDISPLAY.title_str = ['Semi-Auto Subtraction Modes # ', num2str(AMIMODES.CurrSub.curr_mode+[0:(N_dof-1)]), ', From MDOF'];
                    AMIG_MainPlot('MDOFSub', AMIMODES.MDOFSub.fit_band,'sub');
                    
%                     % Save Data for offline plotting
%                     if strcmp(AMISET.SaveSub,'y');
%                         Xfc = comp_FRF(sum(X_fit_rfp,4)); XwmXfc = comp_FRF(AMIDATA.X-sum(X_fit_rfp,4));
%                         for k = 1:size(X_fit_rfp,4)
%                             Xwcn(:,k) = mfrfcond((AMIDATA.X - sum(X_fit_rfp(:,:,:,[1:k-1,k+2:N_fit]),4)),A_fit_rfp(k,:,:));
%                             Xfcn(:,k) = mfrfcond(X_fit_rfp(:,:,:,k),A_fit_rfp(k,:,:));
%                         end
%                         XDOF = 'MDOF';
%                         eval(['save ',AMISET.SaveSubName,'_',num2str(n_sub_figs),'.mat AMIMODES.CurrSub.curr_mode curr_step ',...
%                                 'mode_params A_fit AMIMODES.MDOFSub.mode_params A_fit_rfp mode_store A_store w AMISET.FreqScale '...
%                                 'AMISET CF_set XDOF Xwcn Xfcn fit_band AMIDATA.Xc Xfc XfcRf XwmXfc']);
%                         n_sub_figs = n_sub_figs + 1;
%                     end
                end
                
                % Check to see if 2-DOF fit has reduced the data more than SDOF fit
                    lbm = AMIMODES.MDOFSub.lbub(1); ubm = AMIMODES.MDOFSub.lbub(1);
                    db2 = round((ubm-lbm)/2); lbm = lbm - db2; ubm = ubm + db2;
                        if lbm < 1; lbm = 1; end
                        if ubm > length(AMIDATA.Xc); ubm = length(AMIDATA.Xc); end
                    AMIMODES.MDOFSub.frf_redfact = max(AMIDATA.Xc(lbm:ubm,:))/...
                        max(comp_FRF(abs(AMIDATA.X(lbm:ubm,:,:)-sum(AMIMODES.MDOFSub.X_fit(lbm:ubm,:,:,:),4))));
                    
                    if strcmp(AMISET.AutoMode,'manual');
                        set(AMIDISPLAY.displaytext, 'String', 'Keep these modes?');
                        AMIDISPLAY.hyes = uicontrol('Parent',AMIDISPLAY.hmain, ...
                        'Units','normalized', ...
                        'Position',[0.84 0.1 0.03 0.075], ...
                        'Callback','global AMIDATA; AMIDATA.keepmodes = ''y''; global AMIDISPLAY; set(AMIDISPLAY.hyes,''UserData'',''done''),', ...
                        'String','Yes', ...
                        'Tag','Zero');
                        AMIDISPLAY.hno = uicontrol('Parent',AMIDISPLAY.hmain, ...
                        'Units','normalized', ...
                        'Position',[0.92 0.1 0.03 0.075], ...
                        'Callback','global AMIDATA; AMIDATA.keepmodes = ''n''; global AMIDISPLAY; set(AMIDISPLAY.hyes,''UserData'',''done''),', ...
                        'String','No', ...
                        'Tag','Zero');
                    waitfor(AMIDISPLAY.hyes,'UserData','done');
                    keep_mode = AMIDATA.keepmodes;
                    delete(AMIDISPLAY.hyes);
                    delete(AMIDISPLAY.hno);
                    fprintf(['(RFtotal = ',num2str(max(AMIDATA.Xc)/max(AMIDATA.Hc))...
                            ', RF_MDOF = ', num2str(AMIMODES.MDOFSub.frf_redfact),' RF_SDOF_full = ',num2str(AMIMODES.SDOFSub.frf_rf_full)]);
                    else
                         fprintf(['     RFtotal = ',num2str(max(AMIDATA.Xc)/max(AMIDATA.Hc))...
                            ', RF_MDOF = ', num2str(AMIMODES.MDOFSub.frf_redfact),' RF_SDOF_full = ',num2str(AMIMODES.SDOFSub.frf_rf_full),'...']);
                        if AMIMODES.MDOFSub.frf_redfact > AMIMODES.SDOFSub.frf_redfact & AMIMODES.MDOFSub.frf_redfact > AMISET.FRF_RF & ...
                                sum(AMIMODES.MDOFSub.mode_params(:,2) > 0 | AMIMODES.MDOFSub.mode_params(:,2) < 1) > 0;
                            % keep the modes if the reduction is better and the modes are stable & underdamped
                            keep_mode = 'y';
                            fprintf('modes kept\n');
                        else
                            keep_mode = 'n';
                            unreas_flag = 1;
                            fprintf('modes discarded\n');
                        end
                    end
                    
                    switch keep_mode
                    case 'y'
                        ami_addmodes('MDOF');
                        keep_mode = 'n'; % Don't add the mode later.
                    end
                    if strcmp(AMISET.AutoMode,'manual');
                        set(AMIDISPLAY.displaytext, 'String', 'Continue Subtraction?');
                        AMIDISPLAY.hyes = uicontrol('Parent',AMIDISPLAY.hmain, ...
                        'Units','normalized', ...
                        'Position',[0.85 0.1 0.03 0.075], ...
                        'Callback','global AMIDATA; AMIDATA.contsub = ''y''; global AMIDISPLAY; set(AMIDISPLAY.hyes,''UserData'',''done''),', ...
                        'String','Yes', ...
                        'Tag','Zero');
                        AMIDISPLAY.hno = uicontrol('Parent',AMIDISPLAY.hmain, ...
                        'Units','normalized', ...
                        'Position',[0.91 0.1 0.03 0.075], ...
                        'Callback','global AMIDATA; AMIDATA.contsub = ''n''; global AMIDISPLAY; set(AMIDISPLAY.hyes,''UserData'',''done''),', ...
                        'String','No', ...
                        'Tag','Zero');
                    waitfor(AMIDISPLAY.hyes,'UserData','done');
                    cont_sub = AMIDATA.contsub;
                    delete(AMIDISPLAY.hyes);
                    delete(AMIDISPLAY.hno);
                    else
                        if AMIMODES.SDOFSub.unreas_flag | AMIMODES.SDOFSub.frf_rf_full < AMISET.FRF_RF_full;
                            cont_sub = 'n';
                        else; cont_sub = 'y'; end
                    end

           case 'n' % Don't try a Higher Order Fit
           disp(['RFtotal = ',num2str(max(AMIDATA.Xc)/max(AMIDATA.Hc)),...
                   ', RF_SDOF = ', num2str(AMIMODES.SDOFSub.frf_redfact),' RF_SDOF_full = ',num2str(AMIMODES.SDOFSub.frf_rf_full)]);
                if strcmp(AMISET.AutoMode,'manual');
                    set(AMIDISPLAY.displaytext, 'String', 'Keep the last mode?');
                    AMIDISPLAY.hyes = uicontrol('Parent',AMIDISPLAY.hmain, ...
                        'Units','normalized', ...
                        'Position',[0.85 0.1 0.03 0.075], ...
                        'Callback','global AMIDATA; AMIDATA.keepmodes = ''y''; global AMIDISPLAY; set(AMIDISPLAY.hyes,''UserData'',''done''),', ...
                        'String','Yes', ...
                        'Tag','Zero');
                    AMIDISPLAY.hzero = uicontrol('Parent',AMIDISPLAY.hmain, ...
                        'Units','normalized', ...
                        'Position',[0.88 0.1 0.03 0.075], ...
                        'Callback','global AMIDATA; AMIDATA.keepmodes = ''z''; global AMIDISPLAY; set(AMIDISPLAY.hyes,''UserData'',''done''),', ...
                        'String','Zero', ...
                        'Tag','Zero');
                    AMIDISPLAY.hquitsub = uicontrol('Parent',AMIDISPLAY.hmain, ...
                        'Units','normalized', ...
                        'Position',[0.91 0.1 0.03 0.075], ...
                        'Callback',['global AMIDATA; AMIDATA.keepmodes = ''n''; AMIDATA.contsub = ''n'';',...
                            'global AMIDISPLAY; set(AMIDISPLAY.hyes,''UserData'',''done''),'], ...
                        'String','Quit', ...
                        'Tag','Zero');
                    waitfor(AMIDISPLAY.hyes,'UserData','done');
                    keep_mode = AMIDATA.keepmodes;
                    delete(AMIDISPLAY.hyes);
                    delete(AMIDISPLAY.hzero);
                    delete(AMIDISPLAY.hquitsub);
                else
                    keep_mode = 'n';
                end
               switch keep_mode
               case 'z'
                   cont_sub = 'y';
               case 'n' % Above must have clicked "Quit"
                   cont_sub = 'n';
                    % This was set above:
                        % AMIDATA.contsub = ''n''
                    % Nothing to do - will quit now
               otherwise
                    if strcmp(AMISET.AutoMode,'manual');
                        set(AMIDISPLAY.displaytext, 'String', 'Continue Subtraction?');
                        AMIDISPLAY.hyes = uicontrol('Parent',AMIDISPLAY.hmain, ...
                        'Units','normalized', ...
                        'Position',[0.85 0.1 0.03 0.075], ...
                        'Callback','global AMIDATA; AMIDATA.contsub = ''y''; global AMIDISPLAY; set(AMIDISPLAY.hyes,''UserData'',''done''),', ...
                        'String','Yes', ...
                        'Tag','Zero');
                        AMIDISPLAY.hno = uicontrol('Parent',AMIDISPLAY.hmain, ...
                        'Units','normalized', ...
                        'Position',[0.91 0.1 0.03 0.075], ...
                        'Callback','global AMIDATA; AMIDATA.contsub = ''n''; global AMIDISPLAY; set(AMIDISPLAY.hyes,''UserData'',''done''),', ...
                        'String','No', ...
                        'Tag','Zero');
                    waitfor(AMIDISPLAY.hyes,'UserData','done');
                    cont_sub = AMIDATA.contsub;
                    delete(AMIDISPLAY.hyes);
                    delete(AMIDISPLAY.hno);
                    else
                        cont_sub = 'n'; % SDOF fit failed, AMIMODES.SDOFSub.frf_rf_full < tolerance, don't try MDOF, quit.
                    end
               end
            end
        else % SDOF Reduction is Satisfactory--Prompt to keep mode.
           disp(['RFtotal = ',num2str(max(AMIDATA.Xc)/max(AMIDATA.Hc)),...
                   ', RF_SDOF = ', num2str(AMIMODES.SDOFSub.frf_redfact),' RF_SDOF_full = ',num2str(AMIMODES.SDOFSub.frf_rf_full)]);
           disp('Singular Value Ratios Sj/S1');
           disp(['  ', num2str(AMIMODES.SDOFSub.SR.')]);
            if strcmp(AMISET.AutoMode,'manual');
                set(AMIDISPLAY.displaytext, 'String', 'Keep the last mode?');
                    AMIDISPLAY.hyes = uicontrol('Parent',AMIDISPLAY.hmain, ...
                        'Units','normalized', ...
                        'Position',[0.85 0.1 0.03 0.075], ...
                        'Callback','global AMIDATA; AMIDATA.keepmodes = ''y''; global AMIDISPLAY; set(AMIDISPLAY.hyes,''UserData'',''done''),', ...
                        'String','Yes', ...
                        'Tag','Zero');
                    AMIDISPLAY.hzero = uicontrol('Parent',AMIDISPLAY.hmain, ...
                        'Units','normalized', ...
                        'Position',[0.88 0.1 0.03 0.075], ...
                        'Callback','global AMIDATA; AMIDATA.keepmodes = ''z''; global AMIDISPLAY; set(AMIDISPLAY.hyes,''UserData'',''done''),', ...
                        'String','Zero', ...
                        'Tag','Zero');
                    AMIDISPLAY.hquitsub = uicontrol('Parent',AMIDISPLAY.hmain, ...
                        'Units','normalized', ...
                        'Position',[0.91 0.1 0.03 0.075], ...
                        'Callback',['global AMIDATA; AMIDATA.keepmodes = ''n''; AMIDATA.contsub = ''n'';',...
                            'global AMIDISPLAY; set(AMIDISPLAY.hyes,''UserData'',''done''),'], ...
                        'String','Quit', ...
                        'Tag','Zero');
                    waitfor(AMIDISPLAY.hyes,'UserData','done');
                    keep_mode = AMIDATA.keepmodes;
                    delete(AMIDISPLAY.hyes);
                    delete(AMIDISPLAY.hquitsub);
                    delete(AMIDISPLAY.hzero);
            else
                if AMIMODES.SDOFSub.unreas_flag; keep_mode = 'n'; else keep_mode = 'y'; end
            end
            switch keep_mode
            case 'z'
               cont_sub = 'y';
            case 'n' % Above must have clicked "Quit"
            	cont_sub = 'n';
                % This was set above: AMIDATA.contsub = ''n'';
            otherwise
                if strcmp(AMISET.AutoMode,'manual');
                    set(AMIDISPLAY.displaytext, 'String', 'Continue Subtraction?');
                        AMIDISPLAY.hyes = uicontrol('Parent',AMIDISPLAY.hmain, ...
                        'Units','normalized', ...
                        'Position',[0.85 0.1 0.03 0.075], ...
                        'Callback','global AMIDATA; AMIDATA.contsub = ''y''; global AMIDISPLAY; set(AMIDISPLAY.hyes,''UserData'',''done''),', ...
                        'String','Yes', ...
                        'Tag','Zero');
                        AMIDISPLAY.hno = uicontrol('Parent',AMIDISPLAY.hmain, ...
                        'Units','normalized', ...
                        'Position',[0.91 0.1 0.03 0.075], ...
                        'Callback','global AMIDATA; AMIDATA.contsub = ''n''; global AMIDISPLAY; set(AMIDISPLAY.hyes,''UserData'',''done''),', ...
                        'String','No', ...
                        'Tag','Zero');
                    waitfor(AMIDISPLAY.hyes,'UserData','done');
                    cont_sub = AMIDATA.contsub;
                    delete(AMIDISPLAY.hyes);
                    delete(AMIDISPLAY.hno);
                else
                    if AMIMODES.SDOFSub.unreas_flag; cont_sub = 'n'; else cont_sub = 'y'; end
                end
            end
        end
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       % End Higher Order Fit Routine
        
    % Always accept the first modes, until the Reduction Criteria has been met.   
    else % FRF automatic reduction parameter not yet met & valid results obtained
        keep_mode = 'y'; % Always accept these modes.
    end

    switch keep_mode
        case 'y' % Subtract Mode and Store Parameters
        ami_addmodes('SDOF');
        case 'z' % User Wants to Zero out data here
            set(AMIDISPLAY.displaytext, 'String','User Requests to Zero data');
            % Default Zeroing band is the band cf_lin attempted to curve fit.
            def_band = AMIDATA.wsplot(AMIMODES.SDOFSub.lbub);
            % Prompt User and Zero:
            [user_zero_band] = ami_zero_frf(def_band);
                % The above updates AMIDATA.X,Xc using AMIDATA.X,ws
    end
    
end

if strcmp(ManOrAutoOrInband,'man')
    set(AMIDISPLAY.displaytext, 'String', 'AMI Manual Subtraction Finished! You should now refine the Modal Parameters by Isolating.');
else
    set(AMIDISPLAY.displaytext, 'String', 'AMI Automatic Subtraction Finished! You should now refine the Modal Parameters by Isolating');
end