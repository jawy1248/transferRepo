function [mode_params,A_fit] = rfpm_real(Hpeak,wpeak,Nmodes,varargin)
%
% [mode_params,A_fit] = rfpm(Hpeak,wpeak,Nmodes,SubOrIsol,varargin)
%
% Rational Fraction Polynomial Algorithm based on:
% 	"A Global, Single-Input-Multi-Output (SIMO) Implementation of the Algorithm of Mode Isolation 
%   and Applications to Analytical and Experimental Data," Matthew S. Allen and Jerry H. Ginsberg,
%   Mechanical Systems and Signal processing, (submitted)
%       Written by Matt Allen, 2004
%

global AMIDATA AMISET AMIMODES

% Define Sizes
	Nf = AMIDATA.Nf;
	Ni = AMIDATA.Ni;
    No = AMIDATA.No;
	NoNi = No*Ni;
	
    Nfpeak = length(wpeak);
    
    Hpeak = mimo2simo_rs(Hpeak);
    
% Convert # modes to denominator order + 1
    if Nmodes ~= 1; error('This version only works for one mode'); end
	Nd = 2*Nmodes+1;

    % Nn = Nd-1+Nex; % Numerator Order
	% Manually force Nn = 1 - real modes
    Nn = 1;

%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%     % CUT THIS LATER, Load data:
%     clear all; close all;
%     Nmodes = 3;
% 	n = 2*Nmodes;
%         Nd = n+1;
%     Ne = 1; % Extra numerator Terms
%         Nn = Nd - 1 + Ne; % Numerator Order
%     max_iter = 3;
%     
% 	infname = 'SSP_alldata_rect_3modes.mat';
% 	eval(['load ',infname,' ws H Ps']);
% 	H = H(1:700,:,:);
% 	Ni = size(H,3); No = size(H,2);
% 	ws = ws(1:700).';
%     
%     band_ind = find(ws > 0 & ws < 60);
%     Hpeak = H(band_ind,:,:);
%     Hpeak = mimo2simo_rs(Hpeak);
%     wpeak = ws(band_ind);
% 
%     AMISET.DVA = 3;
%     consist_A = 0;
%     model = 0;
%     
% 	% Define Sizes
% 	Nf = length(ws);
%     Nfpeak = length(wpeak);
% 	Ni = size(H,3); No = size(H,2);
% 	NoNi = size(Hpeak,2);
%         
% 	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5

% Convert to Displacement
    if strcmp(AMISET.DVA,'D'); % Displacement Data
        % Hpeak = Hpeak;
    elseif strcmp(AMISET.DVA,'V'); % Velocity Data
        % Convert Velocity/Force TF to Displacement
        % Change of variables, Scale factor must be included when integrating
        % Note that this is equiavent to re-deriving the SDOF algorithm for acceleration.
        for ii = 1:1:NoNi;
            Hpeak(:,ii) = (Hpeak(:,ii)./(i*wpeak));
        end
    elseif strcmp(AMISET.DVA,'A');
        % Convert Acceleration/Force TF to Displacement
        % Change of variables, Scale factor must be included when integrating
        % Note that this is equiavent to re-deriving the SDOF algorithm for acceleration.
        for ii = 1:1:NoNi
            Hpeak(:,ii) = (Hpeak(:,ii)./(-wpeak.^2));
        end
    else
        error('Unrecognized TF Type');
    end

% Condition Data to avoid Numerical Difficulty %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if isempty(AMISET.Ts);
    % Scale the Transfer function by the average value.
		sf_x = mean(mean(abs(Hpeak)));
		Hpeak = Hpeak/sf_x;
	% Scale w by average value
		sf_w = mean(wpeak);
		wpeak = wpeak/sf_w;
else % Discrete time, but this algorithm isn't done yet for that case: MSA 12/2008
    sf_x = 1; sf_w = 1;
end
%     % Scale the Transfer function by the average value.
% 		sf_x = mean(mean(abs(Hpeak)));
% 		Hpeak = Hpeak/sf_x;
% 	% Scale w by average value
% 		sf_w = mean(wpeak);
% 		wpeak = wpeak/sf_w;
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% To insert into RFP_xx_ami, change: Nf to Nfpeak, Hk to Hpeak, ws to wpeak
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Iterate to improve weighting
	% Initial Weighing and polynomials
%        poly = [];
%        for r = 1:Nd
%            poly = [poly (i*wpeak).^(r-1)];
%        end

        % Form Omega Vectors
%tic
        Omega = zeros(Nfpeak,max(Nd,Nn));
        for s = 1:max(Nd,Nn);
            Omega(:,s) = (i*wpeak).^(s-1);
        end
        Omega_Nd = Omega(:,[1:Nd]);
        Omega_Nn = Omega(:,[1:Nn]);
        %Omega_mat = zeros(max(Nd,Nn),max(Nd,Nn),Nfpeak);
        %for f = 1:Nfpeak
        %    Omega_mat(:,:,f) = Omega(f,:)'*Omega(f,:);
        %end
        %Omega_B = Omega_mat(1:Nd,1:Nn,:);
%t_omega = toc     
%Dlam = 1; its = 0;
%while Dlam > 1e-10
%    its = its+1;
%    if its > max_iter; its = its-1; break; end 
        
    % Find scale factor W(w) for next iteration
%    if its > 1;
%        W = abs(poly*alph).^-1;
%    else
        W = ones(size(wpeak));
        %    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% THIS COULD BE SPED UP BY FORMING C FIRST AND USING KRON TO FORM A AND B FROM IT.

%tic
    % Form A Matrix
    Am = zeros(Nd,Nd);
    for f = 1:Nfpeak
        Am = Am + abs(W(f))^2*(Hpeak(f,:)*(Hpeak(f,:)'))*Omega_Nd(f,:)'*Omega_Nd(f,:);
    end
    Am = real(Am);
        % This operation is very fast
%t_A = toc
%tic
    % Form B Matrix
    Bm = zeros(Nd,Nn*NoNi);
    for s = 1:Nn
        Bsum = zeros(Nd,NoNi);
        for f = 1:Nfpeak
            Bsum = Bsum - real((abs(W(f))^2*(Omega_Nd(f,:)'))*(conj(Hpeak(f,:))*Omega_Nn(f,s)));
        end
        Bm(:,[NoNi*(s-1)+1:No*Ni*s]) = Bsum;
    end
    %Bm = -real(Bm);
        % Considerable effort here.
%t_B = toc
%tic
%    % Form B Matrix
%    Bm = zeros(Nd,Nn*NoNi);
%    for f = 1:Nfpeak
%        Bm = Bm - real(kron(abs(W(f))^2*Omega_B(:,:,f),conj(Hpeak(f,:))));
%    end
%    %Bm = -real(Bm);
%        % This method is considerably slower? why?
%t_B2 = toc

%tic
    % Compute inv(Cprime)
    Cp = zeros(Nn,Nn);
    for f = 1:Nfpeak
        Cp = Cp + abs(W(f))^2*Omega_Nn(f,:)'*Omega_Nn(f,:);
    end
    Cp = real(Cp);
    Cpi = inv(Cp);
        % This computation is very fast

    % Expand Cprime to Cm
    Inoni = spdiags(ones(NoNi,1),0,NoNi,NoNi);
    Cminv = kron(Cpi,Inoni);
        % This is pretty well optimized
%t_C = toc
%tic
    M = Am-Bm*Cminv*(Bm');
%t_M = toc
%t_RST = t_omega + t_A + t_B + t_C + t_M

	% LS Solution for the highest denominator coefficient constrained to one.
		al_ls = [-M(1:Nd-1,1:Nd-1)\M(1:Nd-1,Nd); 1];
		den = fliplr(al_ls.');
		lam_fit_ls = roots(den);
	
 	% Mixed LS-TLS solution
     
 		[EvM,lm] = eig(M);
 		lm = diag(lm);
 		al_lstls = EvM(:,find(abs(lm) == min(abs(lm))));
 		den_lstls = fliplr(al_lstls.');
 		lam_fit_lstls = roots(den_lstls);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	% Choose, LS-TLS solution, affects weighting as well
        alph = al_ls; %alph = al_lstls;
        % For some reason, the LS-TLS solution doesn't seem to work?
        lam_fit = lam_fit_lstls;
        % Sort Eigenvalues
        [junk,sind] = sort(abs(lam_fit) + (min(abs(lam_fit))*0.01)*(imag(lam_fit)<0));
        lam_fit = lam_fit(sind);
        
%    % Monitor Convergence
%        lfi(:,its) = lam_fit;
%        if its > 1;
%            Dlam = max(abs(lam_fit - lfi(:,its-1)));
%        end
        
%end % End of Iteration %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%its
% Find numerator coefficients, and Residues
	bet = zeros(Nn*NoNi);
    bet = -Cminv*(Bm')*alph;
 
    A_fit_mat = (bet/(2*i*imag(lam_fit(1)))).';
    % A_fit_mat = (bet*i*imag(lam_fit(1))).'/2; % Found by trial and error? What's up?

%     bet = reshape(bet,NoNi,Nn).';
% 
%     %tic
%     [A_conj_mat, ExPoly_mat, lam_sort] = RFP_extract_residues(fliplr(alph.'),bet([end:-1:1],:));
%     %t_num_fn = toc
        
% Rescale Modal Properties: ################ VIP ##################
	lam_fit = lam_fit(1:2:end)*sf_w; % now lam_fit no longer contains conjugates
	%A_fit_mat = A_conj_mat(1:2:end,:)*sf_w*sf_x;
    A_fit_mat = A_fit_mat*sf_w*sf_x; %
    A_fit = simo2mimo_rs(A_fit_mat,Ni);
%         % Check
%         Ch_Aconj = norm(imag(A_conj_mat(1:2:end,:)+A_conj_mat(2:2:end,:)));
%         if Ch_Aconj > 1000*eps;
%             disp('Warning: Residues are not conjugates!');
%         end
	% % Rescale Transfer Function % could cut this out?
	% 	Hpeak = Hpeak*sf_x; wpeak = wpeak*sf_w;
    
    mode_params = [abs(lam_fit) -real(lam_fit)./abs(lam_fit) lam_fit];

    
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Process Results
% 	lam_fit_ls = lam_fit_ls(1:2:end)*sf_w; % now lam_fit no longer contains conjugates
%     lam_fit_lstls = lam_fit_lstls(1:2:end)*sf_w; % now lam_fit no longer contains conjugates
%         disp('%%%%%%%%%%%%%%%%%%%%%%%%%');
%         disp('LS wn, zeta');
%         [-real(lam_fit_ls)./abs(lam_fit_ls) abs(lam_fit_ls)]
%         disp('LS-TLS wn, zeta');
%         [-real(lam_fit_lstls)./abs(lam_fit_lstls) abs(lam_fit_lstls)]
%         % Find Errors
%         eval(['load ',infname,' lam']);
%         [ls_wn_sort,s_ind] = sort(abs(lam_fit_ls));
%         ls_wn_sort = ls_wn_sort;
%         ls_zt_sort = -real(lam_fit_ls(s_ind))./abs(lam_fit_ls(s_ind));
%         ls_zt_sort = ls_zt_sort;
%         disp('%%%%%%%%%%%%%%%%%%%%%%%%%');
%         disp('LS Errors: wn, zeta');
%         [(ls_zt_sort - (-real(lam(1:3))./abs(lam(1:3))))./(-real(lam(1:3))./abs(lam(1:3))) ...
%                 (ls_wn_sort - abs(lam(1:3)))./abs(lam(1:3))]
%         
%         [tls_wn_sort,s_ind] = sort(abs(lam_fit_lstls));
%         tls_wn_sort = tls_wn_sort;
%         tls_zt_sort = -real(lam_fit_lstls(s_ind))./abs(lam_fit_lstls(s_ind));
%         tls_zt_sort = tls_zt_sort;
%         disp('%%%%%%%%%%%%%%%%%%%%%%%%%');
%         disp('LS-TLS Errors: wn, zeta');
%         [(tls_zt_sort - (-real(lam(1:3))./abs(lam(1:3))))./(-real(lam(1:3))./abs(lam(1:3))) ...
%                 (tls_wn_sort - abs(lam(1:3)))./abs(lam(1:3))]
% 
% 	figure(1)
% 	subplot(2,2,1)
% 	contourf(imag(reshape(A_fit(1,:,1),9,9)),30);
% 	title('Imag, A, lam 1, drive 1');
% 	subplot(2,2,2)
% 	contourf(imag(reshape(A_fit(1,:,2),9,9)),30);
% 	title('Imag, A, lam 1, drive 2');
% 	subplot(2,2,3)
% 	contourf(imag(reshape(A_fit(1,:,3),9,9)),30);
% 	title('Imag, A, lam 1, drive 3');
% 	
% 	figure(2)
% 	subplot(2,2,1)
% 	contourf(imag(reshape(A_fit(2,:,1),9,9)),30);
% 	title('Imag, A, lam 2, drive 1');
% 	subplot(2,2,2)
% 	contourf(imag(reshape(A_fit(2,:,2),9,9)),30);
% 	title('Imag, A, lam 2, drive 2');
% 	subplot(2,2,3)
% 	contourf(imag(reshape(A_fit(2,:,3),9,9)),30);
% 	title('Imag, A, lam 2, drive 3');
% 	
% 	figure(3)
% 	subplot(2,2,1)
% 	contourf(imag(reshape(A_fit(3,:,1),9,9)),30);
% 	title('Imag, A, lam 3, drive 1');
% 	subplot(2,2,2)
% 	contourf(imag(reshape(A_fit(3,:,2),9,9)),30);
% 	title('Imag, A, lam 3, drive 2');
% 	subplot(2,2,3)
% 	contourf(imag(reshape(A_fit(3,:,3),9,9)),30);
% 	title('Imag, A, lam 3, drive 3');
% 	
% 	% SVD Analysis to filter out only a specific mode.
% 	Asvd = permute(A_fit,[2,3,1]);
% 	[U,S,V] = svd(Asvd(:,:,1),0);
%         %al_1 = sqrt((U(Ps,1)'*(V(:,1)*S(1,1)))/(mode_params(3)*U(Ps,1)'*U(Ps,1)));
%         
%         % Alternative, keep first column of the decomposition only!
%         A_fit_svd = U(:,1)*S(1,1)*V(:,1).';
%         A_fit_svd = ipermute(A_fit_svd,[2,3,1]);
%         
% 	figure(4)
% 	subplot(2,2,1)
% 	contourf(imag(reshape(U(:,1),9,9)),30);
% 	title('Imag(U), Sing. Val #1');
% 	subplot(2,2,2)
% 	contourf(imag(reshape(U(:,2),9,9)),30);
% 	title('Imag(U), Sing. Val #2');
% 	subplot(2,2,3)
% 	contourf(imag(reshape(U(:,3),9,9)),30);
% 	title('Imag(U), Sing. Val #3');
% 	% This works quite well for this problem!
