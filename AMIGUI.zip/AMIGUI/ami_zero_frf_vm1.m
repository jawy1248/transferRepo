function [zero_band] = ami_zero_frf(def_limits);
% [zero_band] = ami_zero_frf(def_limits);
% Function which Prompts the User and Zeros out a section of the
% input FRF:  'AMIDATA.X'
%       def_limits:  the limits in frequency units to zero.
% works for SIMO (2-D) or MIMO (3-D) data

global AMIDATA AMISET AMIMODES AMIDISPLAY

def_limits_str = ['[',num2str(def_limits(1)),',',num2str(def_limits(2)),']'];
disp(['Default Zero Band: ',def_limits_str,' ', AMISET.flabel]);
zero_limits = input(['What band would you like to zero ( d or ', AMISET.flabel,')? '],'s');

if strcmp(lower(zero_limits),'d')
    zero_limits = def_limits;
else
    zero_limits = eval(zero_limits);
    if length(zero_limits) > 2;
        zbl = zero_limits(1); zbu = zero_limits(end);
        zero_limits = [zbl,zbu]
    end
end

% Find Frequency points using find command
zero_band = find(AMIDATA.wsplot >= zero_limits(1) & AMIDATA.wsplot <= zero_limits(2));
zero_band = [zero_band(1), zero_band(end)];

% Zero out the data

disp(['Zeroing: ', num2str(AMIDATA.wsplot(zero_band(1))), ' ',AMISET.flabel,...
    ' to ' num2str(AMIDATA.wsplot(zero_band(2))),' ',AMISET.flabel]);

AMIDATA.X(zero_band(1):zero_band(2),:,:) = 0;

AMIDATA.Xc = comp_FRF(AMIDATA.X);