function [] = ami_addmodes(SorMDOF);
% Add modes in GUI driven AMI

global AMIDATA AMISET AMIMODES

if strcmp(SorMDOF,'MDOF'); % KEEP MDOF FIT
    N_dof = AMIMODES.MDOFSub.N_dof;
    
    AMIMODES.mode_store(AMIMODES.CurrSub.curr_mode:(AMIMODES.CurrSub.curr_mode+(N_dof-1)),:) = ...
        [AMIMODES.MDOFSub.mode_params, AMIMODES.CurrSub.curr_step*ones(size(AMIMODES.MDOFSub.mode_params,1),1)];
    AMIMODES.A_store(AMIMODES.CurrSub.curr_mode:(AMIMODES.CurrSub.curr_mode+(N_dof-1)),:,:) = ...
        AMIMODES.MDOFSub.A_fit;
    if strcmp(AMISET.BandMode,'fixed');
        % Don't need to save model
    else
        AMIMODES.X_model(:,:,:,AMIMODES.CurrSub.curr_mode:(AMIMODES.CurrSub.curr_mode+(N_dof-1))) =...
            AMIMODES.MDOFSub.X_fit;
    end
    AMIMODES.m_bands([AMIMODES.CurrSub.curr_mode:(AMIMODES.CurrSub.curr_mode+(N_dof-1))],:) = ...
        ones(N_dof,1)*AMIMODES.MDOFSub.lbub;

    for k = AMIMODES.CurrSub.curr_mode:(AMIMODES.CurrSub.curr_mode+(N_dof-1));
        fprintf(['Mode Added:  ', AMISET.fl2, 'n = %g \t\t Zeta = %g \n'],...
            AMIMODES.mode_store(k,1)/AMISET.FreqScale,...
            AMIMODES.mode_store(k,2)); % Display fn, Zeta
    end
    % Subtract out Modal Contributions
    AMIDATA.X = AMIDATA.X - sum(AMIMODES.MDOFSub.X_fit,4);

    % Save All data from fit:
    AMIMODES.MDOFSub = rmfield(AMIMODES.MDOFSub,'X_fit');
    sfnames = fieldnames(AMIMODES.MDOFSub); svar = 'MDOFSub';

    % %%%% Zero out data within the bandwidth of the mode %%%%%%%%%%%%%
    % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if strcmp(AMISET.Zeroing,'fb')
        AMIMODES.zero_pts = [AMIMODES.zero_pts [AMIMODES.MDOFSub.fit_band]];
        AMIDATA.X(AMIMODES.zero_pts,:,:) = 0;
    end

else % KEEP SDOF FIT
    
    AMIMODES.mode_store(AMIMODES.CurrSub.curr_mode,:)=...
        [AMIMODES.SDOFSub.mode_params, AMIMODES.CurrSub.curr_step];
    AMIMODES.A_store(AMIMODES.CurrSub.curr_mode,[1:size(AMIMODES.SDOFSub.A_fit,2)],...
        [1:size(AMIMODES.SDOFSub.A_fit,3)]) = AMIMODES.SDOFSub.A_fit(1,:,:);
    if AMISET.OMA % also save B parameters
        AMIMODES.B_store(AMIMODES.CurrSub.curr_mode,[1:size(AMIMODES.SDOFSub.B_fit,2)],...
        [1:size(AMIMODES.SDOFSub.B_fit,3)]) = AMIMODES.SDOFSub.B_fit(1,:,:);
    end
    if strcmp(AMISET.BandMode,'fixed');
        % Don't need to save model
        AMIMODES.m_bands(AMIMODES.CurrSub.curr_mode,:) = AMIMODES.SDOFSub.lbub;
    else
        AMIMODES.X_model(:,:,:,AMIMODES.CurrSub.curr_mode) = AMIMODES.SDOFSub.X_fit;
        AMIMODES.m_bands(AMIMODES.CurrSub.curr_mode,:) = [1,length(AMIDATA.ws)];
    end
    %Phi_store(:,AMIMODES.CurrSub.curr_mode) = Phi_fit;
    fprintf(['Mode Added: ',AMISET.fl2,'n = %g \t\t Zeta = %g \n'],...
        AMIMODES.SDOFSub.mode_params(1:2)./[AMISET.FreqScale,1]); % Display fn, Zeta
    
    AMIDATA.X = AMIDATA.X - AMIMODES.SDOFSub.X_fit;
    N_dof = 1;

    % Save All data from fit:
    AMIMODES.SDOFSub = rmfield(AMIMODES.SDOFSub,'X_fit');
    AMIMODES.SDOFSub = rmfield(AMIMODES.SDOFSub,'X_fit_Rf');
    sfnames = fieldnames(AMIMODES.SDOFSub); svar = 'SDOFSub';
    
    % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % %%%% Zero out data within the bandwidth of the mode %%%%%%%%%%%%%
    % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if strcmp(AMISET.Zeroing,'fb')
        AMIMODES.zero_pts = [AMIMODES.zero_pts [AMIMODES.SDOFSub.fit_band]];
        AMIDATA.X(AMIMODES.zero_pts,:,:) = 0;
    elseif strcmp(AMISET.Zeroing,'xfb')
%         save 'ms_debug.mat'
        % To arrive here, only single modes could be identified.
        z_xws = [-10, 10]*abs(real(AMIMODES.SDOFSub.mode_params(3))) + ...
            AMIMODES.SDOFSub.mode_params(1);
            if ~isempty(max(find(AMIDATA.ws < z_xws(1))))
                z_xb(1) = max(find(AMIDATA.ws < z_xws(1)));
            else
                z_xb(1) = 1;
            end
            if ~isempty(min(find(AMIDATA.ws > z_xws(2))));
                z_xb(2) = min(find(AMIDATA.ws > z_xws(2)));
            else
                z_xb(2) = length(AMIDATA.ws);
            end
            AMIMODES.zero_pts = [AMIMODES.zero_pts [z_xb(1):z_xb(2)]];
            AMIDATA.X(AMIMODES.zero_pts,:,:) = 0;
    end
    
end

for k = 1:length(sfnames);
    AMIMODES.SubData(AMIMODES.CurrSub.curr_step).(sfnames{k}) = AMIMODES.(svar).(sfnames{k});
end

% Form new composite
AMIDATA.Xc = comp_FRF(AMIDATA.X);

% Set indicator that isolation is no longer current
AMIMODES.Status.Isol = 'notcurrent';

AMIMODES.CurrSub.curr_mode = AMIMODES.CurrSub.curr_mode+N_dof;
AMIMODES.CurrSub.curr_step = AMIMODES.CurrSub.curr_step +1;
if AMIMODES.CurrSub.curr_mode > AMISET.MaxModes;
    return; disp('Maximum Number of Modes Found');
end

% Clear out old results:
try; AMIMODES = rmfield(AMIMODES,'MDOFSub'); end
try; AMIMODES = rmfield(AMIMODES,'SDOFSub'); end
    