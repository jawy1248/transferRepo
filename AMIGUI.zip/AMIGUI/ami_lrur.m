function [] = ami_lrur
% Fit Upper and Lower Residuals

global AMIDATA AMIDISPLAY AMISET AMIMODES

if isfield(AMIMODES,'mode_store');
%     X_sum = ss_model(AMIMODES.mode_store(:,3),AMIMODES.A_store,AMIDATA.ws,AMISET.DVA,'s');
    X_sum = sum(AMIMODES.X_model,4);
else % create zero matrix if no modes have been identified
    X_sum = zeros(size(AMIDATA.H));
end
% disp('Norm of X_sum - X_model');
% try
%     norm(X_sum - sum(AMIMODES.X_model,4))
%     figure(200);
%     semilogy(AMIDATA.ws,comp_FRF(X_sum),AMIDATA.ws,comp_FRF(sum(AMIMODES.X_model,4)))
%     grid on;
% catch
%     disp('size mismatch');
% end

AMIMODES.LRUR = find_ur_ami(AMIDATA.H-X_sum,AMIDATA.ws,AMISET.LRUR_dfrac);
% AMIMODES.LRUR = find_lrur_ami(AMIDATA.H-X_sum,AMIDATA.ws,AMISET.LRUR_dfrac);
%% Modified
% AMIMODES.LRUR(1,:,:) = 0; % wipe out 1st term - not working?
AMIMODES.X_LRUR = ss_model([],[],AMIDATA.ws,AMISET.DVA,'s',AMIMODES.LRUR);

%% Update Plots

% COMPOSITE PLOT:
axes(AMIDISPLAY.hmainS1)
hls(1) = semilogy(AMIDATA.wsplot, AMIDATA.Hc,'Color',0.3*[1,1,1]);  hold on;  grid on;
% line(AMIDATA.wsplot, AMIDATA.Xc,'Color','b','LineStyle','-'); 
hls(2) = line(AMIDATA.wsplot, comp_FRF(sum(AMIMODES.X_model,4)),'Marker','.','LineStyle',':','color',[0,0.5,0]);
hls(3) = line(AMIDATA.wsplot, comp_FRF(AMIDATA.H - sum(AMIMODES.X_model,4) - AMIMODES.X_LRUR),'color',[1,0.1,0.1]);
set(gca,'Ylim',AMIDISPLAY.YLim); hold off;
legend('Data','Fit','Data-Fit');
title(['\bf',AMIDISPLAY.title_str]);
xlabel(['\bfFrequency (',AMISET.flabel,')']);
set(hls,'LineWidth',2);

% Nyquist Plot:
axes(AMIDISPLAY.hmainS2)
Hs = LMS_sum_FRFs(AMIDATA.H);
Hs_fit = LMS_sum_FRFs(sum(AMIMODES.X_model,4)+ AMIMODES.X_LRUR);
plot(real(Hs),imag(Hs),real(Hs_fit),imag(Hs_fit),'.:');
title('\bfComplex Sum(abs) FRFs'); xlabel('\bfRe\{H(\omega)\}'); ylabel('\bfIm\{H(\omega)\}');
legend('Data','Fit');
    
