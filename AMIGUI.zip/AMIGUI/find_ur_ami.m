function [LRUR] = find_ur_ami(H,ws,pct_outliers)
% Find upper and lower residuals from Residual FRF data using outlier
% rejection
%
% [LRUR] = find_ur_ami(H,ws,pct_outliers);
%   pct_outliers is a number between 0 and 1 specifying the fraction of
%   outliers.
% where LR and UR satisfy
%
% [H(w)] = UR
%
% Matt Allen - March 9, 2006

[Nf,No,Ni] = size(H);
LRUR = zeros(2,No,Ni);

figure(500); clf(500);

for rind = 1:No
    for dind = 1:Ni;
        % Begin of Algorithm - LR, UR independent for each DP
        vec1 = H(:,rind,dind);
%         vec2 = ws.^-2.*H(:,rind,dind);
        
        % Remove Outliers
        ol1_ind = find_outliers(vec1,pct_outliers);
%         ol2_ind = find_outliers(vec2,pct_outliers);
        all_ol_ind = ol1_ind;%union(ol1_ind,ol2_ind);
        keep_ind = setdiff([1:Nf],all_ol_ind);
            if length(all_ol_ind) > 0.8*Nf;
                warning('More than 80% of the data was outliers');
            end
            if isempty(keep_ind)
                error('All Data are outliers');
            end
        % Sums:
        LRUR(2,rind,dind) = mean(vec1(keep_ind));
        LRUR(1,rind,dind) = 0;
        
        % subplot(2,1,1);
        line(ws(2:end),abs(vec1(2:end)))
        line(ws(keep_ind),abs(vec1(keep_ind)),'Marker','.','Color',[0,0.5,0]); grid on;
%         set(gca,'Ylim',[min(abs(vec1(keep_ind))),max(abs(vec1(keep_ind)))]);
        % subplot(2,1,2);
        % plot(ws(2:end),abs(vec2(2:end)),ws(keep_ind),abs(vec2(keep_ind)),'.'); grid on;
        % set(gca,'Ylim',[min(abs(vec2(keep_ind))),max(abs(vec2(keep_ind)))]);
        % pause
        
    end
end
set(gca,'YScale','Log');
% disp('Saving debugdata.mat');
% save debugdata.mat



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function elim_ind = find_outliers(data,elim_pct);

[dsort, dsort_ind] = sort(data);
Nelim = round(elim_pct*length(data)/2); % 1/2 for each end
elim_ind = dsort_ind([1:Nelim, length(dsort_ind):-1:(length(dsort_ind)-Nelim)]);
    % Indices of tails
