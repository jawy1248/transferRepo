function []=ami_plotisolresid(ws,H,AMIMODES,varargin)
% Function which plots a composite of each mode and a composite Nyquist
% plot, to aid in assessing the quality of the fit for each mode.
%
% ami_plotisolresid(ws,H,AMIMODES,varargin)
%
% M.S. Allen, 2015-12
%
global AMISET
if isempty(AMISET)
    DVA='A'; warning('AMISET not found, assuming acceleration fit');
else
    DVA=AMISET.DVA;
end

if nargin<4
    startfignum=1;
else
    startfignum=varargin{1};
end
if nargin==5
    muse=varargin{2};
else
    muse=1:size(AMIMODES.mode_store,1);
end


% Plot Isolation Residuals for each mode
for k=1:length(muse);%size(AMIMODES.mode_store,1);
    mode_fit=ss_model(AMIMODES.mode_store(muse(k),3),AMIMODES.A_store(muse(k),:,:),ws,'A','s');
    isolresid=H-AMIMODES.X_model+mode_fit; % Data with all other modes removed
    figure(startfignum+muse(k)); set(gcf,'Units','normalized','Position',[.1 .20 .65 .45]);
    subplot(1,3,1:2);
        semilogy(ws/2/pi,comp_FRF(isolresid),'b-'); hold on;  grid on;
        line(ws/2/pi,comp_FRF(mode_fit),'Marker','.','LineStyle',':','color',[0,0.5,0]);
        title(['\bfMode # ',num2str(muse(k)),', at ',num2str(AMIMODES.mode_store(muse(k),1)/2/pi),' Hz']);
        xlabel('\bfFrequency (Hz)'); ylabel('\bfImag');
    subplot(1,3,3);
        Mult_CNP_MIMO(ws/2/pi,isolresid,mode_fit,AMIMODES.A_store(muse(k),:,:),gca);
        title('\bfComposite Nyquist');
        xlabel('\bfReal'); ylabel('\bfImag');
end