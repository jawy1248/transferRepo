function [] = AMIG_SubStepPlot(w,pfsf,fit_band,X_work,Xw_comp,X_fit,A_fit,N_fit,X_fit_FR,AMISET,curr_mode,curr_step,ylims,title_str,sub_or_isol);
% Function which plots data at individual subtraction or isolation steps
% as part of the AMI algorithm
% Matt Allen - Feb. 21, 2005
global AMIDATA AMIDISPLAY AMISET

% Nyquist Plot:
axes(AMIDISPLAY.hmainS1)
    semilogy(w/pfsf,Xw_comp,'b-'); hold on;  grid on;
    line(w/pfsf,comp_FRF(sum(X_fit,4)),'Marker','.','LineStyle',':','color',[0,0.5,0]);
    line(w(fit_band)/pfsf,Xw_comp(fit_band),'Color','r','Marker','.','LineStyle','none');
    line(w/pfsf,comp_FRF(X_work-sum(X_fit,4)),'color',[0,0.5,0]);
    title(['\bf',title_str]);
    xlabel(['\bfFrequency (',AMISET.flabel,')']);
    set(gca,'Ylim',ylims); hold off;
    pos1 = get(ha1,'Position');
axes(AMIDISPLAY.hmainS2)
    Mult_CNP_MIMO(w/pfsf,X_work,X_fit,A_fit,ha2,fit_band);
    title('\bfCNPs for Each Mode');
    pos2 = get(ha2,'Position');
set(ha1,'Position',pos1 + [-0.065, 0, 0.2,0]); legend(ha1,'|FRF|','|Fit|','Peak','|FRF-Fit|',4);
set(ha2,'Position',pos2 + [0.075,0,0,0]); %legend(ha2,'FRF','Peak','Fit');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Old version
if 0
    H = figure(curr_mode+50); set(H,'Units','normalized','Position',[.01 .05 .70 .85]);
    % Nyquist Plot:
    ha1 = subplot(2,2,1);
        Mult_NP_MIMO(X_work,sum(X_fit,4),AMISET.Refs,ha1,fit_band);
        title(['Modes # ', num2str(curr_mode+[0:(N_dof-1)]), ', From RFP']);
        legend('FRF','Fit');
    ha2 = subplot(2,2,3);
        Mult_CNP_MIMO(w/pfsf,X_work,X_fit,A_fit,ha2,fit_band);
        title('Composite Nyquist Plots for Each Mode');
    % FRF Plot, Magnitude
    subplot(2,2,2); semilogy(w/pfsf,Xw_comp,w/pfsf,comp_FRF(sum(X_fit,4)),':.',...
        w(fit_band)/pfsf,Xw_comp(fit_band),'.'); grid;
        legend('|FRF|','|Fit|','Peak',4);
    subplot(2,2,4); semilogy(w/pfsf,comp_FRF(X_work-sum(X_fit,4))); grid;
    title('Sum |FRF| after Subtraction');
end

% ORIGINAL SCRIPTS FROM ms_hf_mimo_v3

        if 0
            H = figure(curr_mode+50); set(H,'Units','normalized','Position',[.01 .05 .70 .85]);
            % Nyquist Plot:
            ha1 = subplot(2,2,1);
                Mult_NP_MIMO(X_work,X_fit,Refs,ha1,fit_band);
                title(['Mode # ', num2str(curr_mode), ', Freq. = ', num2str(mode_params(1)/pfsf,4.2), ...
                    ' ',flabel, ' ,  \zeta = ', num2str(mode_params(2),3)]);
                legend('FRF','Fit');
            ha2 = subplot(2,2,3);
                %Mult_CNP_MIMO(w/pfsf,X_work,X_fit,A_fit,ha2,fit_band);
                Xwcn = mfrfcond(X_work,A_fit); Xfcn = mfrfcond(X_fit,A_fit);
                plot(real(Xwcn),imag(Xwcn),real(Xfcn),imag(Xfcn),':.',...
                    real(Xwcn(fit_band)),imag(Xwcn(fit_band)),'.'); grid on; 
                title('Composite Nyquist Plot');
                legend('FRF','Fit','Peak');
            % FRF Plot, Magnitude
            subplot(2,2,2); semilogy(w/pfsf,Xw_comp,'k-'); hold on;  grid on; ylims = get(gca,'Ylim');
                semilogy(w/pfsf,comp_FRF(X_fit),':.', w/pfsf,comp_FRF(X_fit_Rf),'-.',w(fit_band)/pfsf,Xw_comp(fit_band),'.');
                legend('|FRF|','|Fit|','|Fit FR|','Peak',4); set(gca,'Ylim',ylims); hold off;
            subplot(2,2,4); semilogy(w/pfsf,comp_FRF(X_work-X_fit)); grid;
            title('Sum |FRF| after Subtraction');
        
        H = figure(curr_mode+50); set(H,'Units','normalized','Position',[.01 .20 .85 .55]);
        if curr_mode == 1; ylims = [0.9*min(Xw_comp(find(Xw_comp > 0))),1.1*max(Xw_comp)]; end;
        % Nyquist Plot:
        ha1 = subplot(1,2,1);
            %Mult_CNP_MIMO(w/pfsf,X_work,X_fit,A_fit,ha2,fit_band);
            Xwcn = mfrfcond(X_work,A_fit); Xfcn = mfrfcond(X_fit,A_fit);
            plot(real(Xwcn),imag(Xwcn),real(Xfcn),imag(Xfcn),':.',...
                real(Xwcn(fit_band)),imag(Xwcn(fit_band)),'.'); grid on; 
            title('Composite Nyquist Plot');
            pos1 = get(ha1,'Position');
        ha2 = subplot(1,2,2);
            semilogy(w/pfsf,Xw_comp,'b-'); hold on;  grid on;
            line(w/pfsf,comp_FRF(X_fit),'Marker','.','LineStyle',':','color',[0,0.5,0])
            line(w/pfsf,comp_FRF(X_fit_Rf),'LineStyle','-.','color','k')
            line(w(fit_band)/pfsf,Xw_comp(fit_band),'Color','r','Marker','.');
            line(w/pfsf,comp_FRF(X_work-X_fit),'color',[0,0.5,0]);
            title('Composite Magnitude Plot');
            xlabel(['Frequency (',flabel,')']);
            set(gca,'Ylim',ylims); hold off;
            pos2 = get(ha2,'Position');
        set(ha1,'Position',pos1 + [-0.06, 0, -0.05,0]); legend(ha1,'FRF','Fit','Peak');
        set(ha2,'Position',pos2 + [-0.16,0,0.2,0]); legend(ha2,'|FRF|','|Fit|','|Fit FR|','Peak','|FRF-Fit|',4); 
    end

    % MULT
                      if 0
                        H = figure(curr_mode+50); set(H,'Units','normalized','Position',[.01 .05 .70 .85]);
                        % Nyquist Plot:
                        ha1 = subplot(2,2,1);
                            Mult_NP_MIMO(X_work,sum(X_fit_rfp,4),Refs,ha1,fit_bandm);
                            title(['Modes # ', num2str(curr_mode+[0:(N_dof-1)]), ', From RFP']);
                            legend('FRF','Fit');
                        ha2 = subplot(2,2,3);
                            Mult_CNP_MIMO(w/pfsf,X_work,X_fit_rfp,A_fit_rfp,ha2,fit_bandm);
                            title('Composite Nyquist Plots for Each Mode');
                        % FRF Plot, Magnitude
                        subplot(2,2,2); semilogy(w/pfsf,Xw_comp,w/pfsf,comp_FRF(sum(X_fit_rfp,4)),':.',...
                            w(fit_bandm)/pfsf,Xw_comp(fit_bandm),'.'); grid;
                            legend('|FRF|','|Fit|','Peak',4);
                        subplot(2,2,4); semilogy(w/pfsf,comp_FRF(X_work-sum(X_fit_rfp,4))); grid;
                        title('Sum |FRF| after Subtraction');
                    
                    H = figure(curr_mode+50); set(H,'Units','normalized','Position',[.01 .20 .85 .55]);
                    % Nyquist Plot:
                    ha1 = subplot(1,2,1);
                        Mult_CNP_MIMO(w/pfsf,X_work,X_fit_rfp,A_fit_rfp,ha1,fit_bandm);
                        title('Composite Nyquist Plots for Each Mode');
                        pos1 = get(ha1,'Position');
                    ha2 = subplot(1,2,2);
                        semilogy(w/pfsf,Xw_comp,'b-'); hold on;  grid on;
                        line(w/pfsf,comp_FRF(sum(X_fit_rfp,4)),'Marker','.','LineStyle',':','color',[0,0.5,0]);
                        line(w(fit_band)/pfsf,Xw_comp(fit_band),'Color','r','Marker','.','LineStyle','none');
                        line(w/pfsf,comp_FRF(X_work-sum(X_fit_rfp,4)),'color',[0,0.5,0]);
                        title('Composite Magnitude Plot');
                        xlabel(['Frequency (',flabel,')']);
                        set(gca,'Ylim',ylims); hold off;
                        pos2 = get(ha2,'Position');
                    set(ha1,'Position',pos1 + [-0.06, 0, -0.05,0]); legend(ha1,'FRF','Fit','Peak');
                    set(ha2,'Position',pos2 + [-0.16,0,0.2,0]); legend(ha2,'|FRF|','|Fit|','Peak','|FRF-Fit|',4); 
                    end
% ISOL
                    
            if 0
                hf = figure(999); set(hf,'Units','normalized','Position',[.01 .05 .70 .85]);
                % Nyquist Plot:
                ha1 = subplot(2,2,1);
                    Mult_NP_MIMO(X_work,sum(X_fit_rfp,4),Refs,ha1,[lbm:ubm]);
                    title(['Modes # ', num2str(m_inds.'), ', From RFP']);
                    legend('FRF','Fit');
                ha2 = subplot(2,2,3);
                    Mult_CNP_MIMO(w_MIR/pfsf,X_work,X_fit_rfp,A_fit_rfp,ha2,[lbm:ubm]);
                    title('Composite Nyquist Plots for Each Mode');
                % FRF Plot, Magnitude
                subplot(2,2,2); semilogy(w_MIR/pfsf,Xw_comp,w_MIR/pfsf,comp_FRF(sum(X_fit_rfp,4)),':.',...
                    w_MIR(lbm:ubm)/pfsf,Xw_comp(lbm:ubm),'.'); grid;
                    legend('|FRF|','|Fit|','Peak',4);
                subplot(2,2,4); semilogy(w_MIR/pfsf,comp_FRF(X_work-sum(X_fit_rfp,4))); grid;
                title('Sum |FRF| after Subtraction');
            end