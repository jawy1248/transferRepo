% Iterate to refine Modal parameters and out of band terms.
%

global AMIMODES AMISET AMIDATA

% Prompt user for number of iterations to perform:
prompt={'Number of Isolation Steps Per LRUR Update:','Number of LRUR Updates:'};
name='Number of Iteratios';
numlines=1;
defaultanswer={num2str(AMISET.IsolIter),'10'};
answer=inputdlg(prompt,name,numlines,defaultanswer);

old_II = AMISET.IsolIter;
    AMISET.IsolIter = str2double(answer{1});
old_SIS = AMISET.ShowIsolSteps;
    AMISET.ShowIsolSteps = 'n';
N_loops = str2double(answer{2});

for k = 1:N_loops
    ami_lrur
    ami_isolate
end

% Reset previous value
AMISET.IsolIter = old_II;
AMISET.ShowIsolSteps = old_SIS;

disp('Done Isolating LR and UR');