% Process results form Lab 5
clear all; close all;

load BeamFRFData.mat

global AMISET
AMISET = AMIG_def_opts;
% I used these commands to get a better curve fit for a few of the modes,
% but it didn't help tremendously.
AMISET.FRF_RF = 10;
AMISET.AutoSubLevel = 1.1;
AMISET.DVA = 'A';
AMISET.LM = 'on';

ami(H,ws,AMISET)

%% Plot Mode Shapes
global AMIMODES % brings AMI�s variables into the workspace
fn = AMIMODES.mode_store(:,1)/2/pi
zt = AMIMODES.mode_store(:,2)
res = -2*real(diag(conj(AMIMODES.mode_store(:,3)))*AMIMODES.A_store);

L = 30;
x = [2:3:29, 29:-3:2].'/L;

for k = 1:3;
    figure(10+k);
    N3 = ceil(length(fn)/3);
    m_inds = 3*(k-1)+1:min(N3*k,length(fn));
    plot(x*L,res(m_inds,:).'*diag(max(res(m_inds,:),[],2).^-1)); grid on;
    xlabel('Position'); title('\bfMode Shapes');
    legend(num2str(fn(m_inds),4));
end

% Mass Normalize:
res = -res; % Correct sign error in accelerometer directions
    dp_ind=10;% Pt 10 is the DP
    phi_norm = res(:,:).'*diag(res(:,dp_ind).^(-1/2)); 

% m_plot = 7;
% figure(20);
% surf([1:2],linspace(1,30,10),[res(m_plot,1:10); res(m_plot,11:20)].',...
%     [res(m_plot,1:10); res(m_plot,11:20)].');
% contourf([1:2],linspace(1,30,10),[res(m_plot,1:10); res(m_plot,11:20)].',20);

return
    % The rest is optional - does a comparison with the analtyical modes.
    
%% Compare with Analytical
% Analytical Model

% Create variables for Ritz Series
syms y real;
tic
N = 10;
y_F = .5;
% Find Alpha Values using Ginsberg Reference, back cover
    ce = inline('cos(x) - 1/cosh(x)');
    an0 = [4.730, (2*[4:N+2]-3)/2*pi];
    for k = 1:length(an0);
        an(k) = fzero(ce,an0(k));
    end
    for j = 1:N;
        Rn(j) = -(sin(an(j)) - sinh(an(j)))/(cos(an(j)) - cosh(an(j)));
    end
% Generate Mode functions
for j = 1:N
    psi(j) = sin(an(j)*y) + sinh(an(j)*y) + Rn(j)*(cos(an(j)*y) + cosh(an(j)*y));
end

% Mass Normalize:
for j = 1:N;
    mu_nd(j) = double(int(psi(j)^2,0,1)); 
end % all end up being values near one.

% For a real beam
E = 70e9;   % Pa Aluminum 
G = 26.8e9; % Norton
rhoB = 2700; % kg/m^3
LB = 30*0.0254; %m
b = 2*0.0254; %m
h = 3/16*0.0254; %m
I = b*h^3/12;

% Bending Factor
    BeamMult = (E*I/(rhoB*b*h*LB^4))^(1/2)
    wn_b_an = BeamMult*(an.^2).';
    fn_b_an = wn_b_an/2/pi
    mu = mu_nd*rhoB*b*h*LB;
    psi_end = double(subs(psi,'y',1))./sqrt(mu)

% Torsion - from Inman - better to have Ansys do cross section analysis!
    gam = 0.178e-8; % from ANSYS Beam Tool (Section Analysis)
    J = (1/12)*(rhoB*b*h)*(b^2+h^2);
    anT = ([2:4].'-1)*pi; % Ginsberg
    wn_t_an = anT*(G*gam/(rhoB*J*LB^2))^(1/2);
    fn_t_an = wn_t_an/2/pi

% ind_b = [1:5,7:8]; % For 1-mode fit to 4th peak results
% ind_t = [6];
ind_b = [1:3,5:6,8:9];
ind_t = [4,7];
fn_b = fn(ind_b);
fn_t = fn(ind_t);
res = -2*real(diag(conj(AMIMODES.mode_store(:,3)))*AMIMODES.A_store);
% res = res*(9.81/4.4482);% convert to metric units - now units of (1/kg)
% That seems to have been an error.  Supposedly the UFF file is already in
% metric units.
res = -res; % Correct sign error in accelerometer directions

phib = res(ind_b,:).'*diag(res(ind_b,10).^(-1/2));
phit = res(ind_t,:).'*diag(res(ind_t,10).^(-1/2));
phit = real(phit); % this mode poorly identified - drive point residue is negative.
    % Make it real so that at least it doesn't contaminate things below.
phib(:,4) = real(i*phib(:,4)); % correct for negative drive point
% x = linspace(0.06,0.96,10).'; x = [x; flipud(x)];
xan = linspace(0,1,100).';

phib_an = zeros(length(xan),length(fn_b));
phib_an_x = zeros(length(x),length(fn_b));
for k = 1:length(fn_b);
    phib_an(:,k) = subs(psi(k),'y',xan)/sqrt(rhoB*b*h*LB*mu_nd(k));
    phib_an_x(:,k) = subs(psi(k),'y',x)/sqrt(rhoB*b*h*LB*mu_nd(k));
    phib_sc(:,k) = phib(:,k)*norm(phib_an_x(:,k))/norm(phib(:,k));
end

for k = 1:length(fn_t);
    phit_an(:,k) = cos(k*pi*xan);
    phit_an_x(:,k) = cos(k*pi*x);
	phit_sc(:,k) = phit(:,k)*norm(phit_an_x(1:10,k))/norm(phit(1:10,k));
end
phit_an_x(end/2:end,:) = -phit_an_x(end/2:end,:);

x_ind_an = find(xan*L > x(1)*L,1);
for k = 1:length(fn_b)
%     [junk,pos_ind] = max(abs(phib_sc(:,k)));
    figure(30+k);
    plot(x*L,pltmshape(phib_sc(:,k),1),'ro:'); hold on;
    plot(xan*L,pltmshape(phib_an(:,k),x_ind_an)); hold off;
    set(get(gca,'Children'),'LineWidth',2); grid on;
    xlabel('Position (in)'); ylabel('MassNormShape');
end

    figure(50);
    MAC(res.',[phib_an_x,phit_an_x]);
    mac_mat = MAC(res.',[phib_an_x,phit_an_x]);
    xlabel('\bfExperimental Shapes [\Phi order identified]'); ylabel('\bf Analyitical [\Phi_b(1:7, \Phi_t(1:2)]');

figure(40);
plot(x*L,pltmshape(phit_sc,1),'.:'); hold on;
plot(xan*L,pltmshape(phit_an,1)); 
plot(x*L,pltmshape(phit_an_x,1),'o'); hold off;
set(get(gca,'Children'),'LineWidth',2); grid on;
xlabel('Position (in)'); ylabel('MassNormShape');

MSFvals = MSF(phib,phib_an_x);
% for k = 1:size(phib,2)
%     MSF(k) = phib(:,k).'*phib_an_x(:,k)/(phib_an_x(:,k).'*phib_an_x(:,k));
% end
% MSF

fn_pct_err = pct_err(fn_b,fn_b_an(1:length(fn_b)));
MACvals = diag(MAC(phib,phib_an_x));
[fn_b,fn_b_an(1:length(fn_b)),fn_pct_err,MSFvals,MACvals]

%% Peak Picking
% [inds] = pickpeaks(2,ws/2/pi,comp_FRF(H))
b_ind = [276, 761, 1494, 2470, 3708, 5192, 6922]
t_ind = [2470, 4957]

for k = 1:length(fn_b)
    ppshpb(:,k) = imag(H(b_ind(k),:).');
    ppshpb(:,k) = ppshpb(:,k)*norm(phib_an_x(:,k))/norm(ppshpb(:,k));
    
    figure(30+k);
    line(x*L,pltmshape(ppshpb(:,k),1),'Color',[0,0.5,0],'Marker','*');
end

for k = 1:length(fn_t)
	ppshpt(:,k) = imag(H(t_ind(k),:).');
    ppshpt(:,k) = ppshpt(:,k)*norm(phit_an_x(:,k))/norm(ppshpt(:,k));
end

figure(40);
hold on; plot(x*L,pltmshape(ppshpt,1),'*--'); hold off;

%% Mass Modification
% Note - need the rigid body modes for this to work (for the mode shapes at
% least)
% 
load AMIResults_AddMass.mat res_mod fn_mod zt_mod

rhos = 7800/0.88739; % kg/m^3 % steel - Norton
    % Adjusted to match weight of blocks: 144.04 grams
% Es = 206.8e9; % Pa % steel - Norton

m_beam = rhoB*LB*b*h
dm = (1.0)*(0.5)*(2.0)*0.0254^3*rhos/2*[1; 1] % kg

fn_rb = [0; 0]; zt_rb = [0; 0];
% fn_rb = [0; 0; 0]; zt_rb = [0; 0; 0];
phi_rb(:,1) = ones(size(phib(:,1)))/sqrt(m_beam);
phi_rb(:,2) = (x-1/2)/sqrt(m_beam/12); % Needs ?? *LB^2 factor??  
% phi_rb(:,3) = (b/2)*[ones(10,1); -ones(10,1)]/sqrt(m_beam*b^2/12);
phi_all = [phi_rb, phib, phit];
fn_all = [fn_rb; fn_b; fn_t];
zt_all = [zt_rb; vec(zt([ind_b, ind_t]))];
    [fn_all,sind] = sort(fn_all);
    zt_all = zt_all(sind);
    phi_all = phi_all(:,sind);

% phi_all = [phib, phit];
% fn_all = [fn_b; fn_t];
% zt_all = vec(zt([ind_b, ind_t]));

% Code to scale analytical torsion mode shape to match experimental - since
% I don't have a formula right now to compute mass norm. torsion mode
% shape.
for k = 2; phit_an_xsc(:,k) = phit_an_x(:,k)*norm(phit(:,k))/norm(phit_an_x(:,k)); end

[wn_mod,zt_mod,phi_mod] = ritzsmod(fn_all*2*pi,zt_all,phi_all,dm,[8,13],[],[]);
% Use analytical bending modes only in Ritz model.
% [wn_mod_an,zt_mod_an,phi_mod_an] = ritzsmod([fn_rb; fn_b_an(1:length(fn_b),1)*2*pi],...
%     zeros(length(fn_rb)+length(fn_b),1),[phi_rb, phib_an_x],dm,[8,13],[],[]);
% Modified - use analytical torsion modes too
    wn_an = [fn_rb*2*pi; fn_b_an(1:length(fn_b),1)*2*pi; fn_t*2*pi];
    zt_an = zeros(size(wn_an)); phi_an = [phi_rb, phib_an_x, phit_an_xsc];
        [wn_an,sind] = sort(wn_an); phi_an = phi_an(:,sind);
    [wn_mod_an,zt_mod_an,phi_mod_an] = ritzsmod(wn_an, zt_an,phi_an,dm,[8,13],[],[]);
disp('Nat. Freqs, Experimental Modes + Mass Addition, Analytical Unmodified, Analytical Modes + Mass Addition, Exper.');
view_vecs(sort(fn_all), wn_mod/2/pi, wn_an/2/pi, wn_mod_an/2/pi,[0; 0; fn_mod]);

for k = 1:length(fn_all)
%     [junk,pos_ind] = max(abs(phib_sc(:,k)));
    figure(50+k);
	plot(x*LB,pltmshape(phi_all(:,k),1),'.:'); hold on;
    plot(x*LB,pltmshape(phi_mod(:,k),1),'r-',x([8,13])*LB,[0,0],'ks'); hold off;
    set(get(gca,'Children'),'LineWidth',2); grid on;
    legend('Measured','Modified');
    xlabel('Position (m)'); ylabel('MassNormShape');
end

% for k = 1:length(fn_all)
% %     [junk,pos_ind] = max(abs(phib_sc(:,k)));
%     figure(50+k);
% 	plot(x*LB,pltmshape(phi_an(:,k),1),'.:'); hold on;
%     plot(x*LB,pltmshape(phi_mod_an(:,k),1),'r-',x([8,13])*LB,[0,0],'ks'); hold off;
%     set(get(gca,'Children'),'LineWidth',2); grid on;
%     legend('Measured','Modified');
%     xlabel('Position (m)'); ylabel('MassNormShape');
% end