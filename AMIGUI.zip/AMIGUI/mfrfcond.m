function [Hcn] = mfrfcond(H,A_fit);
% [Hcn] = mfrfcond(H,A_fit);
%
% MIMO FRF condensation.
% 
% This function condenses a set of MIMO FRFs using the Residue
% as a condensing vector.  The resulting vector can be plotted
% in the complex plane as a "Composite Nyquist Plot."
%
% H is assumed to have dimensions of Nf x No x Ni.
% A_fit is assumed to have dimensions of 1 x No x Ni
%
% A_fit is conjugated and then right multiplies H.
%

if size(H,3) ~= size(A_fit,3)
    error('Size (Ni) of Data and Residue Matrix Do Not Match');
end

for k = 1:size(H,3);
    Hcn(:,k) = H(:,:,k)*(A_fit(:,:,k)');
end
Hcn = sum(Hcn,2);