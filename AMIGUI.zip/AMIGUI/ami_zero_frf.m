function [zero_band] = ami_zero_frf(varargin);
% [zero_band] = ami_zero_frf(def_limits);
% Function which Prompts the User and Zeros out a section of the
% input FRF:  'AMIDATA.X'
%       def_limits:  the limits in frequency units to zero.
% works for SIMO (2-D) or MIMO (3-D) data

global AMIDATA AMISET AMIMODES AMIDISPLAY

if nargin > 0;
    def_limits = varargin{1};
    def_limits_str = ['[',num2str(def_limits(1)),',',num2str(def_limits(2)),']'];
%     x = ' ';
%     temp = ' ';
%     temp = sprintf(['Default Zero Band: ',def_limits_str,' ', AMISET.flabel]);
%     x = strcat(x, temp);
    fprintf(['Default Zero Band: ',def_limits_str,' ', AMISET.flabel]);
end

% Gui based version:
% Add button to chose zero limits once you're ready.
set(AMIDISPLAY.displaytext, 'String','Click on the ''Zero'' button when you are ready to select the zero band, then click on the plot at the upper and lower limits you want to zero.');

AMIDISPLAY.hzero = uicontrol('Parent',AMIDISPLAY.hmain, ...
    'Units','normalized', ...
    'Position',[0.878 0.1 0.03 0.075], ...
    'Callback','pick_zero_band; global AMIDISPLAY; set(AMIDISPLAY.hzero,''UserData'',''done''),', ...
    'String','Zero', ...
    'Tag','Zero');

waitfor(AMIDISPLAY.hzero,'UserData','done');
delete(AMIDISPLAY.hzero);
AMIDISPLAY.hzero = [];

% Old method:
% zero_limits = input(['What band would you like to zero ( d or ', AMISET.flabel,')? '],'s');

if length(AMIDISPLAY.zero_limits) > 2;
    zbl = AMIDISPLAY.zero_limits(1); zbu = AMIDISPLAY.zero_limits(end);
    AMIDISPLAY.zero_limits = [zbl,zbu];
end

% Find Frequency points using find command
zero_band = find(AMIDATA.wsplot >= AMIDISPLAY.zero_limits(1) & ...
    AMIDATA.wsplot <= AMIDISPLAY.zero_limits(2));
zero_band = [zero_band(1), zero_band(end)];

% Zero out the data
    % temp = sprintf(['Zeroing: ', num2str(AMIDATA.wsplot(zero_band(1))), ' ',AMISET.flabel,...
    %     ' to ' num2str(AMIDATA.wsplot(zero_band(2))),' ',AMISET.flabel]);
    % x = strcat(x, temp);
    % set(AMIDISPLAY.displaydata, 'String', x);
fprintf(['Zeroing: ', num2str(AMIDATA.wsplot(zero_band(1))), ' ',AMISET.flabel,...
    ' to ' num2str(AMIDATA.wsplot(zero_band(2))),' ',AMISET.flabel]);
AMIDATA.X(zero_band(1):zero_band(2),:,:) = 0;

AMIDATA.Xc = comp_FRF(AMIDATA.X);
