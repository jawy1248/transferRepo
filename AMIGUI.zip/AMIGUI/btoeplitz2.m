function T = btoeplitz2(TC, TR)
%
% T = btoeplitz2(TC, TR)
%
% Creates a block toeplitz matrix,
% where TC is the first block column and TR is the first block row of T.
%
% NOTE - MSA Aug, 2, 2004 - This appears to support rectangular blocks
% in the block toeplitz matrix.  ('btoeplitz' does not.)

% Daniel Kressner, Aug. 2002.
%

ni = nargin;  nout = nargout;
%
if ni < 1 | ni > 2,
   error('Improper number of input arguments')
end
if nout > 1,
   error('Improper number of output arguments')
end

[m l] = size(TC);
if ni == 1,
   k = l;
   n = m;
else
   [k n] = size(TR);
end
if (l==0 & n~=0) | (k==0 & m~=0),
   error('Dimensions of TC and TR do not match');
end
T = zeros(m,n);
if min([k,l,m,n]) == 0,
   return;
end
if rem(m,k) | rem(n,l),
   error('Dimensions of TC and TR do not match');
end
m = m/k;
n = n/l;
if ni == 1,
   TR = zeros(k,n*l);
   for i = 1:m,
       TR(:,(i-1)*l+1:i*l) = TC((i-1)*k+1:i*k,:);
   end
end
if TC(1:k,1:l)~=TR(1:k,1:l),
   warning('Block columns wins block diagonal conflict.');
end
T(:,1:l) = TC;
T(1:k,l+1:n*l) = TR(:,l+1:n*l);
for i = 2:n,
   T(k+1:m*k,(i-1)*l+1:i*l) = T(1:(m-1)*k,(i-2)*l+1:(i-1)*l);
end

%
% end btoeplitz2
