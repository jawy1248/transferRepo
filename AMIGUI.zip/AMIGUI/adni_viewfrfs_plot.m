function [] = adni_viewfrfs_plot;

global AMIDISPLAY AMIDATA AMIMODES AMISET

AMIDISPLAY.ViewInds.ni = AMIDISPLAY.ViewInds.ni + 1;
if AMIDISPLAY.ViewInds.ni > AMIDATA.Ni;
    AMIDISPLAY.ViewInds.ni = 1;
end
   update_viewfrfs_plot;