function [] = update_viewfrfs_plot

global AMIDISPLAY AMIDATA AMIMODES AMISET

no = AMIDISPLAY.ViewInds.no; ni = AMIDISPLAY.ViewInds.ni;
AMIDISPLAY.ViewFRFsTitle = ['Viewing individual FRFs: H(',num2str(AMIDISPLAY.ViewInds.no),...
    ',',num2str(AMIDISPLAY.ViewInds.ni),')'];
% Magnitude Plot
axes(AMIDISPLAY.hviewfrfsS1);
hls(1) = semilogy(AMIDATA.wsplot, abs(AMIDATA.H(:,no,ni)),'Color',0.3*[1,1,1]);  hold on;  grid on;
ylim([0.5*min(abs(AMIDATA.H(:,no,ni))),1.1*max(abs(AMIDATA.H(:,no,ni)))]);
% line(AMIDATA.wsplot, AMIDATA.Xc,'Color','b','LineStyle','-'); 
if ~isempty(AMISET.Ts) && isfield(AMIMODES,'X_LRUR');
    % Check this - should do this whether C-time or D-time is used - why
    % the statement above?? (MSA 12/2008)
    hls(2) = line(AMIDATA.wsplot, abs(sum(AMIMODES.X_model(:,no,ni,:),4)+...
        AMIMODES.X_LRUR(:,no,ni)),'Marker','.','LineStyle',':','color',[0,0.5,0]);
    hls(3) = line(AMIDATA.wsplot, abs(AMIDATA.H(:,no,ni) - sum(AMIMODES.X_model(:,no,ni,:),4) - ...
        AMIMODES.X_LRUR(:,no,ni)),'color',[1,0.1,0.1]);
else
    hls(2) = line(AMIDATA.wsplot, abs(sum(AMIMODES.X_model(:,no,ni,:),4)),'Marker','.','LineStyle',':','color',[0,0.5,0]);
    hls(3) = line(AMIDATA.wsplot, abs(AMIDATA.H(:,no,ni) - sum(AMIMODES.X_model(:,no,ni,:),4)),'color',[1,0.1,0.1]);
end
hold off;
ylabel('Magnitude');
legend('Data','Fit','Data-Fit');
title(['\bf',AMIDISPLAY.ViewFRFsTitle]);
set(hls,'LineWidth',2);

% Phase Plot
axes(AMIDISPLAY.hviewfrfsS3);
hls(1) = plot(AMIDATA.wsplot, 180/pi*angle(AMIDATA.H(:,no,ni)),'Color',0.3*[1,1,1]);  hold on;  grid on;
% line(AMIDATA.wsplot, AMIDATA.Xc,'Color','b','LineStyle','-'); 
hls(2) = line(AMIDATA.wsplot, 180/pi*angle(sum(AMIMODES.X_model(:,no,ni,:),4)),'Marker','.','LineStyle',':','color',[0,0.5,0]);
% hls(3) = line(AMIDATA.wsplot, 180/pi*angle(AMIDATA.H(:,no,ni) - sum(AMIMODES.X_model(:,no,ni,:),4)),'color',[1,0.1,0.1]);
ylabel('Phase (^o)'); hold off;
xlabel(['\bfFrequency (',AMISET.flabel,')']);

% Nyquist Plot:
axes(AMIDISPLAY.hviewfrfsS2);
plot(real(AMIDATA.H(:,no,ni)),imag(AMIDATA.H(:,no,ni,:)),'Color',0.3*[1,1,1]);
line(real(sum(AMIMODES.X_model(:,no,ni,:),4)),imag(sum(AMIMODES.X_model(:,no,ni,:),4)),...
    'Color',[0,0.5,0],'LineStyle',':','Marker','.');
title('\bfNyquist Plot'); xlabel('\bfRe\{H(\omega)\}'); ylabel('\bfIm\{H(\omega)\}');
legend('Data','Fit');