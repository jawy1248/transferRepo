function [varargout] = ami(H,ws,varargin)
% [AMIMODES] = ami(H,ws)
%
% Function that performs modal parameter identification on a given
% transfer function 'H' and accompanying frequency vector 'ws'
% where the frequencies are in rad/s.
%   H is a matrix whose size is [Nf x No x Ni] where
%       Nf is the number of frequency lines
%       No the number of outputs
%       Ni the number of inputs
%
% AMIMODES is a structure containing the modal paramters identified
% including the natural frequencies, damping ratios and residue vectors.
%
% Optional Paramters:
% [AMIMODES] = ami(H,ws,AMI_set)
%
% The AMI_set structure contains the default options for AMI.  If this argument is blank
% the default options are specified.  To see the default options or modify them use the
% following command:
%   AMI_set = AMIG_def_opts
%
%   Individual options can be modified as follows:
%       AMI_set.NumPoints = 0.707;
%
% To wait for execution:  Insert the following into the m-file that calls AMI
%     global AMIMODES AMIDISPLAY AMIDATA AMI_set
%     waitfor(AMIDISPLAY.hmain,'UserData','finished');
%
%
%
% Available options are described below and in AMIG_def_opts
%
% ****************** DATA DESCRIPTION: ******************
% AMI_set.DVA     =     Tells AMI whether the data is Displacement/Force (D),
%                       Velocity/Force (V), or Acceleration/Force (A).
% AMI_set.OMA     =     Switch between standard modal analysis and operational:
%                       (false or 0) [default] FRF data for standard EMA
%                       (true or 1) data is output spectra for operational
%                           modal analysis.
%
% ****************** AMI OPTIONS:  CRITICAL & SEMI-CRITICAL ******************
% AMI_set.NumPoints =   Number of points on each side of max(abs(H)) to use
%                       for curve fits during subtraction stage.
%                       If num_pts < 1 it is interpreted as a level and all
%                       points such that abs(H) > level*max(abs(H)) are taken.
% AMI_set.NumPointsIsol = Number of points on each side of max(abs(H)) to use
%                       for curve fits during the subtraction stage.
% AMI_set.IsolIter =    Maximum number of iteration in the Mode Isolation & Refinement stage.
% AMI_set.NoisePoints = Approx noise width in transfer functions.  When finding the points around a peak,
%                       AMI steps down until this many points beyond the peak are also below the given level.
% AMI_set.FRF_RF  =     Minimum acceptable reduction factor.  AMI Propts for a higher order fit if
%                       this reduction is not achieved (during subtraction).
% AMI_set.FRF_RF_full = Minimum acceptable reduction factor for full rank-residue model.  Used to help
%                       AMI decide whether to try an MDOF fit.
% AMI_set.MaxFitStepIter = Maximum number of iterations to use when refining linear least squares
%                       fits by accounting for the denominator weighting of the FRF data.
%                       i.e. using the method of Sanathanan and Koerner.
% AMI_set.NumeratorTerms = Number of Extra Numerator terms to use in least squares fits.
% AMI_set.SDOFAlg =     Algorithm to use for SDOF fits:
%                           0 => RFP_MATTtls_ami (Allows for extra numerator terms)
%                           1 => cf_etrue_simo (Faster algorithm, no numerator terms allowed)
%                           2 => RFP_MRealtls_ami (Real modes - one mode only)
% AMI_set.BandMode =    Method of identifying data to use in fits.
%                       'fixed' - Uses the bands identified in the subtraction stage throughout the
%                               mode isolation and refinement stage.
%                       'auto' - Uses the AMI_set.NumPointsIsol setting to identify the peak data in
%                               each fit.  This method can be unreliable and is slower.
% AMI_set.Smin =        Relative magnitude of singular value S(j)/S(1) above which other modes might
%                       be present in the data.
% AMI_set.AutoMode =    Automatic or manual termination of the subtraction stage after AutoSubLevel is met.
%                       'manual' (default) - User tells AMI when to stop looking for modes.
%                       'auto' - AMI stops looking for modes if unreasonable results are obtained.
% AMI_set.Zeroing =     Tells AMI how much to zero during the subtraction stage.
%                       'off' (default) - do not zero
%                       'fb' - zero the fit band
% AMI_set.Ts =          Sample Increment.
%                       [] (default) - AMI fits a continuous-time H(w) model to the measurements.
%                       Ts = increment between time samples.  If this is specified, AMI fits a
%                       discrete-time model H(z) to the data, where Z = exp(i*w*Ts)
% AMI_set.LRUR =        'on', 'off' (default) fit Lower and Upper
%                       Residuals, see find_lrur.m
% AMI_set.LRUR_dfrac =  0 < number <= 1 - fraction of the data to use in
%                       the fit for LRUR.  Using a value less than 1 helps
%                       to reject outliers that contaminate the solution.
%                       Default: 0.25
% AMI_set.ResReduce  =  'R1' (default): Reduce residues to rank 1
%                       'raw' : Allow residue matrices to have rank > 1
% AMI_set.OMARealRes =  true (1) : Force real residues for OMA.
%                       This seems to give better results.
%                       false (0) (default) : allow complex residues.
%
% ****************** AMI OPTIONS:  INTERACTION & DISPLAY ******************
% AMI_set.FreqScale =   Scale factor for frequency axis in plots.  For example:
%                       1 => freq. axis in rad/s, 2*pi => Hz
% AMI_set.FigDisp    =  Flag which indicates which figures to show:
%                       (1) = All figures, (2) = Convence progression figure only, other = Off
% AMI_set.ShowIsolSteps = Tells AMI whether to display each isolation step in an interactive mode.
%                       Valid values 'y' or 'n'.
% AMI_set.Refs    =     Reference FRF indices--Reference FRFs are plotted in subtraction an isolation
%                       stages for monitoring purposes.
% AMI_set.AutoSubLevel =The subtraction stage termination parameter. Subtraction continues
%                       automatically until: max(abs(H_current)) < AutoSubLevel*max(abs(H_original)).
% AMI_set.MaxModes =    The maximum number of modes to identify during the
%                       subtraction stage.
% AMI_set.SubDataFile = File for saving the data at the end of the subtraction stage when the automatic
%                       mode is used (AMI_set.AutoMode).  In manual mode the user is prompted for a
%                       file name.  If blank the subtraction data is not saved.
%
%
% Note, to get classical modal parameters
%
% fn = AMIMODES.mode_store(:,1)/2/pi;   % These are the natural frequencies in Hz
% zt = AMIMODES.mode_store(:,2);	% These are the damping ratios, zeta
% res = (-2*real(diag(conj(AMIMODES.mode_store(:,3)))*AMIMODES.A_store)).';
%
% By Matt Allen
%

% Versions:
% v3 - Version used in MSA Thesis.  Latest version as of May, 2005
% v4 - Single plot for all subtraction steps.  Started Oct 11, 2005
%

% Set up variables
clear global AMI* % Clear any data in these variables
global AMIDATA AMISET AMIDISPLAY AMIMODES AMISubData
AMIDATA.H = H; AMIDATA.ws = ws;
clear H ws

if isempty(varargin);
    AMISET = AMIG_def_opts; % Use default options if no options structure is passed in.
else
    AMISET = varargin{1};
    % Should do some kind of error checking here to be sure that
    % AMISET is valid.
end

% Put X, w in Column form:  Each FRF appears as a column of X
[AMIDATA.Nf AMIDATA.No AMIDATA.Ni] = size(AMIDATA.H); [d e] = size(AMIDATA.ws);
if AMIDATA.Nf<AMIDATA.No;
    warning('More References than Freq. Points, Check Input Format Convention');
end;
if d<e; AMIDATA.ws = AMIDATA.ws.'; end;
% Create Discrete-time z vector for H(z).  This is actually z/i, and is
% substituted for omega so that i*omega = i*z/i = z.
if ~isempty(AMISET.Ts);
    AMIDATA.zs = -i*exp(i*AMIDATA.ws*AMISET.Ts);
    if AMISET.SDOFAlg ~= 0; error('Must Use SDOFAlg = 0 with Discrete Time Data'); end
end
% The FRF storage convention is as follows:
%   The first dimension indexes the frequency, thus size(X,1) = length(w)
%   The second dimension indexes the response point while the third dimension
%       indexes the drive point.  Thus X(:,:,r) contains all of the FRF data
%       for the r-th drive point
%   The storage of X_fit models and Residues are made to correspond, in this way
%       X, X_fit and A_fit all tranform from MIMO to pseudo SIMO (of length No*Ni)
%       using mimo2simo_rs.m

% Interpret Setting Structure & Check the validity of the settings.
AMISET.DVA = upper(AMISET.DVA);
if AMISET.DVA ~= 'D' && AMISET.DVA ~= 'V' && AMISET.DVA ~= 'A';
    error(['DVA string not recognized, valid values are ''D'', ''V'', ''A'': ',AMISET.DVA]);
end
if AMISET.FreqScale == 1;   % Labeling Strings for Axes
    AMISET.flabel = 'rad/s'; AMISET.fl2 = 'w';
elseif AMISET.FreqScale == 2*pi;
    AMISET.flabel = 'Hz'; AMISET.fl2 = 'f';
else
    AMISET.flabel = '?'; AMISET.fl2 = '?';
end

if AMISET.SDOFAlg == 1 && AMISET.NumeratorTerms ~= 0;
    warning('cf_etrue_simo algorithm does not allow extra numerator terms, overriding request and using zero');
    AMISET.NumeratorTerms = 0;
end
if AMISET.SDOFAlg == 1 && AMISET.OMA || AMISET.SDOFAlg == 2 && AMISET.OMA;
    error('OMA only works with RFPM.m algorithm, set (SdOFAlg=0).');
end

AMISET.Zeroing = lower(AMISET.Zeroing);
if ~strcmp(AMISET.Zeroing,'fb') & ~strcmp(AMISET.Zeroing,'xfb')& ~strcmp(AMISET.Zeroing,'off');
    warning(['Unrecognized zeroing option: AMISET.Zeroing ',AMISET.Zeroing]);
end
if strcmp(AMISET.ResReduce,'phi') && ~isfield(AMISET,'Ps')
    error('Must Supply Drive Point Indices ''Ps'' for mode vector ''phi'' output');
end

if AMISET.SDOFAlg == 2; warning('THIS HAS NOT BEEN OPTIMIZED!!! - See notes on complex modes to real.'); end

% Initialize some variables.
AMIDATA.dw = AMIDATA.ws(2)-AMIDATA.ws(1);
AMIDATA.Hc = comp_FRF(AMIDATA.H);

% Main Figure Window
ami_setup_display;

% #########################################################################
% Start Subtraction
% #########################################################################

AMIMODES.CurrSub.curr_mode = 1; AMIMODES.CurrSub.curr_step = 1;
n_sub_figs = 1;
A_store = []; mode_store = [];

GLFlag = 'y';
while GLFlag == 'y'; %Global Loop
    
    % Save data at end of Subtraction for Presentation
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if 0;%strcmp(AMISET.AutoMode,'manual')
        set(AMIDISPLAY.displaytext, 'String', 'Save Subtraction Data?');
        AMIDISPLAY.hyes = uicontrol('Parent',AMIDISPLAY.hmain, ...
                'Units','normalized', ...
                'Position',[0.85 0.1 0.03 0.075], ...
                'Callback','global AMIDATA; AMIDATA.savedata = ''y''; global AMIDISPLAY; set(AMIDISPLAY.hyes,''UserData'',''done''),', ...
                'String','Yes', ...
                'Tag','Zero');
                AMIDISPLAY.hno = uicontrol('Parent',AMIDISPLAY.hmain, ...
                'Units','normalized', ...
                'Position',[0.91 0.1 0.03 0.075], ...
                'Callback','global AMIDATA; AMIDATA.savedata = ''n''; global AMIDISPLAY; set(AMIDISPLAY.hyes,''UserData'',''done''),', ...
                'String','No', ...
                'Tag','Zero');
            waitfor(AMIDISPLAY.hyes,'UserData','done');
            save_data = AMIDATA.savedata;
            delete(AMIDISPLAY.hyes);
            delete(AMIDISPLAY.hno);
        if AMIDATA.savedata == 'y';
            set(AMIDISPLAY.displaytext, 'String', 'File Name? (Example: MSSP2004_Z24_sub_end.mat)');
                    AMIDISPLAY.hname = uicontrol('Parent',AMIDISPLAY.hmain, ...
                    'Style', 'Edit',...
                    'Units','normalized', ...
                    'Position',[0.878 0.1 0.03 0.075], ...
                    'Callback',' ;global AMIDISPLAY; set(AMIDISPLAY.horder,''UserData'',''done''),', ...
                    'Tag','Zero');
                    waitfor(AMIDISPLAY.hname,'UserData','done');
            name = get(AMIDISPLAY.hname, 'String');
            delete(AMIDISPLAY.hname);
            if ~isempty(name);
                eval(['save ',name]);
            end
        end
    elseif 0;%~isempty(AMISET.SubDataFile);
        set(AMIDISPLAY.displaytext,'String','Subtraction data saved as: ',AMISET.SubDataFile);
        eval(['save ',AMISET.SubDataFile]);
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % ###########################################################################
    % End of Subtraction Stage
    
    % #########################################################################
    % ISOLATION STAGE
    if 0;%strcmp(AMISET.AutoMode,'isolate')
        set(AMIDISPLAY.displaytext,'String','Starting Isolation Stage...');
    end
    % Prompt the User to Look for More Modes:
    if strcmp(AMISET.AutoMode,'isolate');
        
        % Let user eliminate some modes if desired
        set(AMIDISPLAY.displaytext,'String','Look for More Modes?');
        AMIDISPLAY.hyes = uicontrol('Parent',AMIDISPLAY.hmain, ...
                'Units','normalized', ...
                'Position',[0.85 0.1 0.03 0.075], ...
                'Callback','global AMIDATA; AMIDATA.moremodes = ''y''; global AMIDISPLAY; set(AMIDISPLAY.hyes,''UserData'',''done''),', ...
                'String','Yes', ...
                'Tag','Zero');
                AMIDISPLAY.hno = uicontrol('Parent',AMIDISPLAY.hmain, ...
                'Units','normalized', ...
                'Position',[0.91 0.1 0.03 0.075], ...
                'Callback','global AMIDATA; AMIDATA.moremodes = ''n''; global AMIDISPLAY; set(AMIDISPLAY.hyes,''UserData'',''done''),', ...
                'String','No', ...
                'Tag','Zero');
            waitfor(AMIDISPLAY.hyes,'UserData','done');
            GLFlag = AMIDATA.moremodes;
            delete(AMIDISPLAY.hyes);
            delete(AMIDISPLAY.hno);
    else
        GLFlag = 'n';
    end
    
    if GLFlag == 'y';
        x = sprintf(['Looking for More Modes.  Next Mode #: ',...
            num2str(AMIMODES.CurrSub.curr_mode)]);
        set(AMIDISPLAY.displaytext,'String',x);
        % AMIDATA.X = AMIDATA.X_res_MIR;
        % AMIDATA.Xc = comp_FRF(AMIDATA.X);
    end
    
    %if strcmp(AMISET.AutoMode,'manual');
    
    %disp('########################## Saving Debug Data #####################');
    %save ms_debugdata.mat
    
end % End Global Loop

AMIMODES.Phi_store = [];

if nargout < 2;
    varargout{1} = AMIMODES;
else
    varargout{1} = AMIMODES.mode_store;
    varargout{2} = AMIMODES.A_store;
    varargout{3} = AMIMODES.Phi_store;
    varargout{4} = AMIMODES.X_model;
end
