function [] = advance_viewfrfs_plot;

global AMIDISPLAY AMIDATA AMIMODES AMISET

AMIDISPLAY.ViewInds.no = AMIDISPLAY.ViewInds.no + 1;
if AMIDISPLAY.ViewInds.no > AMIDATA.No;
    AMIDISPLAY.ViewInds.no = 1;
    AMIDISPLAY.ViewInds.ni = AMIDISPLAY.ViewInds.ni + 1;
    if AMIDISPLAY.ViewInds.ni > AMIDATA.Ni;
        AMIDISPLAY.ViewInds.no = 1; AMIDISPLAY.ViewInds.ni = 1;
    end
end
update_viewfrfs_plot;