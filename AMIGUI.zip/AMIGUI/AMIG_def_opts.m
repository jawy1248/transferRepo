function [AMI_set] = AMIG_def_opts
% [AMI_set] = AMI_def_opts
%
% Function which returns a structure containing the default options for AMI.
% The options are described below.  Individual options can be changed, as 
% follows:
% 
%   AMI_set.DVA='A'
%
% ****************** DATA DESCRIPTION: ************************************
% DVA = ('D','V','A') Tells AMI whether the data is:
%           Displacement/Force (D) 
%           Velocity/Force (V)
%           Acceleration/Force (A)
% OMA = (0 or 1) Switch between standard modal analysis and operational:
%       	(false or 0) [default] H = FRF data for standard EMA
%       	(true or 1) H = output spectra for operational modal analysis.
%
% ****************** AMI OPTIONS:  CRITICAL & SEMI-CRITICAL ***************
% NumPoints   = Number of points on each side of max(abs(H)) to use for 
%               curve fits during subtraction stage.  
%               If num_pts < 1 it is interpreted as a level and all points
%               are taken such that abs(H) > level*max(abs(H)).
% NumPointsIsol = Number of points on each side of max(abs(H)) to use for
%               curve fits during the isolation stage. (see NumPoints)
% IsolIter    = Maximum number of iterations allowed in the Mode Isolation
%               & Refinement stage.
% NoisePoints = Approx noise width in transfer functions.  When finding the
%               points around a peak, AMI steps down until this many points
%               beyond the peak are also below the given level.
% FRF_RF      = Minimum acceptable reduction factor: RF=max(H)/max(H-H_fit).
%               AMI Prompts for a higher order fit if this reduction is not
%               achieved (during subtraction).
% FRF_RF_full = Minimum acceptable reduction factor for full rank-residue
%               model.  RF=max(H)/max(H-H_fit) where H_fit has a residue
%               matrix that may have rank>1 (nonphysical).  This is used to
%               help AMI decide whether to try an MDOF fit.
% Smin =        Relative magnitude of singular value S(j)/S(1) above which
%               other modes are assumed to be present in the data.
% AutoMode =    Automatic or manual termination of the subtraction stage
%               after AutoSubLevel is met.
%               	'manual' (default) - User tells AMI when to stop looking for modes.
%               	'auto' - AMI stops looking for modes when unreasonable results are obtained.
% AutoSubLevel = The subtraction stage termination parameter. Subtraction 
%                   continues automatically until: 
%                   max(abs(H_current)) < AutoSubLevel*max(abs(H_original))
% Zeroing =     Tells AMI how much to zero during the subtraction stage.
%               This helps to avoid looking for additional modes in a
%               frequency band where a mode has already been extracted.
%               	'off' (default) - do not zero
%               	'fb' - zero the fit band
% Ts =          Sample Increment.
%               	[] (default) - AMI fits a continuous-time H(\omega)
%                       model to the measurements.
%               	Ts = increment between time samples.  If this is 
%                       specified, AMI fits a discrete-time model H(z) to
%                       the data, where Z = exp(i*w*Ts).
% LRUR =        'on', 'off' (default) fit Lower and Upper Residuals, see 
%                   find_lrur.m.  This has not been thoroughly debuged.
% LRUR_dfrac =  0 < number <= 1 - fraction of the data to use in the fit
%                   for LRUR.  Using a value less than 1 helps to reject
%                   outliers that contaminate the solution.
%                       Default: LRUR_dfrac=0.25
% ResReduce  =  'R1' (default): Reduce residues to rank 1
%               'raw' : Allow residue matrices to have rank > 1
% OMARealRes =  true (1) : Force real residues for OMA. This seems to give
%               better results although the reasons are not fully known.
%               false (0) (default) : allow complex residues.
%
% ****************** AMI OPTIONS:  INTERACTION & DISPLAY ******************
% FreqScale =   Scale factor for frequency axis in plots.  For example: 
%               	1 => freq. axis in rad/s, 2*pi => axis in Hz
% FigDisp    =  Flag which indicates which figures to show:
%               	(1) = All figures
%                   (2) = Convence progression figure only, other = Off
% ShowIsolSteps = ('y','n') Tells AMI whether to display each isolation
%                   step in an interactive mode.
% Refs    =     Reference FRF indices--Reference FRFs are plotted in
%                   subtraction and isolation stages for monitoring
%                   purposes.
% MaxModes =    The maximum number of modes to identify during the
%               	subtraction stage.  Helpful when using automatic mode.
%
% ****************** AMI OPTIONS:  Other **********************************
% (The options below typically do not need to be changed or are for 
% advanced users only).
%
% MaxFitStepIter = Maximum number of iterations to use when refining linear
%               least squares fits by accounting for the denominator
%               weighting of the FRF data. i.e. using the method of
%               Sanathanan and Koerner.
% NumeratorTerms = Number of Extra Numerator terms to use in least squares
%               fits.
% SDOFAlg =     Algorithm to use for SDOF fits:
%               	0* => RFP_MATTtls_ami (Allows for extra numerator terms)
%               	1 => cf_etrue_simo (Faster algorithm, no numerator terms allowed)
%               	2 => RFP_MRealtls_ami (Real modes - one mode only)
% BandMode =    Method of identifying data to use in fits.
%               	'fixed' - Uses the bands identified in the subtraction
%                       stage throughout the mode isolation and refinement stage.
%                   'auto' - Uses the AMI_set.NumPointsIsol setting to
%                       identify the peak data in each fit.  This method
%                       can be unreliable and is slower.
% SubDataFile = File for saving the data at the end of the subtraction
%                   stage when the automatic mode is used
%                   (AMI_set.AutoMode).  In manual mode the user is
%                   prompted for a file name.  If blank the subtraction
%                   data is not saved.

AMI_set.DVA = 'A'; % Acceleration - default changed on 6/28/2017
AMI_set.OMA = false;

AMI_set.NumPoints = 0.707;
AMI_set.NumPointsIsol = 0.707; 
AMI_set.IsolIter = 50;
AMI_set.NoisePoints = 0;
AMI_set.FRF_RF = 3;
AMI_set.FRF_RF_full = 1;
AMI_set.MaxFitStepIter = 1;
AMI_set.NumeratorTerms = 0;
AMI_set.SDOFAlg = 0; % 0 - rfpm (RFP_...), 1 - cf_msa, 2 - rfpm_real (real modes)
AMI_set.BandMode = 'fixed'; % 'auto';
AMI_set.Smin = 0.25;
AMI_set.AutoMode = 'manual';
AMI_set.Zeroing = 'off';
AMI_set.LM = 'on'; % MSA changed default to "on" on 8 Oct 2015
AMI_set.ResReduce = 'R1'; % 'raw','phi'
AMI_set.Ts = [];
AMI_set.LRUR = 'off';% Fit Lower and Upper Residuals
AMI_set.LRUR_dfrac = 0.25;
AMI_set.OMARealRes = false;

AMI_set.FreqScale = 2*pi; % Hz by default
AMI_set.FigDisp = 1;
AMI_set.ShowIsolSteps = 'n';
AMI_set.Refs = [1,1];
AMI_set.AutoSubLevel = 0.2;
AMI_set.MaxModes = 30;
AMI_set.SubDataFile = [];

AMI_set.SaveSub = 'n';
AMI_set.SaveSubName = [];