function [mode_params,A_fit]=cf_msa(Hpeak,wpeak,SubOrIsol,varargin)

% [X_fit,mode_params,A_fit,wp_indx,conv_data]=cf_etrue_simo(X_work,X_comp,w,CF_set)
%
%   where:  mode_params=[wn_fit z_fit lam_fit];
%
% A pseudo-linear curve fitting method for damped modes modal analysis
% Matt Allen-5-6-2002 Based initially on solution by Jerry H. Ginsberg
% This M-file performs a linear-least squares fit on input data
% and returns natural frequency, damping ratio and residuals.
%
% CF_set defines options for this m-file:
%           CF_set = [num_pts TF_type SuborIsol np max_iter lam_guess mimo_flag]
% num_pts = Number of points on each side of max(abs(X)) to use
%           during subtraction and isolation stages.
%           If num_pts < 1 it is interpreted as a level and all
%           points such that abs(X) > level*max(abs(X)) are taken
% TF_type = Defines the Transfer Function Units, for example,
%           1 = Displacement over Force
%           2 = Acceleration over Force
% SuborIsol = Flag which tells cf_lin whether this is the subtraction
%           stage or isolation stage.  Needed for defining which
%           points to use in the fit.  1 - Subtraction, 2 - Isolation
% np      = Number of sequential points which must be below a given
%           level when identifying the peak data.
% max_iter = Maximum number of iterations to use in correcting the
%           weighting for the linear least squares fit (1 by default)
% lam_guess = An initial guess at the eigenvalue, used to tell the algorithm
%           where to look for the peak that you want to fit.  The algorithm
%           uses the natural frequency and bandwidth to define a search location.
% mimo_flag = 0 for simo, a model is created
%           1 for = mimo, model creation is skipped.
%
global AMIDATA AMISET AMIMODES

Nmeas = size(Hpeak,2)*size(Hpeak,3);
Nfreq = length(wpeak);

if strcmp(AMISET.DVA,'D'); % Displacement Data
    % Hpeak = Hpeak;
elseif strcmp(AMISET.DVA,'V'); % Velocity Data
    % Convert Velocity/Force TF to Displacement
	% Change of variables, Scale factor must be included when integrating
	% Note that this is equiavent to re-deriving the SDOF algorithm for acceleration.
    for ii = 1:1:Nmeas;
        Hpeak(:,ii) = (Hpeak(:,ii)./(i*wpeak));
    end
elseif strcmp(AMISET.DVA,'A');;
    % Convert Acceleration/Force TF to Displacement
	% Change of variables, Scale factor must be included when integrating
	% Note that this is equiavent to re-deriving the SDOF algorithm for acceleration.
    for ii = 1:1:Nmeas;
        Hpeak(:,ii) = (Hpeak(:,ii)./-wpeak.^2);
    end
else
    error('Unrecognized TF Type');
end

% Condition Peak Data to avoid Numerical Difficulty ####################
if isempty(AMISET.Ts);
    % Scale the Transfer function by the average value.
		sf_x = mean(mean(abs(Hpeak)));
		Hpeak = Hpeak/sf_x;
	% Scale w by average value
		sf_w = mean(wpeak);
		wpeak = wpeak/sf_w;
else % Discrete time - but this algorithm isn't totally done yet for this case. (MSA 12/2008)
    sf_x = 1; sf_w = 1;
end
% % Scale the Transfer function by the average value.
% 	sf_x = mean(mean(abs(Hpeak)));
% 	Hpeak = Hpeak/sf_x;
% % Scale w by average value
% 	sf_w = mean(wpeak);
% 	wpeak = wpeak/sf_w;

Ww = ones(size(wpeak));  Dlam = 1; DA = 1; its = 0;
while Dlam > 1e-10 | DA > 1e-10
    its = its+1;
   if its > AMISET.MaxFitStepIter; its = its-1; break; end 

    % Even Faster Scheme, Even Less Memory
    % Avoids sums in forming, and uses a smaller matrix solution
    % Solve for denominator coefficients first
	%       A = diag(XtX(1:2,1:2)) B = XtX(1:2,3:end) D = diag(XtX(3:end,3:end))
	% tic
    % Pre-define elements
    A11 = 0; A22 = 0; B11 = zeros(1,Nmeas); B12 = B11; B22 = B11;
    F21 = zeros(Nmeas,1); E11 = 0;
    DrsDis = abs(Ww).^2;
    % Start forming Matrices
	for ii = 1:1:length(wpeak);
        % Start A's
        A11t = [DrsDis(ii)*Hpeak(ii,:)*(Hpeak(ii,:)')];
        A11 = A11 + A11t;
        A22 = A22 + 4*wpeak(ii)^2*A11t;
        % Start B's - don't forget the factors 2,4,8
        B11 = B11 + DrsDis(ii)*real(Hpeak(ii,:));
        B12 = B12 + DrsDis(ii)*wpeak(ii)*imag(Hpeak(ii,:));
        B22 = B22 + DrsDis(ii)*wpeak(ii)^2*real(Hpeak(ii,:));
        % Start E vector
        E11 = E11 + wpeak(ii)^2*A11t;
        % Start F vector
        F21 = F21 + DrsDis(ii)*wpeak(ii)^3*imag(Hpeak(ii,:)).';
	end
    A = [A11 0;
        0, A22];
    B = [2*B11, -2*B12;
        4*B12, 4*B22];
    E = [E11;
        0];
    F = [2*B22.';
        -2*F21];
	Dinv = (4*sum(DrsDis))^-1;
    % Solve for Eigenvalue, then residues
    %   d = [abs(lam)^2; real(lam)]
    %   n = [{lrAr+liAi}; {Ar}]
    d = (A - Dinv*(B*(B.')))\(E - Dinv*B*F);
    n = Dinv*(F-B.'*d);
    
    coeff = [d; n];
	% t_den_only = toc
    
	lr_fit = coeff(2);
	li_fit = sqrt(coeff(1)-lr_fit^2);
	Ar = coeff((3+Nmeas):(2+2*Nmeas));
	Ai = (coeff(3:(2+Nmeas))-lr_fit*Ar)/li_fit;
	
	A_fit = (Ar + i*Ai).';
	lam_fit = lr_fit + i*li_fit;
    [abs(lam_fit) -real(lam_fit)/abs(lam_fit)];
    
    Ww = ((abs(lam_fit)^2)*ones(size(wpeak)) - wpeak.^2 - 2*i*wpeak*real(lam_fit));
    Ww = Ww.^-1;

    % Monitor Convergence
    lfi(its) = lam_fit;
    Afi(its,:) = A_fit;
    if its > 1;
        Dlam = abs(lam_fit - lfi(its-1));
        DA = max(abs(A_fit - Afi(its-1,:)));
    end

end
if its == AMISET.MaxFitStepIter & AMISET.MaxFitStepIter > 1;
    disp('Warning:  Maximum iterations reached without convergence');
end
%disp(['Iterations: ',num2str(its)]);
conv_data(1,1) = its;

% Rescale Modal Properties: ################ VIP ##################
	lam_fit = lam_fit*sf_w;
	A_fit = A_fit*sf_w*sf_x;
	% Ar = Ar*sf_w*sf_x;  Ai = Ai*sf_w*sf_x;

% Find zeta, wn from eigenvalue
wn_fit = abs(lam_fit);
z_fit = -real(lam_fit)./wn_fit;

mode_params=[wn_fit z_fit lam_fit];
A_fit = simo2mimo_rs(A_fit,AMIDATA.Ni);