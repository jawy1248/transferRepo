function [] = Mult_CNP_MIMO(ws,Xw,Xw_fit,A_fit,SubplotHandle,varargin);

% Mult_CNP_MIMO(Xw,Xw_fit,A_fit,SubplotHandle,peak_band);
% 
% Creates A Composite Nyquist Plot of Fitted Versus Actual Data
% One line is shown for each mode in Xw_fit and A_fit.
%
% 'peak_band' is an optional argument which specifies some
% points to be plotted as red dots.

% Check Size Compatibilities
[a,b,c] = size(Xw);
if ~isempty(Xw_fit);
	[d,e,f,g] = size(Xw_fit);
    if b~=e | c~=f;
        disp('Warning: Sizes Not Compatible for Mult_NP_MIMO');
        disp('Size Xw:');
        size(Xw)
        disp('Size Xw_fit');
        size(Xw_fit)
    end
end
if ~isempty(varargin)
    peak_band = varargin{1};
else
    peak_band = [];
end
N = size(Xw_fit,4);
    if size(A_fit,1) ~= N; error('Number of modes in Xw_fit and A_fit do not match'); end

h = subplot(SubplotHandle);
    cols = get(h,'ColorOrder');
    if size(cols,1) < N;
        Ncol = size(cols,1);
        cols((Ncol+1):N,:) = jet(N-Ncol);
    end
%plot(0,0);
for ii = 1:1:N;
    Xsub = sum(Xw_fit(:,:,:,[1:ii-1,ii+1:N]),4);
    Xwcn = mfrfcond((Xw-Xsub),A_fit(ii,:,:));
    line(real(Xwcn), imag(Xwcn),'Color',cols(ii,:));
    if ~isempty(peak_band);
        line(real(Xwcn(peak_band)), imag(Xwcn(peak_band)),'Color',cols(ii,:),...
            'Color',cols(ii,:),'LineStyle', 'none','Marker', '.');
    end
end
if ~isempty(Xw_fit);
	for ii = 1:1:N;
        Xfcn = mfrfcond(Xw_fit(:,:,:,ii),A_fit(ii,:,:));
        hl(ii) = line(real(Xfcn), imag(Xfcn),'Color',cols(ii,:),...
            'LineStyle', ':','Marker', 'o','MarkerSize',3);
        leg_txt{ii} = ['Mode ',num2str(ii)];
	end
end
% Default Title and Labels
title('Composite Nyquist Plots: Data-(solid) vs. Fit-(dotted)');
xlabel('Real'); ylabel('Imag');
legend(hl,leg_txt);





