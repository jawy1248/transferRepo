function [Xout] = FD_DVA(Xin,ws,from_str,to_str);
% Convert FRF from Displacment, Velocity or Accelerance to D, V, A
% Assumes the FRFs are in AMI's standard form:
%   Dimensions correspond to:  Frequency, No, Ni
%
% [Xout] = FD_DVA(Xin,ws,from_str,to_str);
%
% Examples:
% [Xaccel] = FD_DVA(Xdisp,ws,'disp','accel');
% [Xaccel] = FD_DVA(Xvel,ws,'vel','accel');

% Create vector to multiply Xin to create output.
    if strcmp(lower(from_str),'disp')
        omega_pow = 0;
    elseif strcmp(lower(from_str),'vel')
        omega_pow = -1;
    elseif strcmp(lower(from_str),'accel')
        omega_pow = -2;
    else
        error('Unsupported Format');
    end

    if strcmp(lower(to_str),'disp')
        omega_pow = omega_pow + 0;
    elseif strcmp(lower(to_str),'vel')
        omega_pow = omega_pow + 1;
    elseif strcmp(lower(to_str),'accel')
        omega_pow = omega_pow + 2;
    else
        error('Unsupported Format');
    end

    wt_vec = (i*ws(:)).^omega_pow;
    
[Nf,No,Ni] = size(Xin);

Xin = mimo2simo_rs(Xin);
    
    Xout = zeros(size(Xin));
    for k = 1:size(Xin,2);
        Xout(:,k) = wt_vec.*Xin(:,k);
    end
    
% Reshape
Xout = simo2mimo_rs(Xout,Ni);
% Xin = simo2mimo_rs(Xin,Ni);