% M-file which fits data using the Poly-Reference Frequency Domain
% algorithm given by Maia (p. 248) derived by L. Zhang.

clear all; close all;

load car_tfs_v3_n075.mat

for ii = 1:1:length(Gs)
    H(:,:,ii) = [Gs(ii,1:2).' Gs(ii,3:4).'];
end

% Input takes H and ws
[p q L] = size(H)

E = []; F = [];
for ii = 1:1:size(H,3)
    E = [E [H(:,:,ii); eye(size(H,2))]];
end

w_vec(1:2:2*length(ws)) = ws;
w_vec(2:2:2*length(ws)) = ws;

F = E(1:size(H,1),:)*i*diag(w_vec);

E = E.';
F = F.';

A_psi = E\F;
A = A_psi(1:p,1:p).';

lam_prfd = eig(A)
lamss