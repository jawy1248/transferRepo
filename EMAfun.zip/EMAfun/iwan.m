function [f,y0,k]=iwan(x,y0,params)
% Function which computes the force, slip state and instantaneous stiffness
% of an Iwan joint.
% 
% [f,y0,k]=iwan(x,y0,params);
%
%  params=[chi, phi_max,R, S]
%  y0 = slider positions (nsliders+1) (+1 for the macroslip)
%  k = current value of tangent stiffness
%  f = force in slider
%
% Written by Todd Simmermacher, Sandia National Labs, 10/2004
%

n_sliders=length(y0);
alpha=1.2;

%ju=linspace(0,params(2),n_sliders); % for a linear spacing of integration
%points

% the following sets up the non uniform integration points
dphi=params(2)*(alpha-1)/(alpha^(n_sliders-1) -1);
ju=cumsum([0 dphi*alpha.^[0:n_sliders-2]]);
phi=ju(1:end-1)+diff(ju)/2;
phi=[phi(:);params(2)];

% define some commonly used quantities
dif=x-y0;
phi1=ju(:).^(params(1)+1);
phi2=ju(:).^(params(1)+2);
dif=dif(:);

% figure out what sliders are sliding
Il=find((abs(dif(1:end-1))-phi(1:end-1))<0); %fabs(u-x)<phi
Ig=find((abs(dif(1:end-1))-phi(1:end-1))>=0); %fabs(u-x)>=phi

if nargout==3,  % calculate tangent stiffness
	k=0;
	if ~isempty(Il),
		f1=params(3)*sum((phi1(Il+1) - phi1(Il)))/(params(1)+1);
		if abs(dif(end))<params(2),
			k=f1+params(4);
		else
			k=f1;
		end
	end
end

% some more useful quantities
% Iz=find(~dif); % MSA replaced with the below to speed up.
% dif(Iz)=1e-30;
dif(~dif)=1e-30;
% dir=dif./abs(dif); % MSA replaced with the below to speed up.
dir=sign(dif);
% f=0;

% calculate the force in the element
f1=params(3)*sum(dif(Il).*(phi1(Il+1)-phi1(Il)))/(params(1)+1); %not sliding contribution
f2=params(3)*sum(dir(Ig).*(phi2(Ig+1)-phi2(Ig)))/(params(1)+2); %sliding contribution
f=f1+f2;

% add in the macroslip singularity
if abs(dif(end))<phi(end),
	f=f+params(4)*dif(end);
else
	f=f+dir(end)*params(4)*params(2);
end

% update states
y0(Ig)=x-dir(Ig).*phi(Ig);
if abs(dif(end)) > phi(end),
	y0(end)=x-dir(end)*phi(end);
end



