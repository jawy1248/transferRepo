function beam_structure_plotter(ss,beamstruct,modes,varargin)

lspc = '.-';
scale = 0.025;
labels = 0;
wideflag=false; % tall arrangement (for papers)
for i = 1:length(varargin)
    if strcmpi(varargin{i},'LineSpec')
        lspc = varargin{i+1};
    end
    if strcmpi(varargin{i},'Scale')
        scale = varargin{i+1};
    end
    if strcmpi(varargin{i},'Labels')
        labels = 1;
    end
    if strcmpi(varargin{i},'Wide')
        wideflag = true;
    end
end

nmodes = length(modes);
    gridsize = sqrt(nmodes);
    nv=floor(gridsize); nh=ceil(gridsize);
    while nv*nh < nmodes
        nv=nv+1;
    end

% c = 'brkmycg';

for i_mode = 1:length(modes);
    if wideflag
        subplot(nv,nh,i_mode); % for on screen
    else
        subplot(nh,nv,i_mode); % best for papers
    end

    hold all;
    title({['\bfMode ',num2str(modes(i_mode)),'\rm'];
           ['f_n = ',num2str(ss.wn(modes(i_mode))/2/pi,'%10.1f'), ' Hz']});
       
    for i_beam = 1:length(beamstruct)
        phi_i = ss.phi((ss.beam_ind==i_beam)' & (~cellfun('isempty',strfind(ss.names,'X')) | ~cellfun('isempty',strfind(ss.names,'Y'))) ,:);
        th = beamstruct(i_beam).angle;
        xdir = [cos(th),sin(th)];
        ydir = [sin(th),-cos(th)];
        node_locs = beamstruct(i_beam).nodedef;
        plot(node_locs(:,1),node_locs(:,2),'k.:'); % MSA added - plot of undeformed structure
        for i = 1:size(node_locs,1)
            node_locs(i,:) = node_locs(i,:) + xdir*phi_i(2*(i-1)+2,modes(i_mode))*scale;
            node_locs(i,:) = node_locs(i,:) + ydir*phi_i(2*(i-1)+1,modes(i_mode))*scale;
        end
        plot(node_locs(:,1),node_locs(:,2),lspc,'MarkerSize',4);
    end
    axis equal;
    if labels
        for i = 1:size(ss.nodedef,1)
            text(ss.nodedef(i,1),ss.nodedef(i,2),{[' ',ss.names{3*i-2}(1:end-2)];' '},'FontSize',8);
        end
    end
end