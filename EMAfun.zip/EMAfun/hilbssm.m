function [wn_fit,zt_fit,indfit,yfit,varargout]=hilbssm(yltv,ts,Npts,varargin)
% Smoothed Hilbert Transform Analysis of free vibration response.  Matlab's
% curve fitting toolbox is used to fit a spline to the data with the
% desired number of grid points (knots), based on spap2.m
%
% [wn_fit,zt_fit,indfit,yfit,all_data]=hilbssm(yltv,ts,Npts)
%
% [wn_fit,zt_fit,indfit,yfit,all_data]=hilbpsm(yltv,ts,Npts,'verbose')
%
% [wn_fit,zt_fit,indfit,yfit,all_data]=hilbpsm(yltv,ts,Npts,'verbose',indfit)
%
% yltv - time response to process (only one response point allowed)
% ts - corresponding time vector
% Npts - number of time ponits to use in the piecewise-linear approximation.
%
% M.S. Allen, June 2013, msallen@engr.wisc.edu
%
if length(yltv)~=numel(yltv);
    error('yltv must be a vector (only one output point allowed');
end
yltv=yltv(:);
ts=ts(:);
if length(yltv)~=length(ts);
    error('Time vector is not the same length as response vector');
end

if nargin>3
    if strcmpi(varargin{1},'verbose')
        vbflg=true(1);
    else, vbflg=false(1); end
else
    vbflg=false(1);
end
if nargin>4
    indfit=varargin{2};
else
    indfit=[];
end

[Hnlh]=hilbert(yltv);
Hhph=unwrap(angle(Hnlh));
Hhamp=abs(Hnlh);

% Filter time series (for plot only) if there are too many points.
if length(ts)>1e5;
    nskip=floor(length(ts)/1e5);
else
    nskip=1;
end

figure(61); clf(61)
set(gcf,'Units','Normalized');
set(gcf,'Position',[0.33, 0.17, 0.35, 0.75]);
ha101a=subplot(3,1,1);
semilogy(ts(1:nskip:end),abs(yltv(1:nskip:end)),':','Color',0.8*[1,1,1]);
if nskip>1; title(['Showing only every ',num2str(nskip),'th point']); end
hold on; semilogy(ts(1:nskip:end),Hhamp(1:nskip:end),'b','LineWidth',2); hold off; grid on; ylim(1.2*minmax(Hhamp));
ylabel('\bfMagnitude');
ha101b=subplot(3,1,2);
plot(ts(1:nskip:end),Hhph(1:nskip:end)); grid on;
ylabel('\bfAngle (rad)'); xlabel('\bftime (s)');

if isempty(indfit)
    disp('Select the band to curve fit');
    [xg,yg]=ginput(2);
    indfit=find(ts>xg(1) & ts<xg(2));
end

% Fit phase to obtain frequency versus time
    sp_psii = spap2(Npts,4,ts(indfit),Hhph(indfit)); % 4th order fit
    % fnplt(B) % to get an easy plot
    psiit_fit=fnval(sp_psii,ts(indfit));

    sp_wd=fnder(sp_psii); % to get derivative of spline fit
        % this is also d psiit/dt so don't store both
        wd_fit=fnval(sp_wd,ts(indfit));

    % To evaluate sensitivity, repeat with higher order.
    sp_psii2 = spap2(round(Npts*1.5),4,ts(indfit),Hhph(indfit)); % 4th order fit
    % fnplt(B) % to get an easy plot
    psiit_fit2=fnval(sp_psii2,ts(indfit));

    sp_wd2=fnder(sp_psii2); % to get derivative of spline fit
        % this is also d psiit/dt so don't store both
        wd_fit2=fnval(sp_wd2,ts(indfit));
        
        axes(ha101b); line(ts(indfit(1:nskip:end)),psiit_fit(1:nskip:end),'Color','r','LineWidth',2);
        axes(ha101b); line(ts(indfit(1:nskip:end)),psiit_fit2(1:nskip:end),'Color','c','LineWidth',2,'LineStyle','--');
    %     axes(ha101b); line(t_pwl,psii_pwl-2*psii_std,'Color','c','LineWidth',2,'LineStyle','--');
            legend('Measurement','Fit','50% higher order');
    
% Fit amplitude to find damping versus time
    sp_psir = spap2(Npts,4,ts(indfit),log(Hhamp(indfit))); % 4th order fit
    psirt_fit=fnval(sp_psir,ts(indfit));
	sp_alphat=fnder(sp_psir); % derivative
        alphat_fit=fnval(sp_alphat,ts(indfit));
        wn_fit=(wd_fit.^2+(-alphat_fit).^2).^(1/2);
        zt_fit=-alphat_fit./wn_fit;
        psirt_pts=fnval(sp_psir,sp_psir.knots);

	% To evaluate sensitivity, repeat with higher order.
    sp_psir2 = spap2(round(Npts*1.5),4,ts(indfit),log(Hhamp(indfit))); % 4th order fit
    psirt_fit2=fnval(sp_psir2,ts(indfit));
	sp_alphat2=fnder(sp_psir2); % derivative
        alphat_fit2=fnval(sp_alphat2,ts(indfit));
        wn_fit2=(wd_fit2.^2+(-alphat_fit2).^2).^(1/2);
        zt_fit2=-alphat_fit2./wn_fit2;        
        
    axes(ha101a); line(ts(indfit(1:nskip:end)),exp(psirt_fit(1:nskip:end)),'Color','r','LineWidth',2);
        line(sp_psir.knots,exp(psirt_pts),'Marker','o','MarkerSize',5,'Color',[0,0.5,0],'LineStyle','none');
    
% Reconstruct time response
psi_fit=psirt_fit+1i*psiit_fit;
yfit=exp(psi_fit);

    ha101c=subplot(3,1,3);
%     line(ts(indfit),psiit_fit-Hhph(indfit),'Color','r','LineWidth',2); grid on;
%     line(t_pwl,psii_std*[-2,2],'Color','c','LineWidth',2,'LineStyle','--');
%             legend('PWL Fit Error','2\sigma Limits');
%     ylabel('\bfAngle (rad)'); xlabel('\bftime (s)');
    line(ts(1:nskip:end),yltv(1:nskip:end),'Color','b'); grid on;
    line(ts(indfit(1:nskip:end)),real(yfit(1:nskip:end)),'Color',[0,0.5,0],'Marker','.','LineStyle','--');
    line(ts(indfit(1:nskip:end)),yltv(indfit(1:nskip:end))-real(yfit(1:nskip:end)),'Color','r');
        legend('Measurement','Fit','Error');
        ylim(1.2*[min(real(yfit)),max(real(yfit))]);
        if nskip>1; title(['Showing only every ',num2str(nskip),'th point']); end
    ylabel('\bfResponse'); xlabel('\bftime (s)');

%     % Noise analysis
%     % The simple fitting above should really be replaced with a rigorous
%     noise anlaysis based on the residual of the fit and the fitting
%     equations, as is done in pwlinfit.

figure(62)
ha102a=subplot(1,2,1);
% Feldman's approach(es) for natural frequency variation
if vbflg
    dt=ts(2)-ts(1);
    plot(ts(indfit(1:nskip:end)),wn_fit(1:nskip:end)/2/pi);%,ts(indfit),wn_fit_m1/2/pi,'--');
    alims=axis;
    % Feldman 2011, MSSP, eq. (11)
    wd_Feld=angle(Hnlh(1:end-1).*conj(Hnlh(2:end)))/dt/2/pi;
    plot(ts(1:end-1),-wd_Feld,'Color',0.9*[1,1,1]); % not sure why minus is always needed
    hold on; plot(ts(indfit(1:nskip:end)),wd_fit(1:nskip:end)/2/pi,...
        ts(indfit(1:nskip:end)),wd_fit2(1:nskip:end)/2/pi,'c--'); 
    grid on; hold off
    axis(alims);
    legend('Direct Hilbert','PWL Fit','PWL Fit 2');%,'2\sigma Limits');
else
    plot(ts(indfit(1:nskip:end)),wd_fit2(1:nskip:end)/2/pi,'c--',ts(indfit(1:nskip:end)),wd_fit(1:nskip:end)/2/pi,'b');
    grid on;
    legend('PWL Fit 2','PWL Fit');%,'2\sigma Limits');
end
ylabel('\bff_d (Hz)'); xlabel('\bfTime (s)'); title('\bfDamped Nat. Freq. vs Time')

set(get(gca,'Children'),'LineWidth',2);
ha102b=subplot(1,2,2);
plot(ts(indfit(1:nskip:end)),zt_fit2(1:nskip:end),'c--',ts(indfit(1:nskip:end)),zt_fit(1:nskip:end),'b'); grid on; % ,
ylabel('\bf\zeta'); xlabel('\bfTime (s)'); title('\bfDamping vs Time')
set(get(gca,'Children'),'LineWidth',2);
legend('PWL Fit 2','PWL Fit'); % 'Fit + Noise',

if nargout > 4;
    all_data = [];
    S = whos;
    for k = 1:length(S)
        if ~strcmpi(S(k).name,'all_data')
            eval(['all_data.',S(k).name,' = ',S(k).name,';']);
        end
    end
    varargout{1}=all_data;
end