function [Hrs] = ltprs(H,Nltp,No,flg);
% [Hrs] = ltprs(H,Nltp,No,flg)
%
% Reshape and unreshape measurements for LTP system analysis
%
% [Hrs] = ltprs(H,Nltp,No,'rs');
%
% H is an Nf x Nltp x No matrix with Nltp pseudo-outputs for each of No
% outputs.  The outputs Hrs is a matrix that is Nf x Nltp*No, specifically,
%   Hrs = [Ho(:,:,1), Ho(:,:,2),...]
% or, if the measurements have a fourth dimention then:
%   Hrs(:,:,p) = [Ho(:,:,1,p), Ho(:,:,2,p),...]
% where p denotes the pth input.
%
% The algorithm also performs the reverse operation:
%
% H = ltprs(Hrs,Nltp,No,'unrs');
%

if strcmpi(flg,'rs');
    Nf = size(H,1); Ni = size(H,4);
    Hrs = zeros(Nf,Nltp*No,Ni);
    for ki = 1:Ni
        for ko = 1:No
            Hrs(:,[1:Nltp]+(ko-1)*Nltp,ki) = H(:,:,ko,ki);
        end
    end
elseif strcmpi(flg,'unrs');
    Nf = size(H,1); Ni = size(H,3);
    Hrs = zeros(Nf,Nltp,No,Ni);
    for ki = 1:Ni
        for ko = 1:No
            Hrs(:,:,ko,ki) = H(:,[1:Nltp]+(ko-1)*Nltp,ki);
        end
    end
else
    error('Unrecognized Command String');
end