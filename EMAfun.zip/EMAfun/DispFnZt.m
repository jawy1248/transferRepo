function [varargout] = DispFnZt(lam)
% Displays fn and zeta in the command window in a tab-delimited format, 
% suitable for copying in to Excel or Word
%
% [fn, zt] = DispFnZt(lam)
%
% Matt Allen, July 2006
%

fn = abs(lam);
zt = -real(lam)./fn;

fprintf('Mode, \tfn,     \tzeta\n');
for k = 1:length(lam);
    fprintf('%g   \t%g   \t%g\n',k,fn(k)/2/pi,zt(k));
end

if nargout < 2 & nargout > 0;
    varargout{1} = fn;
else
    varargout{1} = fn;
    varargout{2} = zt;
end