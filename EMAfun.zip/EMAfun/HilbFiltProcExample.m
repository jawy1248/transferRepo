% Sample script to load measurements, evaluate for any signs of nonlinear
% damping and use the Hilbert transform to estimate the modal Iwan
% parameter chi.
%
% M.S. Allen, July 2014, msallen@engr.wisc.edu
%
clear; close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Insert commands here to load your data and name it accordingly
load('Hilb_SampleData_CatConv.mat') % Sample data from two catalytic converters bolted together
    t=t_resp(:); % column vector of time samples
    yt=resp(:); % column vector of response data 
        % This could be a matrix where each column is a measurement at a
        % different point.
        yt_ind=1; % pick which channel (column) to use subsequently.
    fs=mean(diff(t)).^-1; % Sample rate in Hz

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Plot initial (unfiltered) signal
figure(1);
plot(t,yt);
xlabel('time,s '); ylabel('Velo'); title('Time Response')

[Yw,ws] = fft_easy(yt,t);

figure(2);
semilogy(ws/2/pi, 2/length(t)*abs(Yw)); hold on;
xlabel('Freq, Hz'); ylabel('|Velo|');title('FFT of Processed Velocity')

figure(3);
semilogy(ws/2/pi, 2/length(t)*comp_FRF(Yw)); hold on;
xlabel('Freq, Hz'); ylabel('|Velo|');title('FFT of Processed Velocity')

%% Analyze with ZNLDetect
% This is a quick way to check whether any of the modal peaks show signs of
% nonlinearity that may need to be described by a modal Iwan model.

[Fmat, f, ts_zc] = ZNLDetect(yt(:,yt_ind), t, [0.6,2], 1000, 5);
    close(103);
    % This data set shows clear evidence of Iwan-type nonlinearinty near
    % the first resonance (110 Hz)
    
return
% Run the rest of the cells one at a time if desired to perform the Hilbert
% analysis on a single peak of interest.

%% Decimate if needed, then filter
% The band pass filter may be ill conditioned if you try to filter over too
% narrow a range.  You can overcome this by decimating the data.  With the
% sample data you'll notice that the filter for the first mode fails if you
% don't decimate.

% {
dec_fact = 2; % Should be an integer
for k=1:size(yt,2); % loop if there are multiple signals
    if k == 1
        ytd=decimate(yt(:,k),dec_fact);
        ytd(:,2:size(yt,2))=0;
    else
        ytd(:,k)=decimate(yt(:,k),dec_fact);
    end
end
% Select which signal to use going forward
ysig=ytd(:,yt_ind); % Pick which channel to use going forward.
fsds = fs/dec_fact;
tds=t(1:dec_fact:end);
    Ysig = 2/length(tds)*fft_easy(ysig,tds);
%}

% or, if you don't need to decimate:
%{
ysig=yt(:,yt_ind);
tds=t;
fsds=fs;
Ysig = 2/length(tds)*fft_easy(ysig,tds);
%}

% Band-Pass Filtering
Norder=8;

fcutoff1=[60,180]; % Hz % for mode 1 % This doesn't work without decimating
m_ind = 1;

% fcutoff1=[160,280]; % Hz % for mode 2
% m_ind = 2;

[b,a] = butter(Norder,fcutoff1/(fsds/2));
yfilt=filtfilt(b,a,ysig);
    if sum(isnan(yfilt))~=0
        error('Filter failed, NAN returned');
        % Note, this doesn't catch every error - the filter may give poor
        % results that aren't NAN...
    end
    Acoefs{m_ind} = a;
    Bcoefs{m_ind} = b;
    
figure(10+1)
subplot(2,1,1);
plot(tds,yfilt);
xlabel('time, s'); ylabel('Velo');
title('Filtered Signal')
[YFilt,wds] = fft_easy(yfilt,tds);
YFilt = 2/length(tds)*YFilt; % scale the fft
% check filtering
subplot(2,1,2);
semilogy(wds/2/pi,abs(Ysig)); hold on;
semilogy(wds/2/pi,abs(YFilt),'r');
xlabel('Frequency, Hz'); ylabel('FFT Velo');
legend('Velo','BP Velo')
title(['FFT of Filter Response - for First Mode'])

%% Analyze with Hilbert function
ys=yfilt; % Choose what to analyze with Hilbert.
ts=tds;

[wn_fit,zt_fit,indfit,yfit,ad]=hilbssm(ys,ts,20); % Pick which of the 4 modes to use
    Amp_fit=exp(ad.psirt_fit);
    
figure(20)
plot(ts,ys,ts(indfit),yfit,'.--'); grid on;
xylabels('Time (s)','Response');

%% ANALYSIS
% For Acceleration Measurements: (Comment out for Velocity (LDV))
% {
    % Convert Acceleration amplitude to Velocity
    % vj = velocity amplitude (so we don't need the 1i facotr)
    VAmp_fit=Amp_fit./wn_fit; % 
%}

    % Compute Dissipation: Vel. Amp before and after
    % one cycle gives difference of energy before/after.
    ts_jp1=ts(indfit)+2*pi./(ad.wd_fit);
    % vj = velocity amplitude (so we don't need the 1i facotr)
    vj=VAmp_fit; vjp1=interp1(ts(indfit),VAmp_fit,ts_jp1,'linear','extrap');
    Edis1=(1/2)*(vj.^2-vjp1.^2); % left out (m) mass factor. This is (Edis/m)

% % Plot Energy Dissipated versus Amplitude.  In the micro-slip region this
% % will be linear with a slope of 3+chi.  For a linear system that is always  
% % excited at the same frequency, displacement is proportional to force, so
% % either force or amplitude could be the horizontal axis.
%     figure(61); clf(61);
%     loglog(VAmp_fit,Edis1); grid on;%,VAmp_fit,Edis2,'-.',VAmp_fit,Edis3,'k--'); grid on;
%     set(get(gca,'Children'),'Linewidth',2);
%     xylabels('\bfAmplitude (m/s)','\bfDissipation D/m');
%     title('\bfDissipation per Cycle vs. Velocity Amplitude')
%     % Add Curve Fits
%         DvsAsq=polyfit(log10(VAmp_fit),log10(Edis1),1); % Fit line to D vs. A
%         D_Pfit=polyval(DvsAsq,log10(VAmp_fit));
%         line(VAmp_fit,10.^D_Pfit,'Color','r','LineWidth',2,'LineStyle','-.');
%             chi_est=DvsAsq(1)-3
%         D_LinFit=polyval([2,DvsAsq(2)],log10(VAmp_fit));
%         line(VAmp_fit,10.^D_LinFit,'Color',[0,0.5,0],'LineWidth',2,'LineStyle','--');
%         legend('Estimated','Iwan Fit','Linear System');

% Damping vs Log Amplitude - This is a horizontal line for a linear system,
% making it much easier to interpret.  It also makes the data quality more
% visible.
zt_est=Edis1./(VAmp_fit.^2*2*pi);
% Note, this is very close to zt_fit from the Hilbert transform!

figure(62); clf(62);
loglog(VAmp_fit,Edis1./(VAmp_fit.^2*2*pi)); grid on;%,VAmp_fit,Edis2,'-.',VAmp_fit,Edis3,'k--'); grid on;
set(get(gca,'Children'),'Linewidth',2);
xylabels('\bfAmplitude (m/s)','\bfDamping Ratio');
title('\bfDamping vs. Velocity Amplitude')
% First subtract off linear damping.

    % Add Curve Fits
        disp('Select the range to curve fit');
        [xg,yg]=ginput(2);
        fit_ind=find(VAmp_fit> min(xg) & VAmp_fit<max(xg));
        ZtvsAsq=polyfit(log10(VAmp_fit(fit_ind)),log10(Edis1(fit_ind)./(VAmp_fit(fit_ind).^2*2*pi)),1); % Fit line to D vs. A
        Zt_Pfit=polyval(ZtvsAsq,log10(VAmp_fit));
        line(VAmp_fit,10.^Zt_Pfit,'Color','r','LineWidth',2,'LineStyle','-.');
            chi_zt=ZtvsAsq(1)-1
            Rv_zt=10^ZtvsAsq(2)
            R_fit=10^(ZtvsAsq(2)+log10(2*pi*mean(wn_fit).^2)+(chi_zt+1)*log10(mean(wn_fit)))

% For this data set you can adjust the curve fit to fit a line to the
% linear portion at higher amplitudes and estimate chi.  The lower
% assymptote gives an estimate of linear damping from the material and
% boundary conditions.

    % Add Lines for linear damping ratios, min and max.
    zt_high=Edis1(1)/(VAmp_fit(1).^2*2*pi) % Note, should be the same as zt_fit(1)...
    zt_low=Edis1(end)/(VAmp_fit(end).^2*2*pi) % 
    minmax(zt_fit)
    line(VAmp_fit,zt_high*ones(size(VAmp_fit)),'Color',[0,0.5,0],'LineWidth',2,'LineStyle','--');
    line(VAmp_fit,zt_low*ones(size(VAmp_fit)),'Color','k','LineWidth',2,'LineStyle','--');
    legend('Estimated',['Iwan Fit, \chi=',num2str(chi_zt)],...
        ['Linear \zeta = ',num2str(zt_high)],['Linear \zeta = ',num2str(zt_low)]);

%% Use new NLDampPalm function instead
frange=[60,180,8]; % Low Freq, High Freq, Filter Order
dec_fact=2; nKnots=20;
[zt,V,C_zt,chi_zt,Edis,ad] = NLDampPalm(ys,ts,frange,dec_fact,nKnots,'A','verbose');
    zt_material=ad.zt_material

%     R_fit=2*pi*mean(wn_fit)^2*C_zt;
%     R_fit=R_fit*(chi+3)*(chi+2)/4;
    R_fit=10^(log10(C_zt)+log10(2*pi*mean(wn_fit).^2)+(chi_zt+1)*log10(mean(wn_fit)));
    p_est=iwanconvert(chi_zt,100,R_fit,0,'rev')
        
%% Add a line to overlay the analytical damping for a modal Iwan model.
% We'll have to guess some parameters to do this with only the data given.

%%%% NOTE: To obtain a true model VAmp_fit should be the mass-normalized
%%%% modal amplitude!  What we are using above is just the
%%%% amplitude of the structure at some point in m/s.  This will affect the
%%%% values of the parameters below!

F_s=1e5; % assume well above tested range, then iterate
f_shift=60; % assumed frequency shift when joint slips completely in this mode
fn_0=112; % natural freuqency when joint completely stuck
K_inf=(fn_0*2*pi-f_shift*2*pi)^2; % Stiffness when spring is completely stuck
K_t=(fn_0*2*pi)^2-K_inf; % 
fn_inf=sqrt(K_inf)/2/pi
beta=1;
chi=chi_zt;
zt_material=0.00251; % defined above, or use this to overwrite it

% Find alternate Iwan parameters, for reference
[~, phi_max,R, S]=iwanconvert(F_s,K_t,chi,beta)
    % in terms of displacement, macro-slip happens when modal
    % amplitude > phi_max.
    disp('Observed range of modal displacement amplitudes');
    XAmp_fit=VAmp_fit./wn_fit;
    minmax(XAmp_fit)

% Optimize to find phi_max such that K_t is maintained
    f=@(phi_max) abs(iwanconvert(chi_zt,phi_max,R_fit,0,'rev')*[0;1;0;0]+K_inf-(fn_0*2*pi)^2)
        [phim_opt]=fminsearch(f,1);
        phi_max=phim_opt
        p_est=iwanconvert(chi_zt,phim_opt,R_fit,0,'rev')
        F_s=p_est(1); beta=p_est(4); % others already preserved.
        
% Construct analytical dissipation and frequency vs amplitude curves.
[Dm,Kj] = iwan_DKvsQ(XAmp_fit,fn_0*2*pi,[F_s,K_t,chi,beta],2*zt_material*(2*pi*fn_0));
% [Dm,Kj] = iwan_DKvsQ(XAmp_fit,fn_0*2*pi,[chi_zt,phi_max,R_fit,0],2*zt_material*(2*pi*fn_0),'math');
    % Convert to physically meaningful parameters.
    wd_iwan = sqrt(Kj+K_inf); % actually the undamped natural frequency...
    zt_iwan = Dm./(XAmp_fit.^2.*wd_iwan.^2*2*pi);

figure(63); clf(63);
hd=subplot(2,1,1);
loglog(VAmp_fit,zt_est); grid on;
set(get(gca,'Children'),'Linewidth',2);
xylabels('\bfAmplitude (m/s)','\bfDamping Ratio');
title('\bfDamping vs. Velocity Amplitude')
	line(VAmp_fit,10.^Zt_Pfit,'Color','r','LineWidth',2,'LineStyle','-.');
    line(VAmp_fit,zt_high*ones(size(VAmp_fit)),'Color',[0,0.5,0],'LineWidth',2,'LineStyle','--');
    line(VAmp_fit,zt_low*ones(size(VAmp_fit)),'Color','k','LineWidth',2,'LineStyle','--');
    line(XAmp_fit.*wd_iwan,zt_iwan,'Color','k','LineWidth',2)
    legend('Estimated','\chi Fit',...
        ['Linear \zeta = ',num2str(zt_high)],['Linear \zeta = ',num2str(zt_low)],'Modal Iwan','location','SouthEast');
hf=subplot(2,1,2);
semilogx(VAmp_fit,wn_fit/2/pi,VAmp_fit,wd_iwan/2/pi,'k'); grid on;%,VAmp_fit,Edis2,'-.',VAmp_fit,Edis3,'k--'); grid on;
set(get(gca,'Children'),'Linewidth',2);
xylabels('\bfAmplitude (m/s)','\bfNatural Frequency');
title('\bfNatural Frequency vs. Velocity Amplitude')
legend('Estimated','Modal Iwan');

% {
% Plot the curve over a wider range to see global (extrapolated) behavior.
Xs=logspace(-6,-1,5000);
[Dm2,Kj2] = iwan_DKvsQ(Xs,fn_0*2*pi,[F_s,K_t,chi,beta],2*zt_material*(2*pi*fn_0));
% [Dm2,Kj2] = iwan_DKvsQ(Xs,fn_0*2*pi,[chi_zt,phi_max,R_fit,0],2*zt_material*(2*pi*fn_0),'math');
    wd_iwan2 = sqrt(Kj2+K_inf);
    zt_iwan2 = Dm2./(Xs.^2.*wd_iwan2.^2*2*pi);
axes(hd); line(Xs.*wd_iwan2,zt_iwan2,'Color',[0,0.5,0],'LineWidth',2)
%}



