function [LRUR] = find_lrur(H,ws,pct_outliers);
% Find upper and lower residuals from Residual FRF data using outlier
% rejection
%
% [LRUR] = find_lrur(H,ws,pct_outliers);
%
% where LR and UR satisfy
%
% [H(w)] = LR/(iw)^2 + UR
%
% Matt Allen - March 9, 2006

[Nf,No,Ni] = size(H);
LRUR = zeros(2,No,Ni);

for rind = 1:No
    for dind = 1:Ni;
        % Begin of Algorithm - LR, UR independent for each DP
        vec1 = ws.^2.*real(H(:,rind,dind));
        vec2 = ws.^4.*real(H(:,rind,dind));
        
        % Remove Outliers
        ol1_ind = find_outliers(vec1,pct_outliers);
        ol2_ind = find_outliers(vec2,pct_outliers);
        all_ol_ind = union(ol1_ind,ol2_ind);
        keep_ind = setdiff([1:Nf],all_ol_ind);
            if length(all_ol_ind) > 0.8*Nf;
                warning('More than 80% of the data was outliers');
            end
            if isempty(keep_ind)
                error('All Data are outliers');
            end
        % Sums:
        Nk = length(keep_ind);
        sw4 = sum(ws(keep_ind).^4); sw2 = sum(ws(keep_ind).^2);
        sum1 = sum(vec1(keep_ind)); sum2 = sum(vec2(keep_ind));
        LRUR(1,rind,dind) = (sw2*sum2-sw4*sum1)/(Nk*sw4-sw2^2);
        LRUR(2,rind,dind) = (-sw2*sum1+Nk*sum2)/(Nk*sw4-sw2^2);
        
    end
end

disp('Saving debugdata.mat');
save debugdata.mat

figure(500);
subplot(2,1,1);
plot(ws(2:end),abs(vec1(2:end)),ws(keep_ind),abs(vec1(keep_ind)),'.'); grid on;
set(gca,'Ylim',[min(abs(vec1(keep_ind))),max(abs(vec1(keep_ind)))]);
subplot(2,1,2);
plot(ws(2:end),abs(vec2(2:end)),ws(keep_ind),abs(vec2(keep_ind)),'.'); grid on;
set(gca,'Ylim',[min(abs(vec2(keep_ind))),max(abs(vec2(keep_ind)))]);
pause

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function elim_ind = find_outliers(data,elim_pct);

[dsort, dsort_ind] = sort(data);
Nelim = round(elim_pct*length(data)/2); % 1/2 for each end
elim_ind = dsort_ind([1:Nelim, length(dsort_ind):-1:(length(dsort_ind)-Nelim)]);
    % Indices of tails
    