% Sample script to load measurements, evaluate for any signs of nonlinear
% damping and use the Hilbert transform to estimate the modal Iwan
% parameter chi.
%
% M.S. Allen, July 2014, msallen@engr.wisc.edu
%
clear; close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Insert commands here to load your data and name it accordingly
% load('Two0pt125in_Plates_Potato2v.mat') %
% v=v(1:end/4);
% t=t(1:end/4);

%
% PolytecImport('Two0pt125in_Plates_CenterExCenterMeas600Nv.txt');
% disp(colheaders)
% t=data(1:end/4,1);
% v=data(1:end/4,2); % Acceleration data

load NLDT_Inp1_plastic.mat
% load Z:\DATA\BoltedJoints_SegalmanPlates\NewPlates\PlateNLVib\SinglePlate\SP_Inp1_plastic_2015-03-13_14-25-44s.mat

yt=AI2;
t=([1:SampNum].'-1)/SampFreq;
% Make sure this is a column vector

fs=SampFreq; %mean(diff(t)).^-1; % Sample rate in Hz
%t=[0:1:length(t)-1].'/fs;
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot initial (unfiltered) signal
figure(1);
plot(t,yt);
xlabel('time,s '); ylabel('Velo'); title('Time Response')

[Yw,ws] = fft_easy(yt,t);

figure(2);
semilogy(ws/2/pi, 2/length(t)*abs(Yw)); hold on;
xlabel('Freq, Hz'); ylabel('|Velo|');title('FFT of Processed Velocity')

% figure(3);
% semilogy(ws/2/pi, 2/length(t)*comp_FRF(Yw)); hold on;
% xlabel('Freq, Hz'); ylabel('|Velo|');title('FFT of Processed Velocity')


%% Analyze with ZNLDetect
% This is a quick way to check whether any of the modal peaks show signs of
% nonlinearity that may need to be described by a modal Iwan model.

[Fmat, f, ts_zc] = ZNLDetect(yt-0.27, t, [0.021,0.14], 3000, 2);
    close(103);
    % This data set shows clear evidence of Iwan-type nonlinearinty near
    % the first resonance (110 Hz)
    
%% Hilbert transform analysis of Damping

[zt_est,VAmp_fit,C_zt,chi_zt,Edis,ad]=NLDampPalm(yt,t,[1100,1300,6],3,10,'A','verb');
    wn_fit=ad.wn_fit;
    
return


%% Hilbert Transform, using flipping and mirroring to reduce noise
frange=[1100,1300];
dec_fact=3;
nKnots=30;
[zt_est,VAmp_fit,C_zt,chi_zt,Edis,ad] = NLDampPalm([flipud(yt); yt],[t,t+t(end)+t(2)],frange,dec_fact,nKnots,'A','verbose');


%% Add a line to overlay the analytical damping for a modal Iwan model.
% We'll have to guess some parameters to do this with only the data given.
% Suggested strategy:  Start with zt_material=0 to se just the effect of
% the iwan parameters.  Then adjust the slip force and frequency shift to
% bring the curves into agreement.  It may take many iterations to get the
% hang of it.
    % This is very sensitive to chi, so be skeptical of the value that you
    % get from the curve fit above.

%%%% NOTE: To obtain a true model VAmp_fit should be the mass-normalized
%%%% modal amplitude!  What we are using above is just the
%%%% amplitude of the structure at some point in m/s.  This will affect the
%%%% values of the parameters below!

F_s=1e5; % assume well above tested range, then iterate
f_shift=28; % assumed frequency shift (Hz) when joint slips completely in this mode
fn_0=112.2; % natural freuqency (Hz) when joint completely stuck
K_inf=(fn_0*2*pi-f_shift*2*pi)^2; % Stiffness when spring is completely stuck
K_t=(fn_0*2*pi)^2-K_inf; % 
fn_inf=sqrt(K_inf)/2/pi
beta=.3;
chi=-0.75;%chi_zt;
zt_material=0.0030;%0.00225;


% Find alternate Iwan parameters, for reference
[~, phi_max,R, S]=iwanconvert(F_s,K_t,chi,beta)
    % in terms of displacement, macro-slip happens when modal
    % amplitude > phi_max.
    disp('Observed range of modal displacement amplitudes');
    XAmp_fit=VAmp_fit./wn_fit;
    minmax(XAmp_fit)
       
% Construct analytical dissipation and frequency vs amplitude curves.
[Dm,Kj] = iwan_DKvsQ(XAmp_fit,fn_0*2*pi,[F_s,K_t,chi,beta],2*zt_material*(2*pi*fn_0));
    % Convert to physically meaningful parameters.
    wd_iwan = sqrt(Kj+K_inf);
    zt_iwan = Dm./(XAmp_fit.^2.*wd_iwan.^2*2*pi);

figure(14); clf(14);
hd=subplot(2,1,1);
loglog(VAmp_fit,zt_est); grid on;
set(get(gca,'Children'),'Linewidth',2);
xylabels('\bfAmplitude (m/s)','\bfDamping Ratio');
title('\bfDamping vs. Velocity Amplitude')
	line(VAmp_fit,10.^ad.Zt_Pfit,'Color','r','LineWidth',2,'LineStyle','-.');
    line(VAmp_fit,ad.zt_high*ones(size(VAmp_fit)),'Color',[0,0.5,0],'LineWidth',2,'LineStyle','--');
    line(VAmp_fit,ad.zt_low*ones(size(VAmp_fit)),'Color','k','LineWidth',2,'LineStyle','--');
    line(XAmp_fit.*wd_iwan,zt_iwan,'Color','k','LineWidth',2)
    legend('Measured','\chi Fit',...
        ['Linear \zeta = ',num2str(ad.zt_high)],['Linear \zeta = ',num2str(ad.zt_low)],'Modal Iwan','location','SouthEast');
hf=subplot(2,1,2);
semilogx(VAmp_fit,wn_fit/2/pi,VAmp_fit,wd_iwan/2/pi,'k'); grid on;%,VAmp_fit,Edis2,'-.',VAmp_fit,Edis3,'k--'); grid on;
set(get(gca,'Children'),'Linewidth',2);
xylabels('\bfAmplitude (m/s)','\bfNatural Frequency');
title('\bfNatural Frequency vs. Velocity Amplitude')
legend('Measured','Modal Iwan');

%{
% Plot the curve over a wider range to see global (extrapolated) behavior.
Xs=logspace(-6,3,5000);
[Dm2,Kj2] = iwan_DKvsQ(Xs,fn_0*2*pi,[F_s,K_t,chi,beta],2*zt_material*(2*pi*fn_0));
    wd_iwan2 = sqrt(Kj2+K_inf);
    zt_iwan2 = Dm2./(Xs.^2.*wd_iwan2.^2*2*pi);
axes(hd); line(Xs.*wd_iwan2,zt_iwan2,'Color',[0,0.5,0],'LineWidth',2)
%}