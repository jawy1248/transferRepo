function [d,nearpos] = lyarosenstein_sc(x,m,tao,meanperiod,maxiter,cycstart,varargin) 
% Adaptation of Rosenstein algorithm to evaluate stability beginning at 
% different points within a gait cycle.
%
% d = lyarosenstein_sc(x,m,tao,meanperiod,maxiter) 
%
% d: divergence of nearest trajectoires
% x: response of system, Size: Nt x N where Nt = number of time samples &
%       N=number of states
% tao: time delay (in samples)
% m: embedding dimension
%       NOTE: It probably doesn't make sense to embed your signal if you
%       are using this algorithm, as that mixes data from different points
%       within the gait cycle.  So set m=1
% meanperiod: average period (in samples).  This is used to locate nearest
%   neighbors.  Neighbors outside of this range are not considered.
%   %% NOTE!!  Here one should probably use half of the period.  Using the
%   full period we run the risk that we will skip pairing two nearest
%   neighbors if they are about one period apart.
% maxiter: Number of points around each nearest neighbor to consider when
%   computing the divergence.  The average divergence is found between each
%   point and its nearest neighbor, out to point+k to NN+k.
% cycstart; % Vector of indices at which each period of the signal begins.
%   We've called this RHS or LHS in our other codes.
%
% To find the LLE, then use:
% %% LLE Calculation
% fs=2000;%sampling frequency
% tlinear=15:78; % range of linear portion
% F = polyfit(tlinear,d(tlinear),1);
% lle = F(1)*fs
%
% Based on algorithm by Merve Kizilkaya from Matlab Central File Exchange.
% This verison by Matt Allen, April 2014
%

N=length(x); % total number of time samples
M=N-(m-1)*tao; % number of time samples in embedded phase space
Y=psr_deneme(x,m,tao);

silentflag=false;
if nargin>6;
    if strcmpi(varargin{1},'silent') || strcmpi(varargin{1},'sil')
        silentflag=true;
    end
end

% Initially I'm hard coding this to compute on 10ths of the period.  Could
% add an input argument later.
Ndiv=10;
cyc_ind=zeros(M,1); % Index telling which fraction of a cycle each point belongs to
for k=1:(length(cycstart)-1); %loop over all of the cycles
    kth_cycinds=[cycstart(k):cycstart(k+1)-1]; Nk=length(kth_cycinds);
    for i=1:Ndiv;
        ith_fracinds=kth_cycinds(floor([(1+(i-1)*Nk/Ndiv):i*Nk/Ndiv]));
        cyc_ind(ith_fracinds)=i;
        % Now this tells us which fraction of a gait cycle each sample
        % belongs to.
    end
end

if ~silentflag;
    h = waitbar(0,'Computing Distances...');
end
neardis=zeros(1,M);
nearpos=zeros(1,M);
for i=1:M
    x0=ones(M,1)*Y(i,:);
    distance=sqrt(sum((Y-x0).^2,2));
    for j=1:M
        if abs(j-i)<=meanperiod
            distance(j)=1e10;
        end
        % We could add a check here to not consider two points as nearest
        % neighbors unless they start within the same bin, or same fraction
        % of the gait cycle.
    end
    [neardis(i),nearpos(i)]=min(distance); 
        % Rather than using min here, we could sort based on smallest
        % distance and then keep the smallest distance that lands within
        % the same bin.
    if ~silentflag;
        waitbar(i/M,h)
    end
end
if ~silentflag; close(h); end

if ~silentflag; 
    figure;
    plot([1:length(cyc_ind)],cyc_ind,'.-',[1:length(cyc_ind)],cyc_ind(nearpos),'o-');
    xlabel('Sample'); ylabel('Bin # (Fraction of Cycle)');
end
if ~silentflag;
    h = waitbar(0,'Computing Average Deviation...');
end

d=zeros(Ndiv,maxiter);
for k=1:maxiter
%     k
    maxind=M-k;
    evolve=zeros(Ndiv,1);%0;
    pnt=zeros(Ndiv,1);%0;
    for j=1:M
        % Loop over the whole data set to find the average divergence for
        % pairs of nearest neighbors after they've evolved k samples.
            % Here we now bin the NNs into fractions of the gait cycle
        if j<=maxind && nearpos(j)<=maxind % Avoid going past end of data
            dist_k=sqrt(sum((Y(j+k,:)-Y(nearpos(j)+k,:)).^2,2));
                % This is the distance between the jth point and its
                % nearest neighbor (at sample zero) after they have evolved
                % through k samples.
            ind_k=cyc_ind(j+k); % This tells us which fraction of the gait cycle we started in
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % Later, need to add a check that the neighbor was also in
                % the same portion of the gait cycle!
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             if dist_k~=0 && ind_k~=0
                evolve(ind_k)=evolve(ind_k)+log(dist_k);
                pnt(ind_k)=pnt(ind_k)+1;
             end
        end
    end
    % This seems to be unecessary - if pnt=0 then evolve should be also
    pnt(pnt==0)=1; % change zeros to 1 to avoid divide by zero
    d(:,k)=evolve./pnt;
%         if pnt > 0
%             d(:,k)=evolve./pnt;
%         else
%             d(k)=0;
%         end
    if ~silentflag;
        waitbar(k/maxiter,h)
    end
end

if ~silentflag; close(h); end

% figure
% plot(d)


% %% LLE Calculation
% % fs=2000;%sampling frequency
% tlinear=15:78;
% F = polyfit(tlinear,d(tlinear),1);
% lle = F(1)*fs


function Y=psr_deneme(x,m,tao,npoint)
%Phase space reconstruction
%x : time series 
%m : embedding dimension
%tao : time delay
%npoint : total number of reconstructed vectors
%Y : M x m matrix
% author:"Merve Kizilkaya"
N=length(x);
n=size(x,2); % if multiple states, assume they are in columns.
if nargin == 4
    M=npoint;
else
    M=N-(m-1)*tao;
end

Y=zeros(M,m*n); 

for i=1:m
    Y(:,[1:n]+(i-1)*n)=x((1:M)+(i-1)*tao,:);
end
