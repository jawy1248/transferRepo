function [phi_tm,wn_tm,Mtm,Ktm,psi_plot_tm,dpsi_plot_tm] = ...
    BeamTipMass(N,mtb_ratio,Ind_ratio,rhoAL,EIoL3,L,ys)

% Compute analytical mode shapes for a cantilever beam with a point mass
% at its tip.  The method in Ginsberg (p. 432-434) is used to solve for the
% analytical mode functions of the beam with a tip mass.  These mode
% functions are the symbolic functions psi(y) found below where y is the
% nondimensional position along the beam y = x/L

syms y real;
tic
syms c1 c2 an_sym x Lsym
psi_sym = c1*(sin(an_sym*x/Lsym)-sinh(an_sym*x/Lsym))+c2*(cos(an_sym*x/Lsym)-cosh(an_sym*x/Lsym));

f1 = subs(Lsym^2*diff(psi_sym,'x',2)+...
    an_sym^4*(Ind_ratio)*Lsym*diff(psi_sym,'x',1),'x','Lsym') %
f2 = subs((Lsym^3/an_sym^3)*diff(psi_sym,'x',3)+...
    an_sym*mtb_ratio*psi_sym,'x','Lsym')

% Create coefficient matrix:
D(1,1) = diff(f1,'c1'); D(1,2) = diff(f1,'c2'); 
D(2,1) = diff(f2,'c1'); D(2,2) = diff(f2,'c2');

% Find Alpha Values
    % ce = inline('cos(x)+1/cosh(x)'); % CE for a cantilever without a tip
    ce = inline(char(det(D))); % CE for a cantilever with a tip
    an0 = [1.2813, 4.0739, 7.1282, 10.328, 13.353, 16.553]; % Initial guesses for alphas - from ezplot(ce,[0,20])       
    for k = 1:length(an0);
        an(k) = fzero(ce,an0(k));
    end
    for j = 1:N;
        Rn(j) = -(sin(an(j)) + sinh(an(j)))/(cos(an(j)) + cosh(an(j))); % ok - same as for cantilever
    end
% Generate Mode functions
for j = 1:N
    psi(j) = sin(an(j)*y) - sinh(an(j)*y) + Rn(j)*(cos(an(j)*y) - cosh(an(j)*y));
end
dpsi = diff(psi,y);

% psi above are the analytical mode functions.  This next part computes M
% and K matrices to mass normalize them.

% Matrices should be diagonal - Mode functions are orthogonal to RGB Modes!
Mtm = zeros(N,N); Ktm = zeros(N,N);
for m = 1:N
    for n = 1:m
        % create inline function from symbolic psi functions, then
        % integrate it using QUADL
        m_integrand = inline(strrep(strrep(strrep(char(psi(m)*psi(n)),'*','.*'),'/','./'),'^','.^'));
        % m_integrand = @(yin) eval(['for k = 1:length(yin); y = yin(k); fout(k) = ',char(psi(m)*psi(n)),'; end']);
    Mtm(m,n) = rhoAL*quadl(m_integrand,0,1)+rhoAL*mtb_ratio*double(subs(psi(m)*psi(n),'y',1));%
        k_integrand = inline(strrep(strrep(strrep(char(diff(psi(m),y,2)*diff(psi(n),y,2)),'*','.*'),'/','./'),'^','.^'));
    Ktm(m,n) = EIoL3*quadl(k_integrand,0,1); % *EI/L^3 for nondim y
        if n ~= m; Mtm(n,m) = Mtm(m,n); Ktm(n,m) = Ktm(m,n); end
    end
end
toc

% Solve eigenvalue problem for this system.  'PHI' should be diagonal because
% the basis functions are the analytical mode vectors.  Test by checking
% that PHI*diag(diag(PHI).^-1) is almost diagonal
[phi,lambda] = eig(Ktm,Mtm);
% Sort:
    [junk,sind] = sort(diag(lambda));
    lambda = diag(lambda); lambda = diag(lambda(sind));
    phi = phi(:,sind);
% Normalize Mode Functions:
mu = diag(phi.'*Mtm*phi); PHI = zeros(size(phi));
for jj = 1:1:length(phi)
    PHI(:,jj) = phi(:,jj)/sqrt(mu(jj));
end

wn_tm = sqrt(diag(lambda));

% Check orthogonality conditions
check_Mtm = max(max(PHI.'*Mtm*PHI-eye(size(PHI))))
check_Ktm = max(max((PHI.'*Ktm*PHI-lambda)))

% Find Numerical Mode Functions
dpsi_plot_tm = zeros(length(ys),N); psi_plot_tm = zeros(length(ys),N);
for p = 1:length(ys);
    for n = 1:N;
        y = ys(p);
        dpsi_plot_tm(p,n) = double(eval(dpsi(n))); %double(subs(dpsi(n),'y',ys(p)));
        psi_plot_tm(p,n) = double(eval(psi(n))); %double(subs(psi(n),'y',ys(p)));
    end
end
syms y

phi_tm = [psi_plot_tm; (1/L)*dpsi_plot_tm]*PHI; 
phi_tm = phi_tm*diag(sign(phi_tm(end,:)));