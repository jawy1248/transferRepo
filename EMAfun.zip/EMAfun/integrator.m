function xi=integrator(x,Sr)
%integration using smallwoods methods
%verified ok to within 80% of nyquist
[y,b] = intgdos(x,120);
h=freqz(b,[1 -1],[1 2]'/Sr);
scale=1/abs(h(1));
%xi=(y(120:end-1)-mean(y(120:end-1)))*scale;
xi=(detrend(y(120:end-1)))*scale;