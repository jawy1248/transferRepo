function FRF_plot(omegas,H,onames,inames,varargin)
if isempty(varargin)
    type = 'Amp+Phase';
    nofigure = false;
else
    type = varargin{1};
    nofigure = false;
end

if length(varargin) >= 2
    nofigure = true;
end

ni = size(H,2);
no = size(H,1);
nf = size(H,3);
try
    if isempty(inames)
        inames = cell(ni,1);
        for i = 1:ni
            inames{i} = ['Input ',num2str(i)];
        end
    end
catch
    inames = cell(ni,1);
    for i = 1:ni
        inames{i} = ['Input ',num2str(i)];
    end
end
try
    if isempty(onames)
        onames = cell(no,1);
        for i = 1:ni
            onames{i} = ['Output ',num2str(i)];
        end
    end
catch
    onames = cell(no,1);
    for i = 1:ni
        onames{i} = ['Output ',num2str(i)];
    end
end
for j = 1:ni
    for i = 1:no
        if ~nofigure
            figure; set(gcf,'Name',['FRF between ',inames{j},' and ',onames{i}]);
            color = [0,0,1];
        else
            if isnumeric(varargin{2}) && length(varargin{2})==3
                color = varargin{2};
            else
                color = [0,0,1];
            end
        end
        if strcmpi(type,'Amp+Phase');
            subplot(4,1,1);
            hold on;
            plot(omegas/2/pi,wrapTo360(radtodeg(phase(permute(H(i,j,:),[3,2,1]))))-360,'Color',color);
            ylabel('Phase'); title(['FRF between ',inames{j},' and ',onames{i}]);
            subplot(4,1,[2,4]);
            hold on;
            h_vect = permute(H(i,j,:),[3,2,1]);
            for l = 1:length(h_vect)
                h_vect(l) = norm(h_vect(l));
            end
            plot(omegas/2/pi,h_vect,'Color',color);
            set(gca,'YScale','log'); xlabel('Frequency (Hz)');
            ylabel('FRF');
        elseif strcmpi(type,'3D');
            hold on;
            h_vect = permute(H(i,j,:),[3,2,1]);
            plot3(omegas/2/pi,real(h_vect),imag(h_vect),'Color',color);
            xlabel('Frequency (Hz)'); ylabel('Re(H)'); zlabel('Im(H)');
        end
        
    end
end

