function [xdot] = MCKsseom(t,x,junk,M,C,K);
% EOM for state space system described by constant matrices M, C and K
%
% [xdot] = MCKsseom(t,x,junk,M,C,K);
% 
%

% Forcing - half-sine
%     tp = 0.01;
%     if t < tp
%         f = sin((pi/tp)*t);
%     else
%         f = 0;
%     end
% Use Impulse response for now

% Equations of Motion
    % xdot = A*x
    % x = [q; qdot];
    % A = [-Ktot, zeros(2); zeros(2), M]\[zeros(2), -Ktot; -Ktot, zeros(2)];
    A = [C, M; M, zeros(size(M))]\[-K, zeros(size(M)); zeros(size(M)), M];

xdot = A*x;% + [0; f];