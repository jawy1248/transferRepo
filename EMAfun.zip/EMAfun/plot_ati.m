% PLOT_ATI - Plot data records from 1 or more files containing I-DEAS time
%   history data.  The data can be read from either I-DEAS time history files
%   (*.ati) or MATLAB MAT-files (*.mat).
% Has no calling arguments; user is prompted for all inputs.

% For multiple files, can choose records in 3 ways:
% - choose among all records in every file
% - choose the same record number in every file
% - choose the same record type, ref, resp in every file (PROGRAM DOES THIS)
%=======================================================================
% Required toolboxes/functions that are not part of basic MATLAB:
% - if the data is read from a *.ati file, this code requires the following
%   IMAT (I-DEAS to MATLAB translator) functions:
%	getunits(), readadf(), setunits()
%
% 10-Nov-2000, Created (Curt Nelson)
% 17-Mar-2006, Last modified (Curt Nelson)
%=======================================================================
clear all
[namekk,fpath,iFilter] = uigetfile( ...
  { '*.ati;*.mat', 'I-DEAS time history file data (*.ati, *.mat)'; ...
    '*.ati', 'I-DEAS time history files (*.ati)'; ...
    '*.mat', 'MATLAB MAT-files (*.mat)' }, ...
  'Files containing I-DEAS time history data to plot:', ...
  'MultiSelect', 'on');
if isequal(namekk,0)
    fprintf(1, 'Program finished.  Have a nice day!\n');
    return
end
namekk = cellstr(namekk);
nFiles = size(namekk, 2);

for kk = 1:nFiles
    name = namekk{kk};

    iFileType = iFilter;
    if iFilter == 1	% find out which file type was selected
	if ~isempty(strfind(lower(name), '.ati'))
	    iFileType = 2;
	elseif ~isempty(strfind(lower(name), '.mat'))
	    iFileType = 3;
	else
	    error(['File <' name '> has an unknown extension.'])
	end
    end
    if iFileType == 2	% I-DEAS time history file (*.ati)
%	setunits('IN');	% set units for I-DEAS interface to in-lbf-slinch
	setunits('SI');	% set units for I-DEAS interface to m-N-kg
	ati = readadf([fpath name]);

	atiFname = name;
	atiUnitSys = getunits;
    elseif iFileType == 3	% MATLAB MAT-file (*.mat)
	load([fpath name])

	iExist = 1;
	iExist = iExist*exist('ati', 'var');
	iExist = iExist*exist('atiFname', 'var');
	iExist = iExist*exist('atiUnitSys', 'var');
	if iExist == 0
	    beep
	    fprintf(1, 'ERROR: <%s> does not contain required data.\n', name);
	    return	% stop the program
	end
    else
	return	% stop the program
    end
    atiTime = ati.Abscissa(:,1);
    atiData = ati.Ordinate;
    atiRespInfo = ati.ResponseCoord;	% sensor location, direction, and sense
    atiRespType = ati.OrdNumDataType;
    %nPts = ati.NumberElements(1)
    %SampFreqHz = 1.0/ati.AbscissaInc(1)
    clear afu iExist name
    if kk == 1
	UnitSys = atiUnitSys;
	minTime = min(atiTime);
	maxTime = max(atiTime);
    end
    minTime = min(minTime, min(atiTime));
    maxTime = max(maxTime, max(atiTime));
    if atiUnitSys ~= UnitSys
	error('All files must use the same unit system.')
    end

% The following MATLAB variables are required:
%	atiTime		nPts x 1		double array
%	atiData		nPts x nRecords		double array
%	atiRespInfo	nRecords x 1		cell array
%	atiRespType	nRecords x 1		cell array
%   where:
%	nPts = number of data points in each time history data record
%	nRecords = number of data records

    nPts = size(atiData,1);
    SampFreqHz = 1.0/(atiTime(2) - atiTime(1));
    nRecords = size(atiRespInfo, 1);	% number of data records in file
    fprintf(1, 'Read %d data records originally from file <%s>.\n', nRecords,...
      atiFname);
    fprintf(1, '  Records are %g sec long (%d points acquired at %g Hz).\n',...
      nPts/SampFreqHz, nPts, SampFreqHz);

    Fname(:,kk) = {atiFname};
    nPtskk(kk) = nPts;
    nRecordskk(kk) = nRecords;
    Time(1:nPts,kk) = atiTime;
    Data(1:nPts,1:nRecords,kk) = atiData;
    RespInfo(1:nRecords,kk) = atiRespInfo;
    RespType(1:nRecords,kk) = atiRespType;
end

% find what types of data records are contained in the first file
iFile = 1;	% select data records to plot using only the first file
nRecType = 0;
for ii = 1:nRecordskk(iFile)
    iFoundType = 0;
    for jj = 1:nRecType
	if strcmp(RespType{ii,iFile}, TypeStr{jj}) == 1
	    nRecOfType(jj) = nRecOfType(jj) + 1;
	    iIndex(jj,nRecOfType(jj)) = ii;
	    iFoundType = 1;
	end
    end
    if iFoundType == 0	% found a new ResponseType
	nRecType = nRecType + 1;
	TypeStr(nRecType) = RespType(ii,iFile);
	nRecOfType(nRecType) = 1;
	iIndex(nRecType,nRecOfType(nRecType)) = ii;
    end
end
fprintf(1, 'Found %d types of records in file <%s>.\n', nRecType, Fname{iFile});

if nRecType == 1	% only one ResponseType; don't need to ask user
    PlotRespType = strtrim(TypeStr{1});
    iPlotType = 1;
else			% multiple ResponseTypes; select desired one from list
    [iSelect, ok] = listdlg('PromptString', 'ResponseType to Plot',...
      'SelectionMode', 'single',...
      'CancelString', 'Quit',...
      'ListString', TypeStr);
    if ok ~= 1
	fprintf(1, 'Program finished.  Have a nice day!\n');
	return
    end
    PlotRespType = strtrim(TypeStr{iSelect});
    iPlotType = iSelect;
end

if nFiles > 1
    fprintf(1, ['\nSelect records to plot from those in the first file, then'...
      ' the program will\n  identify and also plot matching records from the'...
      ' other %d file(s).\n'], nFiles-1)
end
fprintf(1, 'Plot records of type <%s>; %d records are available.\n',...
  PlotRespType, nRecOfType(iPlotType))

LineColor = 'rgbcmykrgbcmyk';
nColors = size(LineColor, 2);
while 1
    % select the desired records of type ResponseType to plot (in first file)
    if nRecOfType(iPlotType) == 1	% only 1 record; don't need to ask user
	iRec = iIndex(iPlotType,1);
	iSelect = 1;
    else			% multiple records; select desired one from list
	for ii = 1:nRecOfType(iPlotType)
	    RecStr(ii) = {sprintf('%d: %s %s', iIndex(iPlotType,ii), ...
	      RespInfo{iIndex(iPlotType,ii),iFile}, ...
	      RespType{iIndex(iPlotType,ii),iFile})};
	end
	[iSelect, ok] = listdlg('PromptString', 'Select Records to Plot',...
	  'SelectionMode', 'multiple',...
	  'Name', PlotRespType,...
	  'CancelString', 'Quit',...
	  'ListString', RecStr);
	if ok ~= 1
	    fprintf(1, 'Program finished.  Have a nice day!\n');
	    return
	end
    end
    clear Legends PlotData	% needed if number of plotted lines is reduced
    nPlot = length(iSelect);
    if nFiles*nPlot > nColors
	error(sprintf(...
	  'Trying to plot %d lines which is more than the maximum of %d.',...
	  nFiles*nPlot, nColors))
    end
    for ii = 1:nPlot
	iRec = iIndex(iPlotType,iSelect(ii));
	fprintf('\t%d\t%s\t%s\n', iRec, RespInfo{iRec,iFile}, ...
	  RespType{iRec,iFile})
	LegendStr = sprintf('%s %s (Rec %d of %d in <%s>)', ...
	  RespInfo{iRec,iFile}, RespType{iRec,iFile}, iRec, nRecords, ...
	  Fname{iFile});
	PlotData(:,ii) = Data(:,iRec,iFile);
	Legends(ii) = {LegendStr};
	for kk = 2:nFiles	% find matching records in each file
	    if kk == 2
		fprintf(['\t\tFind matching %s records in the other files...'...
		  '\n'], PlotRespType);
	    end
	    iFound = 0;
	    for jj = 1:nRecordskk(kk)
		if strcmp(TypeStr{iPlotType}, RespType(jj,kk)) == 1
			if strcmp(RespInfo{jj,kk}, RespInfo{iRec,iFile}) == 1
			    iFound = 1;
			    LegendStr = sprintf(['%s %s (Rec %d of %d in <'...
			      '%s>)'], RespInfo{jj,kk}, RespType{jj,kk}, jj, ...
			      nRecordskk(kk), Fname{kk});
			    PlotData(:,ii+((kk-1)*nPlot)) = Data(:,jj,kk);
			    Legends(ii+((kk-1)*nPlot)) = {LegendStr};
			    fprintf('\t\t%d\t%s\t%s\n', jj, RespInfo{jj,kk}, ...
			      RespType{jj,kk})
			end
		end
	    end
	    if iFound == 0
		error(['Did not find matching record for file ' num2str(kk)])
	    end
	end
    end
   
    TitleStr = ['I-DEAS Time History Data (' UnitSys ' unit system)'];
    for kk = 1:nFiles
	for jj = 1:nPlot
	    plot(Time(1:nPtskk(kk),kk), ...
	      PlotData(1:nPtskk(kk),(kk-1)*nPlot+jj), ...
	      LineColor((kk-1)*nPlot+jj))
	    if (kk == 1) & (jj == 1)
		hold on
	    end
	end
    end
    hold off
    xlabel('Time [sec]')
% common values for ati.OrdNumDataType:
%	'Acceleration'
%	'Excitation Force'
%	'General'
%	'Unknown'
    if strcmp(TypeStr{iPlotType}, 'Acceleration') == 1
%	ylabel('Acceleration [in/s^2]')
	ylabel('Acceleration [m/s^2]')
    elseif strcmp(TypeStr{iPlotType}, 'Excitation Force') == 1
%	ylabel('Excitation Force [lbf]')
	ylabel('Excitation Force [N]')
    else
	ylabel(TypeStr{iPlotType})
    end
    title(TitleStr, 'Interpreter', 'none')
    xlim([minTime maxTime])
    legend(Legends, 4)
    set(findobj(gcf, 'Type', 'Line'), 'LineWidth', 2)
    [legh, objh] = legend;	% refresh legend so its linewidths are changed
    texth = findobj(objh, 'Type', 'text');
    set(texth, 'Interpreter', 'none', 'FontSize', 8)
    fprintf(1, 'Finished plot --- data range = %.3g to %.3g\n\n',...
      min(PlotData(:)), max(PlotData(:)));

    fprintf(1, 'PAUSED: Press any key to continue...\n');
    beep
    pause
end
fprintf(1, 'Program finished.  Have a nice day!\n');
