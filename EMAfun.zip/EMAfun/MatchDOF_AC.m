function [ind1,ind2,sign_vec]=MatchDOF_AC(Dofstr,GeomDofstr)
% Atlas Copco coordinate matching algorithm
%
% Uses geometry and Stijn's DOF structure to create a 3D plot
% [ind1,ind2,sign_vec]=MatchDOF_AC(Dofstr1,Dofstr2);
%
%   Dofstr1 - DOF structure using Stijn's format corresponding to first
%   vector of interest
%   Dofstr2 - DOF structure corresponding to second vector
%
%   We'll search through Dofstr and find any match between each of its
%   nodes and return the indices so that:
%   Dofstr1(ind1)=Dofstr2(ind2)
%
%   And to compare mode shapes:
%   MAC(vec1(ind1),vec2(ind2)*sign_vec);
%   
% 
% M.S. Allen, Sept. 2015

% load AC_GA30andGA30VSD_Dense.mat C DOF_C
% % % These are for Y_SB1 and phi_SB1 
% % B1ind=find(DOF_C>=3e6); 
% % Sind=find(DOF_C<3e6);
% Dofstr=rows0875; % Info on the DOF of the measurements
% GeomDofstr=C.DoFstructMeas_GA30;
% Geom=C.geomMeas_GA30; % Nx3 array with coordinates.
% mnum=1
% shp=F1.res(mnum,:).';
% fn=F1.wn(mnum)/2/pi;

% Find those DOF that are in the NL measurement sets
%     Npts=length(unique({Dofstr.ID_Dir}));
    Nmeas=length(Dofstr);
    skippedpts=[]; pt_ind=zeros(Nmeas,1); pt_used=false(Nmeas,1);
    for k=1:Nmeas;
        temp=find(cellfun(@(x) strcmpi(x,Dofstr(k).ID_Dir),{GeomDofstr.ID_Dir}),1);
        if ~isempty(temp), pt_ind(k)=temp; pt_used(k)=true; end
    end
    disp('The following points were not found in the second coordinate set and will be ignored.');
    Dofstr(~pt_used).label
        % Discard points that weren't found
        pt_ind=pt_ind(pt_used);
        [~,iG,iM]=unique({GeomDofstr(pt_ind).ID_Dir}); % find unique points, filter
            pt_ind_unq=pt_ind(iG);
            % iM tells where in the unique (shorter) list each node lives.
            % iM;
            % Expand iM to the original, full list of measurement points.
            % Insert zeros for the points not found, they will be ignored.
            iMused=zeros(size(pt_used));
            iMused(pt_used)=iM;
            
        ind2 = pt_ind_unq; % These are which indices on the 2nd set are used in the 1st set.
        ind1=find(pt_used);
        sign_vec=zeros(size(ind1));
            for k=1:length(ind1)
                sign_vec(k)=GeomDofstr(ind2(k)).signDir*Dofstr(ind1(k)).signDir; % apply this to either set of shapes to make directions consistent
            end
        
        return
        
    % loop through and find matching nodes for each point
    for k=1:Nmeas;
        if pt_used(k) % skip if this wasn't in the geometry
            % Is it x, y or z
            if strcmpi(Dofstr(k).absDir,'X');
                xyzind=1;
            elseif strcmpi(Dofstr(k).absDir,'Y')
                xyzind=2;
            else
                xyzind=3; % these should all be Z
            end
            defshp(iMused(k),xyzind)=defshp(iMused(k),xyzind)+...
                Dofstr(k).signDir*shp(k);
        end
    end
    shpmag=sqrt(sum((Cgeo-defshp).^2,2));

figure(fignum); clf(fignum);
plot3(Cgeo(:,1),Cgeo(:,2),Cgeo(:,3),'.k'); hold on;
% plot3(defshp(:,1),defshp(:,2),defshp(:,3),'or'); hold off;
scatter3(defshp(:,1),defshp(:,2),defshp(:,3),[],shpmag/max(shpmag),'filled'); hold off;
    for k=1:size(defshp,1); line([Cgeo(k,1),defshp(k,1)],[Cgeo(k,2),defshp(k,2)],...
            [Cgeo(k,3),defshp(k,3)],'Color','k','LineWidth',1,'LineStyle',':'); end
axis equal; xlabel('x'); ylabel('y'); zlabel('z')
% title(['\bfMode Shape of Mode # ',num2str(mnum),' at ',num2str(fn),' Hz']);

