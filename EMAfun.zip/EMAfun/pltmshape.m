function [phi_out,sign_mult] = pltmshape(phi,varargin);
% Force positive sign on an element of all mode shapes so multiple sets of
% mode shapes can be compared more easily.
%
% [phi_out] = pltmshape(phi,ncoord);
% [phi_out,sign_mult] = pltmshape(phi,ncoord);
%
% [phi_out] = pltmshape(phi,'end'); uses the last point in phi
%
%   phi - matrix of mode shapes (shapes in columns)
%   ncoord (optional) - coordinate number (1 < ncoord < size(phi,1)) of node to make
%   positive for all mode shapes
%       default is ncoord = 1;
%
%   phi_out - mode shape matrix with signs altered.
% 
% Note:  if phi(ncoord,k) is zero for mode k, the mode k's sign is not
% modified.
%
% Matt Allen, msallen@engr.wisc.edu

% Updated Nov. 30, 2006 to fix error associated with signum function.
if nargin < 2;
    ncoord = 1;
else
    ncoord = varargin{1};
    if strcmp(ncoord,'end');
        ncoord = size(phi,1);
    elseif strcmp(ncoord,'middle');
        ncoord = round(size(phi,1)/2);
    elseif ncoord < 1 || ncoord > size(phi,1);
        error(['ncoord is not within allowable range of 1 to ',num2str(size(phi,1))]);
    end
end

if any(phi(ncoord,:) == 0)
    warning(['phi(ncoord,k) = 0 for the following k:\n',...
        num2str(find(phi(ncoord,:) == 0)),'\n',...
        'This (these) modes will not be normalized'],1);
end

% Note:  Signum funciton returns zero if x = zero, so use this instead
sign_mult = -1*(phi(ncoord,:) < 0) + 1*(phi(ncoord,:) >= 0);
phi_out = phi*diag(sign_mult);
