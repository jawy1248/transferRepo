function [subsys,geometry] = Modal_Analysis_DR(varargin)
%Modal_Analysis_DR Loads Files and Derives Modal Data
%   This script is meant to be an easy way to perform modal analysis for
%   data in the *.uff format.  This script prompts the user to select files
%   to load data and geometry information.  Additional arguments allow the
%   user to take manual control over certain aspects and then pass the data
%   in manually.  This script depends on the loaduff function and the AMI
%   suite written by Professor Matt S Allen, so ensure that they are
%   visible to MATLAB.  The general followed by the script is as follows:
%
%       1. Load the data *.uff files and get the FRF transfer function
%           matrix.
%       2. Plug that matrix into ami and perform peak picking through AMI.
%       3. Generate the modal information from the AMI output.
%       4. Load the geometry files.
%       5. Plot the basic geometry for verification.  This will plot all
%           points, lines, and faces, and will also label the points and
%           draw in any coordinate systems that are defined.
%       6. Run through the modeshape matrix and plot each modeshape with
%           the applicable modal information.
%       
%   The only input from the user that is required is selecting files and
%   giving input to AMI.
%
%   To give added control to the user, a number of flags have been
%   developed.  Unless otherwise specified, they follow the form:
%       Modal_Analysis_DR(..., 'flag', value, ...)
%   where flag is a string denoting which value will be set, and value is
%   the value of the option being set.  Currently implementable options for
%   this function are:
%
%       |------------|------------|----------------------------------------
%       |flag        |value       |description
%       |------------|------------|----------------------------------------
%       |nfiles      |            | Specifies the number of files to be
%       |  or        |integer     | loaded by loaduff if the dataset exists
%       |numfiles    |            | over more than one file. Default 1.
%       |------------|------------|----------------------------------------
%       |ami output  |AMIMODES    | Specifies that the ami algorithm has   
%       |   or       |output from | already been performed and allows the  
%       |amimodes    |ami algoritm| user to load that file.                
%       |------------|------------|----------------------------------------
%       |manual_uff* |H,ws,       | Allows the user to externally load info
%       |            |rsps.NodeDir| from loaduff, in case the assembly of 
%       |            |refs.NodeDir| the H matrix is complex due to unusual 
%       |            |            | test setup.
%       |------------|------------|----------------------------------------
%       |amiset      |settings for| Allows the user to pass in the settings
%       |            |running ami | he or she would like to use when ami is
%       |            |            | run                                    
%       |------------|------------|----------------------------------------
%       |save        |filename    | Allows the user to save the output from
%       |            |            | this function to a file specified by   
%       |            |            | filename.
%       |------------|------------|----------------------------------------
%   *Note: For the manual_uff flag, you need to specify 4 values after the
%   flag, in the order requested.  The last two arguments are the matrices
%   NodeDirMat contained in the structures rsps and refs given as outputs
%   from loaduff.  The structure is NOT passed as an argument.  The matrix
%   is.
%
%   The script then outputs a geometry structure and a subsys structure
%   that allow the user to further analyze the results.
%   
%   Dan Rohe
%   1-19-2012

% Set default parameters
do_ami = 1;
num_uff = 1;
do_loaduff = 1;
do_save = 0;
amiset = AMIG_def_opts;
for i = 1:length(varargin)
    % Search the extra arguments for a number of files
    if strcmpi(varargin{i},'nfiles') || strcmpi(varargin{i},'numfiles');
        num_uff=varargin{i+1};
    end
    % Search the extra arguments for manually performed AMI
    if strcmpi(varargin{i},'ami output') || strcmpi(varargin{i},'amimodes')
        do_ami = 0;
        amimodes = varargin{i+1};
    end
    % Search the arguments for manually performed uff
    if strcmpi(varargin{i},'Manual_uff')
        do_loaduff = 0;
        H = varargin{i+1};
        ws = varargin{i+2};
        rsps_NodeDirMat = varargin{i+3};
        refs_NodeDirMat = varargin{i+4};
    end
    % Search for AMI settings
    if strcmpi(varargin{i},'amiset')
        amiset = varargin{i+1};
    end
    % Search for a save flag
    if strcmpi(varargin{i},'save')
        do_save = 1;
        save_name = varargin{i+1};
    end
end

% Load Files
% Prompt the user to select the files
disp(['Selecting ',num2str(num_uff),' files']);
if do_loaduff
    % Initialize space
    H = zeros(0,0,0);
    ws = zeros(0,0);
    rsps_NodeDirMat = zeros(0,2);
    refs_NodeDirMat = zeros(0,2);
    for i = 1:num_uff
        % Prompt the user for the correct file
        disp(['Select File ',num2str(i),' of ',num2str(num_uff),' of the *.uff files containing the modal information']);
        % Select the file using loaduff
        [data,dinfo,H_file,ws(:,i),rsps,refs] = loaduff;
        % Save the NodeDirMat from refs and rsps
        rsps_NodeDirMat = [rsps_NodeDirMat;rsps.NodeDirMat];
        if i > 1 && any(any(refs_NodeDirMat~=refs.NodeDirMat))
            disp('!!Impact Hammer Points are not consistent between files!!');
            disp('  Please use loaduff manually and import the output into');
            disp('  this function by using the Manual_uff flag');
            return;
        else
            refs_NodeDirMat = refs.NodeDirMat;
        end
        % Make sure that the data was taken over the same frequency range.
        if any(ws(:,i)~=ws(:,1))
            disp('Warning: Data not taken over same range!');
        end
        % Compile the H matrix
        H(:,:,end+1:end+size(H_file,3))=H_file;
    end
    % Plot the Composite FRF
    figure;
    semilogy(ws(:,1)/2/pi,comp_FRF(H));
    plotlabels('Composite FRF','Frequency (Hz)','|H|',[12,8]);
    grid on;
end

if do_ami
    % Perform AMI
    amimodes = ami(H,ws(:,1),amiset);
end

% Get the modal information
subsys = ami_uff_getSubsys(amimodes,rsps_NodeDirMat,refs_NodeDirMat);

% Load Geometry
disp('Select a *.uff file containing the geometry information.');
geometry = uff_geo;
% Plot the geometry
figure;
plot_geo(geometry,'labels','cs');
axis equal;
axis tight;

% Plot the modeshapes
h = plot_modeshape_geo(geometry,subsys,refs_NodeDirMat);
for i = 1:size(h,2)
    set(h(1,i),'MarkerSize',1.5);
end

% Save the file
if do_save
    save(save_name,'amimodes','geometry','subsys');
end

end