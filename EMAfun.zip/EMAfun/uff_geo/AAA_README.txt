uff_geo and other functions
by Dan Rohe, 1-18-2012

Help files written by M.S. Allen, 2016

Run ModalAnalysisPlotGeo_TestScript.m for a simple example of how to use this to plot mode shapes.

uff_geo is a suite of scripts and functions that complements Prof. Matt Allen's AMI and loaduff functions.  It aims to decrease user effort and therefore error when manipulating modal data from a software in *.uff format.

-----

The suite of tools contains the following functions:
uff_geo.m - Loads geometry from a *.uff file into MATLAB for further analysis
plot_geo.m - Plots the geometry loaded by uff_geo.  Provides arguments for different options.
ami_uff_getSubsys.m - Takes geometry and AMI information to return the modal basis for the system.
plot_modeshape_geo.m - plots the modeshapes of a structure given information on its geometry and modal data.
CS2Global.m - Utility function that returns the global xyz of a point given its local coordinates and coordinate system.



The general proceedure is as follows:

1. Use loaduff to select a file to import data from.
2. Pass the H output from loaduff into ami and perform peak picking.  See ami's documentation for more information.
3. Pass the amimodes output from ami and the rsps.NodeDirMat and refs.NodeDirMat from loaduff into ami_uff_getSubsys to get a subsys structure containing the natural frequencies, damping ratios, and modeshape matrix from the data.
4. Use uff_geo to load the *.uff file containing geometry data.
5. Use plot_geo to confirm that geometry was imported/exported correctly.
6. Use plot_modeshape_geo to plot the modeshapes on the geometry.