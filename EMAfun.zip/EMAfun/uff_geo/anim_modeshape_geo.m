function [F,f_im] = anim_modeshape_geo(geometry,shp, nodeDirMat,plot_commands, varargin )
%anim_modeshape_geo(geometry,subsystem or modeshape matrix,nodeDirMat)
%   Create animation of a modeshape that was plotted with
%   plot_modeshape_geo.m.   The first three input arguments are identical,
%   as are any options.  These are passed directly to plot_modeshape_geo in
%   a loop to create a GIF animation.
%
%   Mode shape must be a single mode vector.
%
%   plot_commands is a list of commands to modify the plot before creating
%   the movie.
%
% Additional optional arguments are:
%   'labels' - plots point numbers as well as the points
%   'rot' or 'rotation' - specifies that the next input argument will be a
%   rotation matrix that will rotate the plot.
%   'scale' - scales the modeshape plots of the turbine.
%   'scaleprop' - scale the mode shapes to a fraction of the max geometry.
%       e.g. plot_modeshape_geo(geometry,phi,mapping,'scaleprop',0.2);
%
%   'frames' - [16] Number of frames for GIF animation.
%
% M.S. Allen, Spring 2018

iscaleprop=[];
scaleprop=0.2;
frames=16;
filename=[];
for i = 1:length(varargin)
    if strcmpi(varargin{i},'frames')
        frames=varargin{i+1};
        if frames<1 || frames >500;
            frames
            error('Frames requested is below 1 or above 500')
        end
    end
	if strcmpi(varargin{i},'scale')
        error('scale is set automatically in this function, don''t pass in ''scale''')
    end
    if strcmpi(varargin{i},'scaleprop')
        iscaleprop=i;
        scaleprop=varargin{i+1};
    end
	if strcmpi(varargin{i},'filename')
        filename=varargin{i+1};
    end
end

% Use default if scaling not set.  Need an entry in varargin for below.
if isempty(iscaleprop)
    iscaleprop=length(varargin)+1;
    varargin{end+1}='scaleprop';
    varargin{end+1}=scaleprop;
end

% create a vector of scales to use
scales=scaleprop*cos([0:(frames-1)]*2*pi/frames); % time vector to scale shape

for k=1:frames

    varargin{iscaleprop+1}=scales(k);
    % Call to plot
    figure(100); clf(100); set(gcf,'Color',[1,1,1]);
%     set(gcf,'Units','Normalized','Position',[0.2943    0.5573    0.4100 0.3086]); % Hack for specific plot
    plot_modeshape_geo(geometry,shp, nodeDirMat,varargin{:});
    
    % Evaluate any commands sent in to orient the plot
    for kk=1:length(plot_commands);
        eval(plot_commands{kk});
    end
    
    % Set same limits for every frame
    if k == 1;
        x_limits = get(gca,'Xlim'); y_limits = get(gca,'Ylim'); z_limits = get(gca,'Zlim');
        % Expand by 10%
        max_lim=max(abs([x_limits, y_limits, z_limits]));
            x_limits=x_limits+max_lim*0.1*[-1,1];
            y_limits=y_limits+max_lim*0.1*[-1,1];
            z_limits=z_limits+max_lim*0.1*[-1,1];
        set(gca,'Xlim',x_limits,'Ylim',y_limits,'Zlim',z_limits);
    else
        % Original
        set(gca,'Xlim',x_limits,'Ylim',y_limits,'Zlim',z_limits);
        % Expand slightly so the animation doesn't leave the frame
%         set(gca,'Xlim',1.2*x_limits,'Ylim',1.2*y_limits,'Zlim',1.2*z_limits);
    end
    
    % Pull frames for movie
    F(k) = getframe(100); 
    f_im = frame2im(F(k));
    
    if k == 1
        [im,map] = rgb2ind(f_im,256,'nodither');
        im(1,1,1,frames) = 0;
    else
        im(:,:,1,k) = rgb2ind(f_im,map,'nodither');
    end
    
end

% Create GIF
if isempty(filename)
    [filename,pathname] = uiputfile('*.gif','Save .GIF Animation');
else
    pathname=cd;
end
strMATDir = cd;
cd(pathname);
imwrite(im,map,filename,'DelayTime',1e-6,'LoopCount',3000);
cd(strMATDir);
    
    

