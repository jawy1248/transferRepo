function [ ptGlobal ] = CS2Global(ptCS,CS)
%CS2Global(ptCS,origin,C) returns a point's location in the global CS
%   CS2Global takes a point ptCS's location in a coordinate system defined
%   by an origin origin and orientation matrix C.  It returns the point's
%   global location.
%   ptCS is a 3x1 vector defining the point's x,y,z location
%   origin is a 3x1 vector defining the point's coordinate system's origin
%   C is a 3x3 rotation matrix of the coordinate system wrt it's parent
%   coordinate system.

ptGlobal = CS.O+CS.C'*ptCS;

end