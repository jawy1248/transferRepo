function geometry = uff_geo( varargin )
% geometry = uff_geo; % (prompts user to select a file)
% 
% uff_geo uff_geo takes a geometry uff file and imports it into matlab
%   uff_geo takes a string pointing to a geometry file which is exported
%   from Pulse as a UFF file.  It returns geometry, a structure containing
%   patches, lines, and points.
%       geometry has fields:
%           points - A list of all of the points' x, y, and z coordinates.
%           lines - A list of the lines (in terms of point numbers)
%           patches - A list of the polygons (in terms of point numbers)
%   An example geometry structure would look like this:
%       geometry.points = [1,0,0,0;
%                          2,0,0,1;
%                          3,0,1,0;
%                          4,0,1,1];
%       geometry.lines = [1,4;
%                         3,2];
%       geometry.patches = [1,2,4,3];
%   This would be a square patch with two lines cutting the diagonal.
%   Note that labshop only outputs triangular elements, but a general
%   element may have any number of nodes (ex. 3 node triangle, 8 node quad)
%
%   Dan Rohe, 12-29-2011
%
%   To create a plot of the deformed structure, use, for example
%
%   plot_modeshape_geo(geometry,Phi,rsps.NodeDirMat,'scaleprop',0.4);

if ~isempty(varargin)
    inputfile = varargin{1};
else
    [filename,pathname] = uigetfile('*.uff;*.unv', 'Select the Geometry File to Import','MultiSelect','off');
    inputfile = [pathname,filename];
end
disp(['Loading Geometry from file ',inputfile,'...']);
% Get the input file:
filecontents = fileread(inputfile);
% Split it into records
records = regexp(filecontents,'\n','split');
% records is a cell array where each element in the cell is a record from
% the data file.

% Recover Coordinate systems:
% According to Universal File Formats for Modal Analysis Testing, Dataset
% number 18 contains the information of the coordinate systems.
for i = 1:length(records)
    if str2double(records{i}) == 18
        break;
    end
    if i == length(records)
        disp('No Coordinate systems found, assuming all are cartesian global');
        geometry.CS(1).num = 99999;
        geometry.CS(1).name = 'Dummy';
        geometry.CS(1).C = eye(3);
        geometry.CS(1).O = zeros(3,1);
    end
end
iCS = 1;
i = i+1;

while str2double(records{i})~=-1
    record1 = str2num(records{i});
    geometry.CS(iCS).num = record1(1);
    CSs(iCS)=record1(1);
    geometry.CS(iCS).type = record1(2);
    geometry.CS(iCS).parent = record1(3);
    geometry.CS(iCS).color = record1(4);
    geometry.CS(iCS).defMethod = record1(5);
    geometry.CS(iCS).name = records{i+1};
    record3 = [str2num(records{i+2}),str2num(records{i+3})];
    geometry.CS(iCS).O = record3(1:3)';
    geometry.CS(iCS).C = zeros(3);
    xdir = record3(4:6)-record3(1:3);
    geometry.CS(iCS).C(1:3,1) = xdir/norm(xdir);
    ydir = -cross(xdir,(record3(7:9)-record3(1:3)));
    geometry.CS(iCS).C(1:3,2) = ydir/norm(ydir);
    zdir = cross(xdir,ydir);
    geometry.CS(iCS).C(1:3,3) = zdir/norm(zdir);
    geometry.CS(iCS).C = geometry.CS(iCS).C.';
    iCS = iCS+1;
    i=i+4; 
end

% Recover points:
% According to Universal File Formats for Modal Analysis Testing,
% Dataset number 15 contains the information of node locations.
geometry.points = zeros(0,4);
geometry.ptDefCS = zeros(0,1);
for i = 1:length(records)
    if str2double(records{i}) == 15
        break;
    end
    if i == length(records)
        disp('No nodes were found, exiting.');
        return;
    end
end
i = i+1;
while str2double(records{i})~=-1
    tmppt = str2num(records{i});
    CS = tmppt(2);
    pt = tmppt([1,5:7]);
    while(CS~=0)
        iCS = find(CSs==CS);
        pt(2:4) = CS2Global(pt(2:4)',geometry.CS(iCS(1)))';
        CS = geometry.CS(iCS(1)).parent;
    end
    
    geometry.points(end+1,:) = pt;
    geometry.ptDefCS(end+1,1) = tmppt(3);
    i = i+1;
end

% Recover lines:
% According to the Universal File Format, Dataset Number 82 contains
% information on drawing lines.
geometry.lines = zeros(0,2);
for i = 1:length(records)
    if str2double(records{i}) == 82
        break;
    end
end

if i == length(records)
    disp('No lines were found.');
else
    % Record 3 through the next -1 contains the line information.
    istart = i+3;
    tmpline = [];
    for iend = istart:length(records)
        if str2double(records{iend}) == -1
            break;
        end
        tmpline = [tmpline,records{iend}(1:end-1)];
    end
    % Each 'line' is defined by 2 nodes followed by a zero
%     tmpline2 = regexp(tmpline,'\n','split');
%     tmpline = '';
%     for i = 1:length(tmpline2)
%         tmpline = strcat(tmpline,tmpline2{i});
%     end
    lines = str2num(tmpline);
	lines = reshape(lines,3,length(lines)/3)';
    geometry.lines = lines(:,1:2);
end

% Recover Patches:
% According to the Universal File Format, Dataset Number 2412 contains
% information on drawing elements, as which Pulse Labshop saves its
% triangles.
for i = 1:length(records)
    if str2double(records{i}) == 2412
        
        break;
    end
end
% For non-beam elements, every other record will contain the information we
% are looking for.
try
geometry.patches = zeros(0,3);
if i == length(records)
    disp('No Elements were found.');
else
    i = i+1;
    while str2double(records{i})~=-1
        i = i+1;
        tmppatch = str2num(records{i});
        geometry.patches(end+1,:) = tmppatch;
        i = i+1;
    end
end
catch
    disp('No Patch Elements Found')
end

end


