function [ttext,xtext,ytext] = ...
    plotlabels(titletext, xlabeltext, ylabeltext, textsizes )
if iscell(titletext)
    nametext = titletext{1};
else
    nametext = titletext;
end
set(gcf,'Name',nametext);
ttext = title(titletext);
set(ttext,'FontSize',textsizes(1));
xtext = xlabel(xlabeltext);
set(xtext,'FontSize',textsizes(2));
ytext = ylabel(ylabeltext);
set(ytext,'FontSize',textsizes(2));
end