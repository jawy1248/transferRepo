function [subsys,rsps_dof] = ami_uff_getSubsys( amimodes,rsps_NodeDirMat,refs_NodeDirMat,varargin)
%uff_getModeshapes Returns a Modeshape Matrix phi given parameters from
%loaduff and ami.
%   This function takes in the matrices NodeDirMat from the rsps and refs
%   structures returned by loaduff.  It loops through information output
%   from AMI to assemble the modal parameters.
%   
%   The algorithm selects the largest drive point for each mode of the
%   structure, and calculates the mass-normalized mode shape based on that
%   parameter.

if nargin>3
    dp_use=varargin{1};
else
    dp_use=[];
end

% Modeshapes
% First go through the rsps list and find the DOF that it corresponds to.
rsps_dof = zeros(size(rsps_NodeDirMat,1),1);
for i = 1:size(rsps_NodeDirMat,1)
    for j = 1:size(refs_NodeDirMat,1)
        % Check that they are at the same point and are parallel (sign
        % doesn't matter)
        if (rsps_NodeDirMat(i,1)==refs_NodeDirMat(j,1)) && (abs(rsps_NodeDirMat(i,2))==abs(refs_NodeDirMat(j,2)))
            rsps_dof(i) = j;
            break;
        end
    end
end

% Go through each accelerometer point and capture the full 3D residual
% matrix.
res_mat = zeros(size(amimodes.A_store,2),size(amimodes.A_store,1),size(amimodes.A_store,3));
for j = 1:size(rsps_NodeDirMat,1)
    res_mat(:,:,j) = (-2*real(diag(conj(amimodes.mode_store(:,3)))*amimodes.A_store(:,:,j))).';
end

% Go though and find the best (i.e. largest) drive point to use for each mode shape.
    % Ok, so this only uses positive drive point residues - doesn't account
    % for negative signs if the impact was actually in the other direction,
    % which might give an even larger (but negative) phi_r*phi_rp.'
if isempty(dp_use);
    rsps_index = zeros(size(res_mat,2),1);
    for r = 1:size(res_mat,2)
        ress = zeros(size(rsps_NodeDirMat,1),1);
        for p = 1:size(rsps_NodeDirMat,1)
            ress(p) = res_mat(rsps_dof(p),r,p);
            % Correct sign if drive point and measurement point are in
            % opposite directions.
            if sign(rsps_NodeDirMat(rsps_dof(p),2))*sign(refs_NodeDirMat(p,2))<0;
                ress(p)=-ress(p);
            end
        end
        [~,rsps_index(r)] = max(ress);
    end
else
    rsps_index=dp_use;
end

% Set some variables so I don't keep having to type size(...,1), etc.
nModes = size(res_mat,2);
nDOF = size(res_mat,1);
nDP = size(res_mat,3);

% Finally collect the modeshape matrix
phi = zeros(nDOF,nModes);
for r = 1:nModes
    dp = rsps_index(r);
    p = rsps_dof(dp);
    dp_res = res_mat(p,r,dp);
        if sign(refs_NodeDirMat(p,2))*sign(rsps_NodeDirMat(dp,2))<0;
            dp_res=-dp_res;
        end
    if dp_res<0;
        warning('Negative Drive Point Residue Corrected - Choose a different one!');
        disp(['Mode # ',num2str(r),', Used Drive Point: ',num2str(dp)]);
        disp('Mode Shapes at All Drive Points');
        res_tmp=squeeze(res_mat(rsps_dof,r,1:3));
            res_tmp = res_tmp*diag(sign(refs_NodeDirMat(rsps_dof,2)).*sign(rsps_NodeDirMat(:,2)))
        phi_dps = res_tmp*diag(diag(res_tmp).^-(1/2))
        % now correct it and go on - may not give good results, but keeps
        % it from bombing.
        dp_res=-dp_res;
    end
    phi_dp = sqrt(dp_res);
    phi(:,r)=res_mat(:,r,dp)/phi_dp;
    % Uncomment this to see results for each drive point:
    % {
    r
    res_tmp=squeeze(res_mat(rsps_dof,r,1:3));
        res_tmp = res_tmp*diag(sign(refs_NodeDirMat(rsps_dof,2)).*sign(rsps_NodeDirMat(:,2)))
    phi_dps = res_tmp*diag(diag(res_tmp).^-(1/2))
    %}
%     for p = 1:nDOF
%         phi(p,r) = res_mat(p,r,dp)/phi_dp;
%     end
end

% Now collect names
subsys.nodeDirMat = refs_NodeDirMat;
subsys.names = cell(nDOF,1);
for i = 1:nDOF
    subsys.names{i} = num2str(refs_NodeDirMat(i,1));
    dirstr = num2str(refs_NodeDirMat(i,2));
    dirstr = strrep(dirstr,'1','X');
    dirstr = strrep(dirstr,'2','Y');
    dirstr = strrep(dirstr,'3','Z');
    if ~strcmp(dirstr(1),'-') && ~strcmp(dirstr(1),'+');
        dirstr = ['+',dirstr];
    end
    subsys.names{i} = [subsys.names{i},dirstr];
end

subsys.wn = amimodes.mode_store(:,1);
subsys.zt = amimodes.mode_store(:,2);
subsys.phi = phi;

end