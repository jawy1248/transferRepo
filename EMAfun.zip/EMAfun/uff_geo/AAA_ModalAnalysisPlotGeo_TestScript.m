%uff_geo_test_script

clear; clc; close all;

% Load Geometry
% disp('Select a *.uff file containing the geometry information.');
% geo=uff_geo
geo=uff_geo('FullTurbine_1-Geometry.uff');

% Plot the geometry
figure(1)
plot_geo(geo,'labels','cs');
axis equal;
axis tight;

% Load measurements
[data,dinfo,H,ws,rsps,refs]=loaduff('FullTurbine_1-FRFs.uff');

figure(2)
semilogy(ws/2/pi,comp_FRF(H));
xlabel('Frequency (Hz)'); ylabel('|H| m/(s^2 N)');

% Pick a peak
[~,fn,f_index] = findpeak(comp_FRF(H),ws/2/pi);
shp=H(f_index,:,1); % Uses the first drive point.
shp=imag(shp).'; % Imaginary part is proportional to mode shape for acceleration/force.
    % must be a column vector

% Or you could run AMI instead
%{
    % Set options
    amiset = AMIG_def_opts;
    amiset.DVA = 'A';
    amiset.FRF_RF = 20;
    amiset.AutoSubLevel = 1.1;
    amiset.LM = 'on';

    ami(H,ws,amiset);
    
    % Modal Data
    global AMIMODES % brings AMI�s variables into the workspace
    wn = AMIMODES.mode_store(:,1)       % Natural frequencies, rad/s
    fn = wn/2/pi;
    zt = AMIMODES.mode_store(:,2)       % Damping ratios
    res = -2*real(diag(conj(AMIMODES.mode_store(:,3)))*AMIMODES.A_store(:,:,1)); % Residue vector ~ mode shapes
    shp=res.';
%}

% Plot the modeshapes
h = plot_modeshape_geo(geo,shp,refs.NodeDirMat,'scaleprop',0.2);
for i = 1:size(h,2)
    set(h(1,i),'MarkerSize',1.5);
    title(['\bfMode # ',num2str(i),' at ',fn(i)',' Hz']);
end

% You'll notice that the plot is 3D, so you need to rotate it to get a good
% view of the mode shape.  Use the rotate tool in the figure window.

