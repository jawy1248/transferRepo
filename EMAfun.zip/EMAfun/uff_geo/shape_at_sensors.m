function shapeTestCS = shape_at_sensors(geometry,nodeDirMat,nodes,FEshapes,FEDOF,varargin)
%shape_at_sensors(geometry,nodeDirMat,nodes,FEshapes)
%
%   Given a set of FE shapes (in a global coordinate system) and the node
%   locations, find the nodes that match test points in geometry.points and
%   perform coordinate transformations to put the FEM deformations in the
%   test coordinate system.
%
%   plot_modeshape_geo takes 4 arguments
%       geometry - argument returned from uff_geo.m, contains point, line,
%       and face information and coordinate system definitions.
%
%       nodeDirMat - The matrix specifying the node points and direction
%       for each degree of freedom.  This is returned from loaduff in the
%       refs structure.
%
%       nodes - Nx4 matrix of locations of nodes of the FE model in the
%       following form: [Node #, x, y, z]
%
%       FEshapes - NxNmodes matrix of mode shapes of the FEM.
%
% Matt Allen, June 2017.  Based on plot_modeshape_geo by Dan Rohe
%

% Find nearest FEM node for each measurement DOF.
dmin=zeros(size(geometry.points,1),1); test_nodes=dmin;
for k=1:size(geometry.points,1);
    % Find distance between all FE points and each measurement point.
    d=sum((nodes(:,2:4)-ones(size(nodes(:,2:4),1),1)*geometry.points(k,2:4)).^2,2);
    [dmin(k),test_nodes(k)]=min(d);
        % test_nodes = rows in FE "nodes" matrix corresponding to each point in the test model
end
disp('Maximum distance between a test point and a point in the FEM');
disp(max(dmin))

% Get each coordinate system number in a vector so we can find them easily
CSs = zeros(size(geometry.CS));
for i = 1:length(geometry.CS)
    CSs(i) = geometry.CS(i).num;
end

nDOF = size(nodeDirMat,1);
shapeTestCS = zeros(nDOF,size(FEshapes,2));

for j = 1:nDOF
    
    % Go through each coordinate system in the current coordinate
    % system's stack to transform the direction to the proper
    % orientation
    point = nodeDirMat(j,1);
    pindex = find(geometry.points(:,1)==point,1);
    CS = geometry.ptDefCS(pindex); Rmat=eye(3);
    while(CS~=0)    % While we are not at the base coordinate system
        iCS = find(CSs==CS);    % Find our coordinate system
        Rmat = geometry.CS(iCS(1)).C'*Rmat; % Undo that rotation
            % Given a sensor direction: [x;y;z], Rmat*[x;y;z] gives the
            % direction in the global coordiante system.
        CS = geometry.CS(iCS(1)).parent;    % And set the current system to the parent (reference CS) of the previous system.
    end
    
    % Assemble FEM shape at the current node
    % Find indicies for current point
    iDOFj=find(nodes(test_nodes(pindex),1)==floor(FEDOF));
        if length(iDOFj)<3; error(['Missing measurement points, found DOF:',num2str(FEDOF(iDOF),1)]); end
    shpsj=FEshapes(iDOFj(1:3).',:);
    % Apply rotation
    shpsj_testCS=Rmat\shpsj; % This is the FE shape in the test CS
    
    % Extract the point and direction of the displacement from the
    % nodeDirMat matrix
    switch abs(nodeDirMat(j,2))
        case 1
            shapeTestCS(j,:)=shpsj_testCS(1,:);
%             direction = [1,0,0]';
        case 2
            shapeTestCS(j,:)=shpsj_testCS(2,:);
%             direction = [0,1,0]';
        case 3
            shapeTestCS(j,:)=shpsj_testCS(3,:);
%             direction = [0,0,1]';
    end
    shapeTestCS(j,:) = shapeTestCS(j,:)*sign(nodeDirMat(j,2)); % Multiply by the sign so the direction is correct;

end

