%uff_geo_test_script

clear; clc; close all;

% Load ami data in case you want to skip the ami portion
load full_turbine.mat;
% If skipping the ami portion is desired, add the following to the arugment
% list of modal analysis: 'amimodes',amimodes_full,

% Set options
num_files = 2;
amiset = AMIG_def_opts;
amiset.DVA = 'A';
amiset.FRF_RF = 20;
amiset.AutoSubLevel = 1.1;
amiset.LM = 'on';

% Call Modal_Analysis
% If you want to see the full script and let it run AMI, then don't pass
% the amimodes flag
Modal_Analysis_DR('numfiles',2,'amiset',amiset);