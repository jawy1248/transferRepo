function phi_rbm = ssRigidBodyModes(m,I,cm,geometry,nodeDirMat,varargin)
% Calculate rigid body modes for an article from its known inertia matrix
% (in the master coordinate system) and the geometry of the measurement
% nodes.
%
% phi_rbm = ssRigidBodyModes(m,I,cm,geometry,nodeDirMat)
%
% ssRigidBodyModes returns the first six rigid body modes of the geometry
%   ssRigidBodyModes returns the 6 rigid body modes of a structure based on
%   an input geometry and nodeDirMat.  These modes will be based on the
%   mass m, the inertia tensor I, the center of mass cm.
%
% geometry is in the format returned by uff_geo
%   The part needed is the point definitions:
%   geometry.point = [point #, x coord, y coord, z coord]
% nodeDirMat, returned by loaduff, is a matrix of:
%   [node number, direction] where direction = 1, 2 or 3 for x, y or z.
%
% Dan Rohe, ~2013


%% Get the principal inertia properties
if nargin>5;
    silflag=varargin{1};
else
    silflag='verbose';
end
[r,p]=eig(I);
I1 = p(1,1);
I2 = p(2,2);
I3 = p(3,3);
for i = 1:3
    r(:,i) = r(:,i)/norm(r(:,i)); % unit vector in the direction of each principal axis.
        % For rotational motion this gives the unit vector in the direction
        % of omega.
end

%% Calculate Mass Normalized Modeshape Matrix
M = [eye(3)*m,zeros(3);
    zeros(3),[I1,0,0;0,I2,0;0,0,I3]];
% phi = M^-1; % This is just 1/ each diagonal element
    % MSA - I don't think that is correct.  Need a (1/2) factor so that
    % phi_r*phi_dp = 1/M.
phi = M^-(1/2); % This is just 1/sqrt(each diagonal element)

%% Calculate contribution of each DOF
nModes = 6;
nDOF = size(nodeDirMat,1);
phi_rbm = zeros(nDOF,nModes);

% Get list of coordinate systems
CSs=zeros(length(geometry.CS),1);
for k=1:length(geometry.CS)
    CSs(k)=geometry.CS(k).num;
end

for i = 1:nModes
    for j = 1:nDOF
        % Get the point and direction of the displacement from the
        % nodeDirMat matrix
        point = nodeDirMat(j,1);
        pindex = find(geometry.points(:,1)==point);
        pindex = pindex(1);
        switch abs(nodeDirMat(j,2))
            case 1
                direction = [1,0,0]'; % unit vector in the direction of the jth DOF
            case 2
                direction = [0,1,0]';
            case 3
                direction = [0,0,1]';
        end
        direction = direction*sign(nodeDirMat(j,2)); % Multiply by the sign so the direction is correct;
        
        % Go through each coordinate system in the current coordinate
        % system's stack to transform the direction to the proper
        % orientation
        CS = geometry.ptDefCS(pindex);
        while(CS~=0)    % While we are not at the base coordinate system
            iCS = find(CSs==CS);    % Find our coordinate system
                if length(iCS)>1;
                    warning('Multiple CS have the same number, taking the first');
                    iCS=iCS(1);
                elseif isempty(iCS)
                    error(['Corrdinate System ',num2str(CS),' Does not exist in the geometry file']);
                end
            direction = geometry.CS(iCS).C'*direction; % Undo that rotation
            CS = geometry.CS(iCS(1)).parent;    % And set the current system to the parent (reference CS) of the previous system.
                % Hence, this will loop through the CS's in order and apply
                % each transformation until it returns to the global (CS=0)
        end
        
        % Add the modeshape to the original point in the direction
        % specified.
        if (i>0 && i<4)
                % Translation in the direction ri
                phi_rbm(j,i) = phi(i,i)*dot(direction,r(:,i));
                    % MSA Note - it would be equally valid to simply put
                    % the translational RB modes in the X, Y and Z
                    % directions.
        else
                % Rotation in the direction ri
                phi_rbm(j,i) = phi(i,i)*dot(direction,cross(r(:,i-3),(geometry.points(pindex,2:4)'-cm)));
        end
    end
end
%% Plot modeshapes for verification
if strcmpi(silflag,'verbose');
    for i = 1:6
        figure;
        plot_modeshape_geo(geometry,phi_rbm(:,i),nodeDirMat,'scale',1/phi(i,i));
        if i>0 && i < 4
            title(['Translation in the <',num2str(r(1,i),4),', ',num2str(r(2,i),4),', ',num2str(r(3,i),4),'> direction']);
            quiver3(cm(1),cm(2),cm(3),r(1,i),r(2,i),r(3,i),'k--');
        else
            title(['Rotation about the <',num2str(r(1,i-3),4),', ',num2str(r(2,i-3),4),', ',num2str(r(3,i-3),4),'> axis']);
            quiver3(cm(1),cm(2),cm(3),r(1,i-3),r(2,i-3),r(3,i-3),'k--');
        end
        hold on;
    end
end
end



