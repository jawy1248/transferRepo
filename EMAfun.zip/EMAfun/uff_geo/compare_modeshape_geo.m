function compare_modeshape_geo( geometry_cells, subsys_cells, nodeDirMat_cells, mode_cells, varargin )

ncomp = length(geometry_cells);
nmss = length(mode_cells);

labels = 0;
rotmat = eye(3);
viewangle=[0,0];
scale = 1;

for i = 1:length(varargin)
    if strcmpi(varargin{i},'labels')
        labels = 1;
    end
    if strcmpi(varargin{i},'rot') || strcmpi(varargin{i},'rotation')
        rotmat = varargin{i+1};
    end
    if strcmpi(varargin{i},'scale')
        scale = varargin{i+1};
    end
    if strcmpi(varargin{i},'view')
        viewangle=varargin{i+1};
    end
end

for i = 1:nmss
    figure;
    for j = 1:ncomp
        subplot(1,ncomp,j);
        plot_modeshape_geo(geometry_cells{j},subsys_cells{j},nodeDirMat_cells{j},'modes',mode_cells{i}(j),'view',viewangle,...
            'scale',scale,'rot',rotmat);
    end
end

end

