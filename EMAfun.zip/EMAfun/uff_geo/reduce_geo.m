function [ red_geo,red_ndm,red_dof_ind] = reduce_geo( geometry,nodeDirMat,points )
%reduce_geo This function simply takes a subset of points out of a geometry
%structure
%   Pass in a geometry and node direction matrix, and it will
%   return the subset of those structures containing the points given by
%   points.

red_ndm = zeros(0,2);
red_geo.points = zeros(0,4);
red_geo.lines = zeros(0,2);
red_geo.CS=geometry.CS;
red_geo.patches = zeros(0,3);
red_geo.ptDefCS = zeros(0,1);
red_dof_ind = zeros(1,0);
%% Find points and nodeDirMat entries
for i = 1:length(points);
    % Find the fixture points in the nodeDirMat of blade
    dof_ind = find(points(i)==nodeDirMat(:,1));
    red_dof_ind = [red_dof_ind,dof_ind'];
    red_ndm(end+1:end+length(dof_ind),:) = nodeDirMat(dof_ind,:);
    pt_ind = find(points(i)==geometry.points(:,1));
    red_geo.points(end+1:end+length(pt_ind),:)=geometry.points(pt_ind,:);
    red_geo.ptDefCS(end+1:end+length(pt_ind),:) = geometry.ptDefCS(pt_ind,:);
end

%% Find lines used
for i = 1:size(geometry.lines,1)
    if any(geometry.lines(i,1)==points) && any(geometry.lines(i,2)==points)
        red_geo.lines(end+1,:) = geometry.lines(i,:);
    end
end

%% Find Patches Used
for i = 1:size(geometry.patches,1)
    if any(geometry.patches(i,1)==points) && any(geometry.patches(i,2)==points) && any(geometry.patches(i,3)==points)
        red_geo.patches(end+1,:) = geometry.patches(i,:);
    end
end

end