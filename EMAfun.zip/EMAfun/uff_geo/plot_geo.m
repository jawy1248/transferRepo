function h = plot_geo( geometry, varargin)
% h = plot_geo(geometry, varargin)
%
%plot_geo Plots Geometry returned by uff_geo.m
%   This function plots a geometry returned by uff_geo.m.  It may also take
%   other inputs as flags to turn on other behavior.
%   Other arguments include:
%       'labels' - plot text labeling each node.
%       'rot' or 'rotation' - applies a global rotation to the plot
%       determined by the rotation matrix passed as the next argument.
%       'CS' - plots all coordinates with rgb (corresponding to xyz) triads
%       'skiplabels' - to show only every other label use: 'skiplabels',2
%
%   Dan Rohe, 12-29-2011
hold on;
h1 = 0;
h2 = 0;
h3 = 0;
labels = 0; nlabskip=1;
rotmat = eye(3);
plotcs = 0;
for i = 1:length(varargin)
    if strcmpi(varargin{i},'labels');
        labels = 1;
    end
    if strcmpi(varargin{i},'rot') || strcmpi(varargin{i},'rotation')
        rotmat = varargin{i+1};
    end
    if strcmpi(varargin{i},'CS') || strcmpi(varargin{i},'coordsys');
        plotcs = 1;
    end
    if strcmpi(varargin{i},'skiplabels')
        nlabskip = varargin{i+1};
    end
end

for i = 1:size(geometry.points,1)
    geometry.points(i,2:4) = rotmat*geometry.points(i,2:4)';
end
% Points
h1 = plot3(geometry.points(:,2),geometry.points(:,3),geometry.points(:,4),'o');
if labels
    for i = 1:nlabskip:size(geometry.points,1)
        text(geometry.points(i,2),geometry.points(i,3),geometry.points(i,4),...
            {['  ',num2str(geometry.points(i,1))],' '});
    end
end

% Lines
for i = 1:size(geometry.lines,1)
    p1_ind = find(geometry.points(:,1)==geometry.lines(i,1));
    p2_ind = find(geometry.points(:,1)==geometry.lines(i,2));
    lineXs =[geometry.points(p1_ind,2);geometry.points(p2_ind,2)];
    lineYs =[geometry.points(p1_ind,3);geometry.points(p2_ind,3)];
    lineZs =[geometry.points(p1_ind,4);geometry.points(p2_ind,4)];
    h2 = plot3(lineXs,lineYs,lineZs);
end

% Patches
xdata = zeros(3,0);
ydata = zeros(3,0);
zdata = zeros(3,0);
for i = 1:size(geometry.patches,1)
    p1_ind = find(geometry.points(:,1)==geometry.patches(i,1));
    p2_ind = find(geometry.points(:,1)==geometry.patches(i,2));
    p3_ind = find(geometry.points(:,1)==geometry.patches(i,3));
    inds = [p1_ind,p2_ind,p3_ind];
    xdata=[xdata,geometry.points(inds,2)];
    ydata=[ydata,geometry.points(inds,3)];
    zdata=[zdata,geometry.points(inds,4)];
end
h3 = patch(xdata,ydata,zdata,'w');
zoom(.75);

% Coordinate systems
if plotcs
for i = 1:length(geometry.CS)
    CSs(i) = geometry.CS(i).num;
end
for i = 1:length(geometry.CS);
    pt = [0,0,0;1,0,0;0,1,0;0,0,1];
    for j = 1:4
        CS = geometry.CS(i).num;
        while(CS~=0)
            iCS = find(CSs==CS);
            pt(j,:) = CS2Global(pt(j,:)',geometry.CS(iCS(1)))';
            CS = geometry.CS(iCS(1)).parent;
        end
        pt(j,:) = rotmat*pt(j,:)';
        if j > 1
            switch j
                case 2
                    c = 'r';
                case 3
                    c = 'g';
                case 4
                    c = 'b';
            end
            plot3(pt([1,j],1),pt([1,j],2),pt([1,j],3),c);
        end
    end
end
end
h = [h1;h2;h3];
end

