function h = plot_modeshape_geo(geometry,subsys, nodeDirMat,varargin )
%plot_modeshape_geo(geometry,subsystem or modeshape matrix,nodeDirMat)
%   plot_modeshape_geo takes 3 arguments
%     geometry - argument returned from uff_geo.m, contains point, line,
%       and face in formation
%
%     subsys - can either be a subsystem like is used for ritzscomb.m
%       function or simply a modeshape matrix.  This function will check
%       for a phi field of the subsys variable, and if one does not exist,
%       it will assume what is passed is a modeshape matrix.  The modeshape
%       matrix should be oriented with each row corresponding to a degree
%       of freedom and each column corresponding to a modeshape.
%
%     nodeDirMat - The matrix specifying the node points and direction
%       for each degree of freedom.  This is returned from loaduff in the
%       refs structure.
%
% Additional optional arguments are:
%   'labels' - plots point numbers as well as the points
%   'rot' or 'rotation' - specifies that the next input argument will be a
%   rotation matrix that will rotate the plot.
%   'scale' - scales the modeshape plots of the turbine.
%   'scaleprop' - scale the mode shapes to a fraction of the max geometry.
%       e.g. plot_modeshape_geo(geometry,phi,mapping,'scaleprop',0.2);
%
% Dan Rohe, 1-03-2012

h1 = 0;
h2 = 0;
h3 = 0;
h4 = 0;
h5 = 0;
h6 = 0;
if isfield(subsys,'phi')
    phi = subsys.phi;
else
    phi = subsys;
end

labels = 0;
rotmat = eye(3);
saveflag = 0;
viewangle=[0,0];
nModes = size(phi,2);
modes = 1:nModes;
figstart=[];
for i = 1:length(varargin)
    if strcmpi(varargin{i},'labels')
        labels = 1;
    end
    if strcmpi(varargin{i},'rot') || strcmpi(varargin{i},'rotation')
        rotmat = varargin{i+1};
    end
    if strcmpi(varargin{i},'scale')
        phi=phi*varargin{i+1};
    end
    if strcmpi(varargin{i},'scaleprop') % added by MSA - scale prop to max displacement
        for k=1:size(phi,2)
            phi(:,k)=(phi(:,k)/max(abs(phi(:,k))))*max(max(abs(geometry.points(:,2:4))))*varargin{i+1};
        end
    end
    if strcmpi(varargin{i},'figstart')
        figstart = varargin{i+1};
    end
    if strcmpi(varargin{i},'save')
        saveflag = 1;
    end
    if strcmpi(varargin{i},'view')
        viewangle=varargin{i+1};
    end
    if strcmpi(varargin{i},'modes')
        modes = varargin{i+1};
        modes = modes(find(modes<=nModes));
    end
end

original_pts = geometry.points;

% Get each coordinate system number in a vector so we can find them easily
CSs = zeros(size(geometry.CS));
for i = 1:length(geometry.CS)
    CSs(i) = geometry.CS(i).num;
end

nDOF = size(phi,1);
if (size(nodeDirMat,1)~=size(phi,1))
    disp('Number of Degrees of freedom in modeshape matrix is not the same as the number in the NodeDirMat matrix');
    return
end
nPoints = size(geometry.points,1);
displacement = zeros(nPoints,1);

% Calculate the original geometry
for i = 1:size(geometry.points,1)
    undefPts(i,2:4) = rotmat*geometry.points(i,2:4)';
end

% We want to plot a figure for each modeshape
for k = modes
    if length(modes) > 1
        if isempty(figstart)
            figure;
        else
            figure(figstart+k);
        end
    end
    hold on;
    geometry.points = original_pts;
    % Loop though each degree of freedom
    for j = 1:nDOF
        % Get the point and direction of the displacement from the
        % nodeDirMat matrix
        point = nodeDirMat(j,1);
        pindex = find(geometry.points(:,1)==point);
        pindex = pindex(1);
        switch abs(nodeDirMat(j,2))
            case 1
                direction = [1,0,0]';
            case 2
                direction = [0,1,0]';
            case 3
                direction = [0,0,1]';
        end
        direction = direction*sign(nodeDirMat(j,2)); % Multiply by the sign so the direction is correct;
        
        % Go through each coordinate system in the current coordinate
        % system's stack to transform the direction to the proper
        % orientation
        CS = geometry.ptDefCS(pindex);
        while(CS~=0)    % While we are not at the base coordinate system
            iCS = find(CSs==CS);    % Find our coordinate system
            direction = geometry.CS(iCS(1)).C'*direction; % Undo that rotation
            CS = geometry.CS(iCS(1)).parent;    % And set the current system to the parent (reference CS) of the previous system.
        end
        
        % Add the modeshape to the original point in the direction
        % specified.
        geometry.points(pindex,2:4) = geometry.points(pindex,2:4)+direction'*phi(j,k);
    end
    
    for i = 1:size(geometry.points,1)
        displacement(i) = norm(geometry.points(i,2:4)-original_pts(i,2:4));
    end
    
    for i = 1:size(geometry.points,1)
        geometry.points(i,2:4) = rotmat*geometry.points(i,2:4)';
    end
    
    % Points
    h1 = plot3(geometry.points(:,2),geometry.points(:,3),geometry.points(:,4),'bo','MarkerSize',2);
    h4 = plot3(undefPts(:,2),undefPts(:,3),undefPts(:,4),'ko','MarkerSize',1.5);
    if labels
        for i = 1:size(geometry.points,1)
            text(geometry.points(i,2),geometry.points(i,3),geometry.points(i,4),...
                {['  ',num2str(geometry.points(i,1))],' '});
        end
    end
    
    % Lines
    for i = 1:size(geometry.lines,1)
        p1_ind = find(geometry.points(:,1)==geometry.lines(i,1));
        p2_ind = find(geometry.points(:,1)==geometry.lines(i,2));
        lineXs =[geometry.points(p1_ind,2);geometry.points(p2_ind,2)];
        lineYs =[geometry.points(p1_ind,3);geometry.points(p2_ind,3)];
        lineZs =[geometry.points(p1_ind,4);geometry.points(p2_ind,4)];
        lineXs_undef = [undefPts(p1_ind,2);undefPts(p2_ind,2)];
        lineYs_undef = [undefPts(p1_ind,3);undefPts(p2_ind,3)];
        lineZs_undef = [undefPts(p1_ind,4);undefPts(p2_ind,4)];
        h2 = plot3(lineXs,lineYs,lineZs,'b-','linewidth',1);
        % Undeformed lines
        h5 = plot3(lineXs_undef,lineYs_undef,lineZs_undef,'k:','linewidth',0.25);
    end
    
    % Patches
    xdata = zeros(3,0);
    ydata = zeros(3,0);
    zdata = zeros(3,0);
    xdata_undef = zeros(3,0);
    ydata_undef = zeros(3,0);
    zdata_undef = zeros(3,0);
    cdata = zeros(3,size(geometry.patches,1));
    for i = 1:size(geometry.patches,1)
        p1_ind = find(geometry.points(:,1)==geometry.patches(i,1));
        p2_ind = find(geometry.points(:,1)==geometry.patches(i,2));
        p3_ind = find(geometry.points(:,1)==geometry.patches(i,3));
        inds = [p1_ind,p2_ind,p3_ind];
        xdata=[xdata,geometry.points(inds,2)];
        ydata=[ydata,geometry.points(inds,3)];
        zdata=[zdata,geometry.points(inds,4)];
        xdata_undef=[xdata_undef,undefPts(inds,2)];
        ydata_undef=[ydata_undef,undefPts(inds,3)];
        zdata_undef=[zdata_undef,undefPts(inds,4)];
        cdata(:,i)=(displacement(inds)/max(displacement)).^(.7);
    end
    h3 = patch(xdata,ydata,zdata,'w');
    set(h3,'FaceColor','interp','Cdata',cdata,'EdgeColor','b','LineWidth',1);
    h6 = patch(xdata_undef,ydata_undef,zdata_undef,'w');
    set(h6,'FaceColor','none','EdgeColor','k','LineWidth',.25,'LineStyle',':');
%     zoom(.75);
    axis equal;
    axis tight;
    if isfield(subsys,'phi')
        titletext = {['Mode Shape ',num2str(k),':'];['f_n = ',num2str(subsys.wn(k)/(2*pi)),' \zeta_n = ',num2str(subsys.zt(k))]};
    else
        titletext = ['Mode Shape ',num2str(k)];
    end
    title(titletext);
    
    h(:,k) = [h1;h2;h3;h4;h5;h6];
    
    view(viewangle);
    if saveflag
        saveas('Mode_',num2str(k),'.png');
    end
    
end

end

