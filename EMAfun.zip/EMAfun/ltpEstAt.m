function [At_est] = ltpEstAt(lam,Ares,wA,ts,ws);
%
% Inputs:
%   lam = unaliased eigenvalues in continuous time
%   A = Residue matrix as identified by AMI (no need to ref to time zero).
%       N_modes x N_outputs (time steps) x N measurement points
%   wA = Frequency of periodicity (rad/s)
%
% OBSOLETE - use ltpRes2STM.m

%% Extract Mode Vectors from Residues:
% #########################################################################
% Correct Eigenvalues - Manual at this point!!
% #########################################################################
% AMI Eigenvalues
    % loaded  %lam = conj(eig_store(:,3)) + i*wA;
    Nm_in = length(lam);
    ts_cyc = ts(1:size(Ares,2)); % time vector for one cycle
    TA = 2*pi/wA;
    NA = size(Ares,2);
    
N_FSE = 3;
for m_num = 1:Nm_in
%     [Azero_AMI(:,:,m_num)] = ltpRes2Phi([Ax_store(m_num,:); Ay_store(m_num,:)],ts,lam(m_num));
    % this matrix has the modes in its last dimension and the measurement
    % points in the first - opposite of AMI standard.
    [Azero_AMI(:,:,m_num)] = ltpRes2Phi(squeeze(conj(Ares(m_num,:,:))).',ts,lam(m_num));
    [B(:,:,m_num),mB(:,:,m_num),ltpFS_ad{m_num}] = ltpResFS(Azero_AMI(:,:,m_num),N_FSE,50+m_num);
        % This gives B(:,1) = x, B(:,2) = y - a row of B's for each
        % coordinate in A
        % Reconstruct Azero_AMI from the Fourier series coefficients B
        Az_fs(:,:,m_num) = zeros(size(Azero_AMI(:,:,1)));
        for m = 1:size(B,2);
            Az_fs(:,:,m_num) = Az_fs(:,:,m_num) + ...
                diag(B(:,m,m_num))*exp(i*wA*mB(:,m,m_num)*ts_cyc); % (ths/omega)
        end
end

% Find STM of System
% Model is now:  
% B(i,j,k) = coeff of FS for xi (x1=x, x2=y), coeff j, mode k
% mB(i,j,k) = same, index of FS coeff for B above
% lam(k) = mode k
% According to the derivation - this becomes the model for [W].  Next we'll
% compute the modal participation factors and scale W to get psi.

No = size(B,1); Nm = size(B,2); N_modes = size(B,3);
A_full = zeros(Nm*N_modes,No); lam_full = zeros(Nm*N_modes,No);
for k = 1:N_modes % loop over modes
    A_full([(k-1)*Nm+1:k*Nm],:) = B(:,:,k).'; % create blocks of mode 1, m1-end x No
    lam_full([(k-1)*Nm+1:k*Nm],:) = lam(k*ones(Nm,No))+i*wA*mB(:,:,k).';
end
% separate response points - trick ss_model into making this correctly
A_full = [A_full(:,1), zeros(Nm*N_modes,1);
    zeros(Nm*N_modes,1), A_full(:,2)];
lam_full = vec(lam_full);
% A_full = [B(1,:,1).', B(2,:,1).'; B(1,:,2).', B(2,:,2).'];
% lam_full = [lam(ones(3,2))+i*wA*[mB(1,:,1).', mB(2,:,1).';]
%     lam(2*ones(3,2))+i*wA*[mB(1,:,2).', mB(2,:,2).']; ];
[H_full] = ss_model(lam_full,A_full,ws,'D','s');

%     figure(16)
%     semilogy(ws,abs(XA),ws,abs(H_full),'--'); hold off; %,ws,abs(XR2F),ws,abs(XR)
%         set(get(gca,'Children'),'LineWidth',2);
%         set(gca,'Xlim',[0,3],'XTick',[0:0.2:3]);
%     legend('x','y','x-fit','y-fit');
    
%
% Find Modal Participation Factors
N = 4;
ICmat = ltpRespFS(lam,B,mB,wA,[],[],[0:(N-1)]*TA,'expand');

% Compute Modal Participation Factors
lam_ss = [lam; conj(lam)];
B_ss = B; B_ss(:,:,3) = conj(B(:,:,1)); B_ss(:,:,4) = conj(B(:,:,2));
mB_ss = mB; mB_ss(:,:,3) = -mB(:,:,1); mB_ss(:,:,4) = -mB(:,:,2);
Ls_t0 = zeros(N,N); Us_t0 = zeros(N,N);
for m_num = 1:4;
    Ls_t0(:,m_num) = (exp(lam_ss(m_num)*[0:(N-1)]*TA)*inv(ICmat)).';
    Us_t0(:,m_num) = [sum(B_ss(:,:,m_num),2); ... % disp portion
        sum(B_ss(:,:,m_num).*(i*wA*mB_ss(:,:,m_num)+lam_ss(m_num)),2)]; % veloc portion
end

test_orth = Us_t0.'*Ls_t0;
if norm(test_orth-eye(size(test_orth))) > 1e3*eps; error('Orthogonality Problem'); end
% Usfs = diag(test_orth);
% B_psi = zeros(size(B)); B_ss_psi = zeros(size(B_ss));
% for m_num = 1:4;
%     if m_num > 3
%         B_psi(:,:,m_num) = B(:,:,m_num)/Usfs(m_num);
%     end
%     B_ss_psi(:,:,m_num) = B_ss(:,:,m_num)/Usfs(m_num);
% end
% B_psi now contains a model for the scaled, time dependent mode vectors PSI

% B now is verified to contain a model for the scaled, time dependend mode
% vectors psi.  One can compute the modal participation factors <Lr> from
% them.

% Finish deriving formulas and compute STM and (d/dt)STM
STM = ltpRespFS(lam,B,mB,wA,Ls_t0(:,1:2),eye(N),ts_cyc,'expand');
Bdiff = ltpDiffFS(B,mB,wA,lam);
STMdot = ltpRespFS(lam,Bdiff,mB,wA,Ls_t0(:,1:2),eye(N),ts_cyc,'expand');

At_est = zeros(size(STM));
for k = 1:NA
    At_est(:,:,k) = STMdot(:,:,k)*inv(STM(:,:,k));
end

figure(31);
f31lhs = plot(ts_cyc,squeeze(At_est(3,1,:)),'bo',...
    ts_cyc,squeeze(At_est(3,2,:)),'ro'); grid on;
xlabel('\bftime (s)'); ylabel('\bfCoefficient');
title('\bfSample Elements of Time Varying State Matrix A(t)')
legend('A(3,1) Est','A(3,2) Est');
% set(f31lhs([1,3]),'LineWidth',2);
% xaxdegrees(gca)