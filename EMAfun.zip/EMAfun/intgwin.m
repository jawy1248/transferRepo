function y = intgwin(x,M)
% intgwin.m
% function y = intgwin(x,M)
% function to evaluate the product of sin(x)/x * window for intgsgn.m
% x = a vector of input values
% M = a constant needed to evaluate the function, an even positive integer, >=2
%     duration of the window is |x| <= M/2
% y = a vector of values of the function evaluated at x, N.

% D.O. Smallwood, Sandia National Laboratories, 5/27/94
% Reference: Smallwood, David O.,"Integration of Equally Spaced Sampled Data
%            Using a Generalized Whittaker's Reconstruction Formula," IEEE Transactions
%            on Acoustics, Speech, and Signal Processing, Vol. ASSP-28, No. 3, June 1980.

if rem(M,2)~=0
   disp(['Error in intgwin: M is not even M=' num2str(M)] )
   return
end
if M<2
   disp(['Error in intgwin: M is not >2  M=' num2str(M)] )
   return
end
% I'll use a Nuttall window type 15
a =[.3635819 .4891775 .1365995 .0106411];
N = length(x);
w = zeros(size(x));
for k=1:N
    if abs(x(k))<=M/2, w(k)=1;, end
end
y = zeros(size(x));
for k=1:4
    y = y + a(k).*cos(2*pi*(k-1).*x./M);
end
pix = pi.*x;
y = (y./M).*w.*sinxovx(pix);

%added 8/22/05 by David Epp
function y=sinxovx(x)
y=(sin(x).*(x~=0)+ones(size(x)).*(x==0))./(x.*(x~=0)+ones(size(x)).*(x==0));