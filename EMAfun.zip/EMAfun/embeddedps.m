function Y=embeddedps(x,m,tao,npoint)
% Create an embedded state space from a measured time series or collection
% of states.
%
% Y=embeddedps(x,m,tao); 
%   or
% Y=embeddedps(x,m,tao,npoint);
%
% x = time series, of size Nt by n, where Nt=number of time samples and
%       n=number of states.
% m = embedding dimension.  The original series is stacked this number of
%       times to make an embededed state space of size n*m.
% tao = number of samples to delay each state space.
% npoint = Number of time samples to retain in the embedded state space.
% By default leave this blank and all samples are used.
% 
% Y is the embedded state space of size [M,n*m] with M=(Nt-(m-1)*tau).
%
% By: M.S. Allen, based on psr_deneme by "Merve Kizilkaya"
%
N=length(x);
n=size(x,2); % if multiple states, assume they are in columns.
if nargin == 4
    M=npoint;
else
    M=N-(m-1)*tao; % maximum length (in samples) of embedded phase space for N, m and tau
end

Y=zeros(M,m*n); 

for i=1:m
    Y(:,[1:n]+(i-1)*n)=x((1:M)+(i-1)*tao,:);
end