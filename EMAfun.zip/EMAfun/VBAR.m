function [lamc,lamd] = VBAR(y,q,T)
% Function which fits data using Vector Backward Auto Regressive Fit
% 	y is a matrix of time responses where the response of each coordinate
% 	is a column of y.

% Arrange Data into solution matrices:
% Form: [y1 y2 y3 ...yN-q] = [a1 a2 a3 ...]*[y2 y3 ... yN-q+1]
%                                           [y3 y4 ... yN-q+2]
%                                           [.  .         .  ]
%                                           [yq+1 yq+2 ... yN]
% B = A*C
%
% Based on a paper - (ref here) on hard drive.

[a,b] = size(y);
if b > a; y = y.'; end %Put Y in column form

[N,p] = size(y);

if q^2 > N; error('Too many block rows requested'); end

B = y([1:N-q],:).';
for ii = 1:1:q;
    C(p*(ii-1)+1:p*ii,1:(N-q)) = y([(ii+1):(N-q+ii)],:).';
end

% A = B*C.'*inv(C*C');
A = ((C*C')\(C*B.')).';

Ad = A;
for ii = 1:1:(q-1)
    Ad([ii*p+1:(ii+1)*p],[(ii-1)*p+1:ii*p]) = eye(p);
end

lamd = eig(Ad).^-1;
[junk,ind] = sort(abs(lamd));
lamd_sort = lamd(ind);
lamd_trunc = lamd_sort(1:max(find(abs(lamd) < 1)));
lamc = ln(lamd_trunc)/T;

% figure(1)
% plot(lamd,'*'); grid on; hold on
% plot(real(exp(i*[0:0.1:2*pi])),imag(exp(i*[0:0.1:2*pi])),'k'); hold off;
% plot(exp(lamss*dt),'ro'); hold off;