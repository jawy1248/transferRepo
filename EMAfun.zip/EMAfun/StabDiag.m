function [] = StabDiag(data);
% Plot a stabilization diagram of data output from a curve fitting
% algorithm.

% Extract:
H = data.He;
ws = data.wse;
psf = data.psf;
int_mat = data.sd_inds;
lf_lssd = data.lam_fit;
fit_band_w = data.fit_band_w;

figure(301); clf(301);
title('\bfComposite FRF and pLSCF Nat. Freq.');
hl1 = line(ws/psf,comp_FRF(H),'Color','b'); grid off;
ax1b = gca;
    pos1 = get(ax1b, 'Position');
    pos1 = pos1 + [0.02 0.04 -0.04 -0.08];
    set(ax1b, 'Position', pos1);
set(ax1b,'XColor','k','YColor','b','Yscale','log','YAxisLocation','right'); %,'Xlim',[0 max(wpeak)*sf_w]
ylabel('Magnitude of Composite FRF');
ax2b = axes('Position',get(ax1b,'Position'), 'XAxisLocation','bottom',...
           'YAxisLocation','left', 'Color','none',...
           'XColor','k','YColor','k','Ylim',[-10 max(max(ind_mat))]); % 'Xlim',[0 max(wpeak)]
% Filter SD
hs1 = []; hs2 = []; hs3 = [];
for r = 1:size(lf_lssd,1);
    for s = 1:size(lf_lssd,2);
        if real(lf_lssd(r,s)) < 0 & (-real(lf_lssd(r,s))/abs(lf_lssd(r,s)) < 0.10) ; % Stable Poles
            hs1 = line(abs(lf_lssd(r,s))/psf,ind_mat(r,s),'Color','k',...
                'LineStyle', 'none','Marker', 'o','MarkerSize',4,'Parent',ax2b);
            lf_filt(r,s) = lf_lssd(r,s);
            % Create Text marker showing nat. frequency and damping
%                 ht1 = text(abs(lf_lssd(r,s)),ind_mat(r,s),['(',num2str(abs(lf_lssd(r,s)),6), ', '...
%                         num2str(-real(lf_lssd(r,s))*100/abs(lf_lssd(r,s)),3),')']);
%                     set(ht1,'FontSize',8,'Color',[0         0.75         0.75]);
            %line(abs(lf_lssd(r,s))+ [real(lf_lssd(r,s)), -real(lf_lssd(r,s))],ind_mat(r,s)*[1,1],'Color','g',...
            %    'LineStyle', ':','Marker', '+','MarkerSize',2,'Parent',ax2b);
        elseif real(lf_lssd(r,s)) < 0 & (-real(lf_lssd(r,s))/abs(lf_lssd(r,s)) < 1)
            hs2 = line(abs(lf_lssd(r,s))/psf,ind_mat(r,s),'Color','b',...
                'LineStyle', 'none','Marker', '+','MarkerSize',3,'Parent',ax2b);
        elseif abs(imag(lf_lssd(r,s))) > eps
            hs3 = line(abs(lf_lssd(r,s))/psf,ind_mat(r,s),'Color','r',...
                'LineStyle', 'none','Marker', 'x','MarkerSize',3,'Parent',ax2b);
        end
    end
end
% Plot a marker for each if none are plotted
if isempty(hs2);
    hs2 = line(-10,min(min(ind_mat)),'Color','b','LineStyle', 'none',...
        'Marker', '+','MarkerSize',3,'Parent',ax2b);
end
if isempty(hs3);
    hs3 = line(-10,min(min(ind_mat)),'Color','r',...
                'LineStyle', 'none','Marker', 'x','Parent',ax2b);
end
xlabel('\bfFrequency'); ylabel('\bfLSCF Model Order (2*N-DOF)');
legend([hs1,hs2,hs3],'Stable \zeta < 0.10','Stable \zeta > 0.10','Unstable')
% legend([hs1,hs3],'Re(\lambda) < 0','Re(\lambda) > 0')
set([ax1b ax2b],'Xlim',[fit_band_w]/psf])
% Zoom Button
uicontrol('Style', 'pushbutton', 'Position', [10 10 100 20], 'String', 'Zoom',...
   'Callback','sdaxset','Tag','ZoomButton');
% disp('Type ''sdaxset'' to Zoom in');