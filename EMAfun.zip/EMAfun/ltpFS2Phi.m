function [phi] = ltpFS2Phi(B,mB,wA,ts_cyc,varargin)
%
% Conversion of Fourier Series Model to phi(t).
%
% [phi] = ltpFS2Phi(B,mB,wA,ts_cyc);
%
% B is a matrix of Fourier coefficients, mB is a matrix of integers giving
% the index for each of the Fourier coefficients.  The size of each is:
%     No - number outputs
%     Nfs - number Fourier Series Coefficients
%     N - number of modes
%
% For CSLDV measurements where No = 1, B and mB are Nfs x N and call 
% the function using the following syntax:
%
% [phi] = ltpFS2Phi(B,mB,wA,ts_cyc,'CSLDV');
%       the matrix phi returned is Nt x N 
%
% MSA, July 2010
%

if nargin > 4 && strcmpi(varargin{1},'CSLDV');
    B = permute(B,[3,1,2]);
    mB = permute(mB,[3,1,2]);
    if size(mB,3) == 1;
        mB = mB(:,:,ones(1,size(B,3)));
    end
end
No = size(B,1);
Nfs = size(B,2);
N = size(B,3);
Nt = length(ts_cyc);
phi = zeros(No,Nt,N);
for k = 1:size(B,1);
    for m = 1:size(B,2); % loop over FS terms
        for n = 1:size(B,3); % loop over modes
            phi(k,:,n) = phi(k,:,n)+B(k,m,n)*exp(1i*mB(k,m,n)*wA*ts_cyc(:).');
        end
    end
end

if nargin > 4 && strcmpi(varargin{1},'CSLDV');
    phi = permute(phi,[2,3,1]);
end