function [] = PlotSubstrContrib(ad,varargin);
% Create a plot illustrating how each of the subcomponent modes contributes
% to the modes of the built up structure.
%
% PlotSubstrContrib(ad);
%   where ad is the structure all_data from "ritzscomb.m"
% PlotSubstrContrib(ad,fig_num,marker_scalefact);
%   plot in figure window "fig_num"
%
% Theory:
% In substructuring predictions, the matrix B*phi_hat tells how each of the
% subcomponent modes contributes to the modes of the built up structure,
% which are the columns of phi_hat.  This m-file plots B*phi_hat, to
% illustrate this dependence.
%
% MSA, May 2010

% Create normalize matrix of modal contributions
Bph = ad.B*ad.Phi_hat;
    Bph = Bph*diag(max(abs(Bph),[],1).^-1); % normalize each column to max of 1
    Bph = abs(Bph); % magnitude of contribution
    
% find frequency vectors
wv = diag(ad.Phi_hat.'*ad.K_hat*ad.Phi_hat).^(1/2);

for k = 1:length(ad.subsys);
    wh{k} = vec(ad.subsys(k).wn);
    Ns(k) = length(wh{k});
    if k == 1;
        v_ind(1,:) = [1,Ns(1)]; % beginning and ending indices in Bph
    else
        v_ind(k,:) = [v_ind(k-1,2)+1,sum(Ns(1:k))];
    end
end

% Could add logic here to only create the plot for the lower frequency
% modes, say only modes up through the max frequency/2

if nargin > 1;
    figure(varargin{1}); clf(varargin{1});
else
    figure
end
mkrs = 'o^sdV*<p>h';
    while length(ad.subsys) > length(mkrs); % in case there are many subsys
        mkrs = [mkrs,mkrs];
    end
if nargin > 2;
    mkr_sf = varargin{2};
else
    mkr_sf = 100;
end

colormap('bone'); cmap = colormap; colormap(flipud(cmap));
hold on;
for k = 1:length(ad.subsys);
    mkr_sizes = vec(Bph(v_ind(k,1):v_ind(k,2),:));
    xVec = vec(wh{k}*ones(1,length(wv)))/2/pi;
    yVec = vec(ones(Ns(k),1)*wv.')/2/pi;
    scatter(xVec(mkr_sizes>0),yVec(mkr_sizes>0),...
        mkr_sizes(mkr_sizes>0)*mkr_sf,mkr_sizes(mkr_sizes>0),mkrs(k),'filled');
    leg_txt{k} = ['Subsys #',num2str(k)];
end
hold off;
xlabel('\bfFreq. of Subsystems (Hz)'); ylabel('\bfFreq. of Built-up System (Hz)');
title({'\bfContribution of Subsys Modes to','Built-up Structure Modes'});
v = axis;
    mv = max(v(3:4));
    line([0,mv],[0,mv],'Color','k','LineStyle','--')
    line([0,mv],[0,0.5*mv],'Color','r','LineStyle',':')
    line([0,0.5*mv],[0,mv],'Color','r','LineStyle',':')
% axis([v(1),0.5*v(2),v(3),0.5*v(4)]);
legend(leg_txt);

