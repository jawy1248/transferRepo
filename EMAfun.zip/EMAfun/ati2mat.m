% ATI2MAT - Convert data from an I-DEAS time history file (*.ati) to a MATLAB
%   MAT-file.  This is done to put the I-DEAS data into a format that can be
%   read by any copy of MATLAB (i.e., you don't need the IMAT toolbox).
% Has no calling arguments; user is prompted for all inputs.

%=======================================================================
% Required toolboxes/functions that are not part of basic MATLAB:
% - IMAT (I-DEAS to MATLAB translator) functions:
%	getunits(), readadf(), setunits()
%
% MAT-file will store the following MATLAB variables that were previously read
%   from an I-DEAS time history file (*.ati):
%	ati		1 x 1			struct array
%	atiFname	1 x N			char array
%	atiUnitSys	1 x 2			char array
%
% 03-Mar-2005, Created (Curt Nelson)
% 15-Mar-2006, Last modified (Curt Nelson)
%=======================================================================

[atiFname,fpath] = uigetfile('*.ati', 'I-DEAS time history file (*.ati): ');

%setunits('IN')	% set units for I-DEAS interface to in-lbf-slinch
%setunits('SI')	% set units for I-DEAS interface to m-N-kg

% get the unit system the data will be converted into (*.ati files always store
%   data in SI units) --- if setunits() has not been previously called, then the
%   user will be prompted for a unit system
atiUnitSys = getunits;

atiObj = readadf([fpath,atiFname])

% convert data from *.ati file into a standard MATLAB structure
%	atiObj is "ideas_fn object" class --- requires IMAT
%	ati is "struct array" class --- understood by basic MATLAB
ati = get(atiObj);

%% also save the most-used data as MATLAB variables
%%	atiTime		nPts x 1		double array
%%	atiData		nPts x nRecords		double array
%%	atiRespInfo	nRecords x 1		cell array
%%	atiRespType	nRecords x 1		cell array
%%   where:
%%	nPts = number of data points in each time history data record
%%	nRecords = number of data records
%atiTime = ati.Abscissa(:,1);
%atiData = ati.Ordinate;
%atiRespInfo = ati.ResponseCoord;	% sensor location, direction, and sense
%atiRespType = ati.OrdNumDataType;
%NumPts = ati.NumberElements(1);	% NumPts = size(ati.Ordinate,1)
%atiSampFreqHz = 1/ati.AbscissaInc(1);

% save data to a binary MAT-file
out_fname = strrep(atiFname, '.ati', '.mat');
fprintf('Saving data (in %s units) to <%s>\n', atiUnitSys, out_fname)
save(out_fname, 'ati', 'atiFname', 'atiUnitSys')

clear fpath out_fname

% use "LOAD filename" to read data from a MAT-file back into MATLAB
