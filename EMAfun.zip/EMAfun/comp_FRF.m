function [Xw_comp] = comp_FRF(X,varargin);
% function [Xw_comp] = comp_FRF(X);
%
% Function which forms a composite FRF given a complex matrix X
% whose columns are the individual FRFs.
%   i.e. X has size Nf x No x Ni where Nf is the number of frequency lines,
%   No is the number of outputs or response points and Ni is the number of
%   inputs or drive points.
% 
% Composite = mean of abs(X) for all drive points
% 
% Matt Allen, 2004
% msalle@sandia.gov
%

% Composite = mean of abs(X) for all drive points
[a b c] = size(X);
if c == 1;
    Xw_comp = sum(abs(X),2)/b;
else
    Xw_comp = sum(abs(X),3);
    Xw_comp = sum(Xw_comp,2)/(b*c);
end
