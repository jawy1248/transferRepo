function [H1,ws,Guu,Gyu] = H1mest(y,u,ts,Nblk,window_name,NoPCToverlap)
%
% MIMO Frequency Response Functin Estimate from input-output data.
%
% [H1,ws,Guu,Gyu] = frfmest(y,u,ts,Nblk,window_name,NoPCToverlap)
%   y - output (Nt x No)
%   u - input (Nt x Ni)
%   ts - time vector (Nt x 1)
%   Nblk = number of samples per block - see mimocsd.m
%   window_name - 'rect', 'hanning' see mimocsd.m
%   NoPCToverlap - number of samples to overlap or percent of records to
%       overlap - see mimocsd.m
%   
%   H1 - FRF estimate using the named methods
%   To also estimate the coherences, use frfmest.  This requires also
%   calculating Gyy, which can require more storage.
%   Guu, Gyu - Auto/Cross Spectrum matrices returned if desired.
%
%
% Matt Allen, Spring 2005
% msalle@sandia.gov
% 2018-08-14 - Added feature to request only H1.
%
% This is a work in progress.  Basic functionality has been verified, yet
% the documentation is incomplete and the options are limited.
%

% Find Spectral Density Matrices for use my algorithms.

[Guu, Gyu, ws] = mimocsd(y,u,ts,Nblk,window_name,NoPCToverlap);
No = size(Gyu,1); Ni = size(Gyu,2); Nw = size(Gyu,3);
H1 = zeros(No,Ni,Nw);

% Estimate FRFs using H1 estimator
% Turn off warnings ??? 
% warning('OFF','MATLAB:nearlySingularMatrix');
for k = 1:Nw
    % H1 Method
    H1(:,:,k) = Gyu(:,:,k)/Guu(:,:,k);
    % H1(:,:,k) = Guu(:,:,k)\(Gyu(:,:,k)'); % Are These Different?
    Fvirt(k,:) = eig(Guu(:,:,k)).';
     
end

% Turn warnings back on
% warning('ON','MATLAB:nearlySingularMatrix');

if Ni > 1;
    figure(2000);
    subplot(2,1,1)
    semilogy(ws, Fvirt);
    title('Virtual force.  Low values might signal ill-conditioning in H_1 estimate');
        for k = 1:Ni; vflab{k} = ['Virtual Force #',num2str(k),' (H1)']; end
        legend(vflab);
    subplot(2,1,2);
    semilogy(ws, RGyu,'-.'); 
    title('Singluar Values of Gyu, relevant for H_2 estimate');
    xlabel('Frequency (rad/s)');
        for k = 1:Ni; vflab2{k} = ['S.V. (Gyu) #',num2str(k),' (H2)']; end
        legend(vflab2);
end
