% Estimate modal damping and stiffness versus displacement amplitude using
% quasi-static analysis
clear; % close all;

%% Build the Model

% Parameters for Quasi-static analysis
    % Create a vector of desired force amplitudes.  This seems to provide a set
    % of well spaced points logarithmically
        % Am = kron(logspace(-3,3,20),[0.5:0.1:1]);
    % Or just use s simple logspace:
        Am = logspace(-3,3,100); % Quasi-static force levels
        Nmin=5; % Minimum number of points to use in a load-displacement curve when estimating damping and stiffness.
            % Below we'll calculate (length(Am)-Nmin) estimates of the 
            % stiffness and damping.
        
    mind=1; % ##### Index of the mode to study #####    

% Set up system of interest
    M0 = 10;               % Mass
    Kinf = 5;              % stiffness of elastic spring
    % zeta = .001;           % modal zeta

    % Nonlinear Iwan Joint parameters
    % params = [Fs,Kt,chi,beta];
    %         IwanPairs = [2,3]; % Iwan joint between masses 2 and 3
    % Multiple Iwan joints
    params=[10,5,-0.5, 0.1;
        1,4,-0.2, 0.01;
        100,3,-0.8,1];%
    IwanPairs = [0,1; 1,2; 2,3];
    Nj=100;

    for k=1:size(params,1) % Find mathematical description of Iwan parameters
        paramm(k,:)=iwanconvert(params(k,:)); % Iwan param - 'm' for mathematical description [chi, phi_max, R, S]
    end

    % Define matrices
    N=3;
    M = M0*diag([1,1,1]);
    KINF = [2*Kinf -Kinf 0;
        -Kinf 2*Kinf -Kinf;
        0 -Kinf Kinf]; % Stiffness matrix at infinite load (all springs slipping)
    KT = [9    -4     0;
        -4     7    -3;
         0    -3     3]; % Stiffness due to joints when they are fully stuck
    K0 = KINF+KT; % Totaly stiffness when all joints stuck
    
    % Eigen Analysis
    [phi0,lam0] = eig(K0,M);      % mode shapes with joint stiffness (micro-slip)
    [phiInf,lamInf] = eig(KINF,M);     % mode shapes without joint stiffness (macro-slip)

    fn0 = sqrt(diag(lam0))/2/pi;  % natural frequencies calculated with joint stiffness
    fnInf = sqrt(diag(lamInf))/2/pi; 

    % Damping based on desired damping ratio
    %   C = M*phi*2*zeta*sqrt(lam)*phi0'*M; % physical damping coeff matrix 
    % Damping based on stiffness proportional, by directly assembly damping
    % matrices.
        C = M*0.002+KINF*0.002;
        ztsInf=diag(phiInf.'*C*phiInf)./(2*sqrt(diag(lamInf)))
        zts0=diag(phi0.'*C*phi0)./(2*sqrt(diag(lam0)))

% Initialize variables and begin quasi-static analysis
tic
    % Create quasi-static force
    f_ext=Am; %A*(0:Nt)/Nt;%A*sin(ts); % ts must be a row vector
    fext = M*phi0(:,mind)*f_ext; % Force applied at DOF N
% #### Solve for quasi-static response ####
ICs={zeros(N,1),zeros(Nj,3)};
[x, f_joint,k_joint,jys,ad] = IwanStatic(KINF,fext,params,IwanPairs,ICs);

    % Transform Physical DOF into Modal DOF
    f_m_all = phi0.'*(fext);
    q_x_all = phi0.'*M*x;

% Use QS load-displacement curve to compute stiffness and damping as a
% function of amplitude.
    Ksec=zeros(1,length(Am)-Nmin); % Secant stiffness
    fnsec=Ksec; D=Ksec; Drect=Ksec; Xamp=Ksec;
    zt=Ksec; qAmp=zeros(size(q_x_all,1),length(Ksec));
for ii = 1:(length(Am)-Nmin) % Force curves go from length=Nmin to length=length(Am)
    % External Force
        
        % Collect current load curves
        f_x = [0,f_m_all(mind,1:(ii+Nmin))]; % Add zero values for no-load case rather than compute them.
%         q_x = [0, (phiTM(mldsnl,:)*u_nls(:,1:ii))];   
        q_x = [0, q_x_all(mind,1:(ii+Nmin))];
        qAmp(:,ii)=max(abs(q_x_all(:,1:(ii+Nmin))),[],2);

        % Compute effective stiffness and dissipation
        % Calculate secant stiffness
        Ksec(ii)=f_x(end)/q_x(end);
            fnsec(ii)=sqrt(Ksec(ii))/2/pi; % Secant nat. freq. in Hz
        
        % Calculcate Dissipation and effective damping ratio due to joint.
        % Use Masing's rules to create force-displacement over a full cycle:
        qfull=[2*q_x-q_x(end) , -2*q_x+q_x(end)];
        ffull=[2*f_x-f_x(end) , -2*f_x+f_x(end)];
            % Doing it like this, the nonlinear curve automatically goes
            % from negative displacement to positive.
        D(ii)=trapz(qfull,ffull);
            % Note, could instead use 4*trapz(2*q_x(:),f_x(:)-0.5*f_x(end))
        Drect(ii)=sum(ffull(2:end).*diff(qfull));
            % tdyn=ts/(fn0(mind)*2*pi);
            % Compute equivalent damping ratio.
            Xamp(ii)=q_x(end);
            zt(ii)=D(ii)/(Xamp(ii)^2*(fnsec(ii)*2*pi)^2*2*pi);
end
        
t_qs=toc
% Estimate Velocity amplitude for plots
Vamp=Xamp.*(2*pi*fnsec);

% Plot of raw force displacement curve
figure(10)
plot(x,f_ext);
xylabels('\bfForce','\bfResponse');

% Plot of force displacement extended over a cycle
figure(11)
iiplot=15;
    f_x = [0,f_m_all(mind,1:(iiplot+Nmin))]; % Add zero values for no-load case rather than compute them.
    %         q_x = [0, (phiTM(mldsnl,:)*u_nls(:,1:ii))];   
    q_x = [0, q_x_all(mind,1:(iiplot+Nmin))];
    % Use Masing's rules to create force-displacement over a full cycle:
    qfull=[2*q_x-q_x(end) , -2*q_x+q_x(end)];
    ffull=[2*f_x-f_x(end) , -2*f_x+f_x(end)];
    fnj=fn0(mind); % linear nat freq, to use below
subplot(1,2,1)
plot(q_x,f_x,qfull,ffull);
xylabels('\bfModal Force','\bfModal Response');
subplot(1,2,2) % Plot again with nonlinear part removed.
plot(q_x,f_x-q_x*(fnj*2*pi)^2,'ro:',qfull,ffull-qfull*(fnj*2*pi)^2); grid on;
xylabels('\bfModal Response','\bfModal Force - Linear Force');

%% Compare to damping extracted from transient response
if mind==1
    DpM=load('3DOF3Iwan_1e3_M1_M1Fit.mat');
    Dp3=load('3DOF3Iwan_1e2pt3_M1Fit.mat');
    Dp2=load('3DOF3Iwan_1e2pt2_M1Fit.mat');
elseif mind==2;
% Mode 2
    DpM=load('3DOF3Iwan_1e3_M2_M2Fit.mat');
    Dp3=load('3DOF3Iwan_1e2pt3_M2Fit.mat');
    Dp2=load('3DOF3Iwan_1e2pt2_M2Fit.mat');
else
% Mode 3 - Save data using IwanIntegrate_3DOF_Example.m and load it here
    error('No data saved for Mode 3');
end

figure(63); %clf(63);
hd=subplot(3,1,1);
loglog(DpM.VAmp_fit,abs(DpM.zt_est-zts0(mind)),...
    Dp3.VAmp_fit,abs(Dp3.zt_est-zts0(mind)),... %Dp3.zt_material
    Dp2.VAmp_fit,abs(Dp2.zt_est-zts0(mind))); grid on; %Dp2.zt_material
% loglog(Dp3.VAmp_fit,abs(Dp3.zt_est),... %Dp3.zt_material
%     Dp2.VAmp_fit,abs(Dp2.zt_est)); grid on; %Dp2.zt_material
set(get(gca,'Children'),'Linewidth',2);
ylabel('\bf(a) Damping Ratio');
% title('\bf(a) Damping vs. Velocity Amplitude')
	line(Vamp,zt,'Color','k','LineWidth',2,'LineStyle','-.','Marker','*'); % +zts0(1)
%     line(XAmp_fit.*wn_iwan,zt_iwan,'Color','k','LineWidth',2)
    legend('Modal Force','Impact Pt3','Impact Pt2','Quasi Static');
    
hf=subplot(3,1,2);
semilogx(DpM.VAmp_fit,DpM.wn_fit/2/pi,Dp3.VAmp_fit,Dp3.wn_fit/2/pi,Dp2.VAmp_fit,Dp2.wn_fit/2/pi,...
    Vamp,fnsec,'k*-'); grid on;%,VAmp_fit,Edis2,'-.',VAmp_fit,Edis3,'k--'); grid on;
set(get(gca,'Children'),'Linewidth',2);
ylabel('\bf(b) Nat. Freq. (Hz)');
% title('\bf(b) Natural Frequency vs. Velocity Amplitude')
% legend('Estimated','Modal Iwan');

subplot(3,1,3)
% loglog(Vamp,qAmp,'LineWidth',2,'LineStyle','-.','Marker','*'); grid on;
loglog(Vamp,qAmp*diag(qAmp(mind,:).^-1),'LineWidth',2,'LineStyle','-.','Marker','*'); grid on;
% loglog(Dp3.VAmp_fit,abs(Dp3.zt_est),... %Dp3.zt_material
%     Dp2.VAmp_fit,abs(Dp2.zt_est)); grid on; %Dp2.zt_material
set(get(gca,'Children'),'Linewidth',2);
xylabels('\bfModal Amplitude (kg^{1/2}m/s)','\bf(c) Modal Disp. Ratio (Q_j/Q_r)');
% title('\bf(c) Modal Disp. vs. Velocity Amplitude')
legend('Mode 1','Mode 2','Mode 3')

return


%% Alternative plot with modal displacement as the x-axis
figure(65); %clf(63);
hd=subplot(2,1,1);
loglog(Dp3.VAmp_fit./Dp3.wn_fit,abs(Dp3.zt_est-zts0(1)),... %Dp3.zt_material
    Dp2.VAmp_fit./Dp2.wn_fit,abs(Dp2.zt_est-zts0(1))); grid on; %Dp2.zt_material
% loglog(Dp3.VAmp_fit,abs(Dp3.zt_est),... %Dp3.zt_material
%     Dp2.VAmp_fit,abs(Dp2.zt_est)); grid on; %Dp2.zt_material
set(get(gca,'Children'),'Linewidth',2);
ylabel('\bfDamping Ratio');
% title('\bfDamping vs. Displacement Amplitude')
	line(Xamp,zt,'Color','r','LineWidth',2,'LineStyle','-.','Marker','*'); % +zts0(1)
%     line(XAmp_fit.*wn_iwan,zt_iwan,'Color','k','LineWidth',2)
%     line(Xamp,ztgk,'Color','k','LineWidth',2,'LineStyle','-.','Marker','o');
    legend('Impact Pt3','Impact Pt2','Quasi Static');
    
hf=subplot(2,1,2);
semilogx(Dp3.VAmp_fit./Dp3.wn_fit,Dp3.wn_fit/2/pi,Dp2.VAmp_fit./Dp2.wn_fit,Dp2.wn_fit/2/pi,...
    Xamp,fnsec,'*-'); grid on;%,VAmp_fit,Edis2,'-.',VAmp_fit,Edis3,'k--'); grid on;
%     line(Xamp,fnsecgk,'Color','k','LineWidth',2,'LineStyle','-.','Marker','o');
set(get(gca,'Children'),'Linewidth',2);
xylabels('\bfModal Amplitude (kg^{1/2}m)','\bfNatural Frequency (Hz)');
% title('\bfNatural Frequency vs. Velocity Amplitude')
% legend('Estimated','Modal Iwan');
    

