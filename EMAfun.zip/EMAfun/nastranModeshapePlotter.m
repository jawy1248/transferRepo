function [ verts,faces ] = nastran_derive_geometry(inputfile, varargin)

plotgeometry = true;
facecolor = 'g';
facealpha = 0.2;
edgealpha = .1;
edgecolor = 'k';
elementList = {'CTETRA','CTRIA','CHEXA','CPENTA','CQUAD4','CQUAD8','CQUADR'};
nfaces =      {    4   ,   1   ,   6   ,    5   ,    1   ,    1   ,    1   };
face_orders = {
    [1,2,4;2,3,4;3,1,4;1,3,2], % CTETRA
    [1,2,3], % CTRIA
    [

disp('Reading Model...');
ID = fopen(inputfile);
file = fread(ID,Inf,'uint8=>char');
fclose(ID);
disp('Done!');

% Preallocation variables
BLOCK_SIZE = 20000;

% Find Newlines in the file
newlines = [0,find(10 == double(file))];

% Set up flags and preallocate.
finding_elems = 0; faces = zeros(BLOCK_SIZE),3); face_ind = 1;
finding_nodes = 0; nodes = zeros(BLOCK_SIZE),4); node_ind = 1;

disp('Gathering Data');
% Set up monitors
perdone = 0; perinc = 1;
nlines = length(newlines)-1;
datagatherer = tic;

for i = 1:length(newlines)-1
    % Display Monitoring Text
    if i/nlines > perdone/100;
        disp([num2str(perdone),'% Done; ',num2str(toc(datagather)),'s elapsed; ',num2str((100/perdone-1)*toc(datagather)/60),' min remaining;']);
        perdone = perdone+perinc;
    end
    % Get the current line
    thisline = file(newlines(i)+1:newlines(i+1));
    
    % Check if the line has a complete tag.  If not, it is blank, so
    % skip it.
    if length(thisline) < 8
        continue;
    end
    
    
end

