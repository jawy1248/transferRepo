function [divavg]=llerosenstein(xvec,dim,lag,numpoints)
% Algorithm to compute the largest lyapunov exponent of a time series.
%
% [divavg]=llerosenstein(x,dim,lag,numpoints);
%
% x = Nt x N vector of time data where
%   Nt = number of time samples and
%   N = number of states.
% dim = embedding dimension
% lag = delay to use when constructing phase portrait from delayed copies
%   of x.
% numpoints = maximum number of points from nearest neighbors over which to
% compute the divergence.  Typically this encompasses about one period.
%
% From Richard Wiebe, Duke Univ. 2014.
%
% After computing the average divergence, use the following to find the
% largest Lyapunov exponent:
%
% plot(divavg)
% [xg,yg]=ginput(2)
% line(xg,yg,'Color','r')
% (diff(yg)/diff(xg))*fs % where fs = the sample rate

if size(xvec,1)==1; xvec=xvec.'; end
numtimes=length(xvec);

%generate reconstructed phase portrait up to dim. 
phasep=xvec(1:numtimes-dim*lag,:);
for j=1:dim-1
  phasep=[phasep xvec(1+j*lag:numtimes-dim*lag+j*lag,:)]; 
end
numdat=size(phasep,1);

%Find nearest neighbors.
neighborid=zeros(numdat,1);
for i=1:numdat
  %Find minimum distance and assign nearest neighbor to i.
  distmin=10^10;
  for k=1:numdat
    if(k~=i)
%         dist=sqrt(sum((phasep(i,:)-phasep(k,:)).^2));
        % Weird, that was way slower.  Usually it is faster to vectorize?
      distsq=0;
      for isum=1:dim
        distsq=distsq+(phasep(i,isum)-phasep(k,isum))^2;
      end
      dist=sqrt(distsq);  
      if(dist<distmin)
        nearneighborid=k; 
        distmin=dist;
      end    
    end
  end
  neighborid(i)=nearneighborid;
  waitbar(i/numdat)
end

%Obtain plot of average divergence rate of nearby neighbors. 
% numpoints=floor(tplot/dt);
divavg=zeros(numpoints,1);
numused=0;
for i=1:numdat
    
  pt1=i;
  pt2=neighborid(i);
  
  %need to make sure we don't go past end of data vector, this only
  %eliminates a small portion of the data.
  if(pt1<numdat-numpoints-1 && pt2<numdat-numpoints-1)
    numused=numused+1;
    
    distsq=0;
    for isum=1:dim
      distsq=distsq+(phasep(pt1,isum)-phasep(pt2,isum))^2;
    end
    dist0=sqrt(distsq);
  
    for j=1:numpoints  
      pt1=i+j;
      pt2=neighborid(i)+j; 
      distsq=0;
      for isum=1:dim
        distsq=distsq+(phasep(pt1,isum)-phasep(pt2,isum))^2;
      end
      dist=sqrt(distsq);
      divavg(j)=divavg(j)+log(dist);
    end
    
  end
end

divavg=divavg/numused;