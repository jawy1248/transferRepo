function [defshp]=PlotMode_AC(shp,Dofstr,GeomDofstr,Geom,fignum);
% Atlas Copco Mode shape Plotter
%
% Uses geometry and Stijn's DOF structure to create a 3D plot
% [defshp]=PlotMode_AC(shp,Dofstr,GeomDofstr,Geom,fignum);
%   shp - mode shape vector
%   Dofstr - DOF structure using Stijn's format corresponding to that shape
%   GeomDofstr - DOF structure corresponding to the geometry file
%   Geom - Geometry file containing coordinates of each node.
% 
% M.S. Allen, Sept. 2015


% load ..\AC_GA30andGA30VSD_Dense.mat C DOF_C
% % % These are for Y_SB1 and phi_SB1 
% % B1ind=find(DOF_C>=3e6); 
% % Sind=find(DOF_C<3e6);
% Dofstr=rows0875; % Info on the DOF of the measurements
% GeomDofstr=C.DoFstructMeas_GA30;
% Geom=C.geomMeas_GA30; % Nx3 array with coordinates.
% mnum=1
% shp=F1.res(mnum,:).';
% fn=F1.wn(mnum)/2/pi;

% Find those points that are in the NL measurement sets
    Npts=length(unique({Dofstr.pointID}));
    Nmeas=length(Dofstr);
    skippedpts=[]; pt_ind=zeros(Nmeas,1); pt_used=false(Nmeas,1);
    for k=1:Nmeas;
        temp=find(cellfun(@(x) strcmpi(x,Dofstr(k).pointID),{GeomDofstr.pointID}),1);
        if ~isempty(temp), pt_ind(k)=temp; pt_used(k)=true; end
    end
    disp('The following points were not found in the geometry and will be ignored.');
    Dofstr(~pt_used).label
        % Discard points that weren't found
        pt_ind=pt_ind(pt_used);
        [~,iG,iM]=unique({GeomDofstr(pt_ind).pointID}); % find unique points, filter
            pt_ind_unq=pt_ind(iG);
            % iM tells where in the unique (shorter) list each node lives.
            % iM;
            % Expand iM to the original, full list of measurement points.
            % Insert zeros for the points not found, they will be ignored.
            iMused=zeros(size(pt_used));
            iMused(pt_used)=iM;
            
        Cgeo=Geom(pt_ind_unq,1:3); % Filter geometry to only these points

shp=shp/max(abs(shp))*0.05;
defshp=[Cgeo]; % undeformed geometry
    % loop through and apply displacements for each node
    for k=1:Nmeas;
        if pt_used(k) % skip if this wasn't in the geometry
            % Is it x, y or z
            if strcmpi(Dofstr(k).absDir,'X');
                xyzind=1;
            elseif strcmpi(Dofstr(k).absDir,'Y')
                xyzind=2;
            else
                xyzind=3; % these should all be Z
            end
            defshp(iMused(k),xyzind)=defshp(iMused(k),xyzind)+...
                Dofstr(k).signDir*shp(k);
        end
    end
    shpmag=sqrt(sum((Cgeo-defshp).^2,2));

figure(fignum); clf(fignum);
plot3(Cgeo(:,1),Cgeo(:,2),Cgeo(:,3),'.k'); hold on;
% plot3(defshp(:,1),defshp(:,2),defshp(:,3),'or'); hold off;
scatter3(defshp(:,1),defshp(:,2),defshp(:,3),[],shpmag/max(shpmag),'filled'); hold off;
    for k=1:size(defshp,1); line([Cgeo(k,1),defshp(k,1)],[Cgeo(k,2),defshp(k,2)],...
            [Cgeo(k,3),defshp(k,3)],'Color','k','LineWidth',1,'LineStyle',':'); end
axis equal; xlabel('x'); ylabel('y'); zlabel('z')
% title(['\bfMode Shape of Mode # ',num2str(mnum),' at ',num2str(fn),' Hz']);

