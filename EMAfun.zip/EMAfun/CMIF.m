function [S,U,V] = CMIF(H,varargin)
% Function that finds the Complex Mode Indicator Function
% [S,U,V] = CMIF(H)
%
% Where S contains one singular value per column and U and V are the singular vectors
%   so that H(:,:,k) = U(:,:,k)*diag(S(k,:))*(V(:,:,k))'
%   i.e. the columns of U and V contain the singular vectors.
%
% If no output arguments are requested and a frequency vector is included,
%   i.e. [] = CMIF(H,ws)
%   then the CMIF is plotted in a new figure window.
%
% The function assumes that H is in the standard form, i.e.
%   size(H) = [No, Ni, Nf]
%   Use 'permute' to get H into this form if needed.
%
% see also SVD
% 
% This version by Matt Allen - 2005
% Caution - other versions with the same name in Diamond and SMAC directories

% Swap outputs and inputs if Ni > No
if size(H,2) > size(H,1);
    H = permute(H,[2,1,3]);
    perm_flag = 'y';
else
    perm_flag = 'n';
end

	[a,b,Nf] = size(H);
	
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	% CMIF Routine
        % Initialize Storage % b < a due to previous
		U = zeros(a,b,Nf);
		Sm = zeros(b,b,Nf);
		V = zeros(b,b,size(H,3));
        % Begin Routine
		for ii = 1:1:Nf
            [U(:,:,ii),Sm(:,:,ii),V(:,:,ii)] = svd(H(:,:,ii),0);
		end
        
        % Take only the diagonal of S
		for ii = 1:Nf
            S(ii,:) = diag(Sm(:,:,ii)).';
		end

% Swap U and V if more inputs than outputs, see previous
if strcmp(perm_flag,'y')
    Ut = U;
        Uout = zeros(b,b,Nf);
	    Vout = zeros(a,b,Nf);
    for ii = 1:Nf
        Uout(:,:,ii) = (V(:,:,ii)').';
        Vout(:,:,ii) = (Ut(:,:,ii).')';
	end
    U = Uout; V = Vout;
    clear Ut Uout Vout
    H = permute(H,[2,1,3]);
end

if nargin > 1 && nargout == 0
    ws = varargin{1};
    if nargin > 2
        fig_num = varargin{2};
        figure(fig_num);
    else
        figure
    end

    semilogy(ws,S); grid on;
    xlabel('Frequency'); ylabel('Magnitude of Singular Values');
    title('Complex Mode Indicator Function');

end



% Note that CMIF doesn't work well on the Frame Problem because of spatial aliasing.

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Alternate Form %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Load Data--Frequency Sweep Data
% load Frame_tfs_M1.mat
% x1 = tresp;
% load Frame_tfs_M2.mat
% x2 = tresp;
% Nt=2^15; T=14.2; delta=T/Nt;
% t=[0:delta:T-delta];
% 
% for ii = 1:1:15
%     [P1_temp, fs] = psd(x1(ii,:),2^15,1/delta);
%     [P2_temp, fs] = psd(x2(ii,:),2^15,1/delta);    
%         for k = 1:7007;%length(Pxy_temp);
%             Pxy(ii,1:2,k) = [P1_temp(k) P2_temp(k)];
%         end
% end
% 
% ws = fs(1:7007)*2*pi;
% figure(1);
% semilogy(ws,rs3d2col(Pxy(1,1,:)),ws,rs3d2col(Pxy(2,2,:)),ws,rs3d2col(Pxy(1,2,:))); grid on;
% % for ii = 1:1:length(Pxy) % Form composite PSD?
% %     Pcomp = trace(Pxy(:,:,ii));
% % end
% 
% save Frame_PSDdata.mat Pxy ws
% 
% %load Frame_PSDdata.mat
% 
% % CMIF Routine
% for ii = 1:1:length(Pxy)
%     psd_svd(:,ii) = svd(Pxy(:,:,ii));
% end
% 
% figure(2)
% semilogy(ws,rs3d2col(Pxy(1,1,:)),ws,psd_svd(1,:), ws,psd_svd(2,:)); grid on;
% xlabel('Frequency');
% legend('P1_temp', 'SV1', 'SV2');