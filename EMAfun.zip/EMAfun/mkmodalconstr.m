function [carray,varargout] = mkmodalconstr(subsys,varargin);
%
% Create constraint array for ritzscomb. Also see mkconstr.m for a
% definiton of 'nodes' (or, alternately, DOF)
%
% carray = mkconstr(subsys,s1,s2,nodes,num_modes,s1,s2,nodes,num_modes,...)
% 
% Creates the constraint arrays to join pairs of subsystems given the
% subsystem index and the names of the nodes to be joined.
%
% Let the nodes to be joined constitute a displacement vector {x}, with
% [phi] the accomanying modal matrix including the first 'num_modes' modes.
% Then {x}=[phi]{q} and {q} can be found using a pseudo-inverse if [phi] is
% full rank.  The following constraint is then applied:
%
%   pinv([phi_1])*{x}_s1 = pinv([phi_1])*{x}_s2
% 
% Note that phi_1 is used to create the modal filter, so the subsystem
% index s1 should correspond to the system whose modes are being used to
% create the filter.
% 
% To also return a structure containing the phi matrices, use the following
% syntax:
%
% [carray,data] = mkconstr(subsys,s1,s2,nodes,num_modes,s1,s2,nodes,num_modes,...)
% 
% where: data(m,n).phi = phi for subsys m, constraint n
%   (m = 1,2 and n = 1...n_constr)
%   data(m,n).snum = subsys_number;
%   data(m,n).nodes = nodes for phi
%
% Matt Allen, May 10, 2007
%   

if (nargin-1)/4 ~= round((nargin-1)/4);
    error('Subsequent input arguments must occur in sets of four');
end

Ncs = (nargin-1)/4;

constr_num = 1;
for cnum = 1:Ncs % loop over constraint sets
    s1 = varargin{4*(cnum-1)+1};
    s2 = varargin{4*(cnum-1)+2};
    nlist = varargin{4*(cnum-1)+3};
    n_modes = varargin{4*(cnum-1)+4};

    % Error Checking
    if ~isfloat(s1); error('s1 should be the integer index for the first subsystem'); end
    if ~isfloat(s2); error('s2 should be the integer index for the first subsystem'); end
    if any([s1, s2] > length(subsys));
        error('s1 or s2 is larger than the number of subsystems contained in subsys.');
    end
%     if ~iscell(nlist); error('nodes should be a cell array listing nodes to be joined'); end
    if n_modes > size(subsys(s1).phi,2);
        error(['Number of Modal Constraints is greater than the number of modes ',...
            'in constraint number ', num2str(cnum), '. N_MConstr = ',num2str(n_modes),...
            ' N_modes = ',num2str(size(subsys(s1).phi,2))]);
    end
    
    if iscell(nlist);

        % Find nodes that will be used in the modal filter to find {q}'s
        % This section simply builds the phi matrix for the nodes requested,
        % along with some error checking.
        nlist1 = zeros(length(nlist),1); nlist2 = zeros(length(nlist),1);
        phi1 = zeros(length(nlist),size(subsys(s1).phi,2)); phi2 = zeros(length(nlist),size(subsys(s2).phi,2));
        for nnum = 1:length(nlist);
            ns1 = find(strcmp(subsys(s1).names,nlist{nnum}));
                if isempty(ns1);
                    error(['Node ',nlist{nnum},' not found on subsys ',num2str(s1)]); end
                if length(ns1) > 1;
                    error(['Multiple matches for node ',nlist{nnum},' on subsys ',num2str(s1)]); end
            ns2 = find(strcmp(subsys(s2).names,nlist{nnum}));
                if isempty(ns2);
                    error(['Node ',nlist{nnum},' not found on subsys ',num2str(s2)]); end
                if length(ns2) > 1;
                    error(['Multiple matches for node ',nlist{nnum},' on subsys ',num2str(s2)]); end
            nlist1(nnum,1) = ns1;
            nlist2(nnum,1) = ns2;
            phi1(nnum,:) = subsys(s1).phi(ns1,:);
                % This includes all modes in modal filter - only 1:n_modes
                % constrained below. (MSA: 7/2016 Is this really true? Doesn't
                % appear to be.)
            phi2(nnum,:) = subsys(s2).phi(ns2,:); % include all modes here - for output only.
        end
    else % Here nlist is an Nconstr x 2 matrix telling which DOF to match
        if ~isnumeric(nlist) || size(nlist,2)~=2
            error('nodes is not a cell array or a numeric Nconstr x 2 matrix');
        end
        if ~isfield(subsys,'DOF');
            error('Subsystem must have a DOF vector to use DOF to locate nodes');
        end
        
        nlist1 = zeros(length(nlist),1); nlist2 = zeros(length(nlist),1);
        phi1 = zeros(length(nlist),size(subsys(s1).phi,2)); phi2 = zeros(length(nlist),size(subsys(s2).phi,2));
        for nnum = 1:size(nlist,1);
            ns1 = find(subsys(s1).DOF==nlist(nnum,1));
                if isempty(ns1);
                    error(['DOF ',num2str(nlist(nnum,1)),' not found on subsys ',num2str(s1)]); end
                if length(ns1) > 1;
                    error(['Multiple matches for DOF ',num2str(nlist(nnum,1)),' on subsys ',num2str(s1)]); end
            ns2 = find(subsys(s2).DOF==nlist(nnum,2));
                if isempty(ns2);
                    error(['Node ',num2str(nlist(nnum,2)),' not found on subsys ',num2str(s2)]); end
                if length(ns2) > 1;
                    error(['Multiple matches for node ',num2str(nlist(nnum,2)),' on subsys ',num2str(s2)]); end
            nlist1(nnum,1) = ns1;
            nlist2(nnum,1) = ns2;
            phi1(nnum,:) = subsys(s1).phi(ns1,:);
                % This includes all modes in modal filter - only 1:n_modes
                % constrained below. (MSA: 7/2016 Is this really true? Doesn't
                % appear to be.)
            phi2(nnum,:) = subsys(s2).phi(ns2,:); % include all modes here - for output only.
        end
    end

    disp('Condition number of mode shape matrix used for modal filter (phi_1)');
    cond(phi1)
    phi1pinv = pinv(phi1);
    for mnum = 1:n_modes
        carray(:,:,constr_num) = [phi1pinv(mnum,:).', nlist1, s1*ones(size(nlist1));
            -phi1pinv(mnum,:).', nlist2, s2*ones(size(nlist2))];
        constr_num = constr_num+1;
    end
    
    if nargout > 1
        data(1,cnum).phi = phi1;
        data(1,cnum).s = s1;
        data(1,cnum).nodes = nlist;
        data(2,cnum).phi = phi2;
        data(2,cnum).s = s2;
        data(2,cnum).nodes = nlist;
    end
    
end

if nargout > 1
    varargout{1} = data;
end