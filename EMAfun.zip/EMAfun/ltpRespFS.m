function [x] = ltpRespFS(lam,Bin,mBin,wA,Lr,x0,ts,varargin)
% Compute the response or the State Transition Matrix for a Linear
% Time-Periodic system defined by a Fourier Series model.
%
% [x] = ltpRespFS(lam,B,mB,wA,Lr,x0,ts);
%
% use Lr = x0 = [] if B is a residue matrix
% IMPORTANT!: The columns of LR are the rows of the inverse of the modal
% matrix:  Residue = Ur*Lr(:,r).';
%
% lam, B and mB do not contain complex conjugates, but are of half the
% length of the state space model order. - (MSA Note - could add an option
% to input state space modes, e.g. if they are overdamped.);
%
% [x] ([disp; vel]) = ltpRespFS(lam,B,mB,wA,Lr,x0,ts,'expand');
%   Expands the model to provide the state velocities also.  They are
%   computed by differentiating the Fourier Series model for x(t).
%
% B is size (No,Nfs,N)
%       No - number outputs
%       Nfs - number Fourier Series Coefficients
%       N - number of modes
%
% X(t) = sum_r sum_m [ B(:,r,m)*exp(i*wA*m*t)*exp(lam(r)*t) ]
%
% M.S. Allen, Feb. 2007
%

[No,Nfs,Nm] = size(Bin);
Nt = length(ts);
% ADD CHECKS!! on mB, lam, ts

if nargin > 7; % expand to state space
    Bdiff = ltpDiffFS(Bin,mBin,wA,lam);
    No = 2*No;
    B = zeros([No,Nfs,Nm]); mB = zeros([No,Nfs,Nm]);
    for m_num = 1:Nm
        B(:,:,m_num) = [Bin(:,:,m_num); Bdiff(:,:,m_num)];
        mB(:,:,m_num) = [mBin(:,:,m_num); mBin(:,:,m_num)];
    end
else
	B = Bin; mB = mBin;
end

% Expand Lambda to state space - could alternatively add a term in the
% summation below.
N = 2*Nm;
lam_ss = [lam(:); conj(lam(:))];
B_ss = zeros([size(B,1),size(B,2),N]); B_ss(:,:,1:Nm) = B;
mB_ss = zeros([size(B,1),size(B,2),N]); mB_ss(:,:,1:Nm) = mB;
for k = 1:Nm;
    B_ss(:,:,Nm+k) = conj(B(:,:,k));
    mB_ss(:,:,Nm+k) = -mB(:,:,k);
end

% Check whether an STM or a simple response was requested and prepare.
if isempty(Lr) && isempty(x0)
    type_flag = 'resp';
    x = zeros(No,Nt);
    x_ts = zeros(No,1);
    LrTx0 = ones(N,1);
else
    type_flag = 'stm';
    Nic = size(Lr,1);
    if length(x0) ~= Nic; error(['x0 is not compatible with Lr. ',...
            'length(x0) should equal size(Lr,1)']); end
    x = zeros(No,Nic,Nt);
    x_ts = zeros(No,Nic); % zero vector size of x at a time step.
    LrTx0 = [Lr.'*x0; conj(Lr.')*x0]; % Expand to state space
end

% Compute Time Response
for nt = 1:Nt;
    xtemp = x_ts;
    for m_num = 1:N; % sum over modes - assumes 2N complex conjugate modes
        xtemp = xtemp + sum(B_ss(:,:,m_num).*exp((lam_ss(m_num)+i*mB_ss(:,:,m_num)*wA)*ts(nt)),2)*...
            LrTx0(m_num,:);
            % Add over second dimension - that's where the coeff for each m
            % are stored.  This adds up all contributions for mode m_num.
    end
    if strcmp(type_flag,'resp');
        x(:,nt) = xtemp;
    else % stm
        x(:,:,nt) = xtemp;
    end
end

x = real(x); % Eliminate spurrious imaginary parts - add a check if user supplies CC modes.
