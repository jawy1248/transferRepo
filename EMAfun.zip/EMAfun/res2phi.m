function [phi] = res2phi(A,lam,P_ind,norm_type);
%
% Compute normalized mode vectors from residue vector and make complex
% modes real.
% [phi] = res2phi(A,lam,P_ind,norm_type);
%
% Matt Allen - June 2006
error('Program not yet finished');
% Real Modes Phi*Phi(P) = -2*real(conj(lam)*A)
    PhiPhiP = -2*(AMIMODES.A_store(:,:,1).')*diag(conj(AMIMODES.mode_store(:,3)));
    pdp = sqrt(Phi_fit(1,:));
        % Save Residues for Real Modes
        A_real = (Phi_fit*diag([2*i*imag(AMIMODES.mode_store(:,3))].^-1)).';
    Phi_fit = Phi_fit*diag(pdp.^-1);
    Hf_real = ss_model(AMIMODES.mode_store(:,3),A_real,ws(band_ind),'A','s');

    % NOTE!!! EWINS SUGGESTS THE SECOND APPROACH!!
        % Phi_fit = real(Phi_fitc);
        Phi_fit = abs(Phi_fitc).*( (abs(angle(Phi_fitc)) <= pi/2) + ...
            (abs(angle(Phi_fitc)) > pi/2)*-1);