function [varargout] = sdaxseta(varargin)
% X-axis Zoom for Stabilization Diagrams or other figures with multiple
% axes.  Bounds selected graphically or as input arguments are set for
% all axes (i.e. subplots or overlaid axes) simultaneously.
% 
% The first two left mouse clicks define a region to zoom into (based on the
% x-location only.)
%
% Subsequently:
%   - Double clik left button - zoom in again. Select the new
%   upper and lower limits.
%   - Middle Button Click - Return to original axis limits.
%   - Right Button Click - keep current X-axis zoom and quit
%
% Alternate Use:
%
% sdaxseta(xlims) - sets all axes to the upper and lower bound specified in
% xlims.
%
% [xlims] = sdaxseta - output current X-axis limit
%
% Shifei Yang, 2010.07.15, based on adaxset.m

% Define Current Axis Properties
fig_num = gcf;
axhs = findall(gcf,'type','axes');
    % Remove Legend Entries - these are also type 'axes'
    axhs = axhs(find(~strcmp(get(axhs,'Tag'),'legend')));
    % Store old limits
    X_LIM_old = get(axhs,'Xlim');
    y_lim_old = get(axhs,'Ylim');

if iscell(X_LIM_old)
    x_lim_old = X_LIM_old;
else
    x_lim_old{1} = X_LIM_old;
end; clear X_LIM_old

if nargin > 0;
    % Set to passed in value if there is one
    set(axhs,'Xlim',varargin{1});
    return
else
    disp('To Zoom in, click the right button twice');
end

% Set Limits once by default
[x_lims,y_lims] = ginput(2);
set(axhs,'Xlim',sort(x_lims));

disp('To Zoom in again, click the LEFT button twice');
disp('To zoom back out, click the MIDDLE mouse button.');
disp('To quit, click the RIGHT mouse button.');
loop_break = 0;
while loop_break == 0;
    [x_lims1,y_lims1,mbutton] = ginput(1);
    if mbutton == 1
        [x_lims2,y_lims2] = ginput(1);
        x_lims = [x_lims1;x_lims2];
        set(axhs,'Xlim',sort(x_lims));
    elseif mbutton == 2;
        % Reset to old limits
        for k = 1:length(axhs);
            set(axhs(k),'Xlim',x_lim_old{k});
        end
    else
        % quit
        loop_break = 1;
    end
end

varargout(1) = {x_lims};




    