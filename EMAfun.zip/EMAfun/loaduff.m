function [data,dinfo,varargout] = loaduff(varargin)
% Load FRF data from Universal Files
% 
% [data,dinfo] = loaduff;
%
% data - structure with information from the UFF file
% dinfo - information about the file read
%
%   User is prompted to select a set of UFF or UNV files.  The program then
% loads each file and stores all of the measurements in the structure
% "data".  For example, data{1} is the first set and to plot the FRF:
% semilogy(data{1}.x,abs(data{1}.measData)); gives a magnitude plot
%
%  To load a complete set of FRFs and form the FRF matrix, use the following syntax:
%
% [data,dinfo,H,ws,rsps,refs] = loaduff;
% 
%   This gives an FRF matrix, H, that is No x Ni x Nf, or number of outputs
% (responses) by the number of inputs (references) by the number of
% frequency lines.
%   ws - frequency vector corresponding to H in rad/s
%
%   Note that this assumes that the node numbers in the data files are
% correct and uses them to create a list of inputs and outputs.  The data
% files may be listed in any order.  rsps(i) and refs(j) gives the directions and
% node numbers for H(i,j).
%
% [~,~,H,ws,rsps,refs] = loaduff(data,dinfo); % Create FRF matrix only
%
% M.S. Allen, 2009
% Updated 2014 to allow to pass in data and dinfo so H can be created after
% filtering out unwanted parts of data and dinfo.  For example:
%   kp_ind=[7,9]
%   data2={data{kp_ind}}
%   dinfo2=dinfo; dinfo2.dsTypes=dinfo2.dsTypes(kp_ind);
% 
if nargin>1
    % This signifies that data and dinfo have been passed in
    data=varargin{1};
    dinfo=varargin{2};
else % Otherwise, open a UFF file and read it.
    if nargin ==0
        [ld_fn,ld_pthn] = uigetfile('*.uff;*.unv', 'Select the Files to Import','MultiSelect','on');
    else
        ld_fn=varargin{1}; 
            % If it contains a path:
            ind=strfind(ld_fn,'\');
            if ~isempty(ind)
                ld_pthn=ld_fn(1:ind(end));
                ld_fn=ld_fn(ind(end)+1:end);
            else
                ld_pthn=[cd,'\'];
            end
    end

    if iscell(ld_fn); % more than one file selected
        for k = 1:length(ld_fn);
            fprintf(['Reading File: ',ld_fn{k},'...']);
                [D,ifo] = readuff([ld_pthn,ld_fn{k}]);
            fprintf(['.done\n']);
            if length(D) > 1;
                data{k} = D; % if the uff contains more than one point, then
                % preserve the size of D.  If D is one by one, put each into
                % the data structure.
                data{k}.fname = ld_fn{k};
            else
                data{k} = D{1};
                data{k}.fname = ld_fn{k};
            end
            dinfo{k} = ifo;
        end
    else
        fprintf(['Reading File: ',ld_fn,'...']);
            [data,ifo] = readuff([ld_pthn,ld_fn]);
            data{1}.fname = ld_fn;
            dinfo = ifo;
        fprintf(['.done\n']);
    end
end
% This next part only applies of the user asks for H, ws, etc...
if nargout > 2;
    try
    if iscell(data{1});
        error('This file does not create FRFs from multidimensional UNV files');
        % Haven't written this to create H matrix if the uff contains more than one point.
    end
    % Check that the data contains only FRFs, or only operate on the FRFs.
    if iscell(dinfo)
        % This part needs to be more robust, but we rarely use it
        % anymore so I won't fix it now.
        if  dinfo{1}.dsTypes~=58
            error('UNV Files do not contain FRFs');
        end
    else
        if any(dinfo.dsTypes~=58)
            is58=dinfo.dsTypes==58;
            data={data{is58}};
            dinfo.kept_indices=find(is58);
        end
    end

    directions = 'xyz'; % rtp
    refNodeDirList = zeros(length(data),2); rspNodeDirList = zeros(length(data),2);
    for k = 1:length(data);
        refNodeDirList(k,:) = [data{k}.refNode,data{k}.refDir];
        if sign(refNodeDirList(k,2)) == 1;
            refNames{k} = ['+',num2str(refNodeDirList(k,1)),directions(abs(refNodeDirList(k,2)))];
        else
            refNames{k} = ['-',num2str(refNodeDirList(k,1)),directions(abs(refNodeDirList(k,2)))];
        end
        rspNodeDirList(k,:) = [data{k}.rspNode,data{k}.rspDir];
        if sign(rspNodeDirList(k,2)) == 1;
            rspNames{k} = ['+',num2str(rspNodeDirList(k,1)),directions(abs(rspNodeDirList(k,2)))];
        else
            rspNames{k} = ['-',num2str(rspNodeDirList(k,1)),directions(abs(rspNodeDirList(k,2)))];
        end
    end; clear k;
    refs.NodeDirMat = unique(refNodeDirList,'rows'); % Nx2 matrix of node #'s and directions
    Ni = size(refs.NodeDirMat,1);
%     UniqueRefNames = unique(refNames);
    rsps.NodeDirMat = unique(rspNodeDirList,'rows'); % Nx2 matrix of node #'s and directions
    No = size(rsps.NodeDirMat,1);
%     UniqueRspNames = unique(rspNames);
    % Create arrays of names of unique references - do this using Unique
    % node dirs so the sorting works
    for k = 1:Ni;
        if sign(refs.NodeDirMat(k,2)) == 1;
            refs.name{k} = ['+',num2str(refs.NodeDirMat(k,1)),directions(abs(refs.NodeDirMat(k,2)))];
        else
            refs.name{k} = ['-',num2str(refs.NodeDirMat(k,1)),directions(abs(refs.NodeDirMat(k,2)))];
        end
    end
    for k = 1:No
        if sign(rsps.NodeDirMat(k,2)) == 1;
            rsps.name{k} = ['+',num2str(rsps.NodeDirMat(k,1)),directions(abs(rsps.NodeDirMat(k,2)))];
        else
            rsps.name{k} = ['-',num2str(rsps.NodeDirMat(k,1)),directions(abs(rsps.NodeDirMat(k,2)))];
        end
    end
    
%     if NrefPts == length(data)
%         display('Data acquired with 1 accelerometer.');
%         [refNodeList(1:NrefPts), indsRefNodes] = sort(refNodeList(1:NrefPts));
%     else
%         Naccels = length(data)/NrefPts;
%         display(['Data acquired with ',num2str(Naccels), ' accelerometers.']);
%         [refNodeList(1:NrefPts), indsRefNodes] = sort(refNodeList(1:NrefPts));
%         for i = 2:Naccels
%             indsRefNodes = [indsRefNodes, indsRefNodes +(i-1)*NrefPts];
%         end
%     end        
%     [rspNodeList, indsRspNodes] = sort(rspNodeList);
%     for k = 1:length(data);
%         pts.rspNode(k) = data{indsRefNodes(k)}.rspNode;
%         pts.rspDir(k) = data{indsRefNodes(k)}.rspDir;
%         pts.refNode(k) = data{indsRefNodes(k)}.refNode;
%         pts.refDir(k) = data{indsRefNodes(k)}.refDir;
%         pts.refName{k} = [num2str(pts.refNode(k)),directions(pts.refDir(k))];
%         pts.rspName{k} = [num2str(pts.rspNode(k)),directions(pts.rspDir(k))];
%     end
%     refs.NodeDirMat = unique([pts.refNode(:),pts.refDir(:)],'rows');  % This is wrong sort
%     rsps.NodeDirMat = unique([pts.rspNode(:),pts.rspDir(:)],'rows');   % This is also wrong

    Nf = length(data{1}.x);
    Nfs = zeros(length(data),1);
    for k = 1:length(data);
        Nfs(k) = length(data{k}.x);
    end
        if any(Nfs ~= Nf);
            disp('Sizes of Frequency Vectors'); Nfs.'
            error('Frequency vectors are not all equal, H will not be returned');
        end
    % Create H Matrix - Ni by No by Nf
    H_fill_ind = zeros(No,Ni);
    H = zeros(No,Ni,Nf);
    ws = data{1}.x*2*pi;
    for k = 1:length(data)
        ki = find(strcmpi(refs.name,refNames{k}));
        ko = find(strcmpi(rsps.name,rspNames{k}));
        H(ko,ki,:) = data{k}.measData;
        H_fill_ind(ko,ki) = 1;
    end
    if any(H_fill_ind ~= 1); % check for missing measurements
        warning('##########################################');
        warning('## FRF Matrix is Missing Some Elements ###');
        warning('##########################################');
    end
    if Ni == 1;
        H = permute(H,[3,1,2]); % SIMO FRF
    end
    if No < Ni;
        H = permute(H,[3,2,1]); % MISO FRF - represent as a SIMO FRF
    else
        H = permute(H,[3,1,2]); % MIMO FRF - leave as given
    end
    varargout{1} = H; varargout{2} = ws(:); varargout{3} = rsps; varargout{4} = refs;
    catch err
%         keyboard
        varargout{1} = []; varargout{2} = []; varargout{3} = []; varargout{4} = [];
        warning('FAILED TO CREATE FRF MATRIX - Check data and dinfo for anomalies');
        % Place the workspace in H so the user can see it
            all_data = [];
            S = whos;
            for k = 1:length(S)
                if ~strcmpi(S(k).name,'all_data')
                    eval(['all_data.',S(k).name,' = ',S(k).name,';']);
                end
            end
            
            try
            S=rmfield(rmfield(S,'data'),'dinfo');
            catch
                % do nothing
            end
            varargout{1}=all_data;
    end
end
