% m-file which generates data from a single degree-of-freedom system with 
% an iwan joint in parallel with a spring and dashpot.  This could be used
% describe a modal iwan model (for one mode) if the parameters are set
% appropriately.  The script also shows how to use time-frequency analysis
% to assess the neonlinearity and how to extract the instantaneous
% frequency and damping to fully characterize the Iwan joint.
%
% Matt Allen, June 2005, Updated July 2014
%
clear all; % close all;

% Set up system parameters
    m = 12; % kg

    % Iwan Element
    % Joint parameters
    F_S   = 30000;
    K_T  = (1000*2*pi)^2*m;  % stiffness of the joint
    beta  = 1;
    chi = -0.3;

    % convert from preferred parameter set to the old parameter set
    [chi, phi_max,R, S]=iwanconvert(F_S,K_T,chi,beta);

    params = [chi, phi_max, R, S];
    
    % Linear Spring
    K_lin = (1000*2*pi)^2*m; % stiffness of linear spring in parallel
    % Linear Viscous Damping:
    zt=0; Ceq=m*2*zt*sqrt((K_T+K_lin)/m); %zt=0.002;
    
    % Force paramters
        % length of half-sine force pulse
        % This is normalized in the EOM to unit area and multiplied by Afnl
        tfp = 1e-4;
        Afnl = 10e7; % Use 10e6 to see micro-slip, 1e10 to see macro-slip
    
wn_lin = sqrt(2*K_T/m);
zt_lin = 0.01; %  estimate of total damping, used to determine time window over which to generate response
fns = wn_lin/2/pi;
lamlin = -zt_lin*wn_lin+1i*wn_lin*sqrt(1-zt_lin.^2);

% Compute appropriate sample rate and time
    dt = (50*max(fns))^-1;
    Tmin = ln(0.001)/(-min(abs(real(lamlin)))); % time over which to sample
    Nt_nl = 2^ceil(log2(Tmin/dt)); % number of time steps to find
    
    tsnl = [0:dt:(Nt_nl-1)*dt].';
    
    % External Force
    fext = zeros(size(tsnl));
    for k = 1:length(tsnl)
        if tsnl(k) <= tfp
            fext(k) = Afnl*(2*tfp/pi)*sin((pi/tfp)*tsnl(k));
        else
            fext(k) = 0;
        end
    end
    figure(41);
    [Fext,ws] = fft_easy(fext,tsnl);
    line(ws/2/pi,abs(Fext));
    legend('F(\omega)');
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Nonlinear Simulation using Newmark Integration
% From Todd Simmermacher's script: 'r3mass1h.m'

    % integration parameters
    beta_N = 1/4;
    gamma_N = 1/2;

    %Initialize Variables - this was initially set for an MDOF simulation...
    Masses = 1;
    u  = zeros(Masses, Nt_nl);
    v = zeros(Masses, Nt_nl);
    a = zeros(Masses, Nt_nl);
%     a_last = zeros(1, Nt_nl);
    KE = zeros(1, Nt_nl);
    f_joint = zeros(1, Nt_nl);
%     diss      = zeros(1, Nt_nl);
    newton_iter=zeros(1,Nt_nl);
    
    u_prev =zeros(Masses,1); v_prev = zeros(Masses,1); a_prev = zeros(Masses,1);

    % lets use NJ Jenkins elements to represent the Iwan joint.
    NJ = 100;
    jy_prev  = zeros(NJ,1);
    jy_temp = zeros(NJ,1);
    jys = zeros(NJ,Nt_nl); % Could remove this to save storage space...

    %integrate through every timestep
    for it = 2:length(tsnl)
        % first guess for acceleration is the previous accleration
        a_est = a_prev;
        v_est = v_prev + dt*( (1-gamma_N)*a_prev + gamma_N*a_est);
        u_est = u_prev + dt*v_prev ...
          + (dt^2/2)*( (1-2*beta_N)*a_prev +2*beta_N*a_est);

        [ftemp, jy_temp, stiff_temp] = iwan(u_est, jy_prev, params);
        resid = m*a_est + Ceq*v_est + K_lin*u_est + ftemp - fext(it);
        grad = m + gamma_N*Ceq*dt + (K_lin+stiff_temp)*(dt^2)*beta_N;
        
        % newton itteration loop
        iter = 0;
        while resid'*resid > 1e-10 % perhaps this should be relative to the norm of the acceleration...
            a_est = a_est - grad\resid;
            v_est = v_prev + dt*( (1-gamma_N)*a_prev + gamma_N*a_est);
            u_est = u_prev + dt*v_prev ...
                + (dt^2/2)*( (1-2*beta_N)*a_prev   +2*beta_N*a_est);

            [ftemp, jy_temp, stiff_temp] = iwan(u_est, jy_prev, params);

            resid = m*a_est + Ceq*v_est + K_lin*u_est +ftemp - fext(it);

            grad = m + gamma_N*Ceq*dt +(K_lin+stiff_temp)*(dt^2)*beta_N;
            iter = iter + 1;
        end
        
        newton_iter(it) = iter;
        u_prev = u_est;
        v_prev = v_est;
        a_prev = a_est;

        f_joint(it) = ftemp;
        
        u(:,it) = u_est;
        v(:,it) = v_est;
        a(:,it) = a_est;

        jy_prev = jy_temp;
        jys(:,it) = jy_temp;
        
        KE(it) = (1/2)*m*v_est.^2;
        if round(it/1000) == (it/1000); fprintf('.'); end
    end
    fprintf('\n');
    u = u.'; v = v.'; a = a.';

% Track the magnitude of the displacement of spring for NL
figure(11);
    set(gcf,'Name','Force vs. Delta Curve','Toolbar','figure');
subplot(1,3,1)
plot(f_joint,u,'.'); grid on;
ax1h = gca;
ylabel('\Delta - Spring 4'); xlabel('Spring Force')
title('Spring Curve');
hx = subplot(1,3,2:3)
plot(tsnl, u); grid on;
% Set Axes to Equal
    ylim2 = get(gca,'Ylim');
    set(ax1h,'Ylim',ylim2);
xlabel('time (s)'); ylabel('\Delta - Spring 4');
title('Displacement of Iwan Joint');

%% Analyze with Hilbert Transform to extract damping and frequency vs amplitude
% Contaminate with noise
ep_noise=0.001;
vnoise=randn(size(v))*ep_noise*max(abs((v)));
[wn_fit,zt_fit,indfit,yfit,ad]=hilbpsm(v+vnoise,tsnl,7,5,'verbose');
    VAmp_fit=exp(ad.psirt_fit);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Alternative: Feldman's FREEVIB program: (must be in the directory 
% containing "HT_identification" from Feldman...
%
% hdec=decimate(v+vnoise,10);
% tdec=tsnl(1:10:end); dtdec=dt*10;
% [y,A,f,f0,h]=freevib(hdec,1/dtdec,220,'v');
% figure(1); lhs=get(gca,'Children'); t=get(lhs(1),'XData');
% ind_fv=find(tdec>=t(1) & tdec<=t(end));
%      ind_fv=[ind_fv; ind_fv(end)+1]; % add this when the above fails.
% figure(52);
% subplot(1,2,1); line(tdec(ind_fv),f0,'Color','m');
% subplot(1,2,2); line(tdec(ind_fv),h./f0/2/pi,'Color','m')
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure(41)
plot(tsnl,v+vnoise,tsnl(indfit),real(yfit),'.--'); grid on;
xylabels('\bfTime (s)','\bfVelocity (m/s)');

figure(53)
loglog(VAmp_fit,zt_fit,VAmp_fit(1),zt_fit(1),'r.',VAmp_fit(1,end),zt_fit(1,end),'b:'); grid on;
set(get(gca,'Children'),'Linewidth',2);
xylabels('\bfAmplitude (m/s)','\bfDamping \zeta'); title('\bfDamping vs. Velocity Amplitude')
PAvsZt=polyfit(log10(VAmp_fit),log10(zt_fit),1);
logzt_Pfit=polyval(PAvsZt,log10(VAmp_fit));
    chi_est=PAvsZt(1)-1
line(VAmp_fit,10.^logzt_Pfit,'Color','r','LineWidth',2,'LineStyle','-.');

% Compute dissipation: Vel. Amp before and after one cycle gives 
% difference of energy before/after.
tsnl_jp1=tsnl(indfit)+2*pi./(ad.wd_fit);
vj=VAmp_fit; vjp1=interp1(tsnl(indfit),VAmp_fit,tsnl_jp1,'linear','extrap');
Edis1=(1/2)*(vj.^2-vjp1.^2); % left out (m) mass factor, divides out later

% Plot Energy Dissipated versus Amplitude as Segalman typically does in his
% papers.  This will be linear (log scale) in micro-slip and has a slope 
% of 3+\chi.
figure(55); clf(55);
loglog(VAmp_fit,Edis1); grid on;%,Amp_fit,Edis2,'-.',Amp_fit,Edis3,'k--'); grid on;
set(get(gca,'Children'),'Linewidth',2);
xylabels('\bfAmplitude (m/s)','\bfDissipation D/m'); title('\bfDissipation per Cycle vs. Velocity Amplitude')
DvsAsq=polyfit(log10(VAmp_fit),log10(Edis1),1); % Use finite difference formula - most rigorous.
D_Pfit=polyval(DvsAsq,log10(VAmp_fit));
line(VAmp_fit,10.^D_Pfit,'Color','r','LineWidth',2,'LineStyle','-.');
    chi_est_D=DvsAsq(1)-3
legend('(1a)','Linear Fit');

% The Damping can also be computed from the energy dissipated per cycle, as
% shown below:
% % Damping vs Log Amplitude - This is a horizontal line for a linear system.
% figure(56); clf(56);
% loglog(VAmp_fit,Edis1./(VAmp_fit.^2*2*pi)); grid on;%,VAmp_fit,Edis2,'-.',VAmp_fit,Edis3,'k--'); grid on;
% set(get(gca,'Children'),'Linewidth',2);
% xylabels('\bfAmplitude (m/s)','\bfDamping Ratio');
% title('\bfDissipation per Cycle vs. Velocity Amplitude')
% line(VAmp_fit,(10.^D_Pfit)./(VAmp_fit.^2*2*pi),'Color','r','LineWidth',2,'LineStyle','-.');
%     % Add Lines for linear damping ratios, min and max.
%     zt_high=Edis1(1)/(VAmp_fit(1).^2*2*pi) % Note, should be the same as zt_fit(1)...
%     zt_low=Edis1(end)/(VAmp_fit(end).^2*2*pi) % 
%     minmax(zt_fit)
%     line(VAmp_fit,zt_high*ones(size(VAmp_fit)),'Color',[0,0.5,0],'LineWidth',2,'LineStyle','--');
%     line(VAmp_fit,zt_low*ones(size(VAmp_fit)),'Color','k','LineWidth',2,'LineStyle','--');
%     legend('Estimated','Iwan Fit',...
%         ['Linear \zeta = ',num2str(zt_high)],['Linear \zeta = ',num2str(zt_low)]);

% Now that Chi has been estimated, one can proceed to estimate the other
% Iwan parameters: F_S, K_T and \beta.  Typically several different time
% histories will need to be combined to obtain a large enough range of
% force to estimate K_T and F_S.

%% Analyze with ZNLDetect - time-frequency analysis

[Fmat, f, ts_zc] = ZNLDetect(v, tsnl, [0,max(tsnl)], 2000, 20);
    close(103);
    
% Note, the analysis with ZNLDetect will not work so well if you do not
% have a long sample time, so the response goes to zero at the end of the
% time record.

