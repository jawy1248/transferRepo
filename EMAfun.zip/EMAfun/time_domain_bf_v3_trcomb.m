% function [bf_data] = time_domain_bf(N);  % Uncomment these lines to run
%                                          % convergence studies.
% % Also need to comment 'clear all;' , 'N = x;' lines and uncomment 'break' line

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Frame problem 9.20 from Dr. Ginsberg's vibration book
% This file creates the time-domain response to simulate the experiment
% The analytical data is then corrupted by noise in the time domain, then
% FFT processed to find the corresponding FRF
% The data will be later used to test AMI through the file frame_ext_sim
% Ritz Analysis by Ginsberg 2002
% Conversion to time domain and full documentation by Bassem Zaki '01-'02
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Note: All numbered equations are in reference to Ginsberg, "Mechanical
% and Structural Vibrations: Theory and Applications", Wiley, 2001
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Define values for material properties and system geometry
% E:	Young's modulus (Pa)
% rho: Density (kg/m3)
% nu:	Poisson's ratio
% G:	Shear modulus (Pa)
% A:	Cross sectional area (m2)
% I:	Moment of Inertia (m4)
% J:	Polar moment of inertia (m4)
% L1:	Length of beam 1 (m)
% L2:	Length of beam 2 (m)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

E=70e9;
rho=2700;
nu=0.33;
G=E/(2*(1+nu));
d = 0.20;
A=pi*(d/2)^2;
I=(pi/4)*(d/2)^4;
J=2*I;
L1=4;
L2=3.85;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Damping constants in the problem description (where c1, c2 are linear
% dampers while c3, c4 are torsional dampers) are given values as follows:
% c1=c_1     (N-s/m)        909.327 Bassem's Thesis
% c2=c_1	 (N-s/m)        181.865
% c3=c_2	 (N-s-m/rad)    0.2598
% c4=c_2	 (N-s-m/rad)    0.2598
% 4-02-2003  Modified to match placement in Thesis.
% Thus both linear dampers have the value c_1, both torsional have c_2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

c_1 = 3000*sqrt(2700/1e6); %10*3000...
c_2 = c_1;
c_3 = 1500*sqrt(2700/1e6); %10*1500
c_4 = c_3;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Define input impulse
% F is a force; FF is a torque
% For generality, both are defined here
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
F=1;
FF=1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ######################################################################
% Ritz Analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Define Psi vectors using Matlab's Symbolic Toolbox
% N:	Series length
% Psi_w:	Basis function vector for displacement
% Psi_o:	Basis function vector for rotation
% For all Psi vectors, index = basis function number
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic
N=11;
Ndof = 4*N-3;

syms x real

for jj = 1:1:N;
    r = (2*jj-1)*pi/2;
    al_v(jj) = fzero('cos(x)+1/cosh(x)',r);
end

for jj=1:N
    R = (sinh(al_v(jj))+sin(al_v(jj)))/(cosh(al_v(jj))+cos(al_v(jj)));
    Psi_w(jj)=sin(al_v(jj)*x)-sinh(al_v(jj)*x)-R*(cos(al_v(jj)*x)-cosh(al_v(jj)*x));
    Psi_o(jj)=sin((2*jj-1)*pi*x/2);
    Psi_pw(jj)=al_v(jj)*(cos(al_v(jj)*x)-cosh(al_v(jj)*x)+R*(sin(al_v(jj)*x)+sinh(al_v(jj)*x)));
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Define the constraint equations for the 3 continuity constraints at the 
% common point of the beams, i.e. form the "a" matrix. Chapter 9 textbook
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for jj=1:N
    x = 1;
  a(1,jj)=double(eval(Psi_w(jj)));
  a(1,jj+2*N)=-double(eval(Psi_w(jj)));
  a(2,jj)=(1/L1)*double(eval(Psi_pw(jj)));
  a(2,jj+3*N)=double(eval(Psi_o(jj)));
  a(3,jj+N)=double(eval(Psi_o(jj)));
  a(3,jj+2*N)=-(1/L2)*double(eval(Psi_pw(jj)));
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Define sorting matrix "P". Chapter 9 textbook, Eq.(9.1.23)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

P(2*N,1)=1;
P(3*N,2)=1;
P(4*N,3)=1;

for j=1:2*N-1
  P(j,j+3)=1;
end

for j=1:N-1
  P(2*N+j,2*N+j+2)=1;
end

for j=1:N-1
  P(3*N+j,3*N+j+1)=1;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Find the sorted constraint matrix "a_hat" and the matrix "B", Eq.(9.1.25)
% Eq.(9.1.26) and Eq.(9.1.28)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

a_hat=a*P;
a_c=a_hat(1:3,1:3);
a_u=a_hat(1:3,4:4*N);

B=P*[-inv(a_c)*a_u; eye(4*N-3)];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Form the "small" partitions of the M,K,C matrices for system components
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
syms x real
for j=1:N       % The component Matrices are diagonal because the basis
                % functions are the modes.
    if j < 9;
        M_w(j,j)=double(eval(int(Psi_w(j)^2,x,0,1)));
    else
        M_w(j,j) = 1;
    end
   M_o(j,j)=0.5;

   K_w(j,j)=al_v(j)^4*M_w(j,j);
   K_o(j,j)=((2*j-1)*pi/2)^2*M_o(j,j);
   
end

% Assemble Mass and Stiffness Matrices
% Change to dimensional values
for j = 1:N
    for n = 1:N
    M(j,n) = rho*A*L1*M_w(j,n);
    M(j+N,n+N) = rho*J*L1*M_o(j,n);
    M(j+2*N,n+2*N) = rho*A*L2*M_w(j,n);
    M(j+3*N,n+3*N) = rho*J*L2*M_o(j,n);
    
    K(j,n) = (E*I/L1^3)*K_w(j,n);
    K(j+N,n+N) = (G*J/L1)*K_o(j,n);
    K(j+2*N,n+2*N) = (E*I/L2^3)*K_w(j,n);
    K(j+3*N,n+3*N) = (G*J/L2)*K_o(j,n);
    end
end

% Form the Damping Matrix
for j = 1:N
    for n = 1:N
    x = L1/L1; % Translational Damper, First Beam
    C(j,n)=double(eval(Psi_w(j)*Psi_w(n)*c_1));
    x = 1/L1; % Rotational Damper, First Beam
    C(j+N,n+N)=double(eval(Psi_o(j)*Psi_o(n)*c_3));
    x = 3/L2; % Translational Damper, Second Beam
    C(j+2*N,n+2*N)=double(eval(Psi_w(j)*Psi_w(n)*c_2));
    x = 1/L2; % Rotational Damper, Second Beam
    C(j+3*N,n+3*N)=double(eval(Psi_o(j)*Psi_o(n)*c_4));
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Form the "hat" matrices according to Eq.(9.1.32) & (9.1.33)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

M_hat=B.'*M*B;
C_hat=B.'*C*B;
K_hat=B.'*K*B;

disp('Condition numbers of M, K');
[cond(M_hat), cond(K_hat)]

% Undamped Modal Solution:
[Phi_und, lam_und] = eig(K_hat,M_hat);
wn_und = sort(sqrt(diag(lam_und)));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Form the small generalized force vector corresponding to the impulse excitation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The following sets the force
for j=1:N
    x = 1/L1; % x = 4/L1 gives 8th DOF excitation, x = 2/L1 gives 6th DOF exc.
    % Q_o1(j,1)=double(eval(Psi_o(j)*F));
    Q_w1(j,1)=double(eval(Psi_w(j)*F)); % for force excitation
    % Second Drive point
    x = 1/L2; % x = 1/L2 gives 9th DOF excitaion
    % Q_o1(j,1)=double(eval(Psi_o(j)*F));
    Q_w2(j,1)=double(eval(Psi_w(j)*F)); % for force excitation
end

Ps = [1,9];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Stack the generalized force vector as [Q_w1;Q_o1;Q_w2;Q_o2]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Q(:,1) = [Q_w1; zeros(N,1); zeros(2*N,1)]; % for force excitation
Q(:,2) = [zeros(2*N,1); Q_w2; zeros(N,1)]; % for force excitation

% Q=[zeros(N,1);Q_o1;zeros(2*N,1)]; % moment excitation on beam #1
% Q=[zeros(3*N,1); Q_o2]; % moment excitation on beam #2
Q_hat=B.'*Q;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Form the damped modes, statespace eigenproblem by assembling the R,S matrices
% and the corresponding force vector Q_bar, Eq.(10.1.6), (10.1.7), (10.2.2)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

S=[-K_hat, zeros(4*N-3, 4*N-3);
   zeros(4*N-3, 4*N-3), M_hat];

R=[zeros(4*N-3, 4*N-3), -K_hat;
   -K_hat, -C_hat];

Q_bar=[zeros(4*N-3,size(Q_hat,2)); Q_hat];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Solve eigenvalue problem
% phi:	matrix of eigenvectors
% lambda:	eigenvalues
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[phi,lambda]=eig(R,S);
lambda=diag(lambda);
% display eigenvalues
disp('wn , zeta , and Eigenvalues');
[l_sort, l_sort_ind] = sort(abs(lambda));
bf_data = [l_sort, -real(lambda(l_sort_ind))./l_sort, lambda(l_sort_ind)];

% break   % When called as a function, break here, subsequent steps are not needed

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% normalize the eigenvectors
% Phi:	Matrix of normal eigenvectors
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sigma=diag(conj(phi')*S*phi);
for n=1:2*(4*N-3)
  Phi(:,n)=(1/sqrt(phi(:,n).'*S*phi(:,n)))*phi(:,n);
end

% Sort lambda and Phi
[lam_imag_sort lam_ims_ind]= sort(abs(imag(lambda)));
lambda = lambda(lam_ims_ind);
Phi = Phi(:,lam_ims_ind);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% check orthogonality of Phi w.r.t S and R
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('First orthogonality check:')
norm(Phi.'*S*Phi-eye(2*(4*N-3)))
disp('Second orthogonality check:')
norm(Phi.'*R*Phi-diag(lambda)) 
t_sys_sol = toc

% Look for Close Modes, Calculate fraction of bandwidth of separation = 2*zeta*wn

del_omega = (bf_data(3:2:end,1) - bf_data(1:2:(end-2),1));
del_bw1 = del_omega./(2*bf_data(1:2:(end-2),2).*bf_data(1:2:(end-2),1));
del_bw2 = del_omega./(2*bf_data(3:2:end,2).*bf_data(3:2:end,1));

figure(1)
semilogy([1:Ndof-1],del_bw1,'.-',[1:Ndof-1],del_bw2); grid on;
title('Modal separation (% of 1/2 Power Bandwidth');
ylabel('% of BW d\omega/(2*\zeta*\omega_n)');
xlabel('Mode #');
close_modes = find([del_bw1 del_bw2] < 2);
QQ=(conj(Phi)')*Q_bar;
disp('Mode No., Phi''*Q, Wn, zeta');
mode_data2 = [[1:Ndof]'  abs(QQ(1:2:end,:)) bf_data(1:2:2*Ndof,1:2)]

bw_sep_89 = [(bf_data(18,1)-bf_data(16,1))/(2*bf_data(18,2)*bf_data(18,1)),...
        (bf_data(18,1)-bf_data(16,1))/(2*bf_data(16,2)*bf_data(16,1))]


% % pause     % Break or Pause Here for eigenvalues only
% break

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot mode shapes:
% Construct psi_vals_x,_o to find displacements and rotations-finer grid
% X = [disp of 1, 1 to 4, disp of 2; rot of 1, 1 to 4, rot 2]

plot_xs = [[1:1:L1],fliplr([(L2+L1-1):-1:(L2+1)])];
plot_os = [[1:1:L1],L1,fliplr([(L2+L1-1):-1:(L2+1)])];

del_x = 1/50;
xs= [0:del_x*L1:L1 L1:del_x*L2:(L1+L2)];
xs1 = [0:del_x*L1:L1]; xs2 = [L2:-del_x*L2:0];
Nxs = length(xs1);
for k = 1:1:Nxs;
    % Displacement
    x = xs1(k)/L1;
    psi_vals_x1(k,1:N) = double(eval(Psi_w));
    % Rotation
    x = xs1(k)/L1;
    psi_vals_o1(k,1:N) = double(eval(Psi_o));
end
for k = 1:1:Nxs; %Nxs1 = Nxs2 = Nxs
    % Displacement
    x = xs2(k)/L2;
    psi_vals_x2(k,1:N) = double(eval(Psi_w));
    % Rotation
    x = xs2(k)/L2;
    psi_vals_o2(k,1:N) = double(eval(Psi_o));
end
%clear psi_vals_x psi_vals_o
psi_vals_x = [psi_vals_x1, zeros(Nxs,3*N);
            zeros(Nxs,2*N), psi_vals_x2, zeros(Nxs,N)];
psi_vals_o = [zeros(Nxs,N), psi_vals_o1, zeros(Nxs,2*N);
            zeros(Nxs,3*N), psi_vals_o2];

Mshapes_x = (psi_vals_x*B)*Phi(1:Ndof,1:2:end);
Mshapes_o = (psi_vals_o*B)*Phi(1:Ndof,1:2:end);

for ii = 1:12/2;
    for jj=  1:2
        figure(50+ii)
        subplot(2,2,2*jj-1)
        plot(xs,real(Mshapes_x(:,(ii*2-2+jj))),xs,imag(Mshapes_x(:,(ii*2-2+jj)))); grid on;
        title(['Shape of mode ', num2str(ii*2-2+jj)]);
        ylabel('Displacement'); xlabel('x-Beam 1 then 2');
        subplot(2,2,2*jj)
        plot(xs,real(Mshapes_o(:,(ii*2-2+jj))),xs,imag(Mshapes_o(:,(ii*2-2+jj)))); grid on;
        title(['Shape of mode ', num2str(ii*2-2+jj)]);
        ylabel('Rotation'); xlabel('x-Beam 1 then 2');
    end
end

return

% % Plots Magnitude and Phase of Mode Shapes
% for ii = 1:20/2;
%     for jj=  1:2
%         H = figure(100+ii); set(H,'Units','normalized','Position',[.25 .05 .5 .85]);
%         subplot(4,2,4*jj-3)
%         plot(xs,abs(Mshapes_x(:,(ii*2-2+jj)))); grid on;
%         title(['Shape of mode ', num2str(ii*2-2+jj)]);
%         ylabel('|Displacement|'); xlabel('x-Beam 1 then 2');
%         subplot(4,2,4*jj-1)
%         plot(xs,angle(Mshapes_x(:,(ii*2-2+jj)))); grid on;
%         ylabel('Phs: Disp.'); xlabel('x-Beam 1 then 2');
%         subplot(4,2,4*jj-2)
%         plot(xs,abs(Mshapes_o(:,(ii*2-2+jj)))); grid on;
%         title(['Shape of mode ', num2str(ii*2-2+jj)]);
%         ylabel('| Rotation |'); xlabel('x-Beam 1 then 2');
%         subplot(4,2,4*jj)
%         plot(xs,angle(Mshapes_o(:,(ii*2-2+jj)))); grid on;
%         ylabel('Phs Rot.'); xlabel('x-Beam 1 then 2');
%     end
% end

% Construct psi_vals to find displacements and rotations
% X = [disp of 1@1,2,3,4; rot 1@1,2,3,4; disp 2@1,2,3; rot 2@1,2,3,4;]
psi_vals = [0];
Ls = [L1 L1 L2 L2];
for n = 1:4;
    if n == 1 | n == 3;
        for k = 1:4
        x = k/Ls(n);
        psi_vals(k,1:N,n) = double(eval(Psi_w));
        end
    else
        for k = 1:4
        x = k/Ls(n);
        psi_vals(k,1:N,n) = double(eval(Psi_o));
        end
    end
end
Psi_matrix = [psi_vals(:,:,1),zeros(4,3*N);
               zeros(4,N), psi_vals(:,:,2),zeros(4,2*N);
               zeros(3,2*N), psi_vals(1:3,:,3),zeros(3,N);
               zeros(4,3*N), psi_vals(:,:,4)];

Phi_15coord = Psi_matrix*B*Phi(1:Ndof,1:2:end);% This skips complex conjugates

% pause
disp('Continuing...');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
% Construct Frequency Domain Transfer Functions
tic
ws = [0:(2*pi/14.2):3800];
ws_dir = ws(1:10:end);
X = zeros(size(Psi_matrix,1),size(Q_hat,2),length(ws_dir));
for jj = 1:1:length(ws_dir);
    X(:,:,jj) = (Psi_matrix*B)*((-ws_dir(jj)^2*M_hat+i*ws_dir(jj)*C_hat+K_hat)\Q_hat);
    % Above equals (Psi_matrix*B)*(Frequency Domain Solution for State Space gen coords)
end
% X is in standard form, though AMI typically uses a different form.
t_fdtf = toc

if 0
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
	% Construct FD TF using the identified modes:
	tic
	% This could be made much faster by eliminating the omega for loop
	last_mode = 14;
	ws_mod = ws(1:10:end);
	N_modal = zeros(last_mode*2,length(ws_mod),size(Q_bar,2));
	for ii = 1:1:length(ws_mod);
        for jj = 1:1:last_mode*2;%Ndof*2;
            N_modal(jj,ii,:) = Phi(:,jj).'*Q_bar/(i*ws_mod(ii)-lambda(jj));
        end
	end
	N_modal((last_mode*2+1):Ndof*2,:) = zeros(2*Ndof-last_mode*2,length(ws_mod));
	
	% Taking Phi(1:Ndof,:)*N_modal returns only the displacements in the state vector x
	X_modal = ((Psi_matrix*B)*Phi(1:Ndof,:))*N_modal; 
	t_modal_tf  = toc
    
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	% Plots of FRF's vs. frequency
    % Used to compare direct solution to the modal frequency domain solution
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	figure(10)
	semilogy(ws_dir,abs(X(1,:)),ws_dir,abs(X(2,:)),ws_dir,abs(X(3,:)),ws_dir,abs(X(4,:)),...
        ws_dir,abs(X(9,:)),ws_dir,abs(X(10,:)),ws_dir,abs(X(11,:)),...
        imag(bf_data(1:2:24,3)),mean(abs(X(2,:)))*ones(1,12),'.');
	title('Displacement FRFs (Magnitude)');
	xlabel('freq (rad/s'); ylabel('Log(Mag(w))');
	legend('1@1m', '1@2m', '1@3m', '1@4m', '2@1m', '2@2m', '2@3m');
	%axis([min(ws) max(ws) 10^(-10) 10^(-4)])
	figure(11)
	semilogy(ws_dir,abs(X(5,:)),ws_dir,abs(X(6,:)),ws_dir,abs(X(7,:)),ws_dir,abs(X(8,:)),...
        ws_dir,abs(X(12,:)),ws_dir,abs(X(13,:)),ws_dir,abs(X(14,:)),ws_dir,abs(X(15,:)),...
        imag(bf_data(1:2:24,3)),mean(abs(X(5,:)))*ones(1,12),'.');
	title('Rotation FRFs (Magnitude)');
	xlabel('freq (rad/s'); ylabel('Log(Mag(\theta))');
	legend('1@1m', '1@2m', '1@3m', '1@4m', '2@1m', '2@2m', '2@3m', '2@4m');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plots of FRF's vs. frequency
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(12)
semilogy(ws_dir,comp_FRF(squeeze(X(:,1,:)).'),ws_dir,comp_FRF(squeeze(X(:,2,:)).'),...
    imag(bf_data(1:2:24,3)),mean(abs(X(2,:)))*ones(1,12),'.');
title('Composite FRFs (Magnitude)');
xlabel('freq (rad/s'); ylabel('Log(Mag(w))');
legend('Composite DP #1','Composite DP #2');
%axis([min(ws) max(ws) 10^(-10) 10^(-4)])
figure(13)
semilogy(ws_dir,abs(squeeze(X(1,1,:))),ws_dir,abs(squeeze(X(9,2,:))),...
    imag(bf_data(1:2:24,3)),mean(abs(X(5,:)))*ones(1,12),'.');
title('Drive Point FRFs (Magnitude)');
xlabel('freq (rad/s'); ylabel('Log(Mag(\theta))');
legend('DP#1,','DP#2');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Construct the time domain solution
% Nt:	number of time samples
% T:	time window
% delta:	time step size
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Nt=2^16; % Need to satisfy Nyqust Crieria for modes 1-21 (possibly excessive)
T=14.2;% Bassem used 31.2;
delta=T/Nt;
t=0:delta:T-delta;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Eq.(10.5.17): xsi are the modal coordinates in the state space - 
% A column holds all coordinate values at a specified instant.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic
QQ=(conj(Phi)')*Q_bar;
Nm_use = 21;
xsi = zeros(2*Nm_use,length(t),size(Q_bar,2));
for k = 1:size(Q_bar,2)
    for n = 1:2*Nm_use;
        xsi(n,:,k)=QQ(n,k)*exp(lambda(n)*t);
    end
end
disp('Time response of modal coordinates completed')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Eq.(10.5.1): modal transformation - x holds the unconstrained variables.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x = zeros(size(Phi,1),size(xsi,2),size(xsi,3));
for k = 1:size(xsi,3)
    x(:,:,k)=Phi(:,1:size(xsi))*xsi(:,:,k);
end
clear xsi;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Return to full set of generalized coordinates, i.e. the 44 Ritz series 
% coefficients: a column of q holds the variables at a specified instant.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for k = 1:size(x,3)
    q(:,:,k)=real(B*x(1:4*N-3,:,k));
end
clear x;

% tresp holds the physical displacements and rotations. 
% A column is sequenced as:
%     disp_1@1,2,3,&4  rotation_1@1,2,3,&4  disp_1@1,2,&3 rotation_1@1,2,3,&4
% Columns hold physical displacment variables at a fixed t.
% Rows hold the time response of a physical displacement.
for k = 1:size(q,3)
    tresp(:,:,k)=Psi_matrix*q(:,:,k);
end
clear q;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FFT of clean time response
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set the frequency band of interest then find the corresponding discrete 
% frequency point
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
wmax=3800;	                                                    
% max_indx is the number of frequency points to be retained
max_indx=1+round(wmax*T/(2*pi));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate the frequency vector
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
wk = (2*pi/T)*[0:(Nt/2+1)];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FFT procedure:
% -scale the results by delta
% -take only the first (Nt/2+1) terms
% -truncate the response at the frequency band of interest (w=0-3080 rad/s)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% FFT of the full time duration
%   When applied to a rectangular array, the FFT treats each column as a separate 
%   time history. Thus, process the transpose of the time response.

% Scale the FFT to standard definition.
for k = 1:size(tresp,3);
    fresp_temp(:,:,k)=delta*fft(tresp(:,:,k).');
end

% fresp_clean has the FRF's for all non-negative frequencies over the full band. 
% A column of fresp_clean holds the FRF's for a specified displacement variable.
fresp_clean=(fresp_temp(1:(Nt/2)+1,:,:));                  
clear fresp_temp

% fresp is the FRF in the interval up to 3080 rad/s
H_td=fresp_clean(1:max_indx,:,:);
clear fresp_clean
wtd=wk(1:max_indx);
t_tresp_to_tf = toc % Measure time elapsed

if 0
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	% Plots of FRF's vs. frequency
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	% Figure to Compare Direct, Modal and Time Domain Solutions:
	figure(100)
	disp_xs = [1:4,9:11];
	colstr = ['bgrcmykbgrcmykbgrcmyk'];
	clf(100);
	for k = 1:length(disp_xs);
        semilogy(ws_dir,abs(X(disp_xs(k),:)), [colstr(k)],...
            wtd,abs(H_td(:,disp_xs(k))), [colstr(k) '--'],...
            ws_mod,abs(X_modal(disp_xs(k),:)), [colstr(k) '.']);
        if(k == 1); hold on; end
	end
	semilogy(bf_data(1:2:24,1),mean(abs(X(disp_xs(k),:)))*ones(1,12),'b+'); hold off;
	title('Displacement FRFs (Magnitude), Freq Sweep (-), Time Resp (--), Modal (.)'); grid on;
	xlabel('freq (rad/s'); ylabel('Log(Mag(w))');
	legend('1@1m', '1@1m', '1@2m', '1@2m', '1@3m', '1@3m', '1@4m', '1@4m');
	
	% Figures of Clean Time Domain FRFs:
	figure(101)
	disp_xs = [1:4,9:11];
	clf(101);
	for k = 1:length(disp_xs);
        semilogy(wtd,abs(H_td(:,disp_xs(k))), [colstr(k) '-']);
        if(k == 1); hold on; end
	end
	semilogy(imag(lambda(1:2:24,1)),mean(abs(H_td(:,disp_xs(k))))*ones(1,12),'b+'); hold off;
	title('Displacement FRFs (Magnitude)'); grid on;
	xlabel('freq (rad/s'); ylabel('Log(Mag(w))');
	legend('1@1m', '1@2m', '1@3m', '1@4m', '2@1m','2@2m', '2@3m');
	%axis([min(ws) max(ws) 10^(-10) 10^(-4)])

	figure(102)
	disp_os = [5:8,12:15];
	clf(102);
	for k = 1:length(disp_os);
        semilogy(wtd,abs(H_td(:,disp_os(k))), [colstr(k) '-']);
        if(k == 1); hold on; end
	end
	title('Rotation FRFs (Magnitude)');  grid on;
	xlabel('freq (rad/s'); ylabel('Log(Mag(\theta))');
	legend('1@1m', '1@2m', '1@3m', '1@4m', '2@1m', '2@2m', '2@3m', '2@4m');
end

% Figures of two Drive Point FRFs, w/wout noise.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plots of FRF's vs. frequency
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(105)
semilogy(ws_dir.',comp_FRF(squeeze(X(:,1,:)).'),ws_dir.',comp_FRF(squeeze(X(:,2,:)).'),...
    wtd,comp_FRF(H_td(:,:,1)),wtd,comp_FRF(H_td(:,:,2)),...
    imag(bf_data(1:2:24,3)),mean(abs(X(2,:)))*ones(1,12),'.');
title('Composite FRFs (Magnitude)');
xlabel('freq (rad/s'); ylabel('Log(Mag(w))');
legend('FD-Composite DP #1','FD-Composite DP #2','TD-Composite DP #1','TD-Composite DP #2');
%axis([min(ws) max(ws) 10^(-10) 10^(-4)])
figure(106)
semilogy(ws_dir,abs(squeeze(X(1,1,:))),ws_dir,abs(squeeze(X(9,2,:))),...
    wtd,comp_FRF(H_td(:,1,1)),':',wtd,comp_FRF(H_td(:,9,2)),':',...
    imag(bf_data(1:2:24,3)),mean(abs(X(5,:)))*ones(1,12),'.');
title('Drive Point FRFs (Magnitude)');
xlabel('freq (rad/s'); ylabel('Log(Mag(\theta))');
legend('FD-DP#1,','FD-DP#2','TD-DP#1,','TD-DP#2');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Find Modal Residue Matrices % Oct 6, 2004
for k = 1:21;
    A_an(:,:,k) = Psi_matrix*B*Phi(1:41,2*k-1)*(Phi(:,2*k-1).')*Q_bar;
end

H_test = zeros(size(H_td));
for k = 1:21;
    for p = 1:2;
        H_test(:,:,p) = H_test(:,:,p) + (i*wtd.'-lambda(2*k-1)).^-1*A_an(:,p,k).' +....
            (i*wtd.'-lambda(2*k-1)').^-1*A_an(:,p,k)';
    end
end

figure(200)
subplot(2,1,1);
semilogy(wtd,abs(H_test(:,5,1)), wtd,abs(H_td(:,5,1))); grid on;
legend('H_t_e_s_t','H_t_d');
subplot(2,1,2);
semilogy(wtd,comp_FRF(H_test), wtd,comp_FRF((H_td))); grid on;
legend('H_t_e_s_t','H_t_d');

figure(201)
plot(wtd,imag(H_test(:,5,1)), wtd,imag(H_td(:,5,1))); grid on;
legend('H_t_e_s_t','H_t_d');

figure(202)
semilogy(wtd,abs(H_td(:,5,1))); grid on;
legend('H_t_e_s_t','H_t_d');
hold on;
for k = 1:11;
    semilogy(abs(lambda(2*k-1)), ...
        abs(imag(A_an(5,1,k))/real(lambda(2*k-1))),'r.');
end