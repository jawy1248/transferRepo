function [wn_fit,zt_fit,indfit,yfit,varargout]=hilbpsm(yltv,ts,P,Pc,varargin)
% Smoothed Hilbert Transform Analysis of free vibration response.  Based on
% algorithm by Hartono Sumali & Rick Kellog, "Calculating Damping from Ring-Down 
% Using Hilbert Transform and Curve Fitting", 4th IOMAC, 9-11 May, 
% Istanbul, Turkey, 2011. #### REPLACE WITH JOURNAL REFERENCE LATER #####
%
% [wn_fit,zt_fit,indfit,yfit,all_data]=hilbpsm(yltv,ts,P,Pc)
%
% [wn_fit,zt_fit,indfit,yfit,all_data]=hilbpsm(yltv,ts,P,Pc,'verbose')
%
% yltv - time response to process (only one response point allowed)
% ts - corresponding time vector
% P, Pc - maximum order of polynomials to fit for the phase and amplitude,
%       respectively, of the Hilbert transformed signal.
%
% M.S. Allen, Sept. 2011, msallen@engr.wisc.edu
if length(yltv)~=numel(yltv);
    error('yltv must be a vector (only one output point allowed');
end
yltv=yltv(:);
ts=ts(:);
if length(yltv)~=length(ts);
    error('Time vector is not the same length as response vector');
end

if nargin>4
    if strcmpi(varargin{1},'verbose')
        vbflg=true(1);
    end
else
    vbflg=false(1);
end
% Normalize time vector to avoid numerical ill conditioning (up to pretty
% high polynomial orders, at least).
tmax=max(ts);
tsnd=ts/tmax;

[Hnlh]=hilbert(yltv);
Hhph=unwrap(angle(Hnlh));
Hhamp=abs(Hnlh);

figure(51); clf(51)
set(gcf,'Units','Normalized');
set(gcf,'Position',[0.33, 0.17, 0.35, 0.75]);
ha101a=subplot(3,1,1);
semilogy(ts,abs(yltv),':','Color',0.8*[1,1,1]);
hold on; semilogy(ts,Hhamp,'b','LineWidth',2); hold off; grid on; ylim(minmax(Hhamp));
ylabel('\bfMagnitude');
ha101b=subplot(3,1,2);
plot(ts,Hhph); grid on;
ylabel('\bfAngle (rad)'); xlabel('\bftime (s)');

disp('Select the band to curve fit');
[xg,yg]=ginput(2);
indfit=find(ts>xg(1) & ts<xg(2));

% Fit phase to obtain frequency versus time
    Amat=ones(length(indfit),P+1); % use ones since we will fill the last column with ones anyway
    Amatd=zeros(length(indfit),P+1); % for derivative
    for k=1:P
        Amat(:,k+1)=tsnd(indfit).^k;
        Amatd(:,k+1)=(1/tmax)*k*tsnd(indfit).^(k-1);
            % The (1/tmax) factor makes this a derivative with respect to ts (not tsnd)
    end
    bs=Amat\Hhph(indfit);
    bs_m1=Amat(:,1:end-1)\Hhph(indfit);
    psiit_fit=Amat*bs;
    axes(ha101b); line(ts(indfit),Amat*bs,'Color','r','LineWidth',2);
    axes(ha101b); line(ts(indfit),Amat(:,1:end-1)*bs_m1,'Color','c','LineWidth',2,'LineStyle','--');
        legend('Measurement','Poly Fit','Poly Fit (order-1)');

ha101c=subplot(3,1,3);
line(ts(indfit),Amat*bs-Hhph(indfit),'Color','r','LineWidth',2); grid on;
line(ts(indfit),Amat(:,1:end-1)*bs_m1-Hhph(indfit),'Color','c','LineWidth',2,'LineStyle','--');
        legend('Poly Fit Error','Poly Fit (order-1) Error');
ylabel('\bfAngle (rad)'); xlabel('\bftime (s)');

% Fit amplitude to find damping versus time
    cs=(Amat(:,1:(Pc+1)))\ln(Hhamp(indfit));
    cs_m1=(Amat(:,1:(Pc)))\ln(Hhamp(indfit));
    
% New (Corrected Method) Sept. 2011:
    % with 6th order polynomials or (P)
    wd_fit=Amatd*bs;
    psirt_fit=Amat(:,1:(Pc+1))*cs; % zero term is actually c0+ln(A0)
        % This is the natural log of the amplitude function
        axes(ha101a); line(ts(indfit),exp(psirt_fit),'Color','r','LineWidth',2);
    alphat_fit=Amatd(:,1:(Pc+1))*cs;
    wn_fit=(wd_fit.^2+(-alphat_fit).^2).^(1/2);
    zt_fit=-alphat_fit./wn_fit;

    % with 6th order polynomials or (P)
	wd_fit_m1=Amatd(:,1:end-1)*bs_m1;
%     psirt_fit_m1=Amat(:,1:(Pc))*cs_m1; % zero term is actually c0+ln(A0)
        % Uncomment above to plot
    alphat_fit_m1=Amatd(:,1:(Pc))*cs_m1;
    wn_fit_m1=(wd_fit_m1.^2+(-alphat_fit_m1).^2).^(1/2);
    zt_fit_m1=-alphat_fit_m1./wn_fit_m1;
   
figure(52)
ha102a=subplot(1,2,1);
% Feldman's approach(es) for natural frequency variation
if vbflg
    dt=ts(2)-ts(1);
    plot(ts(indfit),wn_fit/2/pi,ts(indfit),wn_fit_m1/2/pi,'--'); alims=axis;
    % Feldman 2011, MSSP, eq. (11)
    wd_Feld=angle(Hnlh(1:end-1).*conj(Hnlh(2:end)))/dt/2/pi;
    % Alternate, eq. (26) in Feldman 2011 - nevermind, not formula there.
    plot(ts(1:end-1),-wd_Feld,'Color',0.9*[1,1,1]); % not sure why minus is always needed
    hold on; plot(ts(indfit),wn_fit/2/pi,ts(indfit),wn_fit_m1/2/pi,'--'); grid on; hold off
    axis(alims);
    legend('Direct Hilbert',[num2str(P),'th Order'],[num2str(P-1),'th Order']);
else
    plot(ts(indfit),wn_fit/2/pi,ts(indfit),wn_fit_m1/2/pi,'--'); grid on;
    legend([num2str(P),'th Order'],[num2str(P-1),'th Order']);
end
ylabel('\bff_n (Hz)'); xlabel('\bfTime (s)'); title('\bfNat. Freq. vs Time')

set(get(gca,'Children'),'LineWidth',2);
ha102b=subplot(1,2,2);
plot(ts(indfit),zt_fit,ts(indfit),zt_fit_m1,'--'); grid on;
ylabel('\bf\zeta'); xlabel('\bfTime (s)'); title('\bfDamping vs Time')
set(get(gca,'Children'),'LineWidth',2);
legend([num2str(Pc),'th Order'],[num2str(Pc-1),'th Order']);

% Reconstruct time response
psi_fit=psirt_fit+1i*psiit_fit;
yfit=exp(psi_fit);

if nargout > 4;
    all_data = [];
    S = whos;
    for k = 1:length(S)
        if ~strcmpi(S(k).name,'all_data')
            eval(['all_data.',S(k).name,' = ',S(k).name,';']);
        end
    end
    varargout{1}=all_data;
end