function hvect = plot_shape(shape,fem)

ctrace = imat_ctrace(fem);

for i_mode = 1:length(shape.Frequency)
    h(i_mode) = figure('Color',[1,1,1]);
    
    axes('Units','Normalized','Position',[0,0,1,1],'XLim',[0,1],'YLim',[0,1]);
    axis off;
    tbox = text(0,1,{[' Mode ',num2str(i_mode)];[' Frequency ',num2str(shape.Frequency(i_mode))];...
        [' Damping ',num2str(shape.Damping(i_mode)*100),'%'];
        [' ',shape.IDLine1{i_mode}]; [' ',shape.IDLine2{i_mode}];...
        [' ',shape.IDLine3{i_mode}]; [' ',shape.IDLine4{i_mode}]},...
        'Units','Normalized',...
        'HorizontalAlignment','Left','VerticalAlignment','Top','FontSize',8,...
        'Interpreter','none');
    axes('Units','Normalized','Position',[.05,.05,.9,.9]);
    
    axis off;
    modeshape = shape.Shape(:,i_mode);
    
    maxs = -Inf*ones(1,3);
    mins = Inf*ones(1,3);
    
    for i = 1:length(fem.node.id)
        for j = 1:3
            if fem.node.coord(i,j) < mins(j)
                mins(j) = fem.node.coord(i,j);
            end
            if fem.node.coord(i,j) > maxs(j)
                maxs(j) = fem.node.coord(i,j);
            end
        end
    end
    
    modelsize = norm(maxs-mins);
    modeshape = modeshape/max(abs(modeshape))*modelsize/10;
    
    %% Plot original FEM
    plotfem(fem,'LineSpec',':');
    
    %% Make and plot new FEM.
    femshape = fem;
    for i = 1:length(femshape.node.id)
        femshape.node.coord(i,:) = xform(fem.node.coord(i,:),fem.cs,fem.node.cs(i,1),fem.cs.id(1));
    end
    
    coords = 'XYZ';
    for i = 1:length(femshape.node.id)
        for j = 1:3
            dof = [num2str(fem.node.id(i)),coords(j),'+'];
            femshape.node.coord(i,:) = femshape.node.coord(i,:)...
                + dof_dir(dof,modeshape(3*(i-1)+j),femshape);
        end
    end
%     femshape.node.cs = ones(size(femshape.node.cs));
    plotfem(femshape);
    axis tight;
    set(gcf,'Name',['Mode ',num2str(i_mode)]);
end