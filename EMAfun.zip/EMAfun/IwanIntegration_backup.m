function [x,xd,xdd,f_joint,varargout] = IwanIntegration(params,M,C,K,fext,ts,varargin)
% Use beta-gamma Newmark method to integrate the motion response
% corresponding to time points given in the ts vector of a single or
% multi-DOF system with linear stiffness, viscuous damping, and various
% Iwan elements with Iwan parameters specified by params.
%
% [x,v,a,f_joint,ad] = IwanIntegration(params,M,C,K,fext,ts,iwan_pairs)
%
% INPUTS:
% params = [Fs,Kt,chi,beta] % defines Iwan joint
% M = mass matrix
% C = viscuous damping coefficient matrix
% K = linear stiffness matrix
% fext = external force time history on each node (Nnodes x Ntime)
% ts = time vector with equally spaced time samples
% iwan_pairs = [node1,node2] where node1 and node2 specify the indices of
%   the two nodes that are connected by the Iwan joint.
%
% OUTPUTS:
% x = displacement of masses
% v = velocity
% a = acceleration
% f_joint = cell array of the joint force applied by individual Iwan
%   elements. There are as many cell outputs as the number of Iwan elements.
%
% Created by R.M. Lacayo; July 2013; lacayo@wisc.edu
% Updated by M.S. Allen, July 2015 - speed ups and added multiple joints.
%

% This part isn't yet implemented
% params = [Fs1,Kt1,chi1,beta1]
%          [Fs2,Kt2,chi2,beta2]
%          [        ...       ]
%          [FsN,KtN,chiN,betaN]
% iwan_pairs = an array telling which DOF indices are connected by the nth
%   Iwan element. The number of rows reflects the number of pairs, and
%   the number of columns is always 2. For example, a 5-DOF system with an
%   Iwan element joining DOFs 2 with 4 and another between DOF 3 and ground 
%   would be specified as iwan_pairs=[2,4; 3,0]. The row index of this 
%   array is assosciated with the same row index of Iwan parameters in the
%   params input argument. 

% Cut from above by MSA - doesn't make sense???
%   The order of the pairs is directionally-
%   dependent; the DOFs in second column are in the positive direction
%   ahead of the DOFs in the first column.

% Check function arguments
% Check for size consistency
[Ndof,NtF] = size(fext);
Nt = length(ts);
if Nt~=NtF
    error('Force vector and time vector must be the same length.');
end
if nargin > 6
    iwanPair = varargin{1};
else
    iwanPair = [0,1];
end
if nargin > 7
    % Want ICs={x0,x0d}
    ICs=varargin{2};
    if length(ICs{1})~=length(ICs{2}) || length(ICs{1})~=Ndof
        error('ICs aren''t of comptabile size');
    end
else
    ICs=[];
end
NIwan=size(params,1);
    % Check that iwanPairs is of the same size
    if size(iwanPair,1)~=NIwan; error('Size of "params" and "iwan_pairs" doesn''t match'); end

for k=1:NIwan % Find mathematical description of Iwan parameters
    params2(k,:)=iwanconvert(params(k,:));
end
% % Retrieve parameters
% Fs = params(1); Kt = params(2); chi = params(3); beta = params(4);
% 
% phi_max = Fs*(1+beta)/(Kt*(beta + (chi+1)/(chi+2)));
% R = Fs*(chi+1)/((beta+ (chi+1)/(chi+2))*phi_max^(chi+2) );
% S = (Fs/phi_max)*(beta/(beta + (chi+1)/(chi+2)));
% 
% params2 = [chi, phi_max, R, S];

% integration parameters
beta_N = 1/4;
gamma_N = 1/2;

%Initialize Variables
dt = ts(2)-ts(1); % assumes equally spaced time samples
x  = zeros(Ndof, Nt);
xd = zeros(Ndof, Nt);
    if ~isempty(ICs) % Pass in initial conditions
        x(:,1)=ICs{1};
        xd(:,1)=ICs{2};
    end
xdd = zeros(Ndof, Nt);
newton_iter=zeros(1,Nt);

u_prev = zeros(Ndof,1); 
v_prev = zeros(Ndof,1); 
a_prev = zeros(Ndof,1);
    if ~isempty(ICs) % Pass in initial conditions
        u_prev=x(:,1);
        v_prev=xd(:,1);
    end

f_joint = zeros(NIwan,Nt);
K_joint = zeros(NIwan,Nt);
KE = zeros(1,Nt);

% Use NJ Jenkins elements
% lets use NJ Jenkins elements
NJ = 100;
jy_prev  = zeros(NJ,1);
jys = zeros(NJ,Nt);
if ~isempty(ICs)
    if length(ICs)>2
        NJ=length(ICs{3});
        jy_prev=ICs{3};
        jys=zeros(NJ,Nt);
        jys(:,1)=jy_prev;
    end
end

% Prepare mapping matrices for Iwan forces
indVec = zeros(size(a_prev));
indMat = zeros(size(M));
ind1 = iwanPair(1); ind2 = iwanPair(2);
if ind1==0 % mass index 2 is joined to ground
    indVec(ind2) = 1;
    indMat(ind2,ind2) = 1;
elseif ind2==0 % mass index 1 is joined to ground
    indVec(ind1) = 1; % MSA fixed this - doesn't matter which direction the joint is pointed...
    indMat(ind1,ind1) = 1;
else % mass indices are joined with iwan element
    indVec(ind1) = -1; indVec(ind2) = 1;
    indMat(ind1,ind1) = 1; indMat(ind1,ind2) = -1;
    indMat(ind2,ind1) = -1; indMat(ind2,ind2) = 1;
end

%integrate through every timestep
for it = 2:length(ts)
    % First guess for next acceleration is the previous accleration
    a_est = a_prev;
    v_est = v_prev + dt*( (1-gamma_N)*a_prev + gamma_N*a_est);
    u_est = u_prev + dt*v_prev + (dt^2/2)*((1-2*beta_N)*a_prev + 2*beta_N*a_est);
    
    % Calculate non-linear force at location defined by iwanPair
    if ind1==0 % mass index 2 is joined to ground
        [ftemp, jy_temp, stiff_temp] = iwan(u_est(ind2), jy_prev, params2);
    elseif ind2==0 % mass index 1 is joined to ground
        [ftemp, jy_temp, stiff_temp] = iwan(u_est(ind1), jy_prev, params2);
    else % mass indices are joined with iwan element
        [ftemp, jy_temp, stiff_temp] = iwan(u_est(ind2)-u_est(ind1), jy_prev, params2);
    end
    fjVec = ftemp*indVec;
    stiffMat = stiff_temp*indMat;
    
    resid = M*a_est + C*v_est + K*u_est + fjVec - fext(:,it);
    grad = M + gamma_N*C*dt + beta_N*(K+stiffMat)*dt^2;
    
    % Newton Iteration Loop
    iter = 0;
    while ((resid'*resid/norm(K*u_est).^2) > 1e-6) && (resid'*resid > 1.0e-10) % This should be improved to be a fraction of u and v and z
        a_est = a_est - grad\resid;
        v_est = v_prev + dt*( (1-gamma_N)*a_prev + gamma_N*a_est);
        u_est = u_prev + dt*v_prev ...
            + (dt^2/2)*((1-2*beta_N)*a_prev + 2*beta_N*a_est);
        
        % Calculate non-linear force at location defined by iwanPair
        if ind1==0 % mass index 2 is joined to ground
            [ftemp, jy_temp, stiff_temp] = iwan(u_est(ind2), jy_prev, params2);
        elseif ind2==0 % mass index 1 is joined to ground
            [ftemp, jy_temp, stiff_temp] = iwan(u_est(ind1), jy_prev, params2);
        else % mass indices are joined with iwan element
            [ftemp, jy_temp, stiff_temp] = iwan(u_est(ind2)-u_est(ind1), jy_prev, params2);
        end
        fjVec = ftemp*indVec;
        stiffMat = stiff_temp*indMat;
        
        resid = M*a_est + C*v_est + K*u_est + fjVec - fext(:,it);
        grad = M + gamma_N*C*dt + beta_N*(K+stiffMat)*dt^2;
        iter = iter + 1;  
            
        if round(iter/10000) == (iter/10000); fprintf('*'); end
    end
    
    f_joint(it) = ftemp;
    K_joint(it) = stiff_temp;
    
    jy_prev = jy_temp;
    jys(:,it) = jy_temp;
    
    newton_iter(it) = iter;
    u_prev = u_est;
    v_prev = v_est;
    a_prev = a_est;
    
    x(:,it) = u_est;
    xd(:,it) = v_est;
    xdd(:,it) = a_est;
    
    KE(it) = (1/2)*v_est.'*M*v_est;
    
    if round(it/10000) == (it/10000); fprintf('.'); end
end

% varargouts
if nargout>4;
    ad.KE=KE;
    ad.newton_iter=newton_iter;
    ad.K_joint=K_joint;
    ad.jys=jys;
    ad.params2=params2;
    ad.newton_iter=newton_iter;
    varargout{1}=ad;
end