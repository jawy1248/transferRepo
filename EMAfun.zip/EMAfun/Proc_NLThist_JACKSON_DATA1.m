clc
% Process measurements from perforated plates that seem to be nonlinear.

% Loaded *.csv file and extracted 1st and 2nd columns.  Multiplied by
% scaling to put a (acceleration) in units of g's, 
% data=load('10Hzto25Hz_60s.csv');
% ts=data(:,1);
% a=data(:,2);
% ts=ts-ts(1);
% a=a/4.820e-3;
% save 10Hzto25Hz_60s a ts

load 25Hzto10Hz_60s.mat % contains ts a fs

% First low-pass filter since sample rate is much higher than needed.

fs=mean(diff(ts)).^-1;
f_lp=40;
N_order=6;
[bcoef,acoef] = butter(6,f_lp/(fs/2));
% [bcoef,acoef] = butter(6,[500/(fs/2),650/(fs/2)]); % for band-pass filter
a_filt=filtfilt(bcoef,acoef,a);

fft_easy([a,a_filt],ts);

% [Hnlh]=hilbert(a_filt);
% Hhph=unwrap(angle(Hnlh));
% Hhamp=abs(Hnlh);
% 
% figure(51); clf(51)
% ha101a=subplot(3,1,1);
% semilogy(ts,abs(a_filt),':','Color',0.8*[1,1,1]);
% hold on; semilogy(ts,Hhamp,'b','LineWidth',2); hold off; grid on; ylim(minmax(Hhamp));
% ylabel('Magnitude');
% ha101b=subplot(3,1,2);
% plot(ts,Hhph); grid on;
% ylabel('Angle (rad)'); xlabel('time (s)');
% ha101c=subplot(3,1,3);
% plot(ts(2:end),fs*diff(Hhph)/2/pi); grid on; ylim([0,200]);
% ylabel('Frequency (Hz)'); xlabel('time (s)');

%{
[S,F,T,P] = spectrogram(a,2^13,2^12,2^13,fs);
figure(100)
surf(T,F,10*log10(abs(P)),'EdgeColor','none');
% surf(100+0.8*T,F,10*log10(abs(P)),'EdgeColor','none');
axis xy; axis tight; colormap(jet); view(0,90);
% xlabel('\bfDrive Frequency'); ylim([0,1000])
xlabel('\bfTime (s)');
ylabel('\bfResponse Frequency (Hz)');

% find(T>56,1)
figure(101);
semilogy(F,abs(P(:,123:5:146))); grid on; legend(num2str(T(123:5:146).'));
ylabel('\bfAmplitude');
xlabel('Frequency (Hz)');
%}

% figure(102)
% band_ind=find(F<1000);
% for k=110:180;
%     line(T(k)*ones(size(band_ind)),F(band_ind),abs(P(band_ind,k)));
% end
% xlabel('\bfTime (s)');
% ylabel('\bfResponse Frequency (Hz)');

%% Process with Sumali/Sracic/Allen's Hilbert Transform algorithm.

[wn_fit,zt_fit,indfit,yfit,ad]=hilbpsm(a_filt,ts,7,5);
    Amp_fit=exp(ad.psirt_fit);
    % most of the above is irrelevant since that was for free-response
    % data, but we can get the frequency versus amplitude curve over the
    % continuous regions.
% In this second fit get the part after the jump.
[wn_fit,zt_fit,indfit2,yfit2,ad2]=hilbpsm(a_filt,ts,7,5);
    Amp_fit2=exp(ad2.psirt_fit);
    % most of the above is irrelevant since that was for free-response
    % data, but we can get the frequency versus amplitude curve over the
    % continuous regions.

figure(61);
semilogy(ad.wd_fit/2/pi,Amp_fit,ad2.wd_fit/2/pi,Amp_fit2); grid on;
ylabel('\bfFund. Harm. Amplitude (g)'); xlabel('\bfFrequency (Hz)');
title('\bfFrequency Response for 150mV Forcing');

