function [rot_res] = res2real(cres,varargin)
% Create real mode vectors from complex ones using line-fit procedure.
% One sometimes encounters the situation where the mode vectors identified
% from experimental data are real but rotated by a complex constant [Ewins 
% 2000], for example, due to phase error in the data acquisition system.
% Assuming that the mode vectors have good modal phase colinearity, one can
% fit a line through the shapes and rotate them such that they are as real
% as possible.
%
% [rot_shape] = res2real(cres)
%     Finds the best rotated shape for the mode vectors in cres,
%     considering each individually.
% [rot_shape] = res2real(cres,'plot on') 
%
% real(rot_shape) is the best real approximation to the mode shape, found
% using least squares.
%
% Find best real approximation to complex residues.  Residue matrix input
% in AMI's standard form:
%   cres(1i,j,k) - i corresp to mode number, j is output number, k is input
%   number
%
% Matt Allen, June, 2007
%
% update: if cres is a real matrix, the function returns the matrix with no
%           change
%  Shifei Yang, 2010.07.15

if size(cres,2) == 1 && size(cres,1) > 1;
    warning('Residue Vector has Length One - It should be input as a row vector.');
end

if imag(cres) == 0
    rot_res = cres;
    warning('Residue Vector is real');
else
    rot_res = zeros(size(cres));
    for dp_num = 1:size(cres,3);
        for k = 1:size(cres,1);
            shape1 = cres(k,:,dp_num).';
            mean_angle1 = atan((real(shape1).'*imag(shape1)) / ...
                (real(shape1).'*real(shape1)));
                rot_shape1 = shape1.'*exp(-1i*mean_angle1);
                % Note - atan is singular at 90 degrees - so this algorithm performs
                % poorly if "shape" is purely imaginary.  This tries again with the
                % shape rotated 90 degrees.
            shape2 = 1i*cres(k,:,dp_num).';
            mean_angle2 = atan((real(shape2).'*imag(shape2)) / ...
                (real(shape2).'*real(shape2)));
                rot_shape2 = shape2.'*exp(-1i*mean_angle2);
            % Keep the shape that best minimizes the norm of the imaginary part
            if norm(imag(rot_shape1)) <= norm(imag(rot_shape2))
                rot_res(k,:,dp_num) = rot_shape1; kept_flg = 1;
    %             mean_angle = mean_angle1;
            else
                rot_res(k,:,dp_num) = rot_shape2; kept_flg = 2;
    % %             mean_angle = mean_angle2;
            end

            if nargin > 1
            figure;
            set(gcf,'Units', 'normalized', 'Position', [0.324,0.229,0.35,0.685]);
            subplot(2,1,1)
                line(real(shape1),imag(shape1),'Marker','.','LineStyle','none');
                ln_xs = real(real(shape1*exp(-1i*mean_angle1))*exp(1i*mean_angle1));
                ln_ys = imag(real(shape1*exp(-1i*mean_angle1))*exp(1i*mean_angle1));
                line(ln_xs,ln_ys,'LineStyle',':','Color','k','LineWidth',2);
                line(real(rot_shape1),imag(rot_shape1),'Marker','o','LineStyle','none','Color','r');
                legend('Original','Linear Fit','Rotated');
                if kept_flg == 1; title('\bfKept This Result');
                    line(real(rot_res(k,:,dp_num)),imag(rot_res(k,:,dp_num)),'Marker','d','LineStyle','none','Color','k');
                end
                axis equal 
            subplot(2,1,2)
                line(real(shape2),imag(shape2),'Marker','.','LineStyle','none');
                ln_xs = real(real(shape2*exp(-1i*mean_angle2))*exp(1i*mean_angle2));
                ln_ys = imag(real(shape2*exp(-1i*mean_angle2))*exp(1i*mean_angle2));
                line(ln_xs,ln_ys,'LineStyle',':','Color','k','LineWidth',2);
                line(real(rot_shape2),imag(rot_shape2),'Marker','o','LineStyle','none','Color','r');
                legend('Original*i','Linear Fit','Rotated');
                if kept_flg == 2; title('\bfKept This Result');
                    line(real(rot_res(k,:,dp_num)),imag(rot_res(k,:,dp_num)),'Marker','d','LineStyle','none','Color','k');
                end
                axis equal 
            end
        end
    end
end