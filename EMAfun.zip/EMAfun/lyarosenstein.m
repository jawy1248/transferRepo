function [d,nearpos] = lyarosenstein(x,m,tao,meanperiod,maxiter,varargin) 
% d = lyarosenstein(x,m,tao,meanperiod,maxiter) 
%
% d: divergence of nearest trajectoires
% x: signal
% tao: time delay (in samples)
% m: embedding dimension
% meanperiod: average period (in samples).  This is used to locate nearest
%   neighbors.  Neighbors outside of this range are not considered.
%   %% NOTE!!  Here one should probably use half of the period.  Using the
%   full period we run the risk that we will skip pairing two nearest
%   neighbors if they are about one period apart.
% maxiter: Number of points around each nearest neighbor to consider when
%   computing the divergence.  The average divergence is found between each
%   point and its nearest neighbor, out to point+k to NN+k.
%
% (Merve Kizilkaya): 
% If you have time series data, you can use this code. Before computing The
% Largest Lyapunov Exponent, you must find the minimum embedding
% dimension(m), time delay(tao) and mean period parameters. You can choose
% and change arbitrary the number of iteration. You can calculate the
% minimum embedding dimension with false nearest neighboors algorithm,
% whose code exist in my file exchange page. You can calculate the time
% delay with mutual information algorithm and for mean period, you can
% search in the internet.
%
% To find the LLE, then use:
% %% LLE Calculation
% fs=2000;%sampling frequency
% tlinear=15:78; % range of linear portion
% F = polyfit(tlinear,d(tlinear),1);
% lle = F(1)*fs
%
% author:"Merve Kizilkaya" - From Matlab Central File Exchange.
% Comments and clean up by M.S. Allen
%

N=length(x); % total number of time samples
M=N-(m-1)*tao; % number of time samples in embedded phase space
Y=psr_deneme(x,m,tao);

silentflag=false;
if nargin>5;
    if strcmpi(varargin{1},'silent') || strcmpi(varargin{1},'sil')
        silentflag=true;
    end
end

if ~silentflag;
    h = waitbar(0,'Computing Distances...');
end
neardis=zeros(1,M);
nearpos=zeros(1,M);
for i=1:M
    x0=ones(M,1)*Y(i,:);
    distance=sqrt(sum((Y-x0).^2,2));
    for j=1:M
        if abs(j-i)<=meanperiod
            distance(j)=1e10;
        end
    end
    [neardis(i),nearpos(i)]=min(distance); 
    if ~silentflag;
        waitbar(i/M,h)
    end
end
if ~silentflag; close(h); end

if ~silentflag;
    h = waitbar(0,'Computing Average Deviation...');
end
d=zeros(1,maxiter);
for k=1:maxiter
%     k
    maxind=M-k;
    evolve=0;
    pnt=0;
    for j=1:M
        % Loop over the whole data set to find the average divergence for
        % all pairs of nearest neighbors after they've evolved k samples.
        if j<=maxind && nearpos(j)<=maxind % Avoid going past end of data
            dist_k=sqrt(sum((Y(j+k,:)-Y(nearpos(j)+k,:)).^2,2));
                % This is the distance between the jth point and its
                % nearest neighbor (at sample zero) after they have evolved
                % through k samples.
             if dist_k~=0
                evolve=evolve+log(dist_k);
                pnt=pnt+1;
             end
        end
    end
    if pnt > 0
        d(k)=evolve/pnt;
    else
        d(k)=0;
    end
    if ~silentflag;
        waitbar(k/maxiter,h)
    end
end
if ~silentflag; close(h); end

% figure
% plot(d)


% %% LLE Calculation
% % fs=2000;%sampling frequency
% tlinear=15:78;
% F = polyfit(tlinear,d(tlinear),1);
% lle = F(1)*fs


function Y=psr_deneme(x,m,tao,npoint)
%Phase space reconstruction
%x : time series 
%m : embedding dimension
%tao : time delay
%npoint : total number of reconstructed vectors
%Y : M x m matrix
% author:"Merve Kizilkaya"
N=length(x);
n=size(x,2); % if multiple states, assume they are in columns.
if nargin == 4
    M=npoint;
else
    M=N-(m-1)*tao;
end

Y=zeros(M,m*n); 

for i=1:m
    Y(:,[1:n]+(i-1)*n)=x((1:M)+(i-1)*tao,:);
end
