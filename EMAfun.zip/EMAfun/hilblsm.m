function [wn_fit,zt_fit,indfit,yfit,varargout]=hilblsm(yltv,ts,Npts,varargin)
% Smoothed Hilbert Transform Analysis of free vibration response.  A
% piecewise linear function is fit to the Hilbert transform in order to
% mimimze noise when computing its derivative (in order to compute the
% instantaneous frequency and damping.  Highly efficient piecewise linear
% fitting algorithm used as in Allen, M., H. Sumali, et al. (2008). 
% "Piecewise-linear restoring force surfaces for semi-nonparametric 
% identification of nonlinear systems." Nonlinear Dynamics 54: 123-135.
%
% [wn_fit,zt_fit,indfit,yfit,all_data]=hilblsm(yltv,ts,Npts)
%
% [wn_fit,zt_fit,indfit,yfit,all_data]=hilbpsm(yltv,ts,Npts,'verbose')
%
% yltv - time response to process (only one response point allowed)
% ts - corresponding time vector
% Npts - number of time samples to use in the piecewise-linear approximation.
%
% M.S. Allen, June 2013, msallen@engr.wisc.edu
%
if length(yltv)~=numel(yltv);
    error('yltv must be a vector (only one output point allowed');
end
yltv=yltv(:);
ts=ts(:);
if length(yltv)~=length(ts);
    error('Time vector is not the same length as response vector');
end

if nargin>4
    if strcmpi(varargin{1},'verbose')
        vbflg=true(1);
    end
else
    vbflg=false(1);
end

[Hnlh]=hilbert(yltv);
Hhph=unwrap(angle(Hnlh));
Hhamp=abs(Hnlh);

figure(61); clf(61)
set(gcf,'Units','Normalized');
set(gcf,'Position',[0.33, 0.17, 0.35, 0.75]);
ha101a=subplot(3,1,1);
semilogy(ts,abs(yltv),':','Color',0.8*[1,1,1]);
hold on; semilogy(ts,Hhamp,'b','LineWidth',2); hold off; grid on; ylim(minmax(Hhamp));
ylabel('\bfMagnitude');
ha101b=subplot(3,1,2);
plot(ts,Hhph); grid on;
ylabel('\bfAngle (rad)'); xlabel('\bftime (s)');

disp('Select the band to curve fit');
[xg,yg]=ginput(2);
indfit=find(ts>xg(1) & ts<xg(2));

% Fit phase to obtain frequency versus time
    [psiit_fit, t_pwl, psii_pwl, ~, psii_std] = pwlinfit(ts(indfit),Hhph(indfit),Npts);
%     Amat=ones(length(indfit),P+1); % use ones since we will fill the last column with ones anyway
%     Amatd=zeros(length(indfit),P+1); % for derivative
%     for k=1:P
%         Amat(:,k+1)=tsnd(indfit).^k;
%         Amatd(:,k+1)=(1/tmax)*k*tsnd(indfit).^(k-1);
%             % The (1/tmax) factor makes this a derivative with respect to ts (not tsnd)
%     end
%     bs=Amat\Hhph(indfit);
%     bs_m1=Amat(:,1:end-1)\Hhph(indfit);
%     psiit_fit=Amat*bs;
    axes(ha101b); line(ts(indfit),psiit_fit,'Color','r','LineWidth',2);
    axes(ha101b); line(t_pwl,psii_pwl+2*psii_std,'Color','c','LineWidth',2,'LineStyle','--');
    axes(ha101b); line(t_pwl,psii_pwl-2*psii_std,'Color','c','LineWidth',2,'LineStyle','--');
        legend('Measurement','PWL Fit','+95% CI','-95% CI');

    % Find derivative:
    dt_pwl=diff(t_pwl)+t_pwl(1:end-1);
%     dpsii_pwl=diff(psii_pwl)./diff(t_pwl);
    
    wd_pwl=diff(psii_pwl)./diff(t_pwl); % this is dpsii/dt so don't store both
    wd_fit=interp1(dt_pwl,wd_pwl,ts(indfit),'nearest','extrap');
    
% Fit amplitude to find damping versus time
    [psirt_fit, ~, psir_pwl, ~, psir_std] = pwlinfit(ts(indfit),log(Hhamp(indfit)),Npts);
%     cs=(Amat(:,1:(Pc+1)))\ln(Hhamp(indfit));
%     cs_m1=(Amat(:,1:(Pc)))\ln(Hhamp(indfit));
%     psirt_fit=Amat(:,1:(Pc+1))*cs; % zero term is actually c0+ln(A0)
%         % This is the natural log of the amplitude function
    axes(ha101a); line(ts(indfit),exp(psirt_fit),'Color','r','LineWidth',2);
    alphat_pwl=diff(psir_pwl)./diff(t_pwl); % = dpsir/dt  Amatd(:,1:(Pc+1))*cs;
        alphat_fit=interp1(dt_pwl,alphat_pwl,ts(indfit),'nearest','extrap');
        wn_fit=(wd_fit.^2+(-alphat_fit).^2).^(1/2);
        zt_fit=-alphat_fit./wn_fit;

% Reconstruct time response
psi_fit=psirt_fit+1i*psiit_fit;
yfit=exp(psi_fit);

    ha101c=subplot(3,1,3);
%     line(ts(indfit),psiit_fit-Hhph(indfit),'Color','r','LineWidth',2); grid on;
%     line(t_pwl,psii_std*[-2,2],'Color','c','LineWidth',2,'LineStyle','--');
%             legend('PWL Fit Error','2\sigma Limits');
%     ylabel('\bfAngle (rad)'); xlabel('\bftime (s)');
    line(ts,yltv,'Color','b'); grid on;
    line(ts(indfit),real(yfit),'Color',[0,0.5,0],'Marker','.','LineStyle','--');
    line(ts(indfit),yltv(indfit)-real(yfit),'Color','r');
        legend('Measurement','Fit','Error');
        ylim(1.2*[min(real(yfit)),max(real(yfit))]);
    ylabel('\bfResponse'); xlabel('\bftime (s)');

    % Noise analysis
    % Simple derivation shows that the std of the derivative is the RSS of
    % the std of each component
    wd_std=(psii_std(1:end-1).^2+psii_std(2:end).^2).^(0.5)./diff(t_pwl);
    alphat_std=(psir_std(1:end-1).^2+psir_std(2:end).^2).^(0.5)./diff(t_pwl);
        % Create a noisy time history within the 95% CI
            % Would it be more reasonable to assume a single standard
            % deviation applies to all coordinates?  (add code for that?)
        wd_fit_m1=wd_fit+sqrt(sum(wd_std.^2))*randn(size(wd_fit));
        alphat_fit_m1=alphat_fit+sqrt(sum(alphat_std.^2))*randn(size(wd_fit));
        wn_fit_m1=(wd_fit_m1.^2+(-alphat_fit_m1).^2).^(1/2);
        zt_fit_m1=-alphat_fit_m1./wn_fit_m1;
        
%     % with 6th order polynomials or (P)
% 	wd_fit_m1=Amatd(:,1:end-1)*bs_m1;
% %     psirt_fit_m1=Amat(:,1:(Pc))*cs_m1; % zero term is actually c0+ln(A0)
%         % Uncomment above to plot
%     alphat_fit_m1=Amatd(:,1:(Pc))*cs_m1;
%     wn_fit_m1=(wd_fit_m1.^2+(-alphat_fit_m1).^2).^(1/2);
%     zt_fit_m1=-alphat_fit_m1./wn_fit_m1;
   
figure(62)
ha102a=subplot(1,2,1);
% Feldman's approach(es) for natural frequency variation
if vbflg
    dt=ts(2)-ts(1);
    plot(ts(indfit),wn_fit/2/pi,ts(indfit),wn_fit_m1/2/pi,'--'); alims=axis;
    % Feldman 2011, MSSP, eq. (11)
    wd_Feld=angle(Hnlh(1:end-1).*conj(Hnlh(2:end)))/dt/2/pi;
    % Alternate, eq. (26) in Feldman 2011 - nevermind, not formula there.
    plot(ts(1:end-1),-wd_Feld,'Color',0.9*[1,1,1]); % not sure why minus is always needed
    hold on; plot(ts(indfit),wd_fit/2/pi,dt_pwl,(wd_pwl*[1,1]+wd_std*[-2,2])/2/pi,'c--'); grid on; hold off
    axis(alims);
    legend('Direct Hilbert','PWL Fit','2\sigma Limits');
else
    plot(ts(indfit),wd_fit/2/pi,dt_pwl,(wd_pwl*[1,1]+wd_std*[-2,2])/2/pi,'c--'); grid on;
    legend('PWL Fit','2\sigma Limits');
end
ylabel('\bff_d (Hz)'); xlabel('\bfTime (s)'); title('\bfDamped Nat. Freq. vs Time')

set(get(gca,'Children'),'LineWidth',2);
ha102b=subplot(1,2,2);
plot(ts(indfit),zt_fit_m1,'c--',ts(indfit),zt_fit); grid on;
ylabel('\bf\zeta'); xlabel('\bfTime (s)'); title('\bfDamping vs Time')
set(get(gca,'Children'),'LineWidth',2);
legend('Fit + Noise','PWL Fit');

if nargout > 4;
    all_data = [];
    S = whos;
    for k = 1:length(S)
        if ~strcmpi(S(k).name,'all_data')
            eval(['all_data.',S(k).name,' = ',S(k).name,';']);
        end
    end
    varargout{1}=all_data;
end