function [Dm,Kj] = iwan_DKvsQ(q0,Kinf,params,varargin)
% Function which estimates Dissipation (D) and Stiffness (K) versus modal
% displacement amplitude for a modal iwan model.
%
% [Dm,Kj] = iwan_DKvsQ(q0,Kinf,params)
% [Dm,Kj] = iwan_DKvsQ(q0,Kinf,params,C,pflag)
%
% q0 - is a vector of modal displacement amplitudes
% Kinf - Stiffness of the spring in parallel with the Iwan element.  If the
%       natural frequency when the joint is completely stuck is w_0 and
%       that when the joint slips completely is w_inf then
%       delta_w = w_0 - w_inf
%       and
%       Kinf=(w_0+delta_w)^2
% 
% params - parameters of the modal iwan joint
%   params = [Fs, Kt, chi, beta]
%
% Optional inputs:
% C - modal damping constant when the Iwan joint is fixed C=2*zt*wn
% pflag - 'phys' (default) of 'math' - specify parameters using the
%   physically meaningful [Fs, Kt,...] or using the mathematical parameters
%   params=[chi,phi_max,R,S].
%

% Updated by MSA Aug 2014 to not require the frequency as a function of
% amplitude to be input by the user.  It is determined from Kj.

if nargin > 3;
    C=varargin{1};
else
    C=0;
end
if nargin>4;
    pflag=varargin{2};
    if ~(strcmpi(pflag,'phys')||strcmpi(pflag,'math'))
        error('Unrecognized parameter flag');
    end
else
    pflag='phys';
end

if strcmpi(pflag,'phys')
    Fs = params(1); Kt = params(2); chi = params(3); beta = params(4);
    [~, phi_max,R, S]=iwanconvert(Fs,Kt,chi,beta);
else
    chi = params(1); phi_max = params(2); R = params(3); S = params(4);
    beta=S/((R*phi_max^(chi+1))/(chi+1));
    Fs=phi_max*(R*phi_max^(chi+1)/(chi+1))*((chi+1)/(chi+2)+beta);
    Kt=Fs*(1+beta)/(phi_max*(beta+(chi+1)/(chi+2)));
end
% phi_max = Fs*(1+beta)/(Kt*(beta+(chi+1)/(chi+2)));
% R = Fs*(chi+1)/(phi_max^(chi+2)*(beta+(chi+1)/(chi+2)));
r = abs(q0)*Kt*(beta+(chi+1)/(chi+2))/(Fs*(1+beta));
% minmax(r)

Dm = zeros(size(q0));
Kj = zeros(size(q0));
for k = 1:length(q0)
    if abs(q0(k))< phi_max; %F(k) < Fs
        Kj(k) = Kt*(1-r(k).^(chi+1)/((chi+2)*(beta+1)));
            wd_use=sqrt(Kj(k)+Kinf);
        Dm(k) = 4*R*abs(q0(k)).^(chi+3)/((chi+3)*(chi+2)) + pi*wd_use*C*abs(q0(k)).^2;
    else
        Kj(k) = 0; % In Macro-slip
            wd_use=sqrt(Kinf);
        Dm(k) = abs(4*q0(k)*Fs) + pi*wd_use*C*abs(q0(k)).^2;
    end
end

return