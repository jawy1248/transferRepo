function [x,xd,xdd,ad] = iwan_modaltrans(miparam,ft,dt)
% Function which used Newmark integration to compute the transient response
% of an SDOF modal Iwan model defined by the parameters 'params' subject to
% the modal force 'ft' sampled at 'dt',
%
% [x,xd,xdd,ad] = iwan_modaltrans(miparam,ft,dt);
%
% where 'x' is the displacement response, 'xd' is the velocity and 'xdd' is
% the acceleration.
%
% miparam - parameters of the modal iwan joint
%   miparam = [Fs, Kt, chi, beta, Kinf, C]
%   
%   For definitions of Fs, Kt, chi and beta see: D. J. Segalman, "A
%   Four-Parameter Iwan Model for Lap-Type Joints," Journal of Applied
%   Mechanics, vol. 72, pp. 752-760, Sept. 2005. 
%
%   Kinf - Stiffness of the spring in parallel with the Iwan element.  If the
%       natural frequency when the joint is completely stuck is w_0 and
%       that when the joint slips completely is w_inf then
%       delta_w = w_0 - w_inf
%           and then
%       Kinf=(w_0-delta_w)^2
%       Kt=w_0^2-K_inf
%
%   C - modal damping constant when the Iwan joint is fixed C=2*zt*wn
%
% Optional Parameters:
%   To control the number of jenkins elements used to model the Iwan joint,
%       add a parameter to the params vector:
%   miparam = [Fs, Kt, chi, beta, Kinf, C,NJ]
%
%   NJ - Number of Jenkins elements used to model the Iwan joint.  Default
%       NJ=100;
%
% M.S. Allen, August 2014
% Based on Todd Simmermacher's script: 'r3mass1h.m'
%


% pflag - 'phys' (default) of 'math' - specify parameters using the
% physically meaningful [Fs, Kt,...] or using the mathematical parameters
% params=[chi,phi_max,R,S].
%
% if nargin>4;
%     pflag=varargin{2};
%     if ~(strcmpi(pflag,'phys')||strcmpi(pflag,'math'))
%         error('Unrecognized parameter flag');
%     end
% else
%     pflag='phys';
% end
% 
% if strcmpi(pflag,'phys')
%     Fs = params(1); Kt = params(2); chi = params(3); beta = params(4);
%     [~, phi_max,R, S]=iwanconvert(Fs,Kt,chi,beta);
% else
%     chi = params(1); phi_max = params(2); R = params(3); S = params(4);
%     beta=S/((R*phi_max^(chi+1))/(chi+1));
%     Fs=phi_max*(R*phi_max^(chi+1)/(chi+1))*((chi+1)/(chi+2)+beta);
%     Kt=Fs*(1+beta)/(phi_max*(beta+(chi+1)/(chi+2)));
% end

if length(miparam)<6;
    error({'Not enough parameters supplied for the Iwan Joint','miparam = [Fs, Kt, chi, beta, Kinf, C,NJ]'});
elseif length(miparam)>6
    NJ=miparam(7);
else
    NJ=100; % Number of Jenkins elements used to define the Iwan element.
end


% Set up system parameters
    m = 1; % Always use mass-normalized modes

    % Iwan Element
    % Joint parameters
    F_S = miparam(1); K_T = miparam(2); chi = miparam(3); beta = miparam(4);

    % convert from preferred parameter set to the old parameter set
    [~, phi_max,R, S]=iwanconvert(F_S,K_T,chi,beta);

    params = [chi, phi_max, R, S];
    
    % Linear Spring
    K_lin = miparam(5); % stiffness of linear spring in parallel
    % Linear Viscous Damping:
    Ceq = miparam(6);
    Nt_nl=length(ft);
    tsnl = [0:dt:(Nt_nl-1)*dt].';
       
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Nonlinear Simulation using Newmark Integration
% From Todd Simmermacher's script: 'r3mass1h.m'

    % integration parameters
    beta_N = 1/4;
    gamma_N = 1/2;

    %Initialize Variables - this was initially set for an MDOF simulation...
    Masses = 1;
    x  = zeros(Masses, Nt_nl);
    xd = zeros(Masses, Nt_nl);
    xdd = zeros(Masses, Nt_nl);
%     a_last = zeros(1, Nt_nl);
    KE       =zeros(1, Nt_nl);
    f_joint = zeros(1, Nt_nl);
%     diss      = zeros(1, Nt_nl);
    newton_iter=zeros(1,Nt_nl);
    
    u_prev =zeros(Masses,1); v_prev = zeros(Masses,1); a_prev = zeros(Masses,1);

    % Slider states for Iwan element
    jy_prev  = zeros(NJ,1);
    try % If user requests many jenkins elements, don't bother saving their time histories.
        jys = zeros(NJ,Nt_nl);
        jykpflg=true;
    catch
        jykpflg=false;
    end
    %integrate through every timestep
    disp('Beginning Non-Linear Modal Iwan Simulation')
    report_inds=floor([1:30]*Nt_nl/30);
    for it = 2:Nt_nl
        % first guess for acceleration is the previous accleration
        a_est = a_prev;
        v_est = v_prev + dt*( (1-gamma_N)*a_prev + gamma_N*a_est);
        u_est = u_prev + dt*v_prev ...
          + (dt^2/2)*( (1-2*beta_N)*a_prev   +2*beta_N*a_est);

        [ftemp, jy_temp, stiff_temp] = iwan(u_est, jy_prev, params);

        resid = m*a_est + Ceq*v_est + K_lin*u_est + ftemp - ft(it);

        grad = m + gamma_N*Ceq*dt + (K_lin+stiff_temp)*(dt^2)*beta_N;
        
        % newton itteration loop
        iter = 0;
        while resid'*resid > 1e-10
            a_est = a_est - grad\resid;
            v_est = v_prev + dt*( (1-gamma_N)*a_prev + gamma_N*a_est);
            u_est = u_prev + dt*v_prev ...
                + (dt^2/2)*( (1-2*beta_N)*a_prev   +2*beta_N*a_est);

            [ftemp, jy_temp, stiff_temp] = iwan(u_est, jy_prev, params);

            resid = m*a_est + Ceq*v_est + K_lin*u_est +ftemp - ft(it);

            grad = m + gamma_N*Ceq*dt +(K_lin+stiff_temp)*(dt^2)*beta_N;
            iter = iter + 1;
        end
        
        newton_iter(it) = iter;
        u_prev = u_est;
        v_prev = v_est;
        a_prev = a_est;

        f_joint(it) = ftemp;
        
        x(:,it) = u_est;
        xd(:,it) = v_est;
        xdd(:,it) = a_est;

        jy_prev = jy_temp;
        if jykpflg
            jys(:,it) = jy_temp;
        end
        KE(it) = v_est.'*m*v_est; % Matt's formula, check?
        if any(it==report_inds); fprintf('.'); end
    end
    fprintf('\n');
    x = x.'; xd = xd.'; xdd = xdd.';

if nargout > 3;
    ad = [];
    S = whos;
    for k = 1:length(S)
        if ~strcmpi(S(k).name,'ad')
            eval(['ad.',S(k).name,' = ',S(k).name,';']);
        end
    end
end