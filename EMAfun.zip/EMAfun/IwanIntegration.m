function [x,xd,xdd,f_joint,varargout] = IwanIntegration(paramp,M,C,K,fext,ts,varargin)
% Use beta-gamma Newmark method to integrate the motion response
% corresponding to time points given in the ts vector of a single or
% multi-DOF system with linear stiffness, viscuous damping, and various
% Iwan elements with Iwan parameters specified by paramp.
%
% [x,v,a,f_joint,ad] = IwanIntegration(paramp,M,C,K,fext,ts,iwan_pairs)
%
% INPUTS:
% paramp = [Fs,Kt,chi,beta] % defines Iwan joint in physical parameters
% M = mass matrix (NxN)
% C = viscuous damping coefficient matrix (NxN)
% K = linear stiffness matrix (NxN)
% fext = external force time history on each node (Nnodes x Ntime)
% ts = time vector with equally spaced time samples
% iwan_pairs = [node1,node2] where node1 and node2 specify the indices of
%   the two nodes that are connected by the Iwan joint.
%
% OUTPUTS:
% x = displacement of masses
% v = velocity
% a = acceleration
% f_joint = cell array of the joint force applied by individual Iwan
%   elements. There are as many cell outputs as the number of Iwan elements.
%
% Multiple Iwan joints may also be supplied by providing paramp and
% iwan_pairs as follows:
% paramp = [Fs1,Kt1,chi1,beta1]
%          [Fs2,Kt2,chi2,beta2]
%          [        ...       ]
%          [Fs_Njoints,Kt_Njoints,chi_Njoints,beta_Njoints]
% iwan_pairs = an array telling which DOF indices are connected by the nth
%   Iwan element. The number of rows reflects the number of pairs, and
%   the number of columns is always 2. For example, a 5-DOF system with an
%   Iwan element joining DOFs 2 with 4 and another between DOF 3 and ground 
%   would be specified as iwan_pairs=[2,4; 0,3]. The row index of this 
%   array is assosciated with the same row index of Iwan parameters in the
%   paramp input argument. 
%
% [x,v,a,f_joint,ad] = IwanIntegration(paramp,M,C,K,fext,ts,iwan_pairs,ICs)
%   ICs={x0,v0,j0} where x0 and v0 are N x 1 vectors of initial
%   displacement and velocity and j0 is an Nj (Number Jenkins Elements) x 1
%   vector of initial displacements of the Jenkins elements.
%
% Created by R.M. Lacayo; July 2013; lacayo@wisc.edu
% Updated by M.S. Allen, July 2015 - speed ups and added multiple joints.
%


% Check function arguments
% Check for size consistency
[Ndof,NtF] = size(fext);
Nt = length(ts);
if Nt~=NtF
    error('Force vector and time vector must be the same length.');
end
if nargin > 6
    iwanPair = varargin{1};
else
    iwanPair = [0,1];
end
% Check iwanPair matrix and place any zero indices first.
for k=1:size(iwanPair,1);
    if iwanPair(k,2)==0;
        iwanPair(k,:)=fliplr(iwanPair(k,:));
        if iwanPair(k,2)==0; error('Both indices for the Iwan joint cannot be zero'); end
    end
    % Now the first index is zero if the Iwan joint goes to ground.
end
if nargin > 7
    % Want ICs={x0,x0d,jys}
    ICs=varargin{2};
    if ~isempty(ICs)
        if length(ICs{1})~=length(ICs{2}) || length(ICs{1})~=Ndof
            error('ICs aren''t of comptabile size');
        end
    end
else
    ICs=[];
end
if nargin > 8 % passing in mapping matrices for a substructure problem.
    SSMaps=varargin{3};
        % Must Contain: SSMaps.Fjmap, SSMaps.Ujmap, SSMaps.GradMat
else
    SSMaps=[]; % Used as a flag to tell when a substructuring problem is done
end

%
NIwan=size(paramp,1);
    % Check that iwanPairs is of the same size
    if size(iwanPair,1)~=NIwan; error('Size of "paramp" and "iwan_pairs" doesn''t match'); end

for k=1:NIwan % Find mathematical description of Iwan parameters
    paramm(k,:)=iwanconvert(paramp(k,:));
end
% % Retrieve parameters
% Fs = paramp(1); Kt = paramp(2); chi = paramp(3); beta = paramp(4);
% 
% phi_max = Fs*(1+beta)/(Kt*(beta + (chi+1)/(chi+2)));
% R = Fs*(chi+1)/((beta+ (chi+1)/(chi+2))*phi_max^(chi+2) );
% S = (Fs/phi_max)*(beta/(beta + (chi+1)/(chi+2)));
% 
% paramm = [chi, phi_max, R, S];

% Prepare mapping matrices for Iwan forces
if isempty(SSMaps);
    indVec = zeros(Ndof,NIwan);
    indMat = zeros(Ndof,Ndof,NIwan);
    for k=1:NIwan
        ind1 = iwanPair(k,1); ind2 = iwanPair(k,2);
        if ind1==0 % mass index 2 is joined to ground
            indVec(ind2,k) = 1;
            indMat(ind2,ind2,k) = 1;
        else % mass indices are joined with iwan element
            indVec(ind1,k) = -1; indVec(ind2,k) = 1;
            indMat([ind1,ind2],[ind1,ind2],k) = [1,-1;-1,1];
        end
        Ujmap(:,:,k)=eye(Ndof);
    end
else
    indVec=SSMaps.Fjmap;
    indMat=SSMaps.GradMat;
    Ujmap=SSMaps.Ujmap;
end

%% Begin integration
% integration parameters
beta_N = 1/4;
gamma_N = 1/2;

%Initialize Variables
dt = ts(2)-ts(1); % assumes equally spaced time samples
x  = zeros(Ndof, Nt);
xd = zeros(Ndof, Nt);
    if ~isempty(ICs) % Pass in initial conditions
        x(:,1)=ICs{1};
        xd(:,1)=ICs{2};
    end
xdd = zeros(Ndof, Nt);
newton_iter=zeros(1,Nt);

u_prev = zeros(Ndof,1); 
v_prev = zeros(Ndof,1); 
a_prev = zeros(Ndof,1);
    if ~isempty(ICs) % Pass in initial conditions
        u_prev=x(:,1);
        v_prev=xd(:,1);
    end

% Variables to store joint force
f_joint = zeros(NIwan,Nt);
K_joint = zeros(NIwan,Nt);
KE = zeros(1,Nt);

% Use NJ Jenkins elements
% lets use NJ Jenkins elements
NJ = 100;
jy_prev  = zeros(NJ,NIwan);
jys = zeros(NJ,Nt,NIwan);
if ~isempty(ICs)
    if length(ICs)>2
        NJ=length(ICs{3});
        jy_prev=ICs{3}; % Check, is this the best way to pass in?
        jys=zeros(NJ,Nt,NIwan);
        jys(:,1,:)=jy_prev;
    end
end
% Initialize for below.
ftemp=zeros(NIwan,1); stiff_temp=ftemp; jy_temp=zeros(size(jy_prev));

%integrate through every timestep
for it = 2:length(ts)
    % First guess for next acceleration is the previous accleration
    a_est = a_prev;
    v_est = v_prev + dt*( (1-gamma_N)*a_prev + gamma_N*a_est);
    u_est = u_prev + dt*v_prev + (dt^2/2)*((1-2*beta_N)*a_prev + 2*beta_N*a_est);
    
    fjVec=zeros(Ndof,1);
    stiffMat=zeros(Ndof,Ndof);
    for k=1:NIwan
        ind1 = iwanPair(k,1); ind2 = iwanPair(k,2);
        % Calculate non-linear force at location defined by iwanPair
        uj=Ujmap(:,:,k)*u_est;
        if ind1==0 % mass index 2 is joined to ground
            [ftemp(k,1), jy_temp(:,k), stiff_temp(k,1)] = iwan(uj(ind2), jy_prev(:,k), paramm(k,:));
        else % mass indices are joined with iwan element
            [ftemp(k,1), jy_temp(:,k), stiff_temp(k,1)] = iwan(uj(ind2)-uj(ind1), jy_prev(:,k), paramm(k,:));
        end
        % Add up forces from all Iwan joints.
        fjVec = fjVec + ftemp(k,1)*indVec(:,k);
        stiffMat = stiffMat + stiff_temp(k,1)*indMat(:,:,k);
    end
    resid = M*a_est + C*v_est + K*u_est + fjVec - fext(:,it);
    grad = M + gamma_N*C*dt + beta_N*(K+stiffMat)*dt^2;
    
    % Newton Iteration Loop
    iter = 0;
    while ((resid'*resid/norm(K*u_est+C*v_est).^2) > 1e-6) && (resid'*resid > 1.0e-10) % This should be improved to be a fraction of u and v and z
            % Including both displacement and velocity above so that the
            % denominator doesn't go to zero, but it still starts at time
            % zero, so the second term is needed.  This needs work...
        a_est = a_est - grad\resid;
        v_est = v_prev + dt*( (1-gamma_N)*a_prev + gamma_N*a_est);
        u_est = u_prev + dt*v_prev ...
            + (dt^2/2)*((1-2*beta_N)*a_prev + 2*beta_N*a_est);
        
        fjVec=zeros(Ndof,1);
        stiffMat=zeros(Ndof,Ndof);
        for k=1:NIwan
            ind1 = iwanPair(k,1); ind2 = iwanPair(k,2);
            % Calculate non-linear force at location defined by iwanPair
            uj=Ujmap(:,:,k)*u_est;
            if ind1==0 % mass index 2 is joined to ground
                [ftemp(k,1), jy_temp(:,k), stiff_temp(k,1)] = iwan(uj(ind2), jy_prev(:,k), paramm(k,:));
            else % mass indices are joined with iwan element
                [ftemp(k,1), jy_temp(:,k), stiff_temp(k,1)] = iwan(uj(ind2)-uj(ind1), jy_prev(:,k), paramm(k,:));
            end
            % Add up forces from all Iwan joints.
            fjVec = fjVec + ftemp(k,1)*indVec(:,k);
            stiffMat = stiffMat + stiff_temp(k,1)*indMat(:,:,k);
        end
        
        resid = M*a_est + C*v_est + K*u_est + fjVec - fext(:,it);
        grad = M + gamma_N*C*dt + beta_N*(K+stiffMat)*dt^2;
        iter = iter + 1;  
        if iter>100; error('Newton iteration loop failed to converge after 100 iterations'); end
    end
    
    f_joint(:,it) = ftemp;
    K_joint(:,it) = stiff_temp;
    
    jy_prev = jy_temp;
    jys(:,it,:) = jy_temp;
    
    newton_iter(it) = iter;
    u_prev = u_est;
    v_prev = v_est;
    a_prev = a_est;
    
    x(:,it) = u_est;
    xd(:,it) = v_est;
    xdd(:,it) = a_est;
    
    KE(it) = (1/2)*v_est.'*M*v_est;
    
    if round(it/10000) == (it/10000); fprintf('.'); end
end

% Optional output arguments.
if nargout>4;
    ad.KE=KE;
    ad.newton_iter=newton_iter;
    ad.K_joint=K_joint;
    ad.jys=jys;
    ad.paramm=paramm;
    ad.newton_iter=newton_iter;
    ad.indMat=indMat;
    varargout{1}=ad;
end