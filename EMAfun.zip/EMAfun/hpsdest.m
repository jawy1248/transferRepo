function [Syy,ws,pys,Navg,varargout] = hpsdest(y,refs,t,wA,py,Npblk,win_name,NoPCTovlp,varargin)
% Harmonic Power Spectra Estimation for Output Only LTP EMA
%
% [Syy,ws,pys,Navg] = hpsdest(y,refs,t,wA,py,Npblk,win_name,NoPCTovlp);
%
% y is a matrix with the first dimension being time (size(y)=[Nt x No]) 
% t should be a vector
%   win_name = e.g. = 'hanning'
%   NoPCTovlp = e.g. = 0.875
%   refs = which ref. to use when computing CSD - e.g. use py = 4 and refs =
%       [-1,0] to compute all of the HTFS G([-4,-3,-2,...4],[-1,0]);
%       ** Alternately, one can give a matrix for refs to request specific
%       terms, for example:
%       refs = [1,0; 2,0]; will use only the fundamental harmonics for
%       sensors 1 and 2 as references. Then one can request indices into
%       which coordinate and harmonic each term corresponds to:
%       
%   [Syy,ws,pys,Navg,cind,pysa] = hpsdest(y,refs,t,wA,py,Npblk,win_name,NoPCTovlp);
%
% To reshape Gyy so that the frequency is the first element, use:
%   [...] = hpsdest(...,NoPCTovlp,'rs');
%
% One can select whether to compute Gyy double-sided or single-sided:
%
% [Syy,ws,pys,Navg] = hpsdest(y,refs,t,wA,py,Npblk,win_name,NoPCTovlp,ds_flag);
%   ds_flag = 'onesided' (default) to compute only positive frequencies
%   ds_flag = 'ds' to store both positive and negative frequencies.
%
% M. S. Allen, November 2009
%   Modified June 2010, fixed July 2010 to work correctly for SIMO data.
%

if nargin > 8;
    rs_flag = varargin{1};
else
    rs_flag = [];
end

if nargin > 9;
    ds_flag = varargin{2};
else
    ds_flag = 'onesided';
end
    

t = t(:); % force column vector;
pys = -py:py;
Ny = length(pys);
No = size(y,2);
yexp = zeros(size(y,1),No,Ny);

for k = 1:Ny
    yexp(:,:,k) = y.*exp(-1i*pys(k)*wA*t*ones(1,No));
end
yexp = reshape(yexp,size(yexp,1),size(yexp,2)*Ny);
    % This is stored in blocks, so: y=[y(p=-2); y(p=-1); y(p=0); ...]
if ~isempty(refs);
    if No == 1; % Single sensor
        refs = refs+py+1;
    elseif numel(refs)~=length(refs) % if a matrix is given
        coord_ind=kron(ones(length(pys),1),[1:No].');
        pys_all=kron(pys.',ones(No,1));
        for k=1:size(refs,1)
            ref_ind(k)=find(coord_ind==refs(k,1) & pys_all==refs(k,2));
        end
        varargout{1}=coord_ind; varargout{2}=pys_all;
        refs=ref_ind;
    else
        % otherwise, give each block-column requested.
        refs = py*No + (kron(No*refs(:).',ones(1,No)) + kron(ones(1,length(refs)),[1:No]));
    end
end

[Syy, ws,Navg] = psdest(yexp,refs,t,Npblk,win_name,NoPCTovlp,rs_flag,'peak',ds_flag);

