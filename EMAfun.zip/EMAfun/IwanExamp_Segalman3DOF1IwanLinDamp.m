% Segalman3DOF_1Iwan.m
% Robert Lacayo; June 20, 2013

% This script defines the Segalman 3DOF system with 1 Iwan joint and linear
% modal damping, uses the Newmark-Beta integration technique to solve for
% the time-dependent response of the system and output the modal
% displacement, modal acceleration, and physical external force in
% ModalResponse3D1I.mat so a modal Iwan model can be fit to the
% measurements.
% R.M.Lacayo 2013

clear all; close all;


%% Build the Model
%
% /|               |--> u1              |--> u2                          |--> u3
% /|           _________            _________                        _________
% /|          |         |          |         |         Kinf         |         |
% /|          |         |          |         |______/\/\/\/\/\______|         |
% /|__/\/\/\__|   M0    |__/\/\/\__|   M0    |   ________________   |   M0    |--->f_ext
% /|   Kinf   |         |   Kinf   |         |__| Fs Kt beta chi |__|         |
% /|          |_________|          |_________|  |________________|  |_________|
% /|

% Set up system parameters
M0 = 10;               % Mass
Kinf = 9;              % stiffness of elastic spring
N=3;                   % Number of DOF
zt = .001;             % modal damping ratio (viscous damping)

    % Nonlinear Iwan Joint parameters
    Fs   = 10;  % slip force
    Kt  = 1;    % stiffness of the joint
    beta  = 5;  % parameter that is associated with energy dissipation curve
    chi = -0.5; % parameter associate with slope of log(energy dissipation) vs. log(force)
    params = [Fs,Kt,chi,beta];
    
    % Define matrices
    M = M0*[1 0 0;0 1 0; 0 0 1];
    KINF = [2*Kinf -Kinf 0;-Kinf 2*Kinf -Kinf;0 -Kinf Kinf];
    KT = [0 0 0;0 Kt -Kt;0 -Kt Kt];
    K0 = KINF+KT;
    % FS = [0;Fs;-Fs];

% Set up Impact force
Am = 2e4; %[200,2.5e4, 2e7]; % Impact Force Levels to run
T_forcePulse = 1/20; % Duration of impact force
tsim = 8000;            % simulation duration
F_vec=[0;0;1];          % Maps the scalar force onto the DOF.  This applies a force to DOF 3.

% Eigen Analysis 
[phi0,lam0] = eig(K0,M);      % mode shapes with joint stiffness (micro-slip)
[phiINF,lamINF] = eig(KINF,M);     % mode shapes without joint stiffness (macro-slip)

    fn0 = sqrt(diag(lam0))/2/pi;  % natural frequencies with joint fully stuck

    % Compute damping matrix for viscous (material) part of the damping.
    C = M*phi0*2*zt*sqrt(lam0)*phi0'*M; % physical damping coeff matrix 
    ztsINF=diag(phiINF.'*C*phiINF)./(2*sqrt(diag(lamINF)))
    zts0=diag(phi0.'*C*phi0)./(2*sqrt(diag(lam0)))
    
% Initialize variables
dt = 1/(max(fn0)*200);   % defines timestep. Typically 1/200th of the highest mode works well.
ts = 0:dt:tsim;         % defines time vector
Nt = length(ts);

% Preallocate arrays
f_m = zeros(N,length(ts),length(Am));
q_a = zeros(N,length(ts),length(Am)); % to store the modal force
f_j = zeros(size(params,1),length(ts),length(Am)); % to store the joint forces
a = zeros(N,length(ts),length(Am));
v = zeros(N,length(ts),length(Am));

for ii = 1:length(Am)
    % External Force
    A=Am(ii);
        % Create Impact Force
        f_ext=Am*sin(pi/T_forcePulse*ts).*(ts<T_forcePulse);
        fext = F_vec*f_ext; % Force applied to each DOF
        % Discrete Integration
        IwanPairs = [2,3]; % Iwan joint between masses 2 and 3
        tic
        [x, v(:,:,ii), a(:,:,ii), f_joint] = IwanIntegration(params,M,C,KINF,fext,ts,IwanPairs);
        t_integration=toc
        
        % Transform Physical DOF into Modal DOF and store
        f_m(:,:,ii) = phi0.'*(fext);
        q_a(:,:,ii) = phi0.'*M*a;
        f_j(:,:,ii) = f_joint;
        
        disp(['Impact force ',num2str(ii),' processed.']);
end

% At this point we can typically decimate the data, since the high sample
% rate was only needed for the integrator
ts=ts(1:10:end);
v=v(:,1:10:end,:); a=a(:,1:10:end,:); f_j=f_j(:,1:10:end,:);
f_m=f_m(:,1:10:end,:); % Can't do this - looses pulse % f_ext=f_ext(1:10:end);
q_a=q_a(:,1:10:end,:);

% save('IwanExamp_3DOF.mat','ts','f_m','q_a','v','a','f_j')

figure(1);
plot(ts,v);
xlabel('Time'); ylabel('Velocity');

fft_easy(v.',ts);

%% Optional post processing
return

%% Linear Response
[F_ext,ws_fext]=fft_easy(f_ext.',dt);

H=cl_model(2*pi*fn0,zts0,{phi0,(phi0.'*F_vec).'},ws_fext,'V','s');
    Yd=zeros(size(H));
    for k=1:size(H,2);
        Yd(:,k)=H(:,k).*F_ext;
    end
    % Compare to Newmark Result
    [Xd,ws]=fft_easy(v,ts);
    
    figure(11);
    semilogy(ws_fext/2/pi,(2/length(f_ext))*abs(Yd)); hold on; ax = gca; ax.ColorOrderIndex = 1;
    semilogy(ws/2/pi,(2/length(v))*abs(Xd),'--'); hold off
    grid on;
    xlabel('Frequency'); ylabel('Respnonse (m/s)'); legend('V_1 Lin','V_2 Lin','V_3 Lin','V_1','V_2','V_3');
    title('\bfResponse to Force: (-) Linear FRF, (--) Nonlinear');
    
%% Compute transfer function and find the response
[Xd,ws]=fft_easy(v,ts);
    for k=1:size(Xd,2);
        Hd(:,k)=Xd(:,k)./F_ext;
    end
    
    % Run AMI to fit a linear mode to this
    ami(Hd,ws)