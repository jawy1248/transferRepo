function subsys = reduce_sys(subsys,N);
% Truncate high frequency modes in a subsystem for "ritzscomb"
%
% subsys = reduce_sys(subsys,N);
%   where N specifies the number of modes to keep
%
% ALTERNATE:
% subsys = reduce_sys(subsys,ns);
%   where ns is a vector length>1 that specifies which modes to keep
%
% Matt Allen, May 2007
% Updated Apr. 2010

if length(N) == 1;
    if N > length(subsys.wn);
        warning(['User Requested to Reduce to ',num2str(N),...
            ' Modes, but the system only has ', num2str(length(subsys.wn))]);
    end

    subsys.wn = subsys.wn(1:N);
    subsys.phi = subsys.phi(:,1:N);
    if isfield(subsys,'mmass');
        subsys.mmass = subsys.mmass(1:N);
    end
%     subsys.names = subsys.names; % not needed
    if isfield(subsys,'zt');
        subsys.zt = subsys.zt(1:N);
    end
else % N is a vector of indices
    if max(N) > length(subsys.wn);
        warning(['User Requested to Reduce to ',num2str(max(N)),...
            ' Modes, but the system only has ', num2str(length(subsys.wn))]);
    end

    subsys.wn = subsys.wn(N);
    subsys.phi = subsys.phi(:,N);
%     subsys.names = subsys.names; % not needed
    if isfield(subsys,'zt');
        subsys.zt = subsys.zt(N);
    end
end