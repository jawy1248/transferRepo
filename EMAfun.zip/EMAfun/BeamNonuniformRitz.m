function [phi,wn,M,K,psi_plot,dpsi_plot] = ...
    BeamNonuniformRitz(Nritz,xmeas,hmeas,rhobL,EboL3o12,L,varargin)
% M-file that creates an N-term Ritz model for a cantilever beam with a
% nonuniform thickness.
%
% [phi,wn,M,K,psi_plot,dpsi_plot] = ...
%    BeamNonuniformRitz(Nritz,xmeas,hmeas,rhoALoh,EIoL3oh,L,ys,int_pts)
%
% Note: rhobL = rho*b*h*L/h, EboL3o12 = E*(b*h^3/12)/L^3/h^3
% Last two arguments are optional.
%
% xmeas should be nondimensional - ranging from 0 to 1.
% hmeas gives the thickness in consistent units at each x position.  Linear
% interpolation is used between points.
%
% MS Allen Jan, 2009
%

if nargin > 5
    int_pts = varargin{2};
else
    int_pts = 1e4; % points used in integrals below - should be way more than sufficient.
end
ys_int = linspace(0,1,int_pts);

if nargin > 4
    ys = varargin{1};
else
    ys = [0:0.01:1]; % y-vector for plots of mode shapes
end

syms y real;
tic
% Find Alpha Values
    ce = inline('cos(x)+1/cosh(x)');
    an0 = [1.8751, 4.6941,(2*[3:Nritz]-1)/2*pi];
    for k = 1:length(an0);
        an(k) = fzero(ce,an0(k));
    end
    for j = 1:Nritz;
        Rn(j) = -(sin(an(j)) + sinh(an(j)))/(cos(an(j)) + cosh(an(j)));
    end
% Generate Mode functions
for j = 1:Nritz
    psi(j) = sin(an(j)*y) - sinh(an(j)*y) + Rn(j)*(cos(an(j)*y) - cosh(an(j)*y));
end
dpsi = diff(psi,y);
    
h_y_fun = @(x) interp1(xmeas,hmeas,x);

% Matrices
M = zeros(Nritz,Nritz); K = zeros(Nritz,Nritz);
for m = 1:Nritz
    for n = 1:m
        % Evalutae integrals numerically using trapezoidal integration with
        % a fixed number of increments.
        m_integrand = rhobL*h_y_fun(ys_int).*subs(psi(m),'y',ys_int).*subs(psi(n),'y',ys_int);
            M(m,n) = trapz(ys_int,m_integrand);% 
        % Note - could add tip here with the following:
            % +double(subs(mtip*psi(m)*psi(n),'y',1))
        k_integrand = EboL3o12*h_y_fun(ys_int).^3.*subs(diff(psi(m),y,2)*diff(psi(n),y,2),'y',ys_int);
            K(m,n) = trapz(ys_int,k_integrand); % *EI/L^3 for nondim y

    % This code does the same thing with symbolics for h_y, but it has
    % difficulty because Matlab's Heaviside gives NaN at 0.
%             m_integrand = inline(strrep(strrep(strrep(char((rho*b*h_y*L)*psi(m)*psi(n)),'*','.*'),'/','./'),'^','.^'));
%             % m_integrand = @(yin) eval(['for k = 1:length(yin); y = yin(k); fout(k) = ',char(psi(m)*psi(n)),'; end']);
%         M(m,n) = quadl(m_integrand,0,1)+double(subs(mtip*psi(m)*psi(n),'y',1));%
%             k_integrand = inline(strrep(strrep(strrep(char((E*b*h_y^3/12/L^3)*diff(psi(m),y,2)*diff(psi(n),y,2)),'*','.*'),'/','./'),'^','.^'));
%         K(m,n) = quadl(k_integrand,0,1); % *EI/L^3 for nondim y
        if n ~= m; M(n,m) = M(m,n); K(n,m) = K(m,n); end
    end
end
t_Ritz = toc
    
[phi,lambda] = eig(K,M);
% Normalize Mode Functions:
mu = diag(phi.'*M*phi); PHI = zeros(size(phi));
for jj = 1:1:length(phi)
    PHI(:,jj) = phi(:,jj)/sqrt(mu(jj));
end

wn = sqrt(diag(lambda));

% Check orthogonality conditions
check_M = max(max(PHI.'*M*PHI-eye(size(PHI))))
check_K = max(max((PHI.'*K*PHI-lambda)))

tic
% Find Numerical Mode Functions
dpsi_plot = zeros(length(ys),Nritz); psi_plot = zeros(length(ys),Nritz);
for p = 1:length(ys);
    for n = 1:Nritz;
        y = ys(p);
        dpsi_plot(p,n) = double(eval(dpsi(n))); %double(subs(dpsi(n),'y',ys(p)));
        psi_plot(p,n) = double(eval(psi(n))); %double(subs(psi(n),'y',ys(p)));
    end
end
syms y
t_Ritz_plotshapes = toc

phi = [psi_plot; (1/L)*dpsi_plot]*PHI;
phi = phi*diag(sign(phi(end,:)));
