function [vs_all,ps_all,lam_ave,varargout] = ltpoma_align(lam,vs,ps,wA,varargin)
% Align, Scale and Average mode shapes estimated with LTPOMA.
%
% [vs_all,ps_all,lam_ave] = LTPOMA_align(lam,vs,ps,wA);
%
%   lam = vector of eigenvalues estimated at each peak (or frequencies only)
%   vs = vector of mode shapes or spectra at those frequencies.
%   ps = vector of harmonic shift indices corresp. to vs. (e.g. [-3:3])
%   OPTIONAL:  To filter out spurious terms:
%       To filter based on standard deviation.      
%       [vs_all,ps_all,lam_ave,vs_ave] = LTPOMA_align(lam,vs,ps,wA,'std',std_max);
%           Keeps any terms with std (in percent) < std_max;
%       To keep only the specified terms (e.g. discard high order ones):
%       [vs_all,ps_all,lam_ave,vs_ave] = LTPOMA_align(lam,vs,ps,wA,'ps',ps_kp);
%           ps_kp is a vector of shift indices to keep.  The others are
%           set to zero.  (e.g. setting ps_kp=-2:2 keeps low order terms.)
%   OPTIONAL:  If you would like the option of discarding columns prior to
%   averaging:
%   	[...] = LTPOMA_align(lam,vs,ps,wA,'std',std_max,'discard');
%
% This function assumes that aliased complex conjute eigenvalues have complex
% conjugate shapes - may not be true for certain systems.
%
% MSA, July 6, 2010
%

wpk = abs(lam);
vs = vs*diag(max(vs,[],1).^(-1));

% Average Results and Compare:
disp('Mode Vectors Identified');
[NaN, [1:length(wpk)];
    NaN, wpk.';
    vec(ps),abs(vs)]
cs = input('Input the Column Number and Shift for one column, [Col#,shift,conjugates]:');
if isempty(cs); cs = [1,0]; disp('Using Default value cs = [1,0]'); end
wn_approx = wpk(cs(1))-wA*cs(2);
if length(cs) > 2; % conjugate eigenvalues
    wpk(cs(3:end)) = -wpk(cs(3:end));
    lam(cs(3:end)) = conj(lam(cs(3:end)));
    vs(:,cs(3:end)) = flipud(vs(:,cs(3:end)));
end
disp('Shift indices for each peak');
    (wpk-wn_approx)/wA
ns = round((wpk-wn_approx)/wA);
wn = mean(wpk-ns*wA);

% Find indices for each Fourier Term:
psv = vec(ps)*ones(1,length(ns)) + ones(length(ps),1)*ns.';
ps_all = [min(min(psv)):max(max(psv))].';
vs_all = zeros(length(ps_all),size(vs,2));

% Display vectors:
for k = 1:size(vs,2);
    for m = 1:size(vs,1);
        vs_all(find(ps_all == psv(m,k)),k) = vs(m,k);
    end
end
% Average Mode Vector
    % First normalize all of the phases
    % Find index of largest coefficient - assume it is the most accurate
    del_phi = zeros(1,size(vs_all,2));
    for k = 1:(size(vs_all,2)-1);
        dot_ind = (vs_all(:,k) ~= 0) & (vs_all(:,k+1) ~= 0);
        del_phi(k+1) = angle(vs_all(dot_ind,k+1)'*vs_all(dot_ind,k));
    end
    del_phi = cumsum(del_phi);
    vs_all = vs_all*diag(exp(1i*del_phi));

% Discard some columns prior to averaging.
if nargin > 6
    disp('Shifted Mode Vectors:');
    disp('1st Row Freqs, then Shapes');
%     disp(['ps, wn=',num2str(wpk.')]); % [NaN, [1:length(wpk)];
    [0, [1:length(wpk)];
        0, wpk.';
        ps_all, abs(vs_all)]
    
    disc_cols = input('Which Columns To Discard Prior To Averaging? ([] if none): ');
    kp_cols = setdiff([1:size(vs_all,2)],disc_cols)
    vs_kp = vs_all(:,kp_cols);
else
    vs_kp = vs_all;
end
% Average
    vs_ave = zeros(size(ps_all)); vs_std = zeros(size(ps_all));
    for k = 1:size(vs_kp,1);
        if any((vs_kp(k,:)~=0));
            vs_ave(k) = mean(vs_kp(k,(vs_kp(k,:)~=0)));
            vs_std(k) = std(vs_kp(k,(vs_kp(k,:)~=0)));
        else % put a zero for the average if there aren't any terms to average.
            vs_ave(k) = 0; vs_std(k) = 0;
        end
    end
% Display Mode Vectors
disp('Shifted Mode Vectors:');
disp(['ps, mean(vs), std(vs)./mean(vs), Col# (frequency on 2nd row)']); % [NaN, [1:length(wpk)];
[0, 0, 0, [1:length(wpk)];
    0, 0, 0, wpk.'
    ps_all, abs(vs_ave), abs(vs_std)./abs(vs_ave), abs(vs_all)]
if nargin > 6
    disp(['Discarded columns ',num2str(disc_cols),' when computing average.']);
end

if isreal(lam);
    lam_ave = wn;
else
    lam_ave = mean(lam-1i*ns*wA);
end

% Filter Out Noisy Terms.
if nargin > 4 && strcmpi(varargin{1},'std')
    if nargin <6; error('Must supply std_max for averaging'); end
    std_max = varargin{2};
    % Filter vs_ave to remove values with large standard deviation
%     std_max = 0.2; % fraction of the average value
    varargout{1} = vs_ave.*(abs(vs_std)./abs(vs_ave) < std_max).*(vs_std~=0);
elseif nargin > 4 && strcmpi(varargin{1},'ps')
    if nargin <6; error('Must supply ps_kp for averaging'); end
    % Simply eliminate high order terms in vs_ave
    ps_kp = varargin{2}; kp_val = false(size(ps_all));
    for k = 1:length(ps_all);
        kp_val(k) = any(ps_kp==ps_all(k));
    end
    varargout{1} = vs_ave.*(kp_val);
else
    warning('Couldn''t interpret filtering string, no filtering applied.');
end

if nargout > 4;
    varargout{2}=ns;
end
