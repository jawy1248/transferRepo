function [H1,H2,Hv,ws_est,MCOH1,MCOH2,MCOHv,Guu,Gyu,Gyy] = htfest(y,u,wA,py,pu,t,Npblk,win_name,NoPCTovlp);
% Harmonic Transfer Function Estimation - after Wereley
%
% u and y are matrices with the first dimension being time (time in
% columns) t should be a column vector - add error checking later.
% win_name = 'hanning'
% NoPCTovlp = 0.875
%
% [H1,H2,Hv,ws_est,MCOH1,MCOH2,MCOHv,Guu,Gyu,Gyy] =
% frfmest(yexp.',uexp.',ts_swp,Npblk,'hanning',0.825);
%
size(u)
size(y)

pus = -pu:pu;
pys = -py:py;
Nu = length(pus);
Ny = length(pys);
uexp = zeros(size(u,1),size(u,2),Nu);
yexp = zeros(size(y,1),size(y,2),Ny);
    
for k = 1:Nu
    uexp(:,:,k) = u.*exp(-1i*pus(k)*wA*t*ones(1,size(u,2))); % shifts w to w-p*wA, so u(k) corresp to u(w+p*wA)
end
for k = 1:Ny
    yexp(:,:,k) = y.*exp(-1i*pys(k)*wA*t*ones(1,size(y,2)));
end
uexp = reshape(uexp,size(uexp,1),size(uexp,2)*Nu);
yexp = reshape(yexp,size(yexp,1),size(yexp,2)*Ny);

% [H1,H2,Hv,ws_est,MCOH1,MCOH2,MCOHv,Guu,Gyu,Gyy] = frfmest(y,u,ts,Npblk,window_name,NoPCToverlap)
[H1,H2,Hv,ws_est,MCOH1,MCOH2,MCOHv,Guu,Gyu,Gyy] = frfmest(yexp,uexp,t,Npblk,win_name,NoPCTovlp);
    % This gives H1, which is an Nh_est by Nh_est matrix of HTFs (Gs_hat in
    % Siddiqui).