%% Cool Modeshapes!
% Dan Rohe
clear; clc; close all;

props.E = 30e6; props.nu = 0.28; props.rho = 0.284/(32.2*12);
props.h = 0.75; props.b = 1; props.nodes = 4; 

%% Circle
nsegments = 40;

nodes = [4*cos(linspace(0,2*pi,nsegments+1)'),4*sin(linspace(0,2*pi,nsegments+1)')];
nodes = nodes(1:end-1,:);

for i = 1:size(nodes,1)-1
    conn(i,:) = [i,i+1];
end
conn(i+1,:) = [i+1,1];

[ss,beam] = beam_structure_2d(nodes,conn,props,'noplot');

figure;
beam_structure_plotter(ss,beam,1,'Labels','Scale',0);
figure;
beam_structure_plotter(ss,beam,1:16,'scale',.1,'Linespec','b.-');

%% Unconstrained Star

props.nodes = 10;
nsegments = 7;
nodes2 = [4*cos(linspace(0,2*pi,nsegments+1)'),4*sin(linspace(0,2*pi,nsegments+1)')];
nodes2 = nodes2(1:end-1,:);

skip = 3;

pt = 1;
for i = 1:nsegments
    conn2(i,1) = pt;
    pt = pt+skip+1;
    if pt > nsegments
        pt = pt - nsegments;
    end
    conn2(i,2) = pt;
end

[ss2,beam2] = beam_structure_2d(nodes2,conn2,props,'noplot');

figure;
beam_structure_plotter(ss2,beam2,1,'Labels','Scale',0);
figure;
beam_structure_plotter(ss2,beam2,1:16,'scale',.1,'Linespec','b.-');

%% Ticked Box

nodes3 = [0,0;
          5,0;
          5,5;
          0,5];
conn3 = [1,2;2,3;3,4;4,1;2,4;1,3];

[ss3,beam3] = beam_structure_2d(nodes3,conn3,props,'noplot');

figure;
beam_structure_plotter(ss3,beam3,1,'Labels','Scale',0);
figure;
beam_structure_plotter(ss3,beam3,1:16,'scale',.05,'Linespec','b.-');


%% Heart by MSA
nsegments = 10;

nodes4 = [-4-4*cos([0:pi/nsegments:(pi-pi/nsegments)])',4*sin([0:pi/nsegments:(pi-pi/nsegments)])';
    4-4*cos([0:pi/nsegments:(pi-pi/nsegments)])',4*sin([0:pi/nsegments:(pi-pi/nsegments)])';
    [8:(-8/nsegments):0].',[0:(-8/nsegments):-8].';
	[(0-8/nsegments):(-8/nsegments):(-8+8/nsegments)].',[(-8+8/nsegments):(8/nsegments):(0-8/nsegments)].'];

figure(1); plot(nodes4(:,1),nodes4(:,2))

for i = 1:size(nodes4,1)-1
    conn4(i,:) = [i,i+1];
end
conn4(i+1,:) = [i+1,1];

[ss4,beam4] = beam_structure_2d(nodes4,conn4,props,'noplot');

figure;
beam_structure_plotter(ss4,beam4,1,'Labels','Scale',0);
figure;
beam_structure_plotter(ss4,beam4,4:12,'scale',.1,'Linespec','b.-');

