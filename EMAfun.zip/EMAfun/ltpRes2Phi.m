function [Azero_out] = ltpRes2Phi(Ares,ts,lam,varargin);
% [Azero_out] = ltpRes2Phi(Ares,ts,lam);
%
% Function that creates a residue vector for LTP systems in which all
% elements are referenced to the initial time.  This residue vector,
% denoted A_0 in the following publication, is proportional to the mode
% vector.
% (Method #1 (MDTS method) in 2006 IMAC paper by Allen, and Ginsberg.)
%
% Ares - Residue matrix, where each column corresponds to the residue
%       vector for sequential initial conditions.
%       If multiple eigenvalues are supplied, then each eigenvalue k should
%       correspond to Ares(k,:,:) and the times in 'ts' should correspond
%       to the second dimension of Ares.
% ts -  Time vector covering at least one period (need not be equally
%       spaced)
% lam - Eigenvalue for the residue matrix of interest.
% Azero_out = Residue vector referenced to Zero.  This vector will be
%       periodic with time, as are the mode vectors, if the eigenvalue 
%       used to compute it is correct.
%
% Matt Allen July 11, 2005
%

if nargin > 3;
    res_fmt = varargin{1};
else
    res_fmt = 'na';
end

if length(lam) == 1 && ~strcmpi(res_fmt,'ami'); % Old format - kept for compatibility only;

    No = size(Ares,1); Ns = size(Ares,2);
    %TA = Ns*(ts(2)-ts(1));
    %w1 = 2*pi/TA;

    for k = 1:Ns
        Azero_out(:,k) = Ares(:,k)*exp(-lam*(ts(k)-ts(1)));
    end

else % Standard AMI format - second dimension = response point or LTP point

    Nm = size(Ares,1); Ns = size(Ares,2); Ni = size(Ares,3);
    if length(ts) < Ns; error('Fewer elements in time vector than points in pseudo-mode shape'); end
    if numel(lam) > length(lam)
        error('Vector of Eigenvalues (lam) is not a 1-D vector');
    end
    lam = lam(:); % assure this is a column vector
    %TA = Ns*(ts(2)-ts(1));
    %w1 = 2*pi/TA;
    
    Azero_out = zeros(Nm,Ns,Ni);
    for p = 1:Ni;
        for k = 1:Ns
            Azero_out(:,k,p) = Ares(:,k,p).*exp(-lam*(ts(k)-ts(1)));
        end
    end

end
    
% ps = [-NR:1:NR];
% if length(ps) > Ns;
%     error(['Too many terms in FS expansion.  No more than NR = ',num2str(Ns)...
%         ', terms allowed.']);
% end
% 
% A = zeros(Ns*No, No*length(ps));
% for k = 1:Ns;
%     A(((k-1)*No + 1):(k*No),:) = kron([exp(i*w1*ps*(ts(k)-ts(1)))],...
%         [exp(lam*(ts(k)-ts(1)))*eye(No)]);
% end
% b = Ares(:);
% 
% B = A\b;
% 
% Bc = reshape(B,No,length(ps));
% 
% tcyc = ts(1:Ns);
%     % Make tcyc a row vector
%     tcyc = tcyc(:).';
% 
% Phi_out = zeros(size(Ares));
% for k = 1:length(ps)
%     Phi_out = Phi_out + Bc(:,k)*exp(i*w1*ps(k)*tcyc);
% end
