function [B,m,varargout] = ltpResFS(A,NorMkeep,varargin)
% Expand an identified LTP residue matrix in a Fourier Series and discard
% high order terms.
% - See M.S. Allen, ASME IDETC 2007 paper, Las Vegas, NV.
%
% [B,m] = ltpResFS(A,Nkeep,varargin)
% [B,m] = ltpResFS(A,Nkeep,fig_num) % specify number of figure for plot.
%
% A is input in standard AMI form where size(A) = N x N_LTP
% B and m are N by Nkeep
%
% Alternatively A can be No x N_LTP (single mode, all outputs) and then B
% and m are No by Nkeep
%
% The Fourier Series is independent for each coordinate and for each mode,
% so each has its own set of coefficients.
%
% Yet another alternative:
% [B,m] = ltpResFS(A,Mkeep,fig_num)
% Where Mkeep specifies the values of m in the FS that one wishes to retain.
%
% MSA Feb. 2007
%

Acol = A.'; % put time in columns
NA = size(Acol,1); No = size(Acol,2); % number of resp. points
m_all = [-NA/2:1:(NA/2-1)].';

if round(NA/2) ~= NA/2; % not even
    error(['Number of Pseudo-time points must be even for this algorithm; User supplied NA = ',num2str(NA)]);
end
    % This algorithm gives strange results if the number of pseudo-points
    % is odd.  I think this is due to a difference in the arrangement of
    % the different harmonics in the elements of the FFT, but I don't have
    % time to look into this right now.
    
if length(NorMkeep) > 1;
    % this signals that the specific m-coeff are being given.
    if length(union(m_all,NorMkeep)) > length(m_all);
        error({'Some reqested m-values out of range,',...
            'Allowable range: ',num2str(minmax(m_all))});
    end
    zero_flag = 'm';
    Nkeep = length(NorMkeep);
    Mkeep = NorMkeep;
        if prod(size(Mkeep)) ~= length(Mkeep);
            error('NorMkeep must be a vector or scalar');
        end
else
    zero_flag = 'mag';
    Nkeep = NorMkeep;
end
            
if nargin > 2
    nf = varargin{1};
    figure(nf);
else
    figure;
end

% wAfd = [-NA/2+1:1:NA/2]*w1;
Afd = fft(Acol);
Afd = fftshift(Afd,1);

set(gcf,'Units', 'normalized', 'Position', [0.324,0.329,0.35,0.585])
subplot(2,1,1)
semilogy(m_all,abs(Afd(:,1)),'o'); grid on;
xlabel('Fourier Series Coeff (m)'); ylabel('Amplitude');

% Graphically Select which to keep
    % disp('Select Vertical Threshold - all points below it will be eliminated');
    % [x,y] = ginput(1);
    % 
    % Bind = find(abs(Afd) > y);
    
% Keep the largest Nkeep of the coefficients
if strcmp(zero_flag,'mag');
    A_zeroed = Afd; m = zeros(No,Nkeep); B = zeros(No,Nkeep);
    for k = 1:size(Afd,2);
        [Afd_s,Afd_sind] = sort(abs(Afd(:,k)),1,'descend');
        Bind = Afd_sind(1:Nkeep);
        m(k,:) = m_all(Bind);
        B(k,:) = Afd(Bind,k).';

        % Process FFT series also:  Zero the spurrious coeff
        A_zeroed(setdiff([1:length(Afd)],Bind),k) = 0;
    end
else
    A_zeroed = Afd; m = zeros(No,Nkeep); B = zeros(No,Nkeep);
    for k = 1:length(Mkeep);
        Bind(k) = find(m_all == Mkeep(k));
    end
    for k = 1:size(Afd,2);
        m(k,:) = m_all(Bind);
        B(k,:) = Afd(Bind,k).';
    end
        % Process FFT series also:  Zero the spurrious coeff
        A_zeroed(setdiff([1:length(Afd)],Bind),k) = 0;
end
line(m(1,:),abs(B(1,:)),'Marker','.','LineStyle','none','color','r');
legend('All','kept');

% IFFT of FFT coeff
A_zeroed = ifftshift(A_zeroed,1);
Afd_zeroed_ifft = ifft(A_zeroed);

% Scale B and check frequency
B = B*(1/NA); % to correct for DFT definition

ks = [0:NA-1];
A_fit = zeros(No,length(ks));
for k = 1:size(m,2); % loop over FS coefficients
    A_fit = A_fit+diag((B(:,k)))*exp(i*(m(:,k))*(2*pi/NA)*ks);
    % Bk(k,:) = B(k)*exp(i*m(k)*(2*pi/NA)*ks);
end
A_fit = A_fit.';

% save debugdata.mat

subplot(2,1,2);
plot([1:NA],real(Afd_zeroed_ifft(:,1)),'-',...
    [1:NA],imag(Afd_zeroed_ifft(:,1)), ':',...
    [1:NA],real(Acol(:,1)),'.-',...
    [1:NA],imag(Acol(:,1)), '.:'); grid on;
hold on; plot([1:NA],real(A_fit(:,1)),'k.',[1:NA],imag(A_fit(:,1)),'k.'); 
%plot([1:NA],real(Bk),[1:NA],imag(Bk));
hold off;
legend('Re-Zeroed IFFT','Im-Zeroed IFFT','Re-Measured','Im-Measured',...
    'Re-FS','Im-FS');

if nargout > 2
    S = whos;
    for k = 1:length(S)
        eval(['ad.',S(k).name,' = ',S(k).name,';']);
    end
    varargout{1} = ad;
end