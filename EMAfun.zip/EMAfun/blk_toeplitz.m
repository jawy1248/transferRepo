function t = blk_toeplitz(c,r)
%BLK_TOEPLITZ Block Toeplitz matrix creation.
%   BLK_TOEPLITZ(C,R) is a non-symmetric block Toeplitz matrix having C as its
%   first block-column and R as its first block-row.  The block sizes in
%   C and R must match (square blocks) and both C and R must contain complete blocks.
%
%   BLK_TOEPLITZ(C) is a symmetric (or Hermitian) Toeplitz matrix.
%
%   See also TOEPLITZ.

%   Matt Allen - June 28, 2004
%   Based only slightly on MATLAB's TOEPLITZ function

nb = size(c,2);

if nargin < 2; % symmetric block toeplitz
    r = zeros(size(c,2),size(c,1));
    for b = 1:(size(c,1)/nb);
        r(:,[nb*(b-1)+1:nb*b]) = c([nb*(b-1)+1:nb*b],:);
    end
else
    % Block column and row must be a b-column and a b-row vector for this to work
    if size(r,1) ~= nb;
        error('Number of block rows in row and column do not match');
    end
    if ~isempty(nonzeros(r(1:nb,1:nb) ~= c(1:nb,1:nb)))
        warning('Column wins diagonal conflict.')
    end
end

p = length(r)/nb;
    if p ~= round(p); error('# columns in block row is not an integer multiple of the # rows'); end
    
m = length(c)/nb;
    if m ~= round(m); error('# rows in block column is not an integer multiple of the # columns'); end

t = zeros(p*nb,m*nb);
t(1:size(r,1),1:size(r,2)) = r;
t(1:size(c,1),1:size(c,2)) = c;
for a = 2:p;
    for b = 2:m;
        if a-b >= 0;
            d = a - (b-1);
            t([nb*(a-1)+1:nb*a],[nb*(b-1)+1:nb*b]) = t([nb*(d-1)+1:nb*d],[1:nb]);
        else
            d = b - (a-1);
            t([nb*(a-1)+1:nb*a],[nb*(b-1)+1:nb*b]) = t([1:nb],[nb*(d-1)+1:nb*d]);
        end
    end
end

break

% Alternate method - more memory required, possibly slower?
x = zeros(nb,nb,p+m-1);
for k = 2:p;
    x(:,:,p-k+1) = r(:,[nb*(k-1)+1:nb*k]);
end
for k = 1:m
    x(:,:,k+p-1) = c([nb*(k-1)+1:nb*k],:);
end

t = zeros(p*nb,m*nb);
for a = 1:p;
    for b = 1:m;
        t([nb*(a-1)+1:nb*a],[nb*(b-1)+1:nb*b]) = x(:,:,a-b+p);
    end
end