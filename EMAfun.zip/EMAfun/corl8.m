function [OO,OCO] = corl8(phi1,phi2,M)
%This funciton is used to calculate the orthogonality and
%cross-orthogonality of the test modes wrt the FEM mass matrix
%   phi1 corresponds to the test modes
%   phi2 corresponds to the FEM modes
%   M is the FEM mass matrix
% Input Line: [OO,OCO] = corl8(phi1,phi2,M)

%Mass Normalize the written mode shapes
g1 = diag((diag(phi1'*M*phi1)).^(-1/2));
phi1O = phi1*g1;
g2 = diag((diag(phi2'*M*phi2)).^(-1/2));
phi2O = phi2*g2;

OO=phi1O'*M*phi1O;         %Orthogonality of Test Modes wrt FEM mass matrix
OCO=phi2O'*M*phi1O;        %Cross-Orthogonality of Test modes with FEM modes

end

