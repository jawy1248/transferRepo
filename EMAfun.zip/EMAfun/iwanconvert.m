function [varargout]=iwanconvert(varargin);%F_S,K_T,chi,beta)
% Function which converts between two sets of parameters that describe an
% Iwan joint
%
% [chi, phi_max, R, S]=iwanconvert(F_S,K_T,chi,beta);
%
% Or to convert in reverse:
% 
% [F_S,K_T,chi,beta]=iwanconvert(chi, phi_max, R, S,'reverse');
%
% And it is also possible to pass the parameters as a vector:
%   [param_math]=iwanconvert(param_phys);
%   [param_phys]=iwanconvert(param_math,'reverse');
%   where: 
%       param_math=[chi, phi_max,R, S] % mathematical description
%       param_phys=[F_S,K_T,chi,beta] % physically meaningful
%
% M.S. Allen, July 2013, Revised July 2015
%

% Determine which type of conversion we're doing and what was passed in.
if nargin==1 || nargin==4; %%%%% signifies phyical parameters passed in, so do forward transformation
    
    if nargin==1; % parameter vector passed in
        paramp=varargin{1};
        F_S=paramp(1); K_T=paramp(2); chi=paramp(3); beta=paramp(4);
    else % parameters passed in separately
        F_S=varargin{1}; K_T=varargin{2}; chi=varargin{3}; beta=varargin{4};
    end
    % Now compute the mathematical parameters using the formulas.
    phi_max = F_S*(1+beta)/(K_T*(beta + (chi+1)/(chi+2)));
    R = F_S*(chi+1)/((beta+ (chi+1)/(chi+2))*phi_max^(chi+2) );
    S = (F_S/phi_max)*(beta/(beta + (chi+1)/(chi+2)));
    if nargout==1
        varargout{1}=[chi, phi_max,R, S]; % params vector
    else
        varargout={chi, phi_max,R, S};
    end
    
elseif nargin==2 || nargin==5; %%%%% signifies reverse transformation %%%%%%
    
    if ~strcmpi(varargin{end},'reverse') && ~strcmpi(varargin{end},'rev')
        error([num2str(length(varargin)),'th input argument should be a flag ''rev'' or ''reverse''']);
    end
    if nargin==2; % parameter vector passed in
        paramm=varargin{1};
        chi=paramm(1); phi_max=paramm(2); R=paramm(3); S=paramm(4);
    else % parameters passed in separately
        chi=varargin{1}; phi_max=varargin{2}; R=varargin{3}; S=varargin{4};
    end
    beta=S/((R*phi_max^(chi+1))/(chi+1));
    F_S=phi_max*(R*phi_max^(chi+1)/(chi+1))*((chi+1)/(chi+2)+beta);
    K_T=F_S*(1+beta)/(phi_max*(beta+(chi+1)/(chi+2)));
    if nargout==1
        varargout{1}=[F_S,K_T,chi,beta]; % params vector
    else
        varargout={F_S,K_T,chi,beta};
    end
else
    error('Incorrect number of input arguments, should be 1, 2, 4 or 5.')
end
    


% % Note, the inverse transformation:
%{
beta=S/((R*phi_max^(chi+1))/(chi+1));_
F_S=phi_max*(R*phi_max^(chi+1)/(chi+1))*((chi+1)/(chi+2)+beta);
K_T=F_S*(1+beta)/(phi_max*(beta+(chi+1)/(chi+2)));
%}