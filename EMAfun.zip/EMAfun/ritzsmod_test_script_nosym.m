% Test script for ritzsmod m-file.
% Based on ME 7442 First Homework Assignment:
% Uses Ritz Series Analysis of Free-Free Beam in Flexure
%
% This generates a set of analytical mode vectors for a free-free beam and
% then modifies the beam by adding a mass and computes the modified
% system's natural frequencies and mode vectors.

clear all; close all;
load ritzsmod_test_data.mat
% load in data from Ritz analysis of the free-free beam and for the
% free-free beam with a mass added to the end.

% Plotting
figure(1)
% subplot(211)
% plot([2:1:5],wnd(:,1:3), '*-'); grid;
% xlabel('Series Length (N)'); ylabel('Natural Frequency *sqrt(EI/pAL^4)');
% title('Wn vs. Ritz Series Length--First Three Modes');
% subplot(212)
plot(yd, psi_c);%, yd, psi_c(:,1,2), '.:', yd, psi_c(:,3,2),'.:'); grid;
xlabel('Position (X/L)'); ylabel('Mode Function');
title('Mode Shapes');

% Mass addition - 
% This is all loaded from the previous *.mat file.
    % total_mass = rho*Area*L % lb/(in/s^2)
    % dm = total_mass*0.1;
    % ns_m = 1; % left end of beam
    % dk = []; ns_k = [];
    % phi = psi_c; % note, overwrites previous

[wn_mod,zt_mod,phi_mod,M_mod,C_mod,K_mod] = ritzsmod(wn,zt,phi,dm,ns_m,dk,ns_k);

disp('fn before and after modification');
[wn/2/pi, wn_mod/2/pi]

[phim lambdam] = eig(Km,Mm);
psi_cm = psi_vals*phim; % already normalized.
[wn_modm,sort_ind] = sort(sqrt(diag(lambdam)));
psi_cm = psi_cm(:,sort_ind);

disp('fn before and after modification and Ritz Estimate');
[wn/2/pi, wn_mod/2/pi, wn_modm/2/pi]
disp('The last two columns verify that the modification algorithm gives the ')
disp('same estimate that one would get using the Ritz series directly.');

figure(2)
plot(yd, psi_c*diag(sign(psi_c(1,:)))); hold on;
plot(yd,phi_mod*diag(sign(phi_mod(1,:))),'--');
plot(yd,psi_cm*diag(sign(psi_cm(1,:))),':');
xlabel('\bfPosition (X/L)'); ylabel('\bfMode Shapes');
title('\bfMode Shapes (-) orig, (--) ritzsmod, (:) mod Direct Ritz');
