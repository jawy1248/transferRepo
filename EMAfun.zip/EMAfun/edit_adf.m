% EDIT_ADF - Open an I-DEAS ADF (Associated Data File), edit its contents,
%   and then write the edited results to a new ADF.  This code is really a
%   framework, as the user needs to add code to perform their specific editing
%   task (see the code for examples).
% The ADF should have one of the following file extensions:
%        *.afu  function data (FRF, coherence, autospectrum, etc.)
%        *.ash  mode shape data
%        *.ati  time history data
% Has no calling arguments; user is prompted for all inputs.

%=======================================================================
% Required toolboxes/functions that are not part of basic MATLAB:
% - IMAT (I-DEAS to MATLAB translator) functions:
%	readadf(), setunits(), writeadf()
%
% 03-Mar-2006, Created (Curt Nelson)
% 23-Jun-2006, Last modified (Curt Nelson)
%=======================================================================
clear all

setunits('SI', 'silent')	% set units for I-DEAS interface to m-N-kg
[fname,fpath] = uigetfile('*.afu;*.ash;*.ati', 'I-DEAS associated data file: ');
if isequal(fname,0)
    fprintf(1, 'Program finished.  Have a nice day!\n');
    return
end
adfObj = readadf([fpath,fname]);

% If the ADF contains N data records, then adfObj is a Nx1 variable of
%   "ideas_fn object" class
% Note that ADFs always store data using SI units
% - when data is read from an ADF using readadf(), the data is automatically
%   converted from SI to the user's selected units (chosen by setunits())
% - when data is written to an ADF using writeadf(), the data is automatically
%   converted back to SI from whatever units the user was using
% - this code sets the units to SI so readadf() and writeadf() do not have to
%   perform any of these automatic unit conversions

fprintf(1, '\n');
%--- MAKE EDITS BELOW THIS LINE ----------------------------------------

%fprintf(1, 'Not making any changes\n');
%NEWadfObj = adfObj;

%fprintf(1, 'Deleting data records 1, 3, and 4\n');
%NEWadfObj = adfObj([2 5:end]);

%fprintf(1, 'Deleting data records 1-3\n');
%NEWadfObj = adfObj(4:end);

%fprintf(1, 'Swapping order of 2nd and 3rd data records\n');
%NEWadfObj = adfObj([1 3 2 4:end]);

%fprintf(1, 'Negating the 2nd data record\n');
%NEWadfObj = adfObj;
%NEWadfObj(2) = -NEWadfObj(2);	% negate 2nd data record

%fprintf(1, 'Switching data in records 134 and 135 (due to miswired accels)\n');
%frf134 = adfObj(134).ordinate;
%frf135 = adfObj(135).ordinate;
%NEWadfObj = adfObj;
%NEWadfObj(134).ordinate = (1.01/0.99)*frf135;	% have to correct for accel
%NEWadfObj(135).ordinate = (0.99/1.01)*frf134;	%   sensitivities

nRec = size(adfObj,1);
MeasDesc = 'MC2807, BBN-1238';
fprintf(1, 'Changing Measurement Desciption (IDLine4) from <%s> to <%s>\n',...
  adfObj.IDLine4{1}, MeasDesc);
NEWadfObj = adfObj;
NEWadfObj.IDLine4 = MeasDesc;	% this changes IDLine4 for all 'nRec' records
				%   (since IDLine4 is a <nRec x 1> cell array

%--- MAKE EDITS ABOVE THIS LINE ---------------------------------------
fprintf(1, '\n');

OutFname = ['edit' fname];
% NOTE: writeadf() appends to an existing file instead of replacing it
if exist(OutFname, 'file')
    fprintf('File <%s> already exists.\n', OutFname);
    fprintf('  If you continue, data will be appended to the existing file.\n');
    beep
    ans = input('Do you want to append to the existing file (y or n)? ','s');
    if lower(ans) ~= 'y'
	fprintf('Stopping program - no data was written.\n');
	return
    end
end
writeadf(OutFname, NEWadfObj);
fprintf(1, 'Finished - edited ADF was written to <%s>.\n', OutFname);
return
