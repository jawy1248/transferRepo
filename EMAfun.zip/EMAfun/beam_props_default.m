function props = beam_props_default()
props.E = 30e6; props.nu = 0.28; props.rho = 0.284/(32.2*12);
props.h = 1; props.b = 1; props.nodes = 11;

disp('Using Default Beam Properties:')
disp(props);