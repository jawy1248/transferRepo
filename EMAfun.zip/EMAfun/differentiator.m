function xd=differentiator(x,Sr)
%40 term FIR differentiator
%verified good to within 80% of nyquist
N=40;
b = firpm(N,[0 0.9],[0 0.9*pi*Sr],'d');
xe = x(:);
xe = xe';
xe = [zeros(1,N/2) xe zeros(1,N/2)];
y = filter(b,1,xe);
xd = y(N+1:end);