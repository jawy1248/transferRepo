function [] = plot_FRFandNyqt(w,H,H_fit,title_str,x_label);
% Function which plots magnitude FRFs and a nyquist plot of FRF data, as
% those in step by step plots of AMI
%
% AMI_SubStepPlot(w,H,H_fit,title_str,x_label);
%
%   w = Frequency Vector
%   H = FRF Data
%   H_fit = Fit FRF Data
%   title_str = title for plot
%   x_label = string label for x-axis
%
% Matt Allen - Feb. 21, 2005

figure(1000);
ha1 = subplot(1,2,1);
    semilogy(w,abs(H),'b-'); hold on;  grid on;
    y_lims = get(gca,'Ylim');
    line(w,abs(H_fit),'Marker','.','LineStyle',':','color',[0,0.5,0]);
    line(w,abs(H-H_fit),'color','r');
    title(['\bf',title_str]);
    xlabel(['\bf',x_label]);
    set(gca,'Ylim',ylims);  hold off;
    pos1 = get(ha1,'Position');
% Nyquist Plot:
ha2 = subplot(1,2,2);
    plot(real(H),imag(H),real(H_fit),imag(H_fit)); grid on;
    title('\bfNyquist Plot');
    pos2 = get(ha2,'Position');
set(ha1,'Position',pos1 + [-0.065, 0, 0.2,0]); legend(ha1,'|FRF|','|Fit|','|FRF-Fit|',4);
set(ha2,'Position',pos2 + [0.075,0,0,0]); %legend(ha2,'FRF','Peak','Fit');