function h = springmassmodeshapeplot(nodeloc,wn,phi,modes)
h = figure;
x_plots = ceil(sqrt(length(modes)));
spmat = [x_plots,ceil(length(modes)/x_plots)];
for i_mode = 1:length(modes)
    mode = modes(i_mode);
    subplot(spmat(2),spmat(1),i_mode);
    plot(nodeloc,zeros(size(nodeloc)),'*','Markersize',5);
end