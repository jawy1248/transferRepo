% AFU2MAT - Convert data from an I-DEAS function file (*.afu) to a MATLAB
%   MAT-file.  This is done to put the I-DEAS data into a format that can be
%   read by any copy of MATLAB (i.e., you don't need the IMAT toolbox).
% Has no calling arguments; user is prompted for all inputs.

%=======================================================================
% Required toolboxes/functions that are not part of basic MATLAB:
% - IMAT (I-DEAS to MATLAB translator) functions:
%	getunits(), readadf(), setunits()
%
% MAT-file will store the following MATLAB variables that were previously read
%   from an I-DEAS function file (*.afu):
%	afu		1 x 1			struct array
%	afuFname	1 x N			char array
%	afuUnitSys	1 x 2			char array
%
% 19-Apr-2000, Created (Curt Nelson)
% 15-Mar-2006, Last modified (Curt Nelson)
%=======================================================================

[afuFname,fpath] = uigetfile('*.afu', 'I-DEAS function file (*.afu): ');

%setunits('IN')	% set units for I-DEAS interface to in-lbf-slinch
%setunits('SI')	% set units for I-DEAS interface to m-N-kg

% get the unit system the data will be converted into (*.afu files always store
%   data in SI units) --- if setunits() has not been previously called, then the
%   user will be prompted for a unit system
afuUnitSys = getunits;

afuObj = readadf([fpath,afuFname])

% convert data from *.afu file into a standard MATLAB structure
%	afuObj is "ideas_fn object" class --- requires IMAT
%	afu is "struct array" class --- understood by basic MATLAB
afu = get(afuObj);

%% also save the most-used data as MATLAB variables
%%	afuData		nLines x nRecords	double array (may be complex)
%%	afuFreqHz	nLines x 1		double array
%%	afuFuncType	nRecords x 1		cell array
%%	afuRefInfo	nRecords x 1		cell array
%%	afuRespInfo	nRecords x 1		cell array
%%   where:
%%	nLines = number of frequency lines in each data record
%%	nRecords = number of data records
%afuFreqHz = afu.Abscissa(:,1);
%afuData = afu.Ordinate;
%afuRefInfo = afu.ReferenceCoord;	% sensor location, direction, and sense
%afuRespInfo = afu.ResponseCoord;	% sensor location, direction, and sense
%afuFuncType = afu.FunctionType;

% save data to a binary MAT-file
out_fname = strrep(afuFname, '.afu', '.mat');
fprintf('Saving data (in %s units) to <%s>\n', afuUnitSys, out_fname)
save(out_fname, 'afu', 'afuFname', 'afuUnitSys')

clear fpath out_fname

% use "LOAD filename" to read data from a MAT-file back into MATLAB
