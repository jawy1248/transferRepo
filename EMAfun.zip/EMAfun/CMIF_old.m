% Evaluate Complex Mode Indicator Function (CMIF) for Frame:

clear all; close all;

% Load Data--Frequency Sweep Data
load Frame_tfs_V2a_F1_02.mat
    Gj1 = fresp_clean_trunc.';
    Gj1_noisy = fresp_noisy_trunc.';
load Frame_tfs_V2a_F3_02.mat
    Gj3 = fresp_clean_trunc.';
    Gj3_noisy = fresp_noisy_trunc.';
    ws = wk_trunc;
    
for ii = 1:1:length(ws);
    G(1:15,1:2,ii) = [Gj1(:,ii) Gj3(:,ii)];
end

Gcomp = Gj1(1,:) + Gj3(3,:);

% CMIF Routine
for ii = 1:1:length(G)
    frf_svd(:,ii) = svd(G(:,:,ii));
end

figure(2)
semilogy(ws,abs(Gcomp),ws,abs(frf_svd(1,:)), ws,abs(frf_svd(2,:))); grid on;
xlabel('Frequency');
legend('P1_temp', 'SV1', 'SV2');

% Note that CMIF doesn't work well on the Frame Problem because of spatial aliasing.

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Alternate Form %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Load Data--Frequency Sweep Data
% load Frame_tfs_M1.mat
% x1 = tresp;
% load Frame_tfs_M2.mat
% x2 = tresp;
% Nt=2^15; T=14.2; delta=T/Nt;
% t=[0:delta:T-delta];
% 
% for ii = 1:1:15
%     [P1_temp, fs] = psd(x1(ii,:),2^15,1/delta);
%     [P2_temp, fs] = psd(x2(ii,:),2^15,1/delta);    
%         for k = 1:7007;%length(Pxy_temp);
%             Pxy(ii,1:2,k) = [P1_temp(k) P2_temp(k)];
%         end
% end
% 
% ws = fs(1:7007)*2*pi;
% figure(1);
% semilogy(ws,rs3d2col(Pxy(1,1,:)),ws,rs3d2col(Pxy(2,2,:)),ws,rs3d2col(Pxy(1,2,:))); grid on;
% % for ii = 1:1:length(Pxy) % Form composite PSD?
% %     Pcomp = trace(Pxy(:,:,ii));
% % end
% 
% save Frame_PSDdata.mat Pxy ws
% 
% %load Frame_PSDdata.mat
% 
% % CMIF Routine
% for ii = 1:1:length(Pxy)
%     psd_svd(:,ii) = svd(Pxy(:,:,ii));
% end
% 
% figure(2)
% semilogy(ws,rs3d2col(Pxy(1,1,:)),ws,psd_svd(1,:), ws,psd_svd(2,:)); grid on;
% xlabel('Frequency');
% legend('P1_temp', 'SV1', 'SV2');