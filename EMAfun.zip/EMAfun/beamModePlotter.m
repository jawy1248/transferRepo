function p = beamModePlotter( nodedef, beam_cs, phi, DOF_order, DOF_scale,...
    drawtype,nummodes,varargin)
%beamModePlotter A function that draws a beam for a given modeshape.
%
% beamModePlotter(nodedef,beam_cs,phi,DOF_order,DOF_scale,drawtype,...
%       nummodes,C,v,edgecolor,facecolor,alpha);
% 
%
% This function plots a beam given modeshapes.  Input arguments are:
%
% nodedef: The original position of the beam's nodes.  Output from
%          beamkm_ur function can be used here.  Columns 1,2,3 are x,y,z
%          coords, respectively.  Each row is a specific node.
%
% beam_cs: This is a subsystem for designating beam geometry.  Can assign
%          to .b (base) and .h (height) for rectangular cross sections.
%          Also define .dirdef(i,1:3) as the bending direction 1 for node
%          i.  If undefined, .dirdef will be automatically assigned to
%
% phi:     Phi is the modeshapes of the beam passed in.  Each column is a
%          mode, each row is that DOF's displacement in each mode.
%
% DOF_order: Pass in the ordering of the phi matrix.  Should be a 3-vector,
%            with components ordered:
%               [extension, bend_axis_1, bend_axis_2, torsion, theta_1,
%               theta_2]
%            If any DOF doesn't exist, leave that as zero.
%
% DOF_scale: As the mode shapes are accurate to within a scalar multiple, a
%            maximum value may be set to ensure the DOF isn't plotted
%            unphysically, i.e. to keep all of the mode sizes small.  Same
%            indices as before.  0.01 is a good starting point for all
%            modes.
%
% drawtype: A string to determine what is drawn.  Examples are 'point', 'line'
%           or '3D'.
%
% nummodes: The modes to plot.  If only one is specified, it plots to the
%           current figure.  If more than one is specified, it creates a
%           new figure per plot
%
% optional arguments:
%     C: A 3x3 rotation matrix to rotate the beam.
%     v: A 3-vector translation matrix to move the beam.  Rotation is
%        performed before translation.
%     edgecolor: a 3-vector specifying RGB color of the edges.
%     facecolor: a 3-vector specifying RGB color of the faces.
%     alpha: A 1-vector or 2-vector specifying the transparency of the
%        faces and edges at once (1-vector) or independently (2-vector).
%        If it is a 2-vector, the first index specifies face alpha and the
%        second specifies edge alpha.
%
% The deformations drawn here are decoupled, and only good for small
% displacements.
%
% Dan Rohe, 9-22-2011;

% No error checking yet... :(


if ~isempty(varargin)>0 && sum(size(varargin{1})==[3,3])==2
    C = varargin{1};
else
    C = eye(3);
end



if length(varargin)>1 && sum(size(varargin{2})==[3,1]) == 2
    t = varargin{2};
else
    t = zeros(3,1);
end

if length(varargin)>3 && length(varargin{4}) == 3
    fc=varargin{4};
else
    fc = [1,0,0];
end

if length(varargin)>2 && length(varargin{3}) == 3
    lc = varargin{3};
else
    lc = fc/2;
end


if length(varargin)>4 && length(varargin{5}) == 1
    falpha = varargin{5};
    ealpha = varargin{5};
elseif length(varargin)>4 && length(varargin{5})==2
    falpha = varargin{5}(1);
    ealpha = varargin{5}(2);
else
    falpha = 1;
    ealpha = 1;
end

% Parse Geometry
h = beam_cs.h;
b = beam_cs.b;

nnodes = size(nodedef,1);
nDOFs = 6;

% Discover Degrees of Freedom
% Extension about uniaxial
if DOF_order(1) == 0;
    extensions = zeros(nnodes,length(nummodes));
    nDOFs = nDOFs - 1;
end
% Bending about axis 1
if DOF_order(2) == 0;
    bend1s = zeros(nnodes,length(nummodes));
    nDOFs = nDOFs - 1;
end
% Bending about axis 2
if DOF_order(3) == 0;
    bend2s = zeros(nnodes,length(nummodes));
    nDOFs = nDOFs - 1;
end
% Torsional Rotation
if DOF_order(4) == 0;
    torss = zeros(nnodes,length(nummodes));
    nDOFs = nDOFs - 1;
end
% Rotation about axis 1
if DOF_order(5) == 0;
    rot1 = zeros(nnodes,length(nummodes));
    nDOFs = nDOFs - 1;
end
% Rotation about axis 2
if DOF_order(6) == 0;
    rot2 = zeros(nnodes,length(nummodes));
    nDOFs = nDOFs - 1;
end

% Get the modeshapes that exist
% Extension about uniaxial
if DOF_order(1) ~= 0;
    extensions = phi(DOF_order(1):nDOFs:end,nummodes);
    extensions = extensions*DOF_scale(1);%/(max(max(abs(extensions)))/DOF_scale(1));
end
% Bending about axis 1
if DOF_order(2) ~= 0;
    bend1s = phi(DOF_order(2):nDOFs:end,nummodes);
    bend1s = bend1s*DOF_scale(2);%/(max(max(abs(bend1s)))/DOF_scale(2));
end
% Bending about axis 2
if DOF_order(3) ~= 0;
    bend2s = phi(DOF_order(3):nDOFs:end,nummodes);
    bend2s = bend2s*DOF_scale(3);%/(max(max(abs(bend2s)))/DOF_scale(3));
end
% Torsional Rotation
if DOF_order(4) ~= 0;
    torss = phi(DOF_order(4):nDOFs:end,nummodes);
    torss = torss*DOF_scale(4);%/(max(max(abs(torss)))/DOF_scale(4));
end
% Rotation about axis 1
if DOF_order(5) ~= 0;
    rot1 = phi(DOF_order(5):nDOFs:end,nummodes);
    rot1 = rot1*DOF_scale(5);%/(max(max(abs(rot1)))/DOF_scale(5));
end
% Rotation about axis 2
if DOF_order(6) ~= 0;
    rot2 = phi(DOF_order(6):nDOFs:end,nummodes);
    rot2 = rot2*DOF_scale(6);%/(max(max(abs(rot2)))/DOF_scale(6));
end

if ~isfield(beam_cs,'dirdef')
    dirdef = [ones(nnodes-1,1),zeros(nnodes-1,2)];
else
    dirdef = beam_cs.dirdef;
end

for k = 1:length(nummodes)
    if length(nummodes)>1
        figure;
    end
    mode = nummodes(k);
    
    % Loop through each node;
    theta = atan(b/h);
    radius = sqrt((b/2)^2+(h/2)^2);
    
    for i = 1:nnodes
        if i < nnodes
            dx(i,:) = nodedef(i+1,:)-nodedef(i,:);
            d1(i,:) = dx(i,:)/norm(dx(i,:));
            d2(i,:) = dirdef(i,:)/norm(dirdef(i,:));
            d3(i,:) = cross(d1(i,:),d2(i,:));
        else
            d1(i,:) = d1(i-1,:);
            d2(i,:) = d2(i-1,:);
            d3(i,:) = d3(i-1,:);
        end
        nodecenter(i,:) = nodedef(i,:)+extensions(i,k)*d1(i,:)-bend1s(i,k)*d3(i,:)+bend2s(i,k)*d2(i,:);
        nodecoord(i,1,:) = nodecenter(i,:)...
            + -radius*sin(theta+torss(i,k))*d2(i,:)...
            + radius*cos(theta+torss(i,k))*d3(i,:)...
            + radius*(sin(theta)*sin(rot2(i,k))+cos(theta)*sin(rot1(i,k)))*d1(i,:);
        nodecoord(i,2,:) = nodecenter(i,:)...
            + -radius*sin(theta-torss(i,k))*d2(i,:)...
            + -radius*cos(theta-torss(i,k))*d3(i,:)...
            + radius*(sin(theta)*sin(rot2(i,k))-cos(theta)*sin(rot1(i,k)))*d1(i,:);
        nodecoord(i,3,:) = nodecenter(i,:)...
            + radius*sin(theta+torss(i,k))*d2(i,:)...
            + -radius*cos(theta+torss(i,k))*d3(i,:)...
            + radius*(-sin(theta)*sin(rot2(i,k))-cos(theta)*sin(rot1(i,k)))*d1(i,:);
        nodecoord(i,4,:) = nodecenter(i,:)...
            + radius*sin(theta-torss(i,k))*d2(i,:)...
            + radius*cos(theta-torss(i,k))*d3(i,:)...
            + radius*(-sin(theta)*sin(rot2(i,k))+cos(theta)*sin(rot1(i,k)))*d1(i,:);
        for j = 1:4
            temp(:,1,1) = nodecoord(i,j,:);
            nodecoord(i,j,:) = C*temp+t;
        end
        temp(:,1,1) = nodecenter(i,:);
        nodecenter(i,:) = C*temp+t;
    end
    
    
    if strcmp(drawtype,'point')
        hold on;
        title(['Mode Shape ',num2str(mode)]);
        for i = 1:nnodes
            for j = 1:4
                p = plot3(nodecoord(i,j,1),nodecoord(i,j,2),nodecoord(i,j,3),'k.');
                text(nodecoord(i,j,1),nodecoord(i,j,2),nodecoord(i,j,3),num2str(j));
                quiver3(nodecenter(i,1),nodecenter(i,2),nodecenter(i,3),...
                    0.1*d1(i,1),0.1*d1(i,2),0.1*d1(i,3),'b');
                quiver3(nodecenter(i,1),nodecenter(i,2),nodecenter(i,3),...
                    0.1*d2(i,1),0.1*d2(i,2),0.1*d2(i,3),'g');
                quiver3(nodecenter(i,1),nodecenter(i,2),nodecenter(i,3),...
                    0.1*d3(i,1),0.1*d3(i,2),0.1*d3(i,3),'r');
            end
        end
    elseif strcmp(drawtype,'line');
        hold on;
        title(['Mode Shape ',num2str(mode)]);
        for i = 1:nnodes
            for j = 1:3
                p = plot3([nodecoord(i,j,1),nodecoord(i,j+1,1)],...
                    [nodecoord(i,j,2),nodecoord(i,j+1,2)],...
                    [nodecoord(i,j,3),nodecoord(i,j+1,3)],'k');
                if i ~= nnodes
                    p = plot3([nodecoord(i,j,1),nodecoord(i+1,j,1)],...
                        [nodecoord(i,j,2),nodecoord(i+1,j,2)],...
                        [nodecoord(i,j,3),nodecoord(i+1,j,3)],'k');
                end
            end
            p = plot3([nodecoord(i,4,1),nodecoord(i,1,1)],...
                [nodecoord(i,4,2),nodecoord(i,1,2)],...
                [nodecoord(i,4,3),nodecoord(i,1,3)],'k');
            if i ~= nnodes
                p = plot3([nodecoord(i,4,1),nodecoord(i+1,4,1)],...
                    [nodecoord(i,4,2),nodecoord(i+1,4,2)],...
                    [nodecoord(i,4,3),nodecoord(i+1,4,3)],'k');
            end
        end
    elseif strcmp(drawtype,'3D');
        hold on;
        lighting phong;
        title(['Mode Shape ',num2str(mode)]);
        for i = 1:nnodes-1
            % The Cross Section
            p = patch(...
                [nodecoord(i,1,1),nodecoord(i,2,1),nodecoord(i,3,1),nodecoord(i,4,1)],...
                [nodecoord(i,1,2),nodecoord(i,2,2),nodecoord(i,3,2),nodecoord(i,4,2)],...
                [nodecoord(i,1,3),nodecoord(i,2,3),nodecoord(i,3,3),nodecoord(i,4,3)],...
                [1,0,0]);
            set(p,'EdgeColor',lc);
            set(p,'FaceColor',fc);
            set(p,'FaceAlpha',falpha);
            set(p,'EdgeAlpha',ealpha);
            % Other Faces Faces
            p = patch(...
                [nodecoord(i,1,1),nodecoord(i,2,1),nodecoord(i+1,2,1),nodecoord(i+1,1,1)],...
                [nodecoord(i,1,2),nodecoord(i,2,2),nodecoord(i+1,2,2),nodecoord(i+1,1,2)],...
                [nodecoord(i,1,3),nodecoord(i,2,3),nodecoord(i+1,2,3),nodecoord(i+1,1,3)],...
                [1,0,0]);
            set(p,'EdgeColor',lc);
            set(p,'FaceColor',fc);
            set(p,'FaceAlpha',falpha);
            set(p,'EdgeAlpha',ealpha);
            p = patch(...
                [nodecoord(i,2,1),nodecoord(i,3,1),nodecoord(i+1,3,1),nodecoord(i+1,2,1)],...
                [nodecoord(i,2,2),nodecoord(i,3,2),nodecoord(i+1,3,2),nodecoord(i+1,2,2)],...
                [nodecoord(i,2,3),nodecoord(i,3,3),nodecoord(i+1,3,3),nodecoord(i+1,2,3)],...
                [1,0,0]);
            set(p,'EdgeColor',lc);
            set(p,'FaceColor',fc);
            set(p,'FaceAlpha',falpha);
            set(p,'EdgeAlpha',ealpha);
            p = patch(...
                [nodecoord(i,3,1),nodecoord(i,4,1),nodecoord(i+1,4,1),nodecoord(i+1,3,1)],...
                [nodecoord(i,3,2),nodecoord(i,4,2),nodecoord(i+1,4,2),nodecoord(i+1,3,2)],...
                [nodecoord(i,3,3),nodecoord(i,4,3),nodecoord(i+1,4,3),nodecoord(i+1,3,3)],...
                [1,0,0]);
            set(p,'EdgeColor',lc);
            set(p,'FaceColor',fc);
            set(p,'FaceAlpha',falpha);
            set(p,'EdgeAlpha',ealpha);
            p = patch(...
                [nodecoord(i,4,1),nodecoord(i,1,1),nodecoord(i+1,1,1),nodecoord(i+1,4,1)],...
                [nodecoord(i,4,2),nodecoord(i,1,2),nodecoord(i+1,1,2),nodecoord(i+1,4,2)],...
                [nodecoord(i,4,3),nodecoord(i,1,3),nodecoord(i+1,1,3),nodecoord(i+1,4,3)],...
                [1,0,0]);
            set(p,'EdgeColor',lc);
            set(p,'FaceColor',fc);
            set(p,'FaceAlpha',falpha);
            set(p,'EdgeAlpha',ealpha);
        end
        p = patch(...
            [nodecoord(end,1,1),nodecoord(end,2,1),nodecoord(end,3,1),nodecoord(end,4,1)],...
            [nodecoord(end,1,2),nodecoord(end,2,2),nodecoord(end,3,2),nodecoord(end,4,2)],...
            [nodecoord(end,1,3),nodecoord(end,2,3),nodecoord(end,3,3),nodecoord(end,4,3)],...
            [1,0,0]);
        set(p,'EdgeColor',lc);
        set(p,'FaceColor',fc);
        set(p,'FaceAlpha',falpha);
        set(p,'EdgeAlpha',ealpha);
    end
    view(60,10);
    axis equal
    
end