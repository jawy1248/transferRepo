function [M,K,C,names] = springmassdamper(M_vect,K_vect,C_vect,modalflag)
    if length(K_vect)~= length(C_vect)
        error('Improper Vector Lengths, len(K) ~= len(C)');
    end
    if length(K_vect)~=length(M_vect)+1
        error('Improper Vector Lengths, len(K) ~= len(M)+1');
    end
    
    N = length(M_vect);
M = zeros(N); % Mass matrix
K = zeros(N); % Stiffness Matrix
C = zeros(N); % Damping Matrix

%Generate Names
for i = 1:N
    names{i,1} = ['x',num2str(i)];
end

% Generate Mass Matrix
for i = 1:N
    M(i,i) = M_vect(i);
end

% Generate stiffness and damping matrices
K(1,1) = K_vect(1)+K_vect(2);
C(1,1) = C_vect(1)+C_vect(2);

if N ~= 1
    K(1,2) = -1*K_vect(2);
    K(end,end) = K_vect(end)+K_vect(end-1);
    K(end,end-1) = -1*K_vect(end-1);
    C(1,2) = -1*C_vect(2);
    C(end,end) = C_vect(end)+C_vect(end-1);
    C(end,end-1) = -1*C_vect(end-1);
end

for i = 2:N-1
    K(i,i) = K_vect(i)+K_vect(i+1);
    K(i,i+1) = -1*K_vect(i+1);
    K(i,i-1) = -1*K_vect(i);
    C(i,i) = C_vect(i)+C_vect(i+1);
    C(i,i+1) = -1*C_vect(i+1);
    C(i,i-1) = -1*C_vect(i);
end

%% Determine Eigenvalues and Eigenvectors
[phi,lam] = eig(K,M);

% Mass normalize Eigenvectors
Phi = zeros(size(phi));
for i = 1:N
    Phi(:,i) = phi(:,i)/sqrt(phi(:,i).'*M*phi(:,i));
end

wn = sqrt(diag(lam));

M_hat = Phi.'*M*Phi;
K_hat = Phi.'*K*Phi;
C_hat = Phi.'*C*Phi;

zt = diag(C_hat)./(2*wn);
Zt = C_hat.*eye(N);

if modalflag
    M = Phi;
    K = wn;
    C = zt;
end

end