function [Dm,Kj] = iwan_DKvsQ(q0,wd,params,varargin)
% Function which estimates Dissipation (D) and Stiffness (K) versus modal
% displacement amplitude for a modal iwan model.
%
% [Dm,Kj] = iwan_DKvsQ(q0,wd,params)
% [Dm,Kj] = iwan_DKvsQ(q0,wd,params,C)
%
% q0 - is a vector of modal displacement amplitudes
% wd - corresponding vector of oscillation frequency (versus amplitude)
% params - parameters of the modal iwan joint
%   params = [Fs, Kt, chi, beta]
%
% Optional inputs:
% C - modal damping constant when the Iwan joint is fixed C=2*zt*wn

if nargin > 3;
    C=varargin{1};
else
    C=0;
end

Fs = params(1); Kt = params(2); chi = params(3); beta = params(4);

[~, phi_max,R, S]=iwanconvert(Fs,Kt,chi,beta);
% phi_max = Fs*(1+beta)/(Kt*(beta+(chi+1)/(chi+2)));
% R = Fs*(chi+1)/(phi_max^(chi+2)*(beta+(chi+1)/(chi+2)));
r = abs(q0)*Kt*(beta+(chi+1)/(chi+2))/(Fs*(1+beta));
% minmax(r)

Dm = zeros(size(q0));
Kj = zeros(size(q0));
for k = 1:length(q0)
    if abs(q0(k))< phi_max; %F(k) < Fs
        Dm(k) = 4*R*abs(q0(k)).^(chi+3)/((chi+3)*(chi+2)) + pi*wd(k)*C*abs(q0(k)).^2;
        Kj(k) = Kt*(1-r(k).^(chi+1)/((chi+2)*(beta+1)));
        % Note, shouldn't need to supply an external wd - that should come
        % from Kj - compute that first then use it to add the viscous
        % damping term.
    else
        Dm(k) = abs(4*q0(k)*Fs) + pi*wd(k)*C*abs(q0(k)).^2;
        Kj(k) = 0;
    end
end

return