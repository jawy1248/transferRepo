function [STM,STMdot,At_est,Ls_t0] = ltpRes2STM_Int2x(lam,B,mB,TA,ts_cyc)
%
% warning('This function has been replaced.  Instead Use:');
% warning('[STM,STMdot,At_est,Ls_t0] = ltpRes2STM(lam,B,mB,TA,ts_cyc,''A'')')

%
% Computes STM using measured residues of LTP system, assuming that all of
% the displacement states are measured, using the method presented in:
%   M. S. Allen, "Frequency-Domain Identification of Linear Time-Periodic
%   Systems using LTI Techniques," Journal of Computational and Nonlinear 
%   Dynamics vol. 4, 24 Aug. 2009.
%
% [STM,STMdot,At_est,Ls_t0] = ltpRes2STM(lam,B,mB,TA,ts_cyc)
%
% lam : a vector containing N_modes natural frequencies
% B, mB : are size No x N_FSE x N_modes, where
%   - B(i,j,k) is the jth Fourier coefficients of the kth mode for the ith
%   output.
%   - mB(i,j,k) is the index of that Fourier coefficient
% TA : the fundamental period of the system
% ts_cyc : the time vector of the system over the fundamental period.  The
% state matrix At_est is estimated at each instant in ts_cyc.
%
% This function assumes that lam, B and mB do not include complex
% conjugates, so the function expands them to add the complex conjugates.
% This also presumes that only displacements have been measured, so the
% estimated response model is differentiated to obtain the STM and A(t).
%
% Matt Allen, Oct, 2008, Latest Rev: Dec. 2009
% msallen@engr.wisc.edu

warning('This function has been replaced.  Instead Use:');
warning('[STM,STMdot,At_est,Ls_t0] = ltpRes2STM(lam,B,mB,TA,ts_cyc,''A'')')

% Add error checking - lam is a vector, B, mB sizes, etc...

if length(lam) ~= numel(lam); error('lam is not a vector'); end
if length(lam) ~= size(B,3) || length(lam) ~= size(mB,3);
    disp('Size lam, B, mB'); size(lam), size(B), size(mB)
    error('Sizes of lam, B and mB are not consistent')
end

wA = 2*pi/TA;
Nss = 2*length(lam);

% Integrate twice - accel measurement in, find velo and disp
% ICmat_bot = ltpRespFS(lam,B,mB,wA,[],[],[0:(Nss-1)]*TA);
    Bint = ltpIntFS(B,mB,wA,lam);
    ICmat_bot = ltpRespFS(lam,Bint,mB,wA,[],[],[0:(Nss-1)]*TA);
    Bint2x = ltpIntFS(Bint,mB,wA,lam); % now displacement
    ICmat_top = ltpRespFS(lam,Bint2x,mB,wA,[],[],[0:(Nss-1)]*TA);
    ICmat = [ICmat_top; ICmat_bot];
ICmat_inv = inv(ICmat); % check for cond # warnings.
    % Could modify to try to improve cond # if needed.

% Compute Modal Participation Factors
lam_ss = [lam; conj(lam)]; % SS = state space
B_ss = zeros(size(B,1),size(B,2),2*size(B,3));
Bint_ss = zeros(size(B,1),size(B,2),2*size(B,3));
mB_ss = zeros(size(mB,1),size(mB,2),2*size(mB,3));
for k = 1:length(lam);
    B_ss(:,:,k) = Bint(:,:,k);
    B_ss(:,:,k+size(B,3)) = conj(Bint(:,:,k));
        Bint_ss(:,:,k) = Bint2x(:,:,k);
        Bint_ss(:,:,k+size(B,3)) = conj(Bint2x(:,:,k));
    mB_ss(:,:,k) = mB(:,:,k);
    mB_ss(:,:,k+size(B,3)) = -mB(:,:,k); % indices - conj = negative
end

% Find modal participation factors
Ls_t0 = zeros(Nss,Nss);
Us_t0 = zeros(Nss,Nss);
for m_num = 1:Nss;
    Ls_t0(:,m_num) = (exp(lam_ss(m_num)*[0:(Nss-1)]*TA)*ICmat_inv).';
    Us_t0(:,m_num) = [sum(Bint_ss(:,:,m_num),2); ... % disp portion
        sum(B_ss(:,:,m_num),2)]; % veloc portion
end

% Compute STM and (d/dt)STM
STM = ltpRespFS(lam,Bint2x,mB,wA,Ls_t0(:,1:length(lam)),eye(Nss),ts_cyc,'expand');
% Bdiff = ltpDiffFS(Bint,mB,wA,lam);
STMdot = ltpRespFS(lam,Bint,mB,wA,Ls_t0(:,1:length(lam)),eye(Nss),ts_cyc,'expand');

At_est = zeros(size(STM));
for k = 1:length(ts_cyc)
    At_est(:,:,k) = STMdot(:,:,k)*inv(STM(:,:,k));
end
