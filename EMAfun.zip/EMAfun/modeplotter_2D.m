function p = modeplotter_2D(nodedef,xmode,ymode,varargin)
%modeplotter_2D A modeshape plotter that will plot displacement in x and y
%   Given a node definition, along with x and y displacements, it will plot
%   the mode shapes.  This will be more computationally efficient than
%   drawing patches.
%   
%   nodedef should be a 2D matrix where each row is an ordered pair (X,Y)
%   where the node is located.
%   
%   xmode should be the x 

if isempty(xmode) || isempty(ymode)
    p = [];
    return;
end

if ~isempty(varargin)
    lnspc = varargin{1};
else
    lnspc = '';
end

p = plot(nodedef(:,1)+xmode(:), nodedef(:,2)+ymode(:),lnspc);

end