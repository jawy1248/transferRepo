% PLOT_AFU - Plot data records from 1 or more files containing I-DEAS function
%   data.  The data can be read from either I-DEAS function files (*.afu) or
%   MATLAB MAT-files (*.mat).
% Has no calling arguments; user is prompted for all inputs.

% For multiple files, can choose records in 3 ways:
% - choose among all records in every file
% - choose the same record number in every file
% - choose the same record type, ref, resp in every file (PROGRAM DOES THIS)
%=======================================================================
% Required toolboxes/functions that are not part of basic MATLAB:
% - if the data is read from a *.afu file, this code requires the following
%   IMAT (I-DEAS to MATLAB translator) functions:
%	getunits(), readadf(), setunits()
% - if FRFs are plotted, this code requires the following functions:
%	plotFRF()
%
% 10-Nov-2000, Created (Curt Nelson)
% 22-Apr-2006, Last modified (Curt Nelson)
%=======================================================================
clear all
[namekk,fpath,iFilter] = uigetfile( ...
  { '*.afu;*.mat', 'I-DEAS function file data (*.afu, *.mat)'; ...
    '*.afu', 'I-DEAS function files (*.afu)'; ...
    '*.mat', 'MATLAB MAT-files (*.mat)' }, ...
  'Files containing I-DEAS function data to plot:', ...
  'MultiSelect', 'on');
if isequal(namekk,0)
    fprintf(1, 'Program finished.  Have a nice day!\n');
    return
end
namekk = cellstr(namekk);
nFiles = size(namekk, 2);

for kk = 1:nFiles
    name = namekk{kk};

    iFileType = iFilter;
    if iFilter == 1	% find out which file type was selected
	if ~isempty(strfind(lower(name), '.afu'))
	    iFileType = 2;
	elseif ~isempty(strfind(lower(name), '.mat'))
	    iFileType = 3;
	else
	    error(['File <' name '> has an unknown extension.'])
	end
    end
    if iFileType == 2	% I-DEAS function file (*.afu)
%	setunits('IN');	% set units for I-DEAS interface to in-lbf-slinch
	setunits('SI');	% set units for I-DEAS interface to m-N-kg
	afu = readadf([fpath name]);

	afuFname = name;
	afuUnitSys = getunits;
    elseif iFileType == 3	% MATLAB MAT-file (*.mat)
	load([fpath name])

	iExist = 1;
	iExist = iExist*exist('afu', 'var');
	iExist = iExist*exist('afuFname', 'var');
	iExist = iExist*exist('afuUnitSys', 'var');
	if iExist == 0
	    beep
	    fprintf(1, 'ERROR: <%s> does not contain required data.\n', name);
	    return	% stop the program
	end
    else
	return	% stop the program
    end
    afuFreqHz = afu.Abscissa(:,1);
    afuData = afu.Ordinate;
    afuRefInfo = afu.ReferenceCoord;	% sensor location, direction, and sense
    afuRespInfo = afu.ResponseCoord;	% sensor location, direction, and sense
    afuFuncType = afu.FunctionType;
    clear afu iExist name
    if kk == 1
	UnitSys = afuUnitSys;
	FreqHz = afuFreqHz;
	minFreqHz = min(afuFreqHz);
	maxFreqHz = max(afuFreqHz);
    end
    minFreqHz = min(minFreqHz, min(afuFreqHz));
    maxFreqHz = max(maxFreqHz, max(afuFreqHz));
    if afuUnitSys ~= UnitSys
	error('All files must use the same unit system.')
    end

% The following MATLAB variables are required:
%	afuData		nLines x nRecords	double array (may be complex)
%	afuFname	1 x N			char array
%	afuFreqHz	nLines x 1		double array
%	afuFuncType	nRecords x 1		cell array
%	afuRefInfo	nRecords x 1		cell array
%	afuRespInfo	nRecords x 1		cell array
%	afuUnitSys	1 x 2			char array
%   where:
%	nLines = number of frequency lines in each data record
%	nRecords = number of data records

    nLines = size(afuData,1);
    nRecords = size(afuRespInfo, 1);	% number of data records in file
    fprintf(1, 'Read %d data records originally from file <%s>.\n', nRecords,...
      afuFname);
    fprintf(1, '  Each record has data at %d freq lines from %g to %g Hz.\n',...
      nLines, afuFreqHz(1), afuFreqHz(end));

    Fname(:,kk) = {afuFname};
    nLineskk(kk) = nLines;
    nRecordskk(kk) = nRecords;
    FreqHz(1:nLines,kk) = afuFreqHz;
    Data(1:nLines,1:nRecords,kk) = afuData;
    RefInfo(1:nRecords,kk) = afuRefInfo;
    RespInfo(1:nRecords,kk) = afuRespInfo;
    FuncType(1:nRecords,kk) = afuFuncType;
end

% find what types of data records are contained in the first file
iFile = 1;	% select data records to plot using only the first file
nRecType = 0;
for ii = 1:nRecordskk(iFile)
    iFoundType = 0;
    for jj = 1:nRecType
	if strcmp(FuncType{ii,iFile}, TypeStr{jj}) == 1
	    nRecOfType(jj) = nRecOfType(jj) + 1;
	    iIndex(jj,nRecOfType(jj)) = ii;
	    iFoundType = 1;
	end
    end
    if iFoundType == 0	% found a new FunctionType
	nRecType = nRecType + 1;
	TypeStr(nRecType) = FuncType(ii,iFile);
	nRecOfType(nRecType) = 1;
	iIndex(nRecType,nRecOfType(nRecType)) = ii;
    end
end
fprintf(1, 'Found %d types of records in file <%s>.\n', nRecType, Fname{iFile});

% select the desired FunctionType to plot
if nRecType == 1	% only one FunctionType; don't need to ask user
    PlotFuncType = strtrim(TypeStr{1});
    iPlotType = 1;
else			% multiple FunctionTypes; select desired one from list
    [iSelect, ok] = listdlg('PromptString', 'FunctionType to Plot',...
      'SelectionMode', 'single',...
      'CancelString', 'Quit',...
      'ListString', TypeStr);
    if ok ~= 1
	fprintf(1, 'Program finished.  Have a nice day!\n');
	return
    end
    PlotFuncType = strtrim(TypeStr{iSelect});
    iPlotType = iSelect;
end

if nFiles > 1
    fprintf(1, ['\nSelect records to plot from those in the first file, then'...
      ' the program will\n  identify and also plot matching records from the'...
      ' other %d file(s).\n'], nFiles-1)
end
fprintf(1, 'Plot records of type <%s>; %d records are available.\n',...
  PlotFuncType, nRecOfType(iPlotType))

LineColor = 'rgbcmykrgbcmyk';
nColors = size(LineColor, 2);
while 1
    % select the desired records of type FunctionType to plot (in first file)
    if nRecOfType(iPlotType) == 1	% only 1 record; don't need to ask user
	iRec = iIndex(iPlotType,1);
	iSelect = 1;
    else			% multiple records; select desired one from list
	for ii = 1:nRecOfType(iPlotType)
	    RecStr(ii) = {sprintf('%d: ref %s, resp %s',...
	      iIndex(iPlotType,ii), RefInfo{iIndex(iPlotType,ii),iFile},...
	      RespInfo{iIndex(iPlotType,ii),iFile})};
	end
	[iSelect, ok] = listdlg('PromptString', 'Select Records to Plot',...
	  'SelectionMode', 'multiple',...
	  'Name', PlotFuncType,...
	  'CancelString', 'Quit',...
	  'ListString', RecStr);
	if ok ~= 1
	    fprintf(1, 'Program finished.  Have a nice day!\n');
	    return
	end
    end
    clear FreqData Legends PlotData	% needed when number of plotted lines is reduced
    nPlot = length(iSelect);
    if nFiles*nPlot > nColors
	error(sprintf(...
	  'Trying to plot %d lines which is more than the maximum of %d.',...
	  nFiles*nPlot, nColors))
    end
    for ii = 1:nPlot
	iRec = iIndex(iPlotType,iSelect(ii));
	fprintf('\t%d\treference %s, response %s\n', iRec, ...
	  RefInfo{iRec,iFile}, RespInfo{iRec,iFile})
	LegendStr = sprintf('Ref %s, Resp %s (Rec %d of %d in <%s>)', ...
	  RefInfo{iRec,iFile}, RespInfo{iRec,iFile}, iRec, nRecords, ...
	  Fname{iFile});
	PlotData(:,ii) = Data(:,iRec,iFile);
	FreqData(:,ii) = FreqHz(:,iFile);
	Legends(ii) = {LegendStr};
	for kk = 2:nFiles	% find matching records in each file
	    if kk == 2
		fprintf(['\t\tFind matching %s records in the other files...'...
		  '\n'], PlotFuncType);
	    end
	    iFound = 0;
	    for jj = 1:nRecordskk(kk)
		if strcmp(TypeStr{iPlotType}, FuncType(jj,kk)) == 1
		    if strcmp(RefInfo{jj,kk}, RefInfo{iRec,iFile}) == 1
			if strcmp(RespInfo{jj,kk}, RespInfo{iRec,iFile}) == 1
			    iFound = 1;
			    LegendStr = sprintf(['Ref %s, Resp %s (Rec %d o'...
			      'f %d in <%s>)'], RefInfo{jj,kk}, ...
			      RespInfo{jj,kk}, jj, nRecordskk(kk), Fname{kk});
			    PlotData(:,ii+((kk-1)*nPlot)) = Data(:,jj,kk);
			    FreqData(:,ii+((kk-1)*nPlot)) = FreqHz(:,kk);
			    Legends(ii+((kk-1)*nPlot)) = {LegendStr};
			    fprintf('\t\t%d\treference %s, response %s\n', ...
			      jj, RefInfo{jj,kk}, RespInfo{jj,kk})
			end
		    end
		end
	    end
	    if iFound == 0
		error(['Did not find matching record for file ' num2str(kk)])
	    end
	end
    end
   
    TitleStr = ['I-DEAS Function Data (' UnitSys ' unit system)'];
    if strcmp('Frequency Response Function', TypeStr{iPlotType}) == 1
	if strcmp(UnitSys, 'IN') == 1
	    plotFRF(11, FreqData, PlotData, TitleStr, Legends, '(in/s^2)/lbf')
	elseif strcmp(UnitSys, 'SI') == 1
	    plotFRF(11, FreqData, PlotData, TitleStr, Legends, '(m/s^2)/N')
	else
	    plotFRF(11, FreqData, PlotData, TitleStr, Legends, '(D/s^2)/F')
	end
    else
	if strcmp('Auto Spectrum', TypeStr{iPlotType}) == 1
	    for kk = 1:nFiles
		for jj = 1:nPlot
		    semilogy(FreqHz(1:nLineskk(kk),kk), ...
		      PlotData(1:nLineskk(kk),(kk-1)*nPlot+jj), ...
		      LineColor((kk-1)*nPlot+jj))
		    if (kk == 1) & (jj == 1)
			hold on
		    end
		end
	    end
	    hold off
	    ylabel('Auto Spectrum [EU^2/Hz]')
	else
	    for kk = 1:nFiles
		for jj = 1:nPlot
		    plot(FreqHz(1:nLineskk(kk),kk), ...
		      PlotData(1:nLineskk(kk),(kk-1)*nPlot+jj), ...
		      LineColor((kk-1)*nPlot+jj))
		    if (kk == 1) & (jj == 1)
			hold on
		    end
		end
	    end
	    hold off
	    if strcmp('Coherence', TypeStr{iPlotType}) == 1
		ylabel('Coherence')
		ylim([0.0 1.0])
	    elseif strcmp('Multiple Coherence', TypeStr{iPlotType}) == 1
		ylabel('Multiple Coherence')
		ylim([0.0 1.0])
	    else
		ylabel(TypeStr{iPlotType})
	    end
	end
	xlabel('Frequency [Hz]')
	title(TitleStr, 'Interpreter', 'none')
	xlim([minFreqHz maxFreqHz])
	legend(Legends, 4)
	set(findobj(gcf, 'Type', 'Line'), 'LineWidth', 2)
	[legh, objh] = legend;	% refresh legend so its linewidths are changed
	texth = findobj(objh, 'Type', 'text');
	set(texth, 'Interpreter', 'none', 'FontSize', 8)
    end
    fprintf(1, 'Finished plot --- maximum magnitude = %.3g.\n\n',...
      max(max(abs(PlotData))))

    fprintf(1, 'PAUSED: Press any key to continue...\n');
    beep
    pause
end
fprintf(1, 'Program finished.  Have a nice day!\n');
