function Y=ModalFRFResp(F,ws,wns,zts,phir,phif,varargin)
% Function which computes the response of a system to a given set of forces
% using the modal approximation.
% 
% Y=ModalFRFResp(F,ws,wns,zts,phir,phif)
%
%     F - Ni x Nf matrix of complex amplitudes of the force
%     ws - Nfx1 vector of forcing frequencies
%     wns, zts - vectors of modal parameters - 1xNm
%     phir, phif - matrices of mode shapes at respnose (r) and force (f)
%               locations - No x Nm and Ni x Nm
% 
% Y is the Modal FRF of dimension [Nf x No x Ni]
%
% Modal FRF is produced in Accelerance.  DC term is neglected.

Nf=size(F,2);
No=size(phir,1); Ni=size(phif,1); Nm=length(wns);

if length(zts)~=Nm; error('Size vector of zts doesn''t match'); end

if nargin>6
    FRF_type=varargin{1};
    if ~strcmpi(FRF_type,'D') && ~strcmpi(FRF_type,'V') && ~strcmpi(FRF_type,'A');
        error('Unrecognized FRF_type String');
    end
else
    FRF_type='A';
end

% Y=zeros(Nf,No); 
% for k=2:Nf
%     Y(k,:)=(phir*-ws(k).^2*diag((-ws(k)^2 + 1i*ws(k)*2*zts.*wns + wns.^2).^-1)*(phif.'*F(:,k))).';
% end

% Skip multipying the zeros to make it a little faster.
Y=zeros(Nf,No); 
for k=2:Nf
    Htemp=zeros(Nm,1);
    for r=1:length(wns);
        Htemp(r,1)=(phif(:,r).'*F(:,k))/(-ws(k)^2 + 1i*ws(k)*2*zts(r)*wns(r) + wns(r)^2);
    end
    if strcmpi(FRF_type,'A')
        Y(k,:)=-ws(k).^2*phir*Htemp;
    elseif strcmpi(FRF_type,'V')
        Y(k,:)=1i*ws(k)*phir*Htemp;
    else
        Y(k,:)=phir*Htemp;
    end
end


