function [band_inds] = FindPeakBand(ws,lam,bw_fact);
% Find frequency points relative to the half power bandwidths of the modes
% of interest.
%
% [band_inds] = FindPeakBand(ws,lam,bw_fact);
%
% This function finds the indices corresponding to the frequency band that
% contains the frequencies around each natural frequency specified in lam.
%
% When bw_fact = 1, this corresponds to all the frequencies within the half
% power bandwidth of each mode.

% Matt Allen Sept. 26, 2005
%

% Find band around peaks
band_inds = [];
for k = 1:length(lam);
    band_inds = union(band_inds,find(ws > abs(lam(k)) + bw_fact*real(lam(k)) & ...
        ws < abs(lam(k)) - bw_fact*real(lam(k))));
end
