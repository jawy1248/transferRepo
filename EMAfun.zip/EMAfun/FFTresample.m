function [t_sync, data_sync, f_ratio_int] = FFTresample(t, data, fopt,varargin)
% Resample a signal to be synchronous with frequency fopt (in Hz) by zero
% padding the FFT of the signal and then using linear interpolation
%
% [t_sync, data_sync, f_ratio_int] = FFTresample(t, data , fopt);
%
% t is the time vector for the system, data is matrix with each column the
% same length as t a signal that is to be resampled.  fopt is the frequency
% that the signal is to be synchronous with.  This routine resamples the
% signals such that the new sample frequency is f_ratio_int*fopt, where
% f_ratio_int is an integer.
%
% Optional arguments:
%
% [t_sync, data_sync, f_ratio_int] = ...
%    resampleCSLDV(t, data , fopt, fft_exp_fact,ScanFreqMult);
%
% th_delay:
%   A phase angle.  If this argument is provided, the resampled
%   signal is shifted by theta radians relative to time zero.
% fft_exp_fact
%   The factor by which to expand the FFT of the signal before linearly
%   interpolating.  The default is to expand the signal to eight times its
%   original length.
% ScanFreqMult
%   is used for tracking data.  In that case fopt is the mirror scan
%   frequency, but this is related to f_rot by fopt = ScanFreqMult*f_rot.
%   The algorithm uses this after resampling to trim the data to assure 
%   that no partial cycles of either f_rot or fopt are present.
%
% M.S. Allen & M.W. Sracic, 2007-2009
% Updated Mar. 30, 2010 - MSA added ScanFreqMult
%
% Update:
%     1).break ifft_easy of Data_rs in line 89 into a loop to save
%        memroy
%     2).Shift t_sync to zero for output
%  Shifei Yang , 2010.04.04 
% MSA, May 19, 2010:  Modified so that f_ratio_int (number of samples per
% cycle) is an even number.  Facilitates FFTs in LTP systems analysis.

if nargin > 3;
    th_delay = varargin{1};
else
    th_delay = 0;
end
if nargin > 4
    fft_exp_fact = varargin{2};
else
    fft_exp_fact = 8;
end
if nargin > 5
    SFMult = varargin{3};
%     disp('this is working');
else
    SFMult = 1;
end
% I don't think this part is correct.
% if nargin > 5 % if this argument is given, resample at constant points in the phase, not in time.
%     meas_phase = varargin{3};
%     phasersflag = true;
% else
%     phasersflag = false;
% end

if size(data,2) > size(data,1); warning('data has more columns than rows, may not be shaped correctly.'); end

% Compute start time such that the phase of the mirror signal (or
% time-periodic trajectory) is zero.
np = ceil(-th_delay/2/pi); % cycle at which mirror signal peaks.
tmm = (np+th_delay/2/pi)/fopt;

f_samp = (t(2)-t(1))^-1;
f_ratio = f_samp/fopt;

if ~isinteger(f_ratio)
    [Data,wdata] = fft_easy(data,t,1);
    Data = 2/length(t)*Data;     % Include Scaling Factor for fft
    N_data = length(data);
        N_data_rs = N_data*fft_exp_fact;
            % This is computationally optimized for the case when
            % N_data is a power of two.
    % Pad FFT with zeros coresp. to ideal band-limited resampling (see
    % Stearns textbook).
    length_zeros = (N_data_rs/2+1)-(N_data/2+1);
        % Should add a check here to see if Matlab will run out of
        % memory? max variable size = 2^31-2 or less...
        disp('size vector');
        [length_zeros,size(Data,2)]
    Data_rs = [Data; zeros(length_zeros,size(Data,2))];
    N_data_rs = 2*(length(Data_rs)-1);
    wdata_rs = [0:size(Data_rs,1)-1]*(wdata(2)-wdata(1));
    
    % save memory here  Ben
    for ii = 1:size(Data_rs,2)    
        TEMP = Data_rs(:,ii); 
        [temp,t_rs] = ifft_easy(TEMP,wdata_rs,1);
        clear TEMP
        if ii ==1
            data_rs = zeros(length(temp),size(Data_rs,2));
        end
        data_rs(:,ii)=temp; clear temp
    end; clear Data_rs
    
    data_rs = data_rs*length(t_rs)/2;       % *N/2 - second scaling factor for resampled ifft
    
        if max(imag(data_rs)) > 0.0001*max(real(data_rs));
            warning('IFFT has a significant imaginary component that was discarded');
            disp('Max Imaginary Component / Max Real Component');
            max(imag(data_rs))/max(real(data_rs))
        end
        data_rs = real(data_rs);
    f_ratio_int = ceil(f_ratio);
        % Force an even number of samples per cycle
            if (f_ratio_int/2)~=round(f_ratio_int/2)
                f_ratio_int = f_ratio_int+1;
            end
        f_samp_sync = fopt*f_ratio_int;
    dt_sync = 1/f_samp_sync;
%     if phasersflag
%         dp_sync = 2*pi*fopt*dt_sync;
%         t_sync = interp1(meas_phase,t,meas_phase(1)+dp_sync*[0:1:(length(t)-1)].')+tmm;
% %         t_sync = dp_sync*[0:1:(length(t)-1)].'/(2*pi*fopt)+tmm;
%     else
        t_sync = [tmm:dt_sync:max(t)].';
%     end
    data_sync = interp1(t_rs,data_rs,t_sync,'linear',0); % zero - use zero for extrapolated values
    t_sync = t_sync - t_sync(1);       
    % Eliminate any extra partial cycles, so that the data contains an
    % integer number of cycles.
    Ncyc = length(t_sync)/f_ratio_int;
    if ~isinteger(Ncyc/SFMult);
        t_sync = t_sync(1:(SFMult*floor(Ncyc/SFMult))*f_ratio_int);
        data_sync = data_sync([1:(SFMult*floor(Ncyc/SFMult))*f_ratio_int],:);
    end             
        
else % data already is synchronous, don't resample
    t_sync = t; data_sync = data;
end