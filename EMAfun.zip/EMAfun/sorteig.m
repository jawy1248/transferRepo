function [varargout] = sorteig(lam,varargin);
% Function which sorts eigenvalues in ascending order of their magnitudes,
% with complex conjugates grouped at the end of the sequence as follows:
%
% lam_sort = [lam1; lam2; ... lamN; conj(lam1); conj(lam2); ... conj(lamN)]
%
% [Phi_sort, lam_sort, Psi_sort] = sorteig(lam, Phi, Psi)
% [Phi_sort, lam_sort, Psi_sort,sind] = sorteig(Lam, Phi, Psi)
% [lam_sort] = sorteig(lam);
save debugdata.mat

% Arrange lambda in a column vector
[a,b] = size(lam);
if a == 1 | b == 1
    lam = lam(:);
elseif a == b;
    lam = diag(lam);
else
    error('"lam" must be a vector or a square diagonal matrix of eigenvalues');
end

if nargin == 1;
    if nargout > 1;
        warning('Mode matrix must be input in order to be sorted.');
    end
elseif nargin == 2;
    Phi = varargin{1};
    if nargout > 2;
        warning('Modal Participation matrix must be input in order to be sorted.');
    end
elseif nargin == 3;
    Phi = varargin{1};
    Psi = varargin{2};
end

% Find Complex Conjugate Eigenvalues
alam = [abs(lam), [1:length(lam)].']; cc_inds = [];
while length(alam) > 0;
    cc_ind = find(abs(alam(2:end,1) - alam(1,1)) < 10*eps);
    if ~isempty(cc_ind)
        % Store indices of CC eig
        % Store eig w/pos imag part first - assumes that eig are CC
        if imag(lam(alam(1,2))) > 0
            cc_inds = [cc_inds; alam(1,2), alam(cc_ind+1,2)];
        else
            cc_inds = [cc_inds; alam(cc_ind+1,2), alam(1,2)];
        end
        % Remove from alam vector
        elim_inds = [find(alam(:,2) == cc_inds(end,1)), find(alam(:,2) == cc_inds(end,2))];
        alam = alam(setdiff([1:length(alam)],elim_inds),:);
    else
        alam = alam(2:end,:);
    end
end

% Rest of the eigenvalues are real or complex without CC's
rind = setdiff([1:length(lam)],vec(cc_inds));

% Place CC eig first, w/pos imag first, followed by real eig.
sind = [cc_inds(:,1); cc_inds(:,2); rind(:)];

% % Sort by ascending imaginary parts
% [junk,sind] = sort(imag(lam));
% % Find Real eigenvalues
% rind = find(abs(imag(lam)) < 10*eps);
% nreal = length(rind);
% [junk,cind] = setdiff(sind,rind);
% sind = sind(sort(cind)); % Tricky to get this
% % Place real eigenvalues first, then positive imag. complex, then rest
% sind = [rind; sind([end/2+1:end,end/2:-1:1])];
% % Does this work if a real eig is missed?
% lam_sort = lam(sind);

lam_sort = lam(sind);

% Error Checking
if norm(lam_sort(1:end/2) - conj(lam_sort(end/2+1:end))) > 1e5*eps; % nreal > 0 | 
    warning('You may have some non-conjugate eigenvalues!');
end

if nargout == 1 | nargout == 0;
    varargout{1} = lam_sort;
elseif nargout == 2;
    % Like eig if two aruments out
    varargout{2} = lam_sort;
    Phi_sort = Phi(:,sind);
    varargout{1} = Phi_sort;
elseif nargout == 3;
    varargout{2} = lam_sort;
    Phi_sort = Phi(:,sind);
    varargout{1} = Phi_sort;
    Psi_sort = Psi(sind,:);
    varargout{3} = Psi_sort;
elseif nargout == 4;
    varargout{2} = lam_sort;
    Phi_sort = Phi(:,sind);
    varargout{1} = Phi_sort;
    Psi_sort = Psi(sind,:);
    varargout{3} = Psi_sort;
    varargout{4} = sind;
end