function [y,b] = intgdos(x,N)
% intgdos    function [y,b] = intgdos(x,N)
% function to intgrate equally spaced data, x, using Smallwood's method
% x = a vector of input values
% if N is not given, N is set to 100;
% if N is a scalar, N defines the number of filter weights desired
%    N = the number of terms desired, should be an even number.
%        The larger N the longer the integration takes, but the wider the bandwidth
%        for which the integration is accurate.
% if N is a vector, b=N
% b = a row vector of length N if N is a scalar, the integration weights.
% b = a row vector =N, if N is a vector.
% y = the output, length will be length(x)+N, delayed by N points
% also required: intgdsgn.m  designs the integration filter
%                sinxovx.m   a function to evaluate sin(x)/x
%                intgwin.m   a function used to evaluate integration window
%                quad8m.m    a modification of quad8 which allows parameters
%                            to be passed.
% also see:      intgfrf.m   plots the normalized error of the integration
%                            as a function of normalized frequency

% D. O. Smallwood, Sandia National Laboratories, 5/27/94
% Reference: Smallwood, David O.,"Integration of Equally Spaced Sampled Data
%            Using a Generalized Whittaker's Reconstruction Formula," IEEE Transactions
%            on Acoustics, Spech, and Signal Processing, Vol. ASSP-28, No. 3, June 1980.

if nargin<2
   N = 100;
end
if length(N)==0
   N = 100;
end
if length(N)==1
   b = intgdsgn(N);
else
   b = N;
end
N =length(b);
xe = x(:);
xe = xe';
xe = [zeros(1,N/2) xe zeros(1,N/2)];
y = filter(b,[1 -1],xe);
