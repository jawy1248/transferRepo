% Sample script to load measurements, evaluate for any signs of nonlinear
% damping and use the Hilbert transform to estimate the modal Iwan
% parameter chi.
%
% M.S. Allen, July 2014, msallen@engr.wisc.edu
%
clear; close all; clc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Insert commands here to load your data and name it accordingly
load('Hilb_SampleData_CatConv.mat') % Sample data from two catalytic converters bolted together
    t=t_resp(:); % column vector of time samples
    yt=resp(:); % column vector of response data.
        % To identify a modal model, this should be the response of a
        % single, mass-normalized modal coordinate.  Below we assume this
        % is an acceleration.
    fs=mean(diff(t)).^-1; % Sample rate in Hz

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Plot initial (unfiltered) signal
figure(1);
plot(t,yt);
xlabel('time,s '); ylabel('Velo'); title('Time Response')

[Yw,ws] = fft_easy(yt,t);

figure(2);
semilogy(ws/2/pi, 2/length(t)*abs(Yw)); hold on;
xlabel('Freq, Hz'); ylabel('|Velo|');title('FFT of Processed Velocity')


%% Analyze with ZNLDetect
% This is a quick way to check whether any of the modal peaks show signs of
% nonlinearity that may need to be described by a modal Iwan model.

%%%% Uncomment this to try a nonlinear data screening tool
% [Fmat, f, ts_zc] = ZNLDetect(yt, t, [0.6,2], 1000, 5);  

%% Decimate if needed, then filter
% The band pass filter may be ill conditioned if you try to filter over too
% narrow a range.  You can overcome this by decimating the data.  With the
% sample data you'll notice that the filter for the first mode fails if you
% don't decimate.

% {
dec_fact = 2; % Should be an integer
for k=1:size(yt,2); % loop if there are multiple signals
    if k == 1
        ytd=decimate(yt(:,k),dec_fact);
        ytd(:,2:size(yt,2))=0;
    else
        ytd(:,k)=decimate(yt(:,k),dec_fact);
    end
end
% Select which signal to use going forward
fsds = fs/dec_fact;
tds=t(1:dec_fact:end);
    Ytd = 2/length(tds)*fft_easy(ytd,tds);
%}

% or, if you don't need to decimate:
%{
ytd=yt(:,yt_ind);
tds=t;
fsds=fs;
Ytd = 2/length(tds)*fft_easy(ytd,tds);
%}
%% Now apply a Band-Pass Filter. 

% Band-Pass Filtering
Norder=8;

fcutoff1=[60,180]; % Hz % for mode 1 % This doesn't work without decimating
m_ind = 1;

% fcutoff1=[160,280]; % Hz % for mode 2
% m_ind = 2;

[b,a] = butter(Norder,fcutoff1/(fsds/2));
yfilt=filtfilt(b,a,ytd);
    if sum(isnan(yfilt))~=0
        error('Filter failed, NAN returned');
        % Note, this doesn't catch every error - the filter may give poor
        % results that aren't NAN...
    end
    Acoefs{m_ind} = a;
    Bcoefs{m_ind} = b;
    
figure(10+1)
subplot(2,1,1);
plot(tds,yfilt);
xlabel('time, s'); ylabel('Velo');
title('Filtered Signal')
[YFilt,wds] = fft_easy(yfilt,tds);
YFilt = 2/length(tds)*YFilt; % scale the fft
% check filtering
subplot(2,1,2);
semilogy(wds/2/pi,abs(Ytd)); hold on;
semilogy(wds/2/pi,abs(YFilt),'r');
xlabel('Frequency, Hz'); ylabel('FFT Velo');
legend('Velo','BP Velo')
title(['FFT of Filter Response - for First Mode'])

%% Analyze with Hilbert function

[wn_fit,zt_fit,indfit,yfit,ad]=hilbssm(yfilt,tds,20); 

%Amplitude Fit
Amp_fit=exp(ad.psirt_fit);
    
figure(20)
plot(tds,yfilt,tds(indfit),yfit,'.--'); grid on;
xlabel('Time (s)');
ylabel('Response');
title('Comparison of Signal and Smoothed Hilbert Fit')


%% ANALYSIS
% For Acceleration Measurements, convert to V and U...

    VAmp_fit=Amp_fit./wn_fit;
    XAmp_fit=VAmp_fit./wn_fit;


    % Compute Dissipation per cycle: Vel. Amp before and after
    % one cycle gives difference of energy before/after.
    ts_jp1=tds(indfit)+2*pi./(ad.wd_fit);
    % vj = velocity amplitude (so we don't need the 1i facotr)
    vj=VAmp_fit; vjp1=interp1(tds(indfit),VAmp_fit,ts_jp1,'linear','extrap');
    Edis1=(1/2)*(vj.^2-vjp1.^2); % left out (m) mass factor. This is (Edis/m)

% Damping Ratio vs Log Amplitude - This is a horizontal line for a linear system,
% making it much easier to interpret.  It also makes the data quality more
% visible.
zt_est=Edis1./(VAmp_fit.^2*2*pi);
% Note, this is very close to zt_fit from the Hilbert transform!

figure(62); clf(62);
loglog(VAmp_fit,Edis1./(VAmp_fit.^2*2*pi)); grid on;%,VAmp_fit,Edis2,'-.',VAmp_fit,Edis3,'k--'); grid on;
set(get(gca,'Children'),'Linewidth',2);
xlabel('\bfAmplitude (m/s)');
ylabel('\bfDamping Ratio');
title('\bfDamping vs. Velocity Amplitude')

    % First subtract off linear damping ratio so we are just looking at the
    % nonlinear portion
        disp('Select the linear \zeta level');
        [xg2,zt_mat]=ginput(1);
        line(VAmp_fit,zt_est-zt_mat,'Color','r','LineWidth',2); grid on;
        
    % Add Curve Fits
        disp('Select the range to curve fit to find \chi');
        [xg,yg]=ginput(2);
        fit_ind=find(VAmp_fit> min(xg) & VAmp_fit<max(xg));
        ZtvsAsq=polyfit(log10(VAmp_fit(fit_ind)),log10(zt_est(fit_ind)-zt_mat),1); % Fit line to D vs. A
        Zt_Pfit=polyval(ZtvsAsq,log10(VAmp_fit));
        line(VAmp_fit,10.^Zt_Pfit+zt_mat,'Color','r','LineWidth',2,'LineStyle','-.');
            chi_zt=ZtvsAsq(1)-1
            Rv_zt=10^ZtvsAsq(2)
            R_fit=10^(ZtvsAsq(2)+log10(2*pi*mean(wn_fit).^2)+(chi_zt+1)*log10(mean(wn_fit)))
    legend('Estimated Amplitude Dependant Damping','Nonlinear Contribution',['Iwan Fit, \chi=',num2str(chi_zt)]);

    
%% Start adjusting knobs to get Iwan parameters that match experimental dataset

F_s=1e3;        % assume well above tested range, then iterate
f_shift=60;     % assumed frequency shift when joint slips completely in this mode
fn_0=111.9;       % natural freuqency when joint completely stuck
K_inf=(fn_0*2*pi-f_shift*2*pi)^2; % Stiffness when spring is completely stuck
K_t=(fn_0*2*pi)^2-K_inf;  

fn_inf=sqrt(K_inf)/2/pi

beta=0;
chi=chi_zt;
      
% Construct analytical dissipation and frequency vs amplitude curves.
[Dm,Kj] = iwan_DKvsQ(XAmp_fit,fn_0*2*pi,[F_s,K_t,chi,beta],2*zt_mat*(2*pi*fn_0));
% [Dm,Kj] = iwan_DKvsQ(XAmp_fit,fn_0*2*pi,[chi_zt,phi_max,R_fit,0],2*zt_material*(2*pi*fn_0),'math');
    % Convert to physically meaningful parameters.
    wd_iwan = sqrt(Kj+K_inf); % actually the undamped natural frequency...
    zt_iwan = Dm./(XAmp_fit.^2.*wd_iwan.^2*2*pi);
   
figure(64); clf(64);
hd=subplot(2,1,1);
loglog(VAmp_fit,zt_est); grid on;
set(get(gca,'Children'),'Linewidth',2);
xlabel('\bfAmplitude (m/s)');
ylabel('\bfDamping Ratio');
title('\bfDamping vs. Velocity Amplitude')
	line(VAmp_fit,10.^Zt_Pfit+zt_mat,'Color','r','LineWidth',2,'LineStyle','-.');
        
    
hf=subplot(2,1,2);
semilogx(VAmp_fit,wn_fit/2/pi,VAmp_fit,wd_iwan/2/pi,'k'); grid on;%,VAmp_fit,Edis2,'-.',VAmp_fit,Edis3,'k--'); grid on;
set(get(gca,'Children'),'Linewidth',2);
xlabel('\bfAmplitude (m/s)');
ylabel('\bfNatural Frequency');
title('\bfNatural Frequency vs. Velocity Amplitude')
legend('Measured','Modal Iwan');

% {
% Plot the curve over a wider range to see global (extrapolated) behavior.
Xs=logspace(-6,-1,5000);
[Dm2,Kj2] = iwan_DKvsQ(Xs,fn_0*2*pi,[F_s,K_t,chi,beta],2*zt_mat*(2*pi*fn_0));
% [Dm2,Kj2] = iwan_DKvsQ(Xs,fn_0*2*pi,[chi_zt,phi_max,R_fit,0],2*zt_material*(2*pi*fn_0),'math');
    wd_iwan2 = sqrt(Kj2+K_inf);
    zt_iwan2 = Dm2./(Xs.^2.*wd_iwan2.^2*2*pi);
axes(hd); line(Xs.*wd_iwan2,zt_iwan2,'Color',[0,0.5,0],'LineWidth',2)
legend('Measured','\chi Fit','Modal Iwan','location','SouthEast');
%}



