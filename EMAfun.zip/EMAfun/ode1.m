function [x] = ode1(f,t,x0,varargin)
% Euler integration of state space equations of motion.
%
% [x] = ode1(f,t,x0,u)
%
% f = f(t,x,u) or f(t,x) if u = [];  Example:
%     eomfs = @(t,x,u) ([0, 1; -w0^2*(1+2*bet*cos(Om*t)), -2*zt*w0]*x + ...
%         B_lti*F*u);
% t = vector of time samples at which to perform Euler integration.  Must
% have a constant timestep.
% x0 = column vector of initial conditions
% u = vector of inputs, currently the input must be a scalar so this must
% be the same size as t.
%
% MSA, Oct 2010
%

Nt = length(t);
if size(x0,1) < size(x0,2);
    error('x0 must be a column vector');
end
dt = t(2)-t(1);

if nargin > 3;
    u = varargin{1};
    if length(u) ~= Nt;
        error('Input, u, must be a vector the same size as t');
    end
else
    u = [];
end

% Preallocate & Start Integration
x = zeros(Nt,length(x0));
x(1,:) = x0.';
if isempty(u);
    % Integrate using Euler method
    for k = 2:Nt
        x(k,:) = (x(k-1,:).' + dt*f(t(k-1),x(k-1,:).')).';
    end
    
else
    % Integrate using Euler method
    for k = 2:Nt
        x(k,:) = (x(k-1,:).' + dt*f(t(k-1),x(k-1,:).',u(k-1))).';
    end
end


% Old snippet of code used to integrate EOM with an Iwan joint.

% % Use Euler algorithm to march through time.
% unl = zeros(Ntot,length(ts)); vnl = unl; anl = vnl;
% uj = zeros(1,length(ts)); vj = uj; % Joint or Slider DOF
% fnl = zeros(1,length(ts)); % This is actually the joint force.  It isn't always nonlinear.
% 
% for tk=2:length(ts)
%     %   displacement
%     unl(:,tk) = unl(:,tk-1) + dt*vnl(:,tk-1);
%     uj(tk) = uj(tk-1) + dt*vj(tk-1);
%     %   velocity
%     vnl(:,tk) = vnl(:,tk-1) + dt*anl(:,tk-1);
%         
%         % Joint
%         del_at = (unl(at_ns(1),tk) - uj(tk));
%         deldot_at = [1, -1]*vnl(at_ns,tk);
%         if( (del_at > delslip & deldot_at > 0) | (del_at < -delslip & deldot_at < 0) )
%             % if statement for slip condition
%             vj(tk) = vnl(at_ns(1),tk); % slip occuring
%         else
%             vj(tk) = vnl(at_ns(2),tk);   %  slip not occuring
%         end
%         fnl(tk) = kat*(unl(at_ns(1),tk) - uj(tk));
%     % Acceleration
%     anl(:,tk) = (fext_vec*fext(tk) + fnl_vec*fnl(tk) - Ktot*unl(:,tk) - Ctot*vnl(:,tk))./diag(Mtot);
% end