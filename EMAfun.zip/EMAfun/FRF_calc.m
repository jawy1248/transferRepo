function [ H ] = FRF_calc( wn, zt, Phi,omegas,varargin)
%
% This function takes in the values of the natural frequencies, the damping
% ratios, and the Mode shapes (wn, zt, and Phi, respectively) and
% calculates the transfer function H at each angular frequency in omegas.
% H is then a 3D matrix dimensions numrow(Phi) X numrow(Phi) X
% length(omegas).
%
% Two optional arguments may be specified as the forcing node and the
% output node.
%
% Author: Dan Rohe
% 10-24-2011
if length(varargin)>1
    j = varargin{1};
    p = varargin{2};
    H = zeros(length(omegas),1);
    
    if length(varargin)>2
        modes = varargin{3};
    else
        modes = 1:length(wn);
    end
    
    for i = 1:length(omegas)
        w = omegas(i);
        for r = modes
            %disp( (wn(r)^2-w^2+2i*w*wn(r)*zt(r)));
            mode_cont = (Phi(j,r)*Phi(p,r).')/...
                (wn(r)^2-w^2+2i*w*wn(r)*zt(r));
            if ~isnan(mode_cont)
                H(i) = H(i) + mode_cont;
            end
        end
    end
else
    % Generate 2wz and wn^2 matrices
    mat_wn2 = zeros(length(wn));
    mat_2wz = zeros(length(zt));
    for i = 1:length(wn)
        mat_wn2(i,i) = wn(i)^2;
    end
    for i = 1:length(zt)
        mat_2wz(i,i) = 2*zt(i)*wn(i);
    end
    
    H = zeros(size(Phi,1),size(Phi,1),length(omegas));
    
    for i = 1:length(omegas)
        w = omegas(i);
        % Generate the system matrix
        Modal_Sys = (-w^2*eye(length(wn))+1i*w*mat_2wz+mat_wn2);
        H(:,:,i) = Phi*Modal_Sys^-1*Phi.';
    end
end