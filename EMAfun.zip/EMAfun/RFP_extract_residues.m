function [A_mat, ExPoly_mat, lam_sort] = RFP_extract_residues(denpoly,numpolys);
% function [A_mat, ExPoly_mat] = RFP_extract_residues(denpoly,numpolys)
%
% This function extracts the residues of the pole-residue form of a rational polynomial
% transfer function.  The required inputs are:
% denpoly = denominator polynomial = prod([s - lambda(k)]);
%       Note:  All polynomials are in Matlab format, ie. descending powers:
%       c0 + c1*s + c2*s + ... cN*s => [cN, ..., c2, c1, c0]
% numpolys = Array of numerator polynomials size(num_order,number_outputs)
%       The kth column of numpolys contains the polynomial coefficients for the kth output
%       where the polynomial coefficients are once again in decending powers.
% The outputs A_mat and lam_sort include the complex conjugate eigenvalues, ie.
%       lam_sort = [lam(1); conj(lam(1)); ...]
%       When complex conjugate eigenvalues are present.
%
% This m-file first finds the eigenvalues using the ROOTS command
%
% For systems with many outputs, this is many times faster than applying
% the RESIDUE command repeatedly.
[a,b] = size(denpoly);
if a > b
    denpoly = denpoly.'; % this isn't completely reliable.  The user may have made an error.
    [a,b] = size(denpoly);
end
if a > 1; % Matrix-Polynomial Model
    error('This algorithm is not valid for matrix-polynomial formulations');
else % Common-Denominator Model
% Find the eigenvalues:
		lam = roots(denpoly);
        % Sort Eigenvalues
        [junk,sind] = sort(abs(lam) + (min(abs(lam))*0.01)*(imag(lam)<0));
        lam_sort = lam(sind);

% Find Residues from numerator coefficients
    % Find sizes
    [Nn,NoNi] = size(numpolys);
    Nd = length(denpoly);
    [a,b] = size(denpoly);
    if b > a
        denpoly = denpoly.';
    end
    
    % lam_fit must contain conjugates grouped together, in ascending order of magnitude
    % Solution matrix contains the polynomial multiplying each residue
        P = zeros(Nn,Nn);
        for kn = 1:length(lam_sort)
            P([1:(Nd-1)],kn) = fliplr(deconv(denpoly.',[1 -lam_sort(kn)])).';
		end
    % Add the Terms for the extra numerator coefficients: Valid for (iw) polynomials
        for kn = Nd:Nn
            P([(kn-Nd+1):(kn-Nd+Nd)],kn) = denpoly;
        end
    % Solve
    Pinv = inv(P);
    A_conj_mat = zeros(Nn,NoNi);
        for k = 1:NoNi
            A_conj_mat(:,k) = Pinv*numpolys([end:-1:1],k);
        end
    ExPoly_mat = A_conj_mat([Nd:Nn],:);
    A_mat = A_conj_mat([1:Nd-1],:);
end