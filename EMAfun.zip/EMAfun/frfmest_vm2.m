function [H1,H2,Hv,ws,MCOH,Guu,Gyu,Gyy] = frfmest_vm2(y,u,ts,Nblk,window_name,NoPCToverlap)
% THIS IS AN OBSOLETE VERSION - see frfmest.m
%
% MIMO Frequency Response Functin Estimate from input-output data.
%
% [H1,H2,Hv,ws,MCOH,Guu,Gyu,Gyy] = frfest(y,u,ts,Nblk,window_name,NoPCToverlap,method)
%   y - output (Nt x No)
%   u - input (Nt x Ni)
%   ts - time vector (Nt x 1)
%   Nblk = number of blocks - see mimocsd.m
%   window_name - see mimocsd.m
%   NoPCToverlap - number of samples to overlap or percent of records to
%       overlap - see mimocsd.m
%   
%   H1, H2, Hv - FRF estimate using the named methods
%   MCOH - Coherence:  ordinary coherence is returned for SISO/SIMO data,
%       multiple coherence for MIMO or MISO data.
%       NOTE:  Uses H1 FRF estimate to compute coherence
%   Guu, Gyu, Gyy - Auto/Cross Spectrum matrices returned if desired.
%
% Matt Allen, Spring 2005
% msalle@sandia.gov
%
% This is a work in progress.  Basic functionality has been verified, yet
% the documentation is incomplete and the options are limited.
%

% Find Spectral Density Matrices for use by algorithms.
[Guu Gyu ws Gyy] = mimocsd(y,u,ts,Nblk,window_name,NoPCToverlap);

No = size(Gyu,1); Ni = size(Gyu,2); Nw = size(Gyu,3);
H1 = zeros(No,Ni,Nw); H2 = zeros(No,Ni,Nw); Hv = zeros(No,Ni,Nw);

for k = 1:Nw
    % H1 Method
    H1(:,:,k) = Gyu(:,:,k)/Guu(:,:,k);
    % H1(:,:,k) = Guu(:,:,k)\(Gyu(:,:,k)'); % Are These Different?
    Fvirt(k,:) = eig(Guu(:,:,k)).';
    
    % H2 Method
    H2(:,:,k) = Gyy(:,:,k)/(Gyu(:,:,k)');
    RGyu(k,:) = svd(Gyu(:,:,k)).';
    
    % Hv Method Allemang Course Notes v3_5.pdf eq (5.36)
    for p = 1:No
        GFFXp = [Guu(:,:,k), Gyu(p,:,k)';
                Gyu(p,:,k), Gyy(p,p,k)];
        [V,lam] = eig(GFFXp);
        [las,lsind] = sort(abs(diag(lam)));
        Hrow = (-V(:,lsind(1))/V(end,lsind(1)))';
        Hv(p,:,k) = Hrow(1,1:Ni);
    end
    
end

if Ni > 1;
    figure;
    semilogy(ws, Fvirt,ws, RGyu,'-.'); title('Watch for Low Rank');
    xlabel('Frequency (rad/s)');
    for k = 1:Ni; vflab{k} = ['Virtual Force #',num2str(k),' (H1)']; end
        vflab{k+1} = 'Rank (Gyu) (H2)';
    legend(vflab);
end


MCOH = zeros(Nw,No);
if nargout > 4 & Ni == 1; % Compute Ordinary Coherence - Allemang v3_5.pdf page (5-24)
    for k = 1:Nw
        for p = 1:No
            MCOH(k,p) = abs(Gyu(p,1,k))^2/(Gyy(p,p,k)*Guu(1,1,k));
        end
    end
    % gam = sqrt(MCOH); % Note - COH = gam^2???
    
% Compute Multiple Coherence - Allemang v3_5.pdf page (5-25), eq. 5-43 -
% this gives the linear relationship between the output and all of the
% inputs.
elseif nargout > 4 % Error in the formula?  Which H to use?
    for k = 1:Nw
        for p = 1:No
            for q = 1:Ni
                for t = 1:Ni
                    MCOH(k,p) = MCOH(k,p) + H1(p,q,k)*Guu(q,t,k)*conj(H1(p,t,k))/Gyy(p,p,k);
                end
            end
        end
    end
end

if max(imag(MCOH)./real(MCOH)) > 1e-5; warning('Coherence is not real'); end
    MCOH = real(MCOH);

