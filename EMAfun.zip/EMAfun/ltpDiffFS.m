
function [Bdiff] = ltpDiffFS(B,mB,wA,lam);
% Differentiates a Fourier Series model for a Linear Time-Periodic System
%
% [Bdiff] = ltpDiffFS(B,mB,wA,lam);
%
% X(t) = sum_r sum_m [ B(:,r,m)*exp(i*wA*m*t)*exp(lam(r)*t) ]
%
% dX(t)/dt = sum_r sum_m [ Bdiff(:,r,m)*exp(i*wA*m*t)*exp(lam(r)*t) ]
%
% B is size (No,Nfs,N)
%       No - number outputs
%       Nfs - number Fourier Series Coefficients
%       N - number of modes
%   
% M.S. Allen, Feb. 2007
%

[No,Nfs,N] = size(B);

% ADD: Check that mB is the same size as B
% ADD: Check that lam is the right size

Bdiff = zeros(size(B));
for m_num = 1:N;
    Bdiff(:,:,m_num) = B(:,:,m_num).*(i*wA*mB(:,:,m_num)+lam(m_num));
end


