% Test script for ritzsmod m-file.
% Based on ME 7442 First Homework Assignment:
% Uses Ritz Series Analysis of Free-Free Beam in Flexure
%
% This generates a set of analytical mode vectors for a free-free beam and
% then modifies the beam by adding a mass and computes the modified
% system's natural frequencies and mode vectors.

clear all; close all;

% Create variables for Ritz Series
syms y nn jj real;
tic
N = 5;
ym = 0; % Set attached mass to zero
% Find Alpha Values
    ce = inline('cos(x)*cosh(x)-1');
    an0 = [4.73,(2*[4:(N)]-3)/2*pi];
    for k = 1:length(an0);
        an(k+2) = fzero(ce,an0(k));
    end
    for j = 3:N;
        Rn(j) = -(sin(an(j)) - sinh(an(j)))/(cos(an(j)) - cosh(an(j)));
    end
% Parameters
% Beam Parameters:
L = 6*12; % length (in)
h = 1;      % height (in)
b = 1.5;    % width (in)
E = 1.0602e7; %lb/in^2
rho = 0.097544/(32.2*12); %lb-s^2/in^4
Eorho = E/rho; % E/Rho (in^2/s^2)
Iarea = b*h^3/12; % in^4
Area = b*h; % in^2
    % Use given info
    fns_an = (sqrt(Eorho*Iarea/Area)*(1/L)^2*an.^2/2/pi).';
%     % Load experimental to compare:
%         data = load('../../SWAT/Al_beam/Beam_AMI_results_v1complex.mat');
%         disp('Fn_meas');
%         data.mode_store(:,1)/2/pi
    disp('Bending Modes');
    disp('Fn_Analytical');
    fns_an
    disp('First Two Axial Modes');
    fns_axial_an = sqrt(Eorho/L^2)*([1,2]*pi)/2/pi

% psiffb.m contains beam functions for rigid body modes and elastic modes
psi(1) = 1+0*y;
psi(2) = y-0.5;
for j = 3:N
    psi(j) = sin(an(j)*y) + sinh(an(j)*y) + Rn(j)*(cos(an(j)*y) + cosh(an(j)*y));
end
% for j = 1:N;
%     for n = 1:j;
%         M(j,n) = double(int(psi(j)*psi(n),y,0,1));%  % *rho*Area*L  % + ym^2*sin(j*pi*ym)*sin(n*pi*ym);
%         K(j,n) = double(int((diff(psi(j),y,2)*diff(psi(n),y,2)),y,0,1)); % *EI
%         M(n,j) = M(j,n)
%         K(n,j) = K(j,n)
%     end
% end
% load RFFB_KM.mat
% Matrices are diagonal - Mode functions are orthogonal to RGB Modes!
M = zeros(N,N); K = zeros(N,N);
for n = 1:N;
    M(n,n) = (rho*Area*L)*double(int(psi(n)*psi(n),y,0,1));%  % *rho*A*L  % + ym^2*sin(j*pi*ym)*sin(n*pi*ym);
    K(n,n) = (E*Iarea/L^3)*double(int((diff(psi(n),y,2)*diff(psi(n),y,2)),y,0,1)); % *EI/L^3 for nondim y
end
toc

% Finding Numerical Mode Functions
Ns = N;
yd = [0:10]/10';
psi_vals = 0; phi = 0; lambda = 0;
for q = 1:1:length(Ns); % THIS LOOP IS NOT USED NOW
    [phi lambda] = eig(K(1:Ns(q),1:Ns(q)),M(1:Ns(q),1:Ns(q)));
	for p = 1:length(yd);
        for n = 1:Ns(q);
            y = yd(p);
            psi_vals(p,n) = double(eval(psi(n)));
        end
	end

    % Normalize Mode Functions:
    mu = diag(phi.'*M(1:Ns(q),1:Ns(q))*phi);
    for jj = 1:1:length(phi)
        PHI(:,jj) = phi(:,jj)/sqrt(mu(jj));
    end

    % Check orthogonality conditions
    check_M = max(max(PHI.'*M*PHI-eye(size(PHI))))
    check_K = max(max(PHI.'*K*PHI-lambda))

end

psi_c = psi_vals*PHI; % I think these are normalized correctly - check!!
wn = sqrt(diag(lambda));
zt = 0.01*ones(size(wn));

% Plotting
figure(1)
% subplot(211)
% plot([2:1:5],wnd(:,1:3), '*-'); grid;
% xlabel('Series Length (N)'); ylabel('Natural Frequency *sqrt(EI/pAL^4)');
% title('Wn vs. Ritz Series Length--First Three Modes');
% subplot(212)
plot(yd, psi_c);%, yd, psi_c(:,1,2), '.:', yd, psi_c(:,3,2),'.:'); grid;
xlabel('Position (X/L)'); ylabel('Mode Function');
title('Mode Shapes');

% Mass addition - 
total_mass = rho*Area*L % lb/(in/s^2)
dm = total_mass*0.1;
ns_m = 1; % left end of beam
dk = []; ns_k = [];
phi = psi_c; % note, overwrites previous

[wn_mod,zt_mod,phi_mod,M_mod,C_mod,K_mod] = ritzsmod(wn,zt,phi,dm,ns_m,dk,ns_k);
% ritzsmod

disp('fn before and after modification');
[wn/2/pi, wn_mod/2/pi]

% Compute Ritz series for modified system
% evaluate Ritz vectors at mass location
y = yd(ns_m); psi_m = eval(psi); syms y
Mm = zeros(N,N); Km = zeros(N,N);
tic
for j = 1:N;
    for n = 1:j;
        Mm(j,n) = (rho*Area*L)*double(int(psi(j)*psi(n),y,0,1)) + dm*psi_m(j)*psi_m(n);
        Km(j,n) = (E*Iarea/L^3)*double(int((diff(psi(j),y,2)*diff(psi(n),y,2)),y,0,1)); % *EI
        if n~=j
            Mm(n,j) = Mm(j,n);
            Km(n,j) = Km(j,n);
        end
    end
end
toc
[phim lambdam] = eig(Km,Mm);
psi_cm = psi_vals*phim; % already normalized.
[wn_modm,sort_ind] = sort(sqrt(diag(lambdam)));
psi_cm = psi_cm(:,sort_ind);

disp('fn before and after modification and Ritz Estimate');
[wn/2/pi, wn_mod/2/pi, wn_modm/2/pi]
disp('The last two columns verify that the modification algorithm gives the ')
disp('same estimate that one would get using the Ritz series directly.');

figure(2)
% subplot(211)
% plot([2:1:5],wnd(:,1:3), '*-'); grid;
% xlabel('Series Length (N)'); ylabel('Natural Frequency *sqrt(EI/pAL^4)');
% title('Wn vs. Ritz Series Length--First Three Modes');
% subplot(212)
plot(yd, psi_c*diag(sign(psi_c(1,:)))); hold on;
plot(yd,phi_mod*diag(sign(phi_mod(1,:))),'--');
plot(yd,psi_cm*diag(sign(psi_cm(1,:))),':');
xlabel('\bfPosition (X/L)'); ylabel('\bfMode Shapes');
title('\bfMode Shapes (-) orig, (--) ritzsmod, (:) mod Direct Ritz');
