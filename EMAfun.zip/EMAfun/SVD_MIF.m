% Analyze free-free beam data
% This idea was taken from "MIFs and MACs in Modal Analysis" by
% M. Rades and D.J. Ewins

clear; close all;

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Load Experimental Data from Siglab Files
% 
% %load ffbeam1_13.mat; % 13 Point Data file by Matt
% load ffbeam1_17.mat; % 17 Point Data file by Chris
% 
% for ii = 1:1:length(data);
%     X(:,ii) = data(ii).xcmeas(1,2).xfer;
% end
% w = data(ii).fdxvec.';
% 
% save ffbeam1_17_Gjp.mat X w

load ffbeam1_17_Gjp.mat

CFRF = X.';

[U,S,V] = svd(CFRF);
V = V(:,1:17);
S = S(1:17,1:17);

A_check = (CFRF - U*S*(V'));
max(max(A_check))

S_Rades = svd(CFRF.');

figure(1)
semilogy(w,abs(X)); grid on;
title('Transfer Functions for Free-Free Beam (Accelerance)');
xlabel('Frequency (Hz)'); ylabel('|G_j_P|');

figure(2)
plot([1:17],real(U(:,1:4))); grid on;
title('QRF Transfer Functions for Free-Free Beam (Accelerance)');
xlabel('Frequency (Hz)'); ylabel('|Q_j_P|');

figure(3)
subplot(211)
semilogy(w,abs(V(:,1:4))); grid on;
title('QRF Transfer Functions for Free-Free Beam (Accelerance)');
xlabel('Frequency (Hz)'); ylabel('|Q_j_P|');
subplot(212)
plot(real(V(:,1)), imag(V(:,1)),real(V(:,2)), imag(V(:,2)),...
    real(V(:,3)), imag(V(:,3)),real(V(:,4)), imag(V(:,4))); grid on;
title('QRF Nyquist Plots for Free-Free Beam (Accelerance)');
xlabel('Real'); ylabel('Imag');

figure(4)
plot([1:16],diff(diag(S)),'.-',[1:16],diff(diag(S)),'*'); grid on;
title('Differences in Singular Values');
legend('Matt = (R^T)','Rades');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Convert Accelerance Data to Displacement
% The accelerometers measure acceleration, so this conversion is 
% necessary to obtain propperly scaled mode shapes

for ii = 1:1:17;
    Xd(1,ii) = X(1,ii);
    Xd(2:length(X),ii) = X(2:end,ii)./(-w(2:end).^2);
end

% Check Orthogonality in a Euclidean Sense
w1_ind = find(w > 89.8 & w < 90.2);
w2_ind = find(w > 247.2 & w < 247.7);
w3_ind = find(w > 485.2 & w < 485.4);
w4_ind = find(w > 802.1 & w < 802.4);

Mshapes = imag(X([w1_ind; w2_ind; w3_ind; w4_ind],:)).'

figure(5);
plot([1:17],Mshapes); grid on

% Normalize Mode Vectors to Unit Length
Mshapes_scaled = Mshapes*inv(diag(sqrt(diag(Mshapes.'*Mshapes))));

MAC = Mshapes_scaled.'*Mshapes_scaled

% Try a simple sweeping method for AMI
for ii = 1:1:size(CFRF,2)
    nvec2(ii) = CFRF(:,ii)'*CFRF(:,ii);
end

figure(7);
plot(w,abs(nvec)); grid on;
title('Norm of Columns of CFRF');

% Perform Grahm-Schmidt on Matrix
[junk,inds] = sort(abs(nvec));
inds = inds(end:-1:1);
inds = inds([1,3,4,6]);

Xswp = CFRF;
for ii = 1:1:4
    v(:,ii) = imag(Xswp(:,inds(ii),ii));
    tic
    cs(ii,:) = v(:,ii)'*Xswp(:,:,ii)/(v(:,ii)'*v(:,ii));
    toc
    Xswp(:,:,ii+1) = Xswp(:,:,ii)*diag(cs(ii,:).^-1);
end

figure(8)
plot([1:17],v*diag(max(abs(v),[],1).^-1)); grid on
title('Mode Shapes');

figure(9)
semilogy(w,abs(cs)); grid on;
xlabel('Frequency'); ylabel('Coeff of Shape Vector');