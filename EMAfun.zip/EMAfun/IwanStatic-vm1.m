function [x,f_joint,K_joint,jys,varargout] = IwanStatic(params,K,x0,fext,varargin)
% Modified - static response of an Iwan joint
%
% Use beta-gamma Newmark method to integrate the motion response
% corresponding to time points given in the ts vector of a single or
% multi-DOF system with linear stiffness, viscuous damping, and various
% Iwan elements with Iwan parameters specified by params.
%
% [x,v,a,f_joint,ad] = IwanIntegration(params,M,C,K,fext,ts,iwan_pairs)
%
% INPUTS:
% params = [Fs,Kt,chi,beta] % defines Iwan joint
% M = mass matrix
% C = viscuous damping coefficient matrix
% K = linear stiffness matrix
% fext = external force time history on each node (Nnodes x Ntime)
% ts = time vector with equally spaced time samples
% iwan_pairs = [node1,node2] where node1 and node2 specify the indices of
%   the two nodes that are connected by the Iwan joint.
%
% OUTPUTS:
% x = displacement of masses
% v = velocity
% a = acceleration
% f_joint = cell array of the joint force applied by individual Iwan
%   elements. There are as many cell outputs as the number of Iwan elements.
%
% Created by R.M. Lacayo; July 2013; lacayo@wisc.edu
%

% This part isn't yet implemented
% params = [Fs1,Kt1,chi1,beta1]
%          [Fs2,Kt2,chi2,beta2]
%          [        ...       ]
%          [FsN,KtN,chiN,betaN]
% iwan_pairs = an array telling which DOF indices are connected by the nth
%   Iwan element. The number of rows reflects the number of pairs, and
%   the number of columns is always 2. For example, a 5-DOF system with an
%   Iwan element joining DOFs 2 with 4 and another between DOF 3 and ground 
%   would be specified as iwan_pairs=[2,4; 3,0]. The row index of this 
%   array is assosciated with the same row index of Iwan parameters in the
%   params input argument. 

% Cut from above by MSA - doesn't make sense???
%   The order of the pairs is directionally-
%   dependent; the DOFs in second column are in the positive direction
%   ahead of the DOFs in the first column.

% Check function arguments
% Check for size consistency
if nargin > 4
    iwanPair = varargin{1};
else
    iwanPair = [0,1];
end
if nargin > 5 % NOT USED NOW??
    % Want ICs={x0,x0d}
    ICs=varargin{2};
    if length(ICs{1})~=length(ICs{2}) || length(ICs{1})~=Ndof
        error('ICs aren''t of comptabile size');
    end
else
    ICs=[];
end
% Retrieve parameters
Fs = params(1); Kt = params(2); chi = params(3); beta = params(4);

phi_max = Fs*(1+beta)/(Kt*(beta + (chi+1)/(chi+2)));
R = Fs*(chi+1)/((beta+ (chi+1)/(chi+2))*phi_max^(chi+2) );
S = (Fs/phi_max)*(beta/(beta + (chi+1)/(chi+2)));

params2 = [chi, phi_max, R, S];

u_est = x0; 

% Use NJ Jenkins elements
% lets use NJ Jenkins elements
NJ = 100;
jy_prev  = zeros(NJ,1);

% Solve for response
   
    % initialize index arrays
    indVec = zeros(size(u_est));
    indMat = zeros(size(K));
    ind1 = iwanPair(1); ind2 = iwanPair(2);
    % Calculate non-linear force at location defined by iwanPair
        %%% MSA: This part should be re-worked - the location of hte iwan joint
        %%% only affects where we assemble ftemp within the force vector and
        %%% jacobian. %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if ind1==0 % mass index 2 is joined to ground
        [ftemp, jy_temp, stiff_temp] = iwan(u_est(ind2), jy_prev, params2);
        indVec(ind2) = 1;
        indMat(ind2,ind2) = 1;
    elseif ind2==0 % mass index 1 is joined to ground
        [ftemp, jy_temp, stiff_temp] = iwan(-u_est(ind1), jy_prev, params2);
        indVec(ind1) = -1;
        indMat(ind1,ind1) = 1;
    else % mass indices are joined with iwan element
        [ftemp, jy_temp, stiff_temp] = iwan(u_est(ind2)-u_est(ind1), jy_prev, params2);
        indVec(ind1) = -1; indVec(ind2) = 1;
        indMat(ind1,ind1) = 1; indMat(ind1,ind2) = -1;
        indMat(ind2,ind1) = -1; indMat(ind2,ind2) = 1;
    end
    fjVec = ftemp*indVec;
    stiffMat = stiff_temp*indMat;
    
    resid = K*u_est + fjVec - fext;
    grad = (K+stiffMat);
    
    % Newton Iteration Loop
    iter = 0;
    while (resid'*resid/norm(K*u_est).^2) > 1e-6 %1e-10 % This should be improved to be a fraction of u and v and z
        u_est = u_est - grad\resid;
         
        % initialize index arrays
        indVec = zeros(size(u_est));
        indMat = zeros(size(K));
        ind1 = iwanPair(1); ind2 = iwanPair(2);
        % Calculate non-linear force at location defined by iwanPair
        if ind1==0 % mass index 2 is joined to ground
            [ftemp, jy_temp, stiff_temp] = iwan(u_est(ind2), jy_prev, params2);
            indVec(ind2) = 1;
            indMat(ind2,ind2) = 1;
        elseif ind2==0 % mass index 1 is joined to ground
            [ftemp, jy_temp, stiff_temp] = iwan(-u_est(ind1), jy_prev, params2);
            indVec(ind1) = -1;
            indMat(ind1,ind1) = 1;
        else % mass indices are joined with iwan element
            [ftemp, jy_temp, stiff_temp] = iwan(u_est(ind2)-u_est(ind1), jy_prev, params2);
            indVec(ind1) = -1; indVec(ind2) = 1;
            indMat(ind1,ind1) = 1; indMat(ind1,ind2) = -1;
            indMat(ind2,ind1) = -1; indMat(ind2,ind2) = 1;
        end
        fjVec = ftemp*indVec;
        stiffMat = stiff_temp*indMat;
        
        resid = K*u_est + fjVec - fext;
        grad = (K+stiffMat);
        iter = iter + 1;  
    end
    
    f_joint = fjVec;
    K_joint = stiff_temp;
    x=u_est;
    jys=jy_temp;
    
    newton_iter = iter;

% varargouts
if nargout>4;
    ad.newton_iter=newton_iter;
    ad.K_joint=K_joint;
    ad.jys=jys;
    ad.params2=params2;
    ad.newton_iter=newton_iter;
    varargout{1}=ad;
end