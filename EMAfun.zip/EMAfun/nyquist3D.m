function nyquist3D(Hp,ws,varargin);
% nyquist3D(Hp,ws,varargin)
%
% Function which plots a 3-D Nyquist plot of the 
% complex data H with frequency vector ws.
%
% nyquist3D(ws,H,fig_num) - Puts the plot in figure number 'fig_num'.
%
% Matt Allen, 2005
% msalle@sandia.gov
%
% 

if nargin < 2
    hf = figure;
else
    hf = figure(varargin{1});
end

set(hf,'Units','Normalized','Position',[0.1,0.25,0.7,0.6]);

%axes('Position', [0.13, 0.13, 0.5, 0.8]);
scatter(real(Hp),imag(Hp),10,ws,'filled');  colorbar;
set(gca,'Color',[0.8,0.8,0.8]);
xlabel('Real'); ylabel('Imag');