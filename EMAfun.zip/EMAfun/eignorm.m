function [varargout] = eignorm(varargin)
%EIG    Eigenvalues and eigenvectors.
%   The following is extracted from "eig.m," modified by Matt Allen
%   on July 28, 2004.
%
%   E = EIG(X) is a vector containing the eigenvalues of a square 
%   matrix X.
%
%   [V,D] = EIG(X) produces a diagonal matrix D of eigenvalues and a
%   full matrix V whose columns are the corresponding eigenvectors so
%   that X*V = V*D.
%
%   [V,D] = EIG(X,'nobalance') performs the computation with balancing
%   disabled, which sometimes gives more accurate results for certain
%   problems with unusual scaling. If X is symmetric, EIG(X,'nobalance')
%   is ignored since X is already balanced.
%
%   E = EIG(A,B) is a vector containing the generalized eigenvalues
%   of square matrices A and B.
%
%   [V,D] = EIG(A,B) produces a diagonal matrix D of generalized
%   eigenvalues and a full matrix V whose columns are the
%   corresponding eigenvectors so that A*V = B*V*D.
%
%   EIG(A,B,'chol') is the same as EIG(A,B) for symmetric A and symmetric
%   positive definite B.  It computes the generalized eigenvalues of A and B
%   using the Cholesky factorization of B.
%   EIG(A,B,'qz') ignores the symmetry of A and B and uses the QZ algorithm.
%   In general, the two algorithms return the same result, however using the
%   QZ algorithm may be more stable for certain problems.
%   The flag is ignored when A and B are not symmetric.
%
%   See also CONDEIG, EIGS, ORDEIG.

% See if the problem is a standard Eigenvalue problem or a generalized
% Eigenvalue problem
if nargin > 1 & ~isstr(varargin{2}) & isreal([varargin{1}, varargin{2}]) % Signifies real generalized EVP
    [Phi,Lam] = eig(varargin{:});
    Phin =  Phi*diag(sqrt((diag(Phi.'*varargin{2}*Phi)).^-1));
    % Check to make sure the procedure succeeds - (Necesary?)
    if norm(Phin.'*varargin{2}*Phin - eye(size(varargin{2}))) > 1e8*eps;
        msg = 'Eigenvalue Routine has not diagonalized the Matrices\n';
        msg = [msg,'norm(Phi.''*S*Phi - eye(size(S))) = %g'];
        warning(msg, norm(Phin.'*varargin{2}*Phin - eye(size(varargin{2}))));
    end
    varargout{1} = Phin; varargout{2} = Lam;
else % Standard EVP - no moidification required
    [varargout{1:nargout}] = eig(varargin{:});
end

    