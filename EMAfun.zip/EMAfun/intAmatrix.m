function X_dot = intAmatrix(t,x)
% interpolate a state coefficient matrix and integrate to get the state
% transtion matrix
% Assumes that A_an and tcyc exist as global variables.
% Mike Sracic, July 2010


global A_an tcyc
II = size(A_an,1);
JJ = size(A_an,2);
A = zeros(II,JJ);
for ii = 1:II
    for jj = 1:JJ
        A(ii,jj) = interp1(tcyc,squeeze(A_an(ii,jj,:)),t);
    end
end

% A(1,1) = interp1(tcyc,squeeze(A_an(1,1,:)),t);
% A(2,1) = interp1(tcyc,squeeze(A_an(2,1,:)),t);
% A(1,2) = interp1(tcyc,squeeze(A_an(1,2,:)),t);
% A(2,2) = interp1(tcyc,squeeze(A_an(2,2,:)),t);

X_dot = A*x;