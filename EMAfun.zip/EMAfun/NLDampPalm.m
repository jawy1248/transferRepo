function [zt_est,VAmp_fit,C_zt,chi_zt,Edis,varargout]=NLDampPalm(yt,t,frange,varargin)
%
% Fit a Palmov (special case of an Iwan) damping model to a time history.
% The data is band-pass filtered using the frequency range (in Hz)
% specified in [frange]. Then a Hilbert transform is performed and smoothed
% using spline fitting, and the resulting amplitude and frequency versus
% time are processed to extract the dissipation and Palmov coefficients.
%
% [zt,V,C_zt,chi,Edis,ad] = NLDampPalm(yt,t,frange,varargin);
%
% The outputs are:
%     zt = damping as a function of time
%     V = velocity amplitude as a function of time. Typically we plot (V,zt)
%     C_zt = coefficient of Palmov model for Dissipation, see below.
%     chi_zt = exponent of Palmov model, see below
%     Edis = dissipation versus time. One can plot(V,Ediss)
%     ad = structure containing all internal variables.
%
% The inputs are as follows:
%     yt = vector of acceleration time response at the point of interest. (or velocity, see below)
%     t = vector of evenly spaced time samples corresponding to yt
%     frange = [f_low,f_high] (in Hz), or optionally
%     frange = [f_low,f_high,N_order] where N_order is the order of the
%       butterworth filter used. Or for a low-pass filter, use:
%     frange = [f_low]
%     frange = [] to skip filtering
%
% ADDITIONAL OPTIONS:
% [zt,V,C_zt,chi,Edis,ad] = NLDampPalm(yt,t,frange,dec_fact);
%   first decimates the signal by the factor dec_fact
%
% [zt,V,C_zt,chi,Edis,ad] = NLDampPalm(yt,t,frange,[],knots);
%   Uses the number of knots specified in the spline smoothing.
%
% [zt,V,C_zt,chi,Edis,ad] = NLDampPalm(yt,t,frange,[],[],'V');
%   The input signal is assumed to be acceleration.  If this is not the
%   case, specify displacement 'D', velocity 'V', or accel 'A'.
%
% [zt,V,C_zt,chi,Edis,ad] = NLDampPalm(yt,t,frange,[],[],[],'PWL')
%   Input 'PWL' specifies a piecewise linear function to smooth the Hilbert
%   fit over the input signal. The default fitting function uses splines,
%   which may be specified by replacing 'PWL' with 'spline' or [].
%
% [zt,V,C_zt,chi,Edis,ad] = NLDampPalm(yt,t,frange,[],[],[],[],'verb');
%   shows all diagnostic plots
% [zt,V,~,~,Edis] = NLDampPalm(yt,t,frange,[],[],[],[],'stop');
%   Stop the function before performing the curve fits for C and chi
%
% Note that:
% 1.) If the input signal, yt, is a modal amplitude, then Edis will
%     have units of Joules and C will be scaled accordingly.
% 2.) If the input signal, yt, is a physical displacement amplitude, then
%     Edis will have units of J/kg.
%     C_zt does not require conversion from physical to modal coordinates.
%     To convert C from physical to modal use C_q=C_x/phi(point,mode#)^2
%
%   A Palmov model has the following form:
%       D = C_q*q^beta
%   where D is the energy dissipated per cycle and q is the modal
%   displacement amplitude.
%   
%   This script actually fits a model to the damping:
%       zeta=C_zt*q_dot^(1+chi)
%   so to extract the Palmov parameters use:
%   C_q = 2*pi*wn^2*C_zt
%   beta=(3+chi) so chi=-1 corresponds to linear damping
%
% M.S. Allen, April 2015
% Modified: Robert Lacayo, May 2016 - Added Hilbert curve smoothing with
%   piecewise-continuous linear functions using hilblsmMP function. 

if numel(yt)~=length(yt)
    error('yt must be a vector');
end
yt=yt(:); t=t(:);

dec_fact=1; verb_flg=false; knots=10; DVA='A'; spln_flg = true; stop_flg=false;
if nargin>3
    if ~isempty(varargin{1})
        dec_fact=varargin{1};
    end
    if dec_fact~=round(dec_fact);
        error('Decimation Factor must be an integer');
    end
end
if nargin>4
    if ~isempty(varargin{2})
        knots=varargin{2};
    end
    if knots~=round(knots)
        error('Number of knots for spline fitting must be an integer');
    end
end
if nargin>5
    if ~isempty(varargin{3})
        DVA=varargin{3};
    end
    if ~strcmpi(DVA,'A') && ~strcmpi(DVA,'V') && ~strcmpi(DVA,'D')
        error(['Unrecognized Measurement Type DVA = ',DVA]);
    end
end
if nargin>6
    if strcmpi(varargin{4},'verb') || strcmpi(varargin{4},'verbose')
        verb_flg=true;
    end
    if strcmpi(varargin{4},'stop')
        verb_flg=true;
        stop_flg=true;
    end
end
if nargin>7
    if strcmpi(varargin{5},'PWL') % fit Hilbert with piecewise linear funcs
      spln_flg = false;
    elseif strcmpi(varargin{5},'spline') || isempty(varargin{5})
      % default is already spline fitting
    else
      warning(['Using default (spline fit) algorithm.']);
    end
end

%% Decimate if needed, then filter
% The band pass filter may be ill conditioned if you try to filter over too
% narrow a range.  You can overcome this by decimating the data.  With the
% sample data you'll notice that the filter for the first mode fails if you
% don't decimate.

% dec_fact = 3; % Should be an integer
ytd=decimate(yt,dec_fact);

% Select which signal to use going forward
ysig=ytd; 
fs=mean(diff(t)).^-1; % sample frequency
fsds = fs/dec_fact;
tds=t(1:dec_fact:end);
    Ysig = 2/length(tds)*fft_easy(ysig,tds);

%% Filter
if isempty(frange); % don't filter
    yfilt=ysig;
else
    if length(frange)>2
        Norder=frange(3);
        frange=frange(1:2); % reduce this to only the filter bounds
    else
        Norder=6;
    end
    fcutoff=frange;
        if fcutoff(1)==0
            fcutoff=fcutoff(2); % low-pass filter
        end

    [b,a] = butter(Norder,fcutoff/(fsds/2));
    yfilt=filtfilt(b,a,ysig);

        if sum(isnan(yfilt))~=0
            error('Filter failed, NAN returned');
            % Note, this doesn't catch every error - the filter may give poor
            % results that aren't NAN...
        end

    if verb_flg
        figure(10+1)
        subplot(2,1,1);
        plot(tds,yfilt);
        xlabel('time, s'); ylabel('Response');
        title('Filtered Signal')
        [YFilt,wds] = fft_easy(yfilt,tds);
        YFilt = 2/length(tds)*YFilt; % scale the fft
        % check filtering
        subplot(2,1,2);
        semilogy(wds/2/pi,abs(Ysig)); hold on;
        semilogy(wds/2/pi,abs(YFilt),'r');
        xlabel('Frequency, Hz'); ylabel('FFT(Resp.)');
        legend('Resp.','BP Resp.')
        title(['FFT of Filter Response'])
    end
end

%% Analyze with Hilbert function
if spln_flg
    [wn_fit,zt_fit,indfit,yfit,ad]=hilbssm(yfilt,tds,knots);
    Amp_fit=exp(ad.psirt_fit);
    wd_fit = ad.wd_fit;
  
    figure(10+2)
    plot(tds,yfilt,tds(indfit),yfit,'.--'); grid on;
    xylabels('Time (s)','Response');
    legend('Filtered','Smoothed Hilbert Fit')
  
    % ANALYSIS
    if DVA=='A'
        % For Acceleration Measurements:
        % Convert Acceleration amplitude to Velocity
        % vj = velocity amplitude (so we don't need the 1i facotr)
        VAmp_fit=Amp_fit./wd_fit; % 
    elseif DVA=='D'
        VAmp_fit=Amp_fit.*wd_fit; %
    else % already in velocity
        VAmp_fit=Amp_fit;
    end

        % Compute Dissipation: Vel. Amp before and after
        % one cycle gives difference of energy before/after.
        ts_jp1=tds(indfit)+2*pi./(wd_fit);
        % vj = velocity amplitude (so we don't need the 1i facotr)
        vj=VAmp_fit; vjp1=interp1(tds(indfit),VAmp_fit,ts_jp1,'linear','extrap');
        Edis=(1/2)*(vj.^2-vjp1.^2); % left out (m) mass factor.
        % If v is the velocity of a mass normalized mode, then this is Edis.
        % Otherwise this is (Edis/m) and has units J/kg
  
    %{
    % Plot Energy Dissipated versus Amplitude.  In the micro-slip region this
    % will be linear with a slope of 3+chi.  For a linear system that is always  
    % excited at the same frequency, displacement is proportional to force, so
    % either force or amplitude could be the horizontal axis.
        figure(13); clf(13);
        loglog(VAmp_fit,Edis); grid on;%,VAmp_fit,Edis2,'-.',VAmp_fit,Edis3,'k--'); grid on;
        set(get(gca,'Children'),'Linewidth',2);
        xylabels('\bfAmplitude (m/s)','\bfDissipation D/m');
        title('\bfDissipation per Cycle vs. Velocity Amplitude')
        % Add Curve Fits
            DvsAsq=polyfit(log10(VAmp_fit),log10(Edis),1); % Fit line to D vs. A
            D_Pfit=polyval(DvsAsq,log10(VAmp_fit));
            line(VAmp_fit,10.^D_Pfit,'Color','r','LineWidth',2,'LineStyle','-.');
    %             chi_est=DvsAsq(1)-3
            D_LinFit=polyval([2,DvsAsq(2)],log10(VAmp_fit));
            line(VAmp_fit,10.^D_LinFit,'Color',[0,0.5,0],'LineWidth',2,'LineStyle','--');
            legend('Estimated','\chi Fit','Linear System');
    %}
    
    % Damping vs Log Amplitude - This is a horizontal line for a linear system,
    % making it much easier to interpret.  It also makes the data quality more
    % visible.
    zt_est=Edis./(VAmp_fit.^2*2*pi);
    % Note, this is very close to zt_fit from the Hilbert transform.
else
    [wd_fit,zt_est,~,Amp_fit,ad] = hilblsmMP(yfilt,tds,knots);
    wn_fit = wd_fit./sqrt(1-zt_est.^2);
    yfit=ad.yfit;
    indfit=ad.indfit;
    
    figure(10+2)
    plot(tds,yfilt,tds(indfit),yfit,'.--'); grid on;
    xylabels('Time (s)','Response');
    legend('Filtered','Smoothed Hilbert Fit')
  
    if DVA=='A'
        VAmp_fit=Amp_fit./wd_fit;
    elseif DVA=='D'
        VAmp_fit=Amp_fit.*wd_fit;
    else % already in velocity
        VAmp_fit=Amp_fit;
    end
    
    Edis = 2*pi*zt_est.*VAmp_fit.^2;
end
%% Fit Damping vs. Amplitude curve.  Note that if material damping is high,
% then this can be quite unreliable. Instead, fit the nonlinear part of the
% damping only (below).
%{
figure(14); clf(14);
loglog(VAmp_fit,zt_est); grid on;
set(get(gca,'Children'),'Linewidth',2);
xylabels('\bfAmplitude (m/s)','\bfDamping Ratio');
title('\bfDamping vs. Velocity Amplitude')
%     % Add Curve Fits
        disp('Select the range to curve fit');
        [xg,yg]=ginput(2);
%         xg(1)=VAmp_fit(round(end*0.02)); xg(2)=VAmp_fit(round(end*0.33));
        fit_ind=find(VAmp_fit> min(xg) & VAmp_fit<max(xg));
        ZtvsAsq=polyfit(log10(VAmp_fit(fit_ind)),log10(zt_est(fit_ind)),1); % Fit line to D vs. A
        Zt_Pfit=polyval(ZtvsAsq,log10(VAmp_fit));
        line(VAmp_fit,10.^Zt_Pfit,'Color','r','LineWidth',2,'LineStyle','-.');
        % Extract constants in Palmov/Iwan Model
            chi_zt=ZtvsAsq(1)-1  % This is chi from from damping vs amplitude fit
            C_zt=10^ZtvsAsq(2)

% For this data set you can adjust the curve fit to fit a line to the
% linear portion at higher amplitudes and estimate chi.  The lower
% assymptote gives an estimate of linear damping from the material and
% boundary conditions.

    % Add Lines for linear damping ratios, min and max.
    zt_high=Edis(1)/(VAmp_fit(1).^2*2*pi); % Note, should be the same as zt_fit(1)...
    zt_low=Edis(end)/(VAmp_fit(end).^2*2*pi); % 
%     minmax(zt_fit)
    line(VAmp_fit,zt_high*ones(size(VAmp_fit)),'Color',[0,0.5,0],'LineWidth',2,'LineStyle','--');
    line(VAmp_fit,zt_low*ones(size(VAmp_fit)),'Color','k','LineWidth',2,'LineStyle','--');
    legend('Estimated',['Fit, \chi=',num2str(chi_zt)],...
        ['Linear \zeta = ',num2str(zt_high)],['Linear \zeta = ',num2str(zt_low)]);
%}

%% For a more accurate model, subtract off the linear damping first.
figure(15); clf(15);
loglog(VAmp_fit,zt_est); grid on;
set(get(gca,'Children'),'Linewidth',2);
xylabels('\bfAmplitude (m/s)','\bfDamping Ratio');
title('\bfDamping vs. Velocity Amplitude','Color','k')


if stop_flg
    chi_zt=0; % dummy value
    C_zt=0;
    zt_material=0;
else
    % Fit linear damping and subtract
    title('\bfSelect the linear (low amplitude) damping ratio','Color','r');
    [xg,yg]=ginput(1);
    zt_material=yg;
    % Update plot now
    pdata1=(zt_est-zt_material);
    line(VAmp_fit(pdata1>0),pdata1(pdata1>0),'Color',[0,0.5,0],'LineWidth',2);
    title('\bfDamping vs. Velocity Amplitude','Color','k')
    
%     % Add Curve Fits
        title('\bfSelect the range to curve fit','Color','r');
        [xg,yg]=ginput(2);
%         xg(1)=VAmp_fit(round(end*0.02)); xg(2)=VAmp_fit(round(end*0.33));
        fit_ind=find(VAmp_fit> min(xg) & VAmp_fit<max(xg));
        ZtvsAsq=polyfit(log10(VAmp_fit(fit_ind)),log10(zt_est(fit_ind)-zt_material),1); % Fit line to D vs. A
        Zt_Pfit=polyval(ZtvsAsq,log10(VAmp_fit));
        line(VAmp_fit,10.^Zt_Pfit,'Color','r','LineWidth',2,'LineStyle','-.');
        title('\bfDamping vs. Velocity Amplitude','Color','k')
        % Extract constants in Palmov/Iwan Model
            chi_zt=ZtvsAsq(1)-1  % This is chi from from damping vs amplitude fit
            C_zt=10^ZtvsAsq(2)
        legend('Meas Damping','Meas NL Damping',...
            ['Fit, \chi=',num2str(chi_zt)],'Location','SouthEast');
        line(VAmp_fit,zt_material+10.^(Zt_Pfit),'Color','r','LineWidth',2,'LineStyle','-.');
end
    
% For this data set you can adjust the curve fit to fit a line to the
% linear portion at higher amplitudes and estimate chi.  The lower
% assymptote gives an estimate of linear damping from the material and
% boundary conditions.

%{
    % Add Lines for linear damping ratios, min and max.
    zt_high=Edis(1)/(VAmp_fit(1).^2*2*pi); % Note, should be the same as zt_fit(1)...
    zt_low=Edis(end)/(VAmp_fit(end).^2*2*pi); % 
%     minmax(zt_fit)
    line(VAmp_fit,zt_high*ones(size(VAmp_fit)),'Color',[0,0.5,0],'LineWidth',2,'LineStyle','--');
    line(VAmp_fit,zt_low*ones(size(VAmp_fit)),'Color','k','LineWidth',2,'LineStyle','--');
    legend('Estimated',['Fit, \chi=',num2str(chi_zt)],...
        ['Linear \zeta = ',num2str(zt_high)],['Linear \zeta = ',num2str(zt_low)]);
%}

%% Finish
    
 if nargout > 5;
    all_data = [];
    S = whos;
    for k = 1:length(S)
        if ~strcmpi(S(k).name,'all_data')
            eval(['all_data.',S(k).name,' = ',S(k).name,';']);
        end
    end
    varargout{1}=all_data;
end