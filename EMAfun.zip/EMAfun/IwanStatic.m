function [x,f_joint,K_joint,jys,varargout] = IwanStatic(K,fext,paramp,iwanPair,varargin)
% Solve for quasi-static response of a structure with Iwan joints.  Uses
% the Newton method as in IwanIntegration.m.
%
% [x,f_joint,K_joint,jys,varargout] = IwanStatic(K,fext,paramp,iwanPair,varargin)
%
% INPUTS:
% paramp = [Fs,Kt,chi,beta] % defines Iwan joint in physical parameters
% K = linear stiffness matrix (not including the stiffness of the Iwan
%   joints).
% fext = Applied force time history (Nnodes x Ntime)  If more than one time
% point is given, the response to each load is found sequentially using the
% prior state as an initial condition.
% iwanPair = [node1,node2] where node1 and node2 specify the indices of
%   the two nodes that are connected by the Iwan joint.
%
% OUTPUTS:
% x = displacement of each DOF
% f_joint = joint force applied by individual Iwan elements.
%
% Multiple Iwan joints may also be supplied by providing paramp and
% iwanPair as follows:
% paramp = [Fs1,Kt1,chi1,beta1]
%          [Fs2,Kt2,chi2,beta2]
%          [        ...       ]
%          [FsN,KtN,chiN,betaN]
% iwanPair = an array telling which DOF indices are connected by the nth
%   Iwan element. The number of rows reflects the number of pairs, and
%   the number of columns is always 2. For example, a 5-DOF system with an
%   Iwan element joining DOFs 2 with 4 and another between DOF 3 and ground 
%   would be specified as iwanPair=[2,4; 0,3]. The row index of this 
%   array is assosciated with the same row index of Iwan parameters in the
%   paramp input argument. 
%
% Other Options:
% Specify Initial Conditions
%   [x,f_joint,K_joint,jys,varargout] = IwanStatic(K,fext,paramp,iwanPair,ICs)
% Include maps for Iwan forces (e.g. for a substructuring problem).  For
% example, if we have physical coordinates {x} related to modal coordinates
% {q} and we have {x}=[L]{q} then we can use:
%   [x,f_joint,K_joint,jys,varargout] = IwanStatic(K,fext,paramp,iwanPair,ICs,SSMaps)
%       Must include: SSMaps.Fjmap, SSMaps.Ujmap, SSMaps.GradMat
%       These help relate the joint forces, displacement and jacobian as:
%       uj_vector=Ujmap(:,:,k)*u_est(all DOF); % uj_vector in Physical Coordinates
%           uj(scalar)=uj_vector(iwanPair(2,k))-uj_vector(iwanPair(1,k))
%           e.g. Ujmap(:,:,k)=L
%       K(all DOF) = k_joint(scalar)*GradMat
%           e.g. GradMat=L.'*[1; -1; 0; 0; ...]*[1, -1, 0, 0, ...]*L
%       f(all DOF) = f_joint(scalar)*Fjmap
% 
% Created by M.S. Allen, July 2015 from Lacayo's IwanIntegration.m
%

% Check function arguments, check for size consistency
[Ndof,Nt] = size(fext);
if Ndof~=size(K,1) || Ndof~=size(K,2)
    error('Size of Force Vector is not compatible with size of K');
end
% Check iwanPair matrix and place any zero indices first.
for k=1:size(iwanPair,1);
    if iwanPair(k,2)==0;
        iwanPair(k,:)=fliplr(iwanPair(k,:));
        if iwanPair(k,2)==0; error('Both indices for the Iwan joint cannot be zero'); end
    end
    % Now the first index is zero if the Iwan joint goes to ground.
end
if nargin > 4
    % Want ICs={x0,jys}
    ICs=varargin{1};
    if ~isempty(ICs)
        if length(ICs{1})~=Ndof
            error('ICs aren''t of comptabile size');
        end
    end
else
    ICs=[];
end
if nargin > 5 % passing in mapping matrices for a substructure problem.
    SSMaps=varargin{2};
        % Must Contain: SSMaps.Fjmap, SSMaps.Ujmap, SSMaps.GradMat
else
    SSMaps=[]; % Used as a flag to tell when a substructuring problem is done
end

%
NIwan=size(paramp,1);
    % Check that iwanPairs is of the same size
    if size(iwanPair,1)~=NIwan; error('Size of "paramp" and "iwanPair" doesn''t match'); end
for k=1:NIwan % Find mathematical description of Iwan parameters
    paramm(k,:)=iwanconvert(paramp(k,:));
end

% Prepare mapping matrices for Iwan forces
if isempty(SSMaps);
    indVec = zeros(Ndof,NIwan);
    indMat = zeros(Ndof,Ndof,NIwan);
    for k=1:NIwan
        ind1 = iwanPair(k,1); ind2 = iwanPair(k,2);
        if ind1==0 % mass index 2 is joined to ground
            indVec(ind2,k) = 1;
            indMat(ind2,ind2,k) = 1;
        else % mass indices are joined with iwan element
            indVec(ind1,k) = -1; indVec(ind2,k) = 1;
            indMat([ind1,ind2],[ind1,ind2],k) = [1,-1;-1,1];
        end
        Ujmap(:,:,k)=eye(Ndof);
    end
else
    indVec=SSMaps.Fjmap;
    indMat=SSMaps.GradMat;
    Ujmap=SSMaps.Ujmap;
end

%% Begin quasi-static solution

%Initialize Variables
x  = zeros(Ndof, Nt);
    if ~isempty(ICs) % Pass in initial conditions
        x(:,1)=ICs{1};
    end
newton_iter=zeros(1,Nt);

u_prev = zeros(Ndof,1); 
    if ~isempty(ICs) % Pass in initial conditions
        u_prev=x(:,1);
    end

% Variables to store joint force
f_joint = zeros(NIwan,Nt);
K_joint = zeros(NIwan,Nt);

% Use NJ Jenkins elements
NJ = 100;
jy_prev  = zeros(NJ,NIwan);
jys = zeros(NJ,Nt,NIwan);
if ~isempty(ICs)
    if length(ICs)>2
        NJ=length(ICs{3});
        jy_prev=ICs{2}; % Check, is this the best way to pass in?
        jys=zeros(NJ,Nt,NIwan);
        jys(:,1,:)=jy_prev;
    end
end
% Initialize for below.
ftemp=zeros(NIwan,1); stiff_temp=ftemp; jy_temp=zeros(size(jy_prev));

% Solve for every timestep
for it = 1:Nt
    
    u_est=u_prev; %     u_est = u_prev + -grad\resid; % MSA inserted 9/6/2016
    
    % Calculate Iwan Force and Jacobian
    fjVec=zeros(Ndof,1);
    stiffMat=zeros(Ndof,Ndof);
    for k=1:NIwan
        ind1 = iwanPair(k,1); ind2 = iwanPair(k,2);
        % Calculate non-linear force at location defined by iwanPair
        uj=Ujmap(:,:,k)*u_est;
        if ind1==0 % mass index 2 is joined to ground
            [ftemp(k,1), jy_temp(:,k), stiff_temp(k,1)] = iwan(uj(ind2), jy_prev(:,k), paramm(k,:));
        else % mass indices are joined with iwan element
            [ftemp(k,1), jy_temp(:,k), stiff_temp(k,1)] = iwan(uj(ind2)-uj(ind1), jy_prev(:,k), paramm(k,:));
        end
        % Add up forces from all Iwan joints.
        fjVec = fjVec + ftemp(k,1)*indVec(:,k);
        stiffMat = stiffMat + stiff_temp(k,1)*indMat(:,:,k);
    end
    resid = K*u_est + fjVec - fext(:,it);
    grad = K+stiffMat; % Not needed here
    u_prev=u_est;
    
    % Newton Iteration Loop
    iter = 0;
    while ((resid'*resid/norm(fext)^2) > 1e-12) || iter<1
        % MSA added the second condition 9/6/2016 - forces it to do at
        % least one iteration so it works for very small displacements.

        u_est = u_prev + -grad\resid;
%         [u_prev, u_est, resid];
        
        % Recalculate force and check residual
        fjVec=zeros(Ndof,1);
        stiffMat=zeros(Ndof,Ndof);
        for k=1:NIwan
            ind1 = iwanPair(k,1); ind2 = iwanPair(k,2);
            % Calculate non-linear force at location defined by iwanPair
            uj=Ujmap(:,:,k)*u_est;
            if ind1==0 % mass index 2 is joined to ground
                [ftemp(k,1), jy_temp(:,k), stiff_temp(k,1)] = iwan(uj(ind2), jy_prev(:,k), paramm(k,:));
            else % mass indices are joined with iwan element
                [ftemp(k,1), jy_temp(:,k), stiff_temp(k,1)] = iwan(uj(ind2)-uj(ind1), jy_prev(:,k), paramm(k,:));
            end
            % Add up forces from all Iwan joints.
            fjVec = fjVec + ftemp(k,1)*indVec(:,k);
            stiffMat = stiffMat + stiff_temp(k,1)*indMat(:,:,k);
        end
        
        resid = K*u_est + fjVec - fext(:,it);
        grad = K+stiffMat; % Updates the gradient for the next iteration.
        u_prev=u_est; % That is the new point to linearize about
        iter = iter + 1;  
%         if iter>100;
%             disp('About to fail due to excessive iterations: pausing'); pause
%         end

        % MSA Idea: Use: >> "dbstop in myprogram at 4 if n>=4"
        % Then use dbquit to get out.
        if iter>100; error('Newton iteration loop failed to converge after 100 iterations'); end
    end
    
    f_joint(:,it) = ftemp;
    K_joint(:,it) = stiff_temp;
    
    jy_prev = jy_temp;
    jys(:,it,:) = jy_temp;
    
    newton_iter(it) = iter;
    epval(it)=(resid'*resid/norm(fext)^2);
    u_prev = u_est;
    
    x(:,it) = u_est;
    
    if round(it/10000) == (it/10000); fprintf('.'); end
end

% Optional output arguments.
if nargout>4;
    ad.newton_iter=newton_iter;
    ad.K_joint=K_joint;
    ad.jys=jys;
    ad.paramm=paramm;
    ad.newton_iter=newton_iter;
    ad.indMat=indMat;
    ad.indVec=indVec;
    ad.epval=epval;
    varargout{1}=ad;
end