function [Azero_out] = ptvRes2Phi(Ares,ts,lam);
% [Azero_out] = ptvRes2Phi(Ares,ts,lam);
%
% Function that extracts a vector proportional to the mode vector for
% Rotating systems from the identified residues.  (Method #1 in IMAC paper
% 2006 by Allen, and Ginsberg.)
%
% Ares - Residue matrix, where each column corresponds to the residue
%       vector for sequential initial conditions
% ts -  Time vector covering at least one period
% lam - Eigenvalue for the residue matrix of interest.
% Azero_out = Residue vector with the effect of differing initial times
% removed.
%
% Matt Allen July 11, 2005
%

No = size(Ares,1); Ns = size(Ares,2);
%TA = Ns*(ts(2)-ts(1));
%w1 = 2*pi/TA;

for k = 1:Ns
    Azero_out(:,k) = Ares(:,k)*exp(-lam*(ts(k)-ts(1)));
end

% ps = [-NR:1:NR];
% if length(ps) > Ns;
%     error(['Too many terms in FS expansion.  No more than NR = ',num2str(Ns)...
%         ', terms allowed.']);
% end
% 
% A = zeros(Ns*No, No*length(ps));
% for k = 1:Ns;
%     A(((k-1)*No + 1):(k*No),:) = kron([exp(i*w1*ps*(ts(k)-ts(1)))],...
%         [exp(lam*(ts(k)-ts(1)))*eye(No)]);
% end
% b = Ares(:);
% 
% B = A\b;
% 
% Bc = reshape(B,No,length(ps));
% 
% tcyc = ts(1:Ns);
%     % Make tcyc a row vector
%     tcyc = tcyc(:).';
% 
% Phi_out = zeros(size(Ares));
% for k = 1:length(ps)
%     Phi_out = Phi_out + Bc(:,k)*exp(i*w1*ps(k)*tcyc);
% end

save debugdata.mat