function [Phi_out] = ptvRes2Phi(Ares,NR,ts,lam);
% [Phi_out] = ptvRes2Phi(Ares,NR);
%
% Function that extracts a vector proportional to the mode vector for
% Rotating systems via Fourier Expansion
%
% Ares - Residue matrix, where each column corresponds to the residue
%       vector for sequential initial conditions
% NR -  Number of terms to use in the Fourier Series expansion of Phi.
% ts -  Time vector covering at least one period
% lam - Eigenvalue for the residue matrix of interest.
% Phi_out = Mode shape as a function of theta (or omega*t).  The size of
%       Phi_out is made to match that of Ares.
%
% Matt Allen July 11, 2005
%

No = size(Ares,1); Ns = size(Ares,2);
TA = Ns*(ts(2)-ts(1));
w1 = 2*pi/TA;

ps = [-NR:1:NR];
if length(ps) > Ns;
    error(['Too many terms in FS expansion.  No more than NR = ',num2str(Ns)...
        ', terms allowed.']);
end

A = zeros(Ns*No, No*length(ps));
for k = 1:Ns;
    A(((k-1)*No + 1):(k*No),:) = kron([exp(i*w1*ps*(ts(k)-ts(1)))],...
        [exp(lam*(ts(k)-ts(1)))*eye(No)]);
end
b = Ares(:);

B = A\b;

Bc = reshape(B,No,length(ps));

tcyc = ts(1:Ns);
    % Make tcyc a row vector
    tcyc = tcyc(:).';

Phi_out = zeros(size(Ares));
for k = 1:length(ps)
    Phi_out = Phi_out + Bc(:,k)*exp(i*w1*ps(k)*tcyc);
end

save debugdata.mat