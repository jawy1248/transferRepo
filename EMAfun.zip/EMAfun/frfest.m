function [H,ws,gam] = frfest(y,u,ts,Nblk,window_name,NoPCToverlap,method)
%
% [H,ws,gam] = frfest(y,u,ts,Nblk,window_name,NoPCToverlap,method)
%
% Frequency Response Functin Estimate from input-output data.
%
% Function which forms power and cross spectra and estimates
% method =  'H1'
%        =  'H2'
%   other methods not yet supported.
%
% Matt Allen, Spring 2005
% msalle@sandia.gov
%

% Find Spectral Density Matrices for use by algorithms.
if nargout > 2 | ~strcmp(upper(method),'H1')
    % This is somewhat inefficient.  We really only need the diagonal of Gyy to find coherence.
    [Guu Gyu ws Gyy] = mimocsd(y,u,ts,Nblk,window_name,NoPCToverlap);
else
    [Guu Gyu ws] = mimocsd(y,u,ts,Nblk,window_name,NoPCToverlap);
end

Ni = size(Gyu,1); No = size(Gyu,2); Nw = size(Gyu,3);
H = zeros(No,Ni,Nw);

if strcmp(upper(method),'H1');
    for k = 1:Nw
        H(:,:,k) = Gyu(:,:,k)/Guu(:,:,k);
        Fvirt(k,:) = eig(Guu(:,:,k)).';
    end
    
    if Ni > 1;
        figure(1);
        plot(ws, Fvirt); title('Virtual Forces');
        xlabel('Frequency (rad/s)');
    end
    
elseif strcmp(upper(method),'H2');
    for k = 1:Nw
        H(:,:,k) = Gyy(:,:,k)/Gyu(:,:,k);
        RGyu(k,:) = eig(Guu(:,:,k)).';
    end
    
    if Ni > 1;
        figure(1);
        plot(ws, Rgyu); title('Rank of Gyu at each frequency');
        xlabel('Frequency (rad/s)');
    end
end

% Compute Multiple Coherence - Allemang v3_5.pdf page (5-25)
gam = zeros(Nw,No);
if nargout > 2
    for k = 1:Nw
        for p = 1:No
            for q = 1:Ni
                for t = 1:Ni
                    gam(k,p) = gam(k,p) + H(p,q,k)*Guu(q,t,k)*conj(H(p,t,k))/Gyy(p,p,k);
                end
            end
        end
    end
end
if norm(imag(gam))/norm(real(gam)) > 1e-5; warning('Coherence is not real'); end

gam = real(gam);

return

% Compute Ordinary Coherence - Allemang v3_5.pdf page (5-24)
gam = zeros(Nw,No);
if nargout > 2 & Ni == 1;
    for k = 1:Nw
        for p = 1:No
            gam(k,p) = abs(Gyu(p,1,k))^2/(Gyy(p,p,k)*Guu(1,1,k));
        end
    end
end
gam = sqrt(gam);