function [Hsum] = LMS_sum_FRFs(Hin);
% function [Xw_comp] = LMS_sum_FRFs(Hin);
%
% Function which adds the absolute values of the real and imaginary parts (respectively)
% to form a sort of Nyquist Composite, mapped to the first quadrant.
%
% Source:  Communication with Bart Peeters - Feb 10, 2005
%


% Sum over all drive points
[a b c] = size(Hin);
if c == 1;
    Hsum = sum(abs(real(Hin)),2) + i*sum(abs(imag(Hin)),2);
else
    Hsum = sum(abs(real(Hin)),3) + i*sum(abs(imag(Hin)),3);
    Hsum = sum(abs(real(Hsum)),2) + i*sum(abs(imag(Hsum)),2);
%     for ii = 1:1:c
%         Xc_temp(:,ii) = sum(abs(X(:,:,ii)),2);
%     end
%     Xw_comp = sum(Xc_temp(:,2))/(b*c);
end
