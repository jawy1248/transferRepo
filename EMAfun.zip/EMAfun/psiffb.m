function [psi] = psiffb(y,j,an,Rn)
% [psi] = psiffb(y,j,an,Rn)
% Mode Functions for Free-Free Beam
% j = 1 and j = 2 correspond to rigid body modes, the rest correspond to
% the anaylytical mode functions
%
% Elastic Modes:
% [psi] = sin(an*y) + sinh(an*y) + Rn*(cos(an*y) + cosh(an*y))
%
% From Ginsberg Mechanical and Structural Vibrations 2001
%
% Note:  to Compute an and Rn:
%
% N = 10;
% an0 = [4.73,(2*[4:(N+2)]-3)/2*pi];
% for k = 1:N;
%     an(k) = fzero(ce,an0(k));
% end
% for j = 1:N;
%     Rn(j) = -(sin(an(j)) - sinh(an(j)))/(cos(an(j)) - cosh(an(j)));
% end
%
% Vectorized to work with 'quadl' numerical integration scheme.

if j == 1;
    % First Rigid Body Mode
    psi = ones(size(y));
elseif j == 2;
    % Second Rigid Body Mode
    psi = y-0.5;
elseif j > 2;
    psi = sin(an*y) + sinh(an*y) + Rn*(cos(an*y) + cosh(an*y));
end