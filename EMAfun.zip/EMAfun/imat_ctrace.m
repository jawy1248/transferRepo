function cstr = imat_ctrace(fem)
cstr = {};
for i = 1:length(fem.node.id)
    for j = 'XYZ'
        cstr{end+1,1} = [num2str(fem.node.id(i)),j,'+'];
    end
end