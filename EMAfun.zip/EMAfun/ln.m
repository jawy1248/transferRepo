function [natlogvalue] = ln(x);

natlogvalue = log(x);