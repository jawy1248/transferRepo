% function [Hout] = frfscomb(HA,nmHA,HB,nmHB,cnames,ofrfs_ioc);
% 
% FRF based substructure coupling using the derivation of Jetmundsen et al.
% Finds FRFs for C system which is the result of combining subsystems A and
% B and the connection coordinates "c".
%
% [Hout] = frfscomb(HA,HB,nmHA,nmHB,cnames,nmOutCoords);
%
% INPUTS:
%   HA - NoA x NiA FRF matrix for A system
%   nmHA - cell array giving names of inputs and outputs for HA:
%       nmHA.in = {'name_input_1'; 'name_input_2'; ...}
%       nmHA.out = {'name_output_1'; 'name_output_2'; ...}
%   HB - defined similarly
%   connpts - Nc x 2 array of coordinates to be connected.  First column
%           corresponds to A, second to B.  For example:
%       connpts = {'name_input_1','name_input_2';...
%               'name_output_1','name_output_3'}
%               % Connects name_input_1 on A to name_input_2 on B and
%               name_output_1 on A to name_output_3 on B.
%   #### NOT FINISHED!!!! #####
%   nmOutCoords - similar to nmHA but for the output desired.  This m-file
%   generates all of the FRFs between the inputs and outputs specified.
%       nmOutCoords.in = {'name_input_1','A'; ...
%                         'name_input_2','B'; ...}
%       nmOutCoords.out = {'name_output_1','B'; ...
%                          'name_output_2','A'; ...}
%
%   Note - reciprocity is assumed if full FRF matrices are not provided...????
%
% OUTPUTS:
%   Hout
%
% Matt Allen, Dec 2006
%   Last Modified Dec. 20, 2006

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Note: Equations from Phil Ind's Thesis, Imperial College, London, p. 117,
% eq. 4.3.3.  Originally from Jetmundsen, Bielawa & Flannelly.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Debug data
HA = randn(3,4,100);
nmHA.out = {'1'; '2'; '3'; '4'}; nmHA.in = {'1'; '2'; '4'; '3'};
HB = randn(2,2,100);
nmHB.out = {'1'; '2'; '5'}; nmHB.in = {'1'; '2'; '5'};
connpts = {'1', '1'; '3', '2'};
anms = {'3'; '4'}; bnms = {'5'};
outs_req = {'ab','cc'};
% nmOutCoords.out = {'1', 'A'; '2', 'B'};
% nmOutCoords.in = {'1', 'A'; '2', 'B'};


%% Add a check - always need full FRF matrices for coupling DOF for A and B
% Check that everything needed to provide the desired output is given.
%%

% Partition HA and HB into connection and other dof as in Ind 4.3.3
% Find indices of connection points on A and B inputs and outputs
Nc = size(connpts,1); Acindout=zeros(Nc,1); Acindin=zeros(Nc,1);
Bcindout=zeros(Nc,1); Bcindin=zeros(Nc,1);
for k = 1:Nc
    Acindout(k) = find(strcmp(connpts{k,1},nmHA.out));
    Acindin(k) = find(strcmp(connpts{k,1},nmHA.in));
	Bcindout(k) = find(strcmp(connpts{k,2},nmHB.out));
    Bcindin(k) = find(strcmp(connpts{k,2},nmHB.in));
end
% Find indices of other points on A and B inputs and outputs.

Aaindout = setdiff([1:size(HA,1)],Acindout);
Aaindin = setdiff([1:size(HA,2)],Acindin);
Bbindout = setdiff([1:size(HB,1)],Bcindout);
Bbindin = setdiff([1:size(HB,2)],Bcindin);

% Partition matrices
    HAcc = HA(Acindout,Acindin,:);
    HAca = HA(Acindout,Aaindin,:);
    HAac = HA(Aaindout,Acindin,:);
    HAaa = HA(Aaindout,Aaindin,:);

    HBcc = HB(Bcindout,Bcindin,:);
    HBcb = HB(Bcindout,Bbindin,:);
    HBbc = HB(Bbindout,Bcindin,:);
    HBbb = HB(Bbindout,Bbindin,:);

% Determine which blocks of the solution matrix are needed, 11, 12, etc...
    % Find indices for input and outputs requested in A and B
    for k = 1:size(nmOutCoords.out,1)
        if strcmpi(nmOutCoords.out{k,2},'A')
            nmOutCoords.oind(k) = find(strcmp(nmOutCoords.out{k,1},nmHA.out));
            nmOutCoords.oAflg(k) = true(1);
        else
            nmOutCoords.oind(k) = find(strcmp(nmOutCoords.out{k,1},nmHB.out));
            nmOutCoords.oAflg(k) = false(1);
        end
    end
	for k = 1:size(nmOutCoords.in,1)
        if strcmpi(nmOutCoords.in{k,2},'A')
            nmOutCoords.iind(k) = find(strcmp(nmOutCoords.in{k,1},nmHA.in));
            nmOutCoords.iAflg(k) = true(1);
        else
            nmOutCoords.iind(k) = find(strcmp(nmOutCoords.in{k,1},nmHB.in));
            nmOutCoords.iAflg(k) = false(1);
        end
    end


