function [d, v, a] = genalpha(M,C,K,ts,d0,v0,Ft,rho);
% Generalize Alpha method for time integration of Structural Dynamics
% equations of motion.
%
% Taken from Salinas Theory Manual - Sandia National Lab. and Hulbert, G. M
% and J. Chung, "Explicit time integration algorithms for structural
% dynamics with optimal numerical dissipation," Computer Methods in Applied
% Mechanics and Engineering, vol. 137, 1996, pg. 175-188.
%
% [d, v, a] = genalpha(M,C,K,ts,d0,v0,Ft,rho);
%
% 'ts' is a vector of times, spaced by an equal time increment dt.
%
% rho controls the numerical damping
%       rho = 0.9 is a typical value (T. W. Simmermacher & Salinas Manual)
%
% Matt Allen July 27, 2005

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % TEMPORARY - Parameters for testing
% clear all; close all
% k1 = 1;
% k2 = 2;
% m = 1;
% 
% % System Matrices
%     M = [m 0; 0 m]; % mass matrix is constant with theta
%     K = [(k1+k2), -k2;
%         -k2, k2];
%     % Use Modal Damping
%     [Phir,Lamr] = eignorm(K,M);
%     ztset = 0.02;
%         C = inv(Phir.')*2*ztset*sqrt(Lamr)*inv(Phir);
%     % K = zeros(2); C = zeros(2);
% % Set Sampling Parameters - Correctly sampled
%     ts = [0:0.5:500];
%     
% rho = 0.9;
% d0 = [0; 0];
% v0 = [1; 0];
% Ft = zeros(2,length(ts));
%     
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Set up integration parameters
alf = rho/(rho+1);
alm = (2*rho-1)/(1+rho);
gam = 1/2 - alm + alf;
bet = (1/4)*(1/2 + gam)^2;

% Check Time Vector
dt = mean(diff(ts));
if abs(max(diff(ts)) - min(diff(ts))) > 1e5*eps;
    error('time samples are not uniformly spaced');
end
N = length(ts);

% Check IC vectors and Force Vector
if size(Ft,1) ~= length(d0) | size(Ft,1) ~= length(v0)
    error('Initial Condition and Force Vector sizes don''t match');
end

% Find initial acceleration and set up vectors
a0 = M\(Ft(:,1) - C*v0 - K*d0);
d = zeros(length(d0),length(ts));
v = zeros(length(d0),length(ts));
a = zeros(length(d0),length(ts));
d(:,1) = d0; v(:,1) = v0; a(:,1) = a0;

% Begin algorithm
for n = 1:(N-1);
    d(:,n+1) = (M*((1-alm)/(bet*dt^2)) + C*((1-alf)*gam/(bet*dt)) + K*(1-alf))\...
        (   (1-alf)*Ft(:,n+1) + alf*Ft(:,n) - K*alf*d(:,n) - ...
        C*(alf*v(:,n) + (1-alf)*(v(:,n) + dt*(1-gam)*a(:,n) + ...
            (gam/(bet*dt))*(-d(:,n) - dt*v(:,n)) - ...
            ((gam*dt*(1-2*bet))/(2*bet))*a(:,n))) + ...
        M*(-alm*a(:,n) + ((1-alm)/(bet*dt^2))*(d(:,n) + v(:,n)*dt) + ...
            (1-alm)*((1-2*bet)/(2*bet))*a(:,n))   );
    a(:,n+1) = (1/(bet*dt^2))*(d(:,n+1) - d(:,n) - v(:,n)*dt) - ((1-2*bet)/(2*bet))*a(:,n);
    v(:,n+1) = v(:,n) + dt*((1-gam)*a(:,n) + gam*a(:,n+1));
end

% 
% figure(1);
% plot(ts,d, '.-', ts, v, '.-',ts, a, '.-'); grid on;
% legend('d1','d2','v1','v2','a1','a2');


