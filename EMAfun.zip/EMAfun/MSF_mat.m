function msf = MSF_mat(phi1,phi2)
% Modal Scale Factor:
%
% [MSF] = MSF(phi1,phi2);
%
% Computes the modal scale factor between pairs of vectors comprising the
% the columns of the matrices phi1 and phi2.

Nmds = min(size(phi1,2),size(phi2,2));
if size(phi1,2) ~= size(phi2,2);
    warning(['Matrices have different numbers of modes.  ',...
        'Only the first ',num2str(Nmds),' will be used.']);
end
if size(phi1,1) ~= size(phi2,1);
    error(['Mode shape matrices have different numbers of rows (points)']);
end

% Calculate the MSF values also.  (Based on UC Vibrations)
msf = zeros(Nmds,1);
for kk = 1:Nmds
    msf(kk) = (phi1(:,kk)).'*phi2(:,kk)/...
        (phi2(:,kk).'*phi2(:,kk));
end

msf = abs(msf);