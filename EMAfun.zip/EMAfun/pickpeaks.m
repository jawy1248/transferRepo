function [inds] = pickpeaks(N,x,varargin)
% Pick N peaks off of a plot and locate the nearest index in the frequency
% (horizontal axis) vector.
%
% [inds] = pickpeaks(N,x)
% 
% use picks N points on the current plot.  The algorithm then finds the
% indicies of the nearest values in the vector x.]
% If the x- and y- data used to create the plot is given, then this m-file 
% adds a marker at each peak that is chosen.  Use the following calling
% format to utilize this feature.
%
% [inds] = pickpeaks(N,ws/2/pi,comp_FRF(H));
%

[xg,yg] = ginput(N)

if nargin > 2
    y = varargin{1};
end

for k = 1:N
    [junk,inds(k)] = min(abs(x-xg(k)));
    % Add points to plot if given
    if nargin > 2
        line(x(inds(k)),y(inds(k)),'Marker','*','Color','k'); end
end


