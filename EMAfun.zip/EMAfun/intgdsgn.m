function b = intgdsgn(N)
% intgdsgn      function b = intgdsgn(N)
% function to design an integrator, using Smallwood's method
% N = the number of terms desired, should be an even number.
%     The larger N the longer the integration takes, but the wider the bandwidth
%     for which the integration is accurate.
% b = a row vector of length(N), the integration weights.

% D. O. Smallwood, Sandia National Laboratories, 5/27/94
% Reference: Smallwood, David O.,"Integration of Equally Spaced Sampled Data
%            Using a Generalized Whittaker's Reconstruction Formula," IEEE Transactions
%            on Acoustics, Spech, and Signal Processing, Vol. ASSP-28, No. 3, June 1980.

N = 2*fix(N/2);    % make sure N is an even integer
if N<2, N=2;, end  % 2 is the smallest size allowed
N2=N/2;
for j=1:N2
    %b(j) = quad8m('intgwin',j-1,j,1e-6,[],N);
    b(j) = quadl('intgwin',j-1,j,1e-6,[],N);  %modified by D. Epp 8/22/05
%disp('line 18 intgsgn'), keyboard
end
b=b(:);
b = b';
bm = b(N2:-1:1);
b = [bm b];
bsum = sum(b);
b = b./bsum;       % sum of all b's must be 1.0

