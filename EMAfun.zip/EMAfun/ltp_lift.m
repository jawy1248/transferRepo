function [hlifted] = ltp_lift(h,Nltp);
% [hlifted] = ltp_lift(h,Nltp)
%
% Lift a periodically sampled signal to create a [Nt x Nltp x Ni] set of
% responses, hlifted, from an [Nt x Ni] matrix, h, of responses.
% 
% If h has a length that is not evenly divisible by Nltp, then the extra
% fraction of a cycle is discarded.
%
% MSA 4/27/2009

Nt_lifted = floor(size(h,1)/Nltp); % number of time points per lifted response
hlifted = zeros(Nt_lifted,Nltp,size(h,2));

for ki = 1:size(h,2)
    for kt = 1:Nt_lifted;
        for kl = 1:Nltp;
            hlifted(kt,kl,ki) = h(kl+(kt-1)*Nltp,ki);
        end
    end
end