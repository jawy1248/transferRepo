function [carray] = mkconstr(subsys,varargin)
%
% Make constraints for cms.m or ritzscomb.m - creates constraint arrays to 
% join pairsof subsystems given the subsystem index and the names of the 
% nodes to be joined.
% 
%   carray = mkconstr(subsys,s1,s2,nodes,s1,s2,nodes,...)
%
% subsys is a cell array containing the following for the kth subsystem:
%   subsys(k).wn = vector of nat freqs
%   subsys(k).zt = vector of damping ratos (optional)
%   subsys(k).phi = mode shape matrix (No x N where No = number of outputs,
%       N = number of modes)
%   subsys(k).names = cell array of names of each of the nodes (length No)
%   
%   The result is:
%   carray = [1, ns1, s1; -1, ns2, s2]; etc... as needed for cms.m
%
% EXAMPLE:  Join two subsystems so that (y1)1=(y1)2 and (z1)1=(z1)2 displacement
%   subsys(1).phi = [3xN matrix]
%   subsys(1).names = {'x1','y1','z1');
%   subsys(2).phi = [4xN matrix]
%   subsys(2).names = {'x3','x1','y1','z1');
%   carray = mkconstr(subsys,1,2,{'y1','z1'})
%       returns the constraint array needed to enforce equal motion of
%       those two nodes between subsytems 1 and 2.
%       - One could then use [...] = ritzscomb(subsys,carray,[1,1]) to
%       compute the modes of the coupled system.
%
% Alternate Input: Provide DOF vectors saying which nodes to match.
%   nodes=[DOF1,DOF2]
%       (example)
%       subsys(1).DOF=[101.1; 101.2; 101.3]; % etc...
%       nodes=[101.1, 201.1;
%              101.2, 201.2];
%       carray = mkconstr(subsys,s1,s2,nodes,s1,s2,nodes,...)
%   This constrains DOF 101.1 to DOF 201.1 and DOF 101.2 to DOF 201.2
%
% M.S. Allen (Aug 2006), Revised July 2016 - updated help file
%

if (nargin-1)/3 ~= round((nargin-1)/3);
    error(['Subsequent input arguments must occur in triples, nargin = ',num2str(nargin)]);
end

Ncs = (nargin-1)/3;

constr_num = 1;
for cnum = 1:Ncs % loop over constraint sets
    s1 = varargin{3*(cnum-1)+1};
    s2 = varargin{3*(cnum-1)+2};
    nlist = varargin{3*(cnum-1)+3};

    %if ~isnumeric(s1); error('s1 should be the integer index for the first subsystem'); end
    %if ~isnumeric(s2); error('s2 should be the integer index for the first subsystem'); end
    %if ~iscell(nlist); error('nodes should be a cell array listing nodes to be joined'); end
    
    if iscell(nlist);
        
        for nnum = 1:length(nlist);
            ns1 = find(strcmp(subsys(s1).names,nlist{nnum}));
                if isempty(ns1);
                    error(['Node ',nlist{nnum},' not found on subsys ',num2str(s1)]); end
                if length(ns1) > 1;
                    error(['Multiple matches for node ',nlist{nnum},' on subsys ',num2str(s1)]); end
            ns2 = find(strcmp(subsys(s2).names,nlist{nnum}));
                if isempty(ns2);
                    error(['Node ',nlist{nnum},' not found on subsys ',num2str(s2)]); end
                if length(ns2) > 1;
                    error(['Multiple matches for node ',nlist{nnum},' on subsys ',num2str(s2)]); end
            carray(:,:,constr_num) = [1, ns1, s1; -1, ns2, s2];
            constr_num = constr_num+1;
        end
    
    else % Here nlist is an Nconstr x 2 matrix telling which DOF to match
        if ~isnumeric(nlist) || size(nlist,2)~=2
            error('nodes is not a cell array or a numeric Nconstr x 2 matrix');
        end
        if ~isfield(subsys,'DOF');
            error('Subsystem must have a DOF vector to use DOF to locate nodes');
        end
        
        for nnum = 1:size(nlist,1);
            ns1 = find(subsys(s1).DOF==nlist(nnum,1));
                if isempty(ns1);
                    error(['DOF ',num2str(nlist(nnum,1)),' not found on subsys ',num2str(s1)]); end
                if length(ns1) > 1;
                    error(['Multiple matches for DOF ',num2str(nlist(nnum,1)),' on subsys ',num2str(s1)]); end
            ns2 = find(subsys(s2).DOF==nlist(nnum,2));
                if isempty(ns2);
                    error(['Node ',num2str(nlist(nnum,2)),' not found on subsys ',num2str(s2)]); end
                if length(ns2) > 1;
                    error(['Multiple matches for node ',num2str(nlist(nnum,2)),' on subsys ',num2str(s2)]); end
            carray(:,:,constr_num) = [1, ns1, s1; -1, ns2, s2];
            constr_num = constr_num+1;
        end
    end
            
end

%{
for k = 1:size(carray,3);
    disp(['Connecting ',subsys(carray(1,3,k)).names{carray(1,2,k)},...
        ' on SS ',num2str(carray(1,3,k)),' to ',...
        subsys(carray(2,3,k)).names{carray(2,2,k)},' on SS ',...
        num2str(carray(2,3,k))]);
end
%} 

    