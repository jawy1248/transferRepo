function [hls] = FRFplot(FreqHz, FRF, varargin)
%function FRFplot(FreqHz, FRF)
% Plot one or more Frequency Response Functions (FRFs); each FRF must have the
% same frequency lines.
%
% Modified by Matt Allen to require only two inputs, others optional.
% function plotFRF(FreqHz, FRF, iPlotType, TitleStr, LegendStr, FRFunits,YLimits)
%
%	iPlotType	1 x 1			integer
%		= 1	(default) Bode plot (semilogy magnitude and linear phase)
%		= 2	real and imaginary (2 linear subplots)
%		= 3	magnitude (semilogy)
%		= 4	phase (linear)
%		= 5	real (linear)
%		= 6	imaginary (linear)
%		= 11	Bode plot (magnitude and phase, 2 linear subplots)
%		= 13	magnitude (linear)
%       = 21    Bode plot with log mag, linear phase, log freq. axis.
%	FreqHz		nFreqLines x 1		real
%	FRF		nFreqLines x nFRF	complex
%	TitleStr	1 x numchars		char array
%	LegendStr	1 x nFRF		cell array
%	FRFunits	1 x numchars		char array
%	YLimits		(optional) y limits for plot	1 x 2 real in the form
%						  [Ymin Ymax]
% This function assumes each FRF is a column vector; use the non-conjugate
%   transpose (.') when calling this function if FRFs are row vectors.
% Sample calling sequences:
% (1) plot single FRF
%	plotFRF(1, FreqHz, FRFdata(:,Resp1), 'Title', 'line 1', '(in/s^2)/ft')
% (2) plot 2 FRFs
%	plotFRF(1, FreqHz, [FRFdata(:,Resp1), FRFdata(:,Resp2)], 'Title',...
%	  {'line 1' 'line 2'}, '(in/s^2)/ft')
% (3) plot only first 200 frequency lines of 2 FRFs
%	plotFRF(1, FreqHz(1:200),...
%	  [FRFdata(1:200,Resp1), FRFdata(1:200,Resp2)], 'Title',...
%	  {'line 1' 'line 2'}, '(in/s^2)/ft')
% (4) plot single FRF with specified y-limits on plots
%	plotFRF(1, FreqHz, FRFdata(:,Resp1), 'Title', 'line 1',...
%	  '(in/s^2)/ft', [0.0 50.0])
%
% Based on plotFRF by Curt Nelson,
% Modified by Matt Allen to only require two inputs.

%=======================================================================
% Based on plotFRF by Curt Nelson,
% Modified by Matt Allen to only require two inputs.
% 11-Sep-2003, Created (Curt Nelson)
% 03-Oct-2005, Last modified (Curt Nelson)

% features to add:
% - add plot options for logarithmic frequency axis
% - options
%	disable TeX processing for title
%	disable TeX processing for x- and y-axis labels
%	disable TeX processing for legend
%=======================================================================

% Check for inputs supplied and use defaults for the rest.
if nargin > 2
    iPlotType = varargin{1};
    if isempty(iPlotType); iPlotType = 1; end
else
    iPlotType = 1;
end
if nargin > 3; TitleStr = varargin{2}; else TitleStr = []; end
if nargin > 4; LegendStr = varargin{3}; else LegendStr = [];  end
if nargin > 5; FRFunits = varargin{4}; else FRFunits = [];  end
if nargin > 6; YLimits = varargin{5}; else YLimits = [];  end

LineColor = kron(ones(ceil(size(FRF,2)/7),1),get(gca,'ColorOrder'));
if length(FreqHz) ~= numel(FreqHz);
	beep
	whos FreqHz FRF
    error('FreqHz is not a vector');
else
    nFreqLines = size(FreqHz, 1);
end

if nFreqLines ~= size(FRF, 1)
    beep
    whos FreqHz FRF
    error('FreqHz vector and FRF matrix must have the same number of columns')
end
nFRF = size(FRF, 2);
if nFRF ~= size(LegendStr, 2) & ~isempty(LegendStr)
    whos FRF LegendStr
    error('LegendStr must have the same number of columns as the FRF matrix')
end

switch iPlotType
    case{1,11,4,21}
        % Generate phase of FRF if needed
        Deg = 180*angle(FRF)/pi;
        for ii=1:nFreqLines
            for jj=1:nFRF
            if (Deg(ii, jj) > 0.0)
                Deg(ii, jj) = Deg(ii, jj) - 360.0;
            end
            if (ii > 1)
                if abs(Deg(ii-1, jj) - Deg(ii, jj)) > 340.0
                Deg(ii, jj) = NaN;	% the 'NaN' acts like a pen-up command
                end
            end
            end
        end
end

switch iPlotType
    case {1,11,21}
        yvals = Deg;
        haxp = subplot('position',[0.10 0.84 0.88 0.10]);
    case 2
        yvals = imag(FRF);
        haxp = subplot('position',[0.10 0.53 0.88 0.41]);
    case {3,13}
        yvals = abs(FRF);
    case 4
        yvals = Deg;
    case 5
        yvals = real(FRF);
    case 6
        yvals = imag(FRF);
    otherwise
	error(['Illegal value (',num2str(iPlotType),') for iPlotType.'])
end

if iPlotType==3		% semilog plot
    hls(1,1) = semilogy(FreqHz, yvals(:,1), 'Color',LineColor(1,:));
else                % linear plot
    hls(1,1) = plot(FreqHz, yvals(:,1), 'Color',LineColor(1,:));
end
% Add Additional Lines if needed
    if nFRF > 1
        for ii = 2:nFRF
            hls(ii,1) = line(FreqHz, yvals(:,ii), 'Color',LineColor(ii,:));
        end
    end
if ~isempty(TitleStr); 
    title(['\bf',TitleStr])% , 'Interpreter', 'none' to disable TeX processing which displays
                        %   filename underscores as subscripts
end
set(gca, 'XLim', [min(FreqHz) max(FreqHz)])

switch iPlotType
    case {1,11,21}
        set(gca, 'YLim', [-360 0])
        set(gca, 'YTick', [-360 -180 0]);
        ylabel('\bfPhase [deg]')
        set(gca, 'XTickLabel', '')
    case 2
	if ~isempty(YLimits)
	    ylim(YLimits)
	end
        ylabel(['\bfImaginary part of FRF [' FRFunits ']'])
        set(gca, 'XTickLabel', '')
    case {3,13}
	if ~isempty(YLimits)
	    ylim(YLimits)
	end
        ylabel(['\bfFRF magnitude [' FRFunits ']'])
    case 4
        set(gca, 'YLim', [-360 0])
        set(gca, 'YTick', [-360:45:0]);
        ylabel(['\bfPhase [deg]'])
    case 5
	if ~isempty(YLimits)
	    ylim(YLimits)
	end
        ylabel(['\bfReal part of FRF [' FRFunits ']'])
    case 6
	if ~isempty(YLimits)
	    ylim(YLimits)
	end
        ylabel(['\bfImaginary part of FRF [' FRFunits ']'])
    otherwise
	error(sprintf('Illegal value (=%d) for iPlotType.', iPlotType))
end

% second subplot (if needed)

if iPlotType == 1 | iPlotType == 21
    hax = subplot('position',[0.10 0.09 0.88 0.71]);
    hls(1,2) = semilogy(FreqHz, abs(FRF(:,1)), 'Color',LineColor(1,:));
    if nFRF > 1
        for ii = 2:nFRF
            hls(ii,2) = line(FreqHz, abs(FRF(:,ii)), 'Color',LineColor(ii,:));
        end
    end
    ylabel(['\bfFRF magnitude [' FRFunits ']'])
    if ~isempty(YLimits)
	ylim(YLimits)
    end
    set(gca, 'XLim', [min(FreqHz) max(FreqHz)])
    % Change scale for type 21
        if iPlotType == 21
            set([haxp,hax],'XScale','Log');
        end
elseif iPlotType==2
    hax = subplot('position',[0.10 0.09 0.88 0.41]);
    hls(1,2) = plot(FreqHz, real(FRF(:,1)), 'Color',LineColor(1,:));
    if nFRF > 1
        for ii = 2:nFRF
            hls(ii,2) = line(FreqHz, real(FRF(:,ii)), 'Color',LineColor(ii,:));
        end
    end
    ylabel(['\bfReal part of FRF [' FRFunits ']'])
    if ~isempty(YLimits)
	ylim(YLimits)
    end
    set(gca, 'XLim', [min(FreqHz) max(FreqHz)])
elseif iPlotType==11
    hax = subplot('position',[0.10 0.09 0.88 0.71]);
    hls(1,2) = plot(FreqHz, abs(FRF(:,1)), 'Color',LineColor(1,:));
    if nFRF > 1
        for ii = 2:nFRF
            hls(ii,2) = line(FreqHz, abs(FRF(:,ii)), 'Color',LineColor(ii,:));
        end
    end
    ylabel(['\bfFRF magnitude [' FRFunits ']'])
    if ~isempty(YLimits)
	ylim(YLimits)
    end
    set(gca, 'XLim', [min(FreqHz) max(FreqHz)])
end

if ~isempty(LegendStr); legend(LegendStr, 4); end
xlabel('\bfFrequency (Hz)')

set(findobj(gcf, 'Type', 'Line'), 'LineWidth', 2)
legend		% refresh the legend so its linewidths are changed
[legh,childh] = legend;
% texth = findobj(childh, 'Type', 'text');
% set(texth, 'Interpreter', 'none', 'FontSize', 8)
% set(legh, 'Interpreter', 'none', 'FontSize', 8)

axes(hax); % make the main axis current before exiting
