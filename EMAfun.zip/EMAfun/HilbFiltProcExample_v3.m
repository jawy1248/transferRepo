% Sample script to load measurements, evaluate for any signs of nonlinear
% damping and use the Hilbert transform to estimate the modal Iwan
% parameter chi.
%
% M.S. Allen, July 2014, msallen@engr.wisc.edu
% Revised by R.M. Lacayo May 2016
%
clear; close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Insert commands here to load your data and name it accordingly
load('Hilb_SampleData_CatConv.mat') % Sample data from two catalytic converters bolted together
    t=t_resp(:); % column vector of time samples
    yt=resp(:); % column vector of response data 
        % This should be a 1DOF signal corresponding to a single mode.  To
        % make it a true modal amplitude, it should be divided by the mass
        % normalized mode shape:
    % yt=yt/phi
            % where phi is the mode shape for the mode of interest at the
            % measurement point.  Now yt = modal amplitude q(t)
    fs=mean(diff(t)).^-1; % Sample rate in Hz

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Plot initial (unfiltered) signal
figure(1);
plot(t,yt);
xlabel('time,s '); ylabel('Velo'); title('Time Response')

[Yw,ws] = fft_easy(yt,t);

figure(2);
semilogy(ws/2/pi, 2/length(t)*abs(Yw)); hold on;
xlabel('Freq, Hz'); ylabel('|Velo|');title('FFT of Processed Velocity')

figure(3);
semilogy(ws/2/pi, 2/length(t)*comp_FRF(Yw)); hold on;
xlabel('Freq, Hz'); ylabel('|Velo|');title('FFT of Processed Velocity')

%% Analyze with ZNLDetect
% This is a quick way to check whether any of the modal peaks show signs of
% nonlinearity that may need to be described by a modal Iwan model.

%{
[Fmat, f, ts_zc] = ZNLDetect(yt, t, [0.6,2], 1000, 5);
    close(103);
    % This data set shows clear evidence of Iwan-type nonlinearinty near
    % the first resonance (110 Hz)
%}

%% Analyze with new NLDampPalm.m function
ys=yt; % Choose which signal to analyze with Hilbert.
ts=t; % time vector
frange=[60,180,6]; % Low Freq, High Freq, Filter Order
% frange=[260,450,6]; % Low Freq, High Freq, Filter Order
dec_fact=2; nKnots=20;
% Call Palmov fitting function
% [zt_est,VAmp_fit,C_zt,chi_zt,Edis,ad] = NLDampPalm(ys,ts,frange,dec_fact,nKnots,'A','verbose','spline');
% Or, this way of calling uses a piecewise linear fit
[zt_est,VAmp_fit,C_zt,chi_zt,Edis,ad] = NLDampPalm(ys,ts,...
    frange,dec_fact,nKnots,'A','verbose','pwl');

%{
% And sometimes we need to flip and mirror the signals to improve the
% Hilbert analysis
[zt_est,VAmp_fit,C_zt,chi_zt,Edis,ad] = NLDampPalm([flipud(ys); ys],...
    [ts,ts+ts(end)+ts(2)],frange,dec_fact,nKnots,'A','verbose','pwl');
%}

    zt_material=ad.zt_material
    wn_fit=ad.wn_fit;  

% Find R for the Iwan model from the intercept (C_zt) from the damping fit
%     R_fit=2*pi*mean(wn_fit)^2*C_zt;
    R_fit=10^(log10(C_zt)+log10(2*pi*mean(wn_fit).^2)+(chi_zt+1)*log10(mean(wn_fit)));
        R_fit=R_fit*(chi_zt+3)*(chi_zt+2)/4; % Convert from Palmov to Iwan (R value defined differently in Iwan).
        
%% Add a line to overlay the analytical damping for a modal Iwan model.
%%%% NOTE: To obtain a meaningful model, VAmp_fit should be the mass-normalized
%%%% modal amplitude!

%{
% OPTION #1: Estimate all of the parameters and use trial and error to set
% them.
F_s=1e5; % assume well above tested range, then iterate
f_shift=50; % assumed frequency shift when joint slips completely in this mode
fn_0=112; % natural freuqency when joint completely stuck
K_inf=(fn_0*2*pi-f_shift*2*pi)^2; % Stiffness when spring is completely stuck
K_t=(fn_0*2*pi)^2-K_inf; % 
fn_inf=sqrt(K_inf)/2/pi
beta=1;
chi=chi_zt;
zt_material=0.00251; % defined above, or use this to overwrite it
%}

% OPTION #2: Keep Chi and R from above, estimate K_t and solve for F_s
f_shift=20/2/pi; %50; % assumed frequency shift when joint slips completely in this mode
fn_0=703.5/2/pi;%112; % natural freuqency when joint completely stuck
K_inf=(fn_0*2*pi-f_shift*2*pi)^2; % Stiffness when spring is completely stuck
K_t=(fn_0*2*pi)^2-K_inf; % 
fn_inf=sqrt(K_inf)/2/pi % this is the high amplitude natural frequency.
% zt_material=0.00251; % defined above, or use this to overwrite it

    % Calculate range of displacement amplitudes, so we can get a feel for
    % what phi_max should be.
    disp('Observed range of modal displacement amplitudes');
    XAmp_fit=VAmp_fit./wn_fit;
    minmax(XAmp_fit)

% Optimize to find phi_max such that K_t is maintained
    S=0;
    f=@(phi_max) abs(iwanconvert(chi_zt,phi_max,R_fit,S,'rev')*[0;1;0;0]+K_inf-(fn_0*2*pi)^2)
        [phim_opt]=fminsearch(f,1);
        phi_max=phim_opt
        p_est=iwanconvert(chi_zt,phim_opt,R_fit,S,'rev')
        F_s=p_est(1); beta=p_est(4); % others already defined above
        
% Construct analytical dissipation and frequency vs amplitude curves.
[Dm,Kj] = iwan_DKvsQ(XAmp_fit,K_inf,[F_s,K_t,chi_zt,beta],2*zt_material*(2*pi*fn_0));
% [Dm,Kj] = iwan_DKvsQ(XAmp_fit,K_inf,[chi_zt,phi_max,R_fit,0],2*zt_material*(2*pi*fn_0),'math');
    % Convert to physically meaningful parameters.
    wn_iwan = sqrt(Kj+K_inf); 
    zt_iwan = Dm./(XAmp_fit.^2.*wn_iwan.^2*2*pi);

% Construct some quantities from the iwan parameters
% Linear fit to damping vs. amplitude
Zt_Pfit=ad.zt_material+C_zt*VAmp_fit.^(chi_zt+1);
    
figure(63); %clf(63);
hd=subplot(2,1,1);
loglog(VAmp_fit,zt_est); grid on;
set(get(gca,'Children'),'Linewidth',2);
xylabels('\bfAmplitude (m/s)','\bfDamping Ratio');
title('\bfDamping vs. Velocity Amplitude')
	line(VAmp_fit,Zt_Pfit,'Color','r','LineWidth',2,'LineStyle','-.');
%     line(VAmp_fit,zt_high*ones(size(VAmp_fit)),'Color',[0,0.5,0],'LineWidth',2,'LineStyle','--');
%     line(VAmp_fit,zt_low*ones(size(VAmp_fit)),'Color','k','LineWidth',2,'LineStyle','--');
    line(XAmp_fit.*wn_iwan,zt_iwan,'Color','k','LineWidth',2)
    legend('Estimated',['Fit, \chi=',num2str(chi_zt)]);%,...
%         ['Linear \zeta = ',num2str(zt_high)],...
%             ['Linear \zeta = ',num2str(zt_low)],'Modal Iwan','location','SouthEast');
hf=subplot(2,1,2);
semilogx(VAmp_fit,wn_fit/2/pi,VAmp_fit,wn_iwan/2/pi,'k'); grid on;%,VAmp_fit,Edis2,'-.',VAmp_fit,Edis3,'k--'); grid on;
set(get(gca,'Children'),'Linewidth',2);
xylabels('\bfAmplitude (m/s)','\bfNatural Frequency');
title('\bfNatural Frequency vs. Velocity Amplitude')
legend('Estimated','Modal Iwan');

% {
% Plot the curve over a wider range to see global (extrapolated) behavior.
Xs=logspace(-6,-1,5000);
[Dm2,Kj2] = iwan_DKvsQ(Xs,K_inf,[F_s,K_t,chi_zt,beta],2*zt_material*(2*pi*fn_0));
% [Dm2,Kj2] = iwan_DKvsQ(Xs,K_inf,[chi_zt,phi_max,R_fit,0],2*zt_material*(2*pi*fn_0),'math');
    wd_iwan2 = sqrt(Kj2+K_inf);
    zt_iwan2 = Dm2./(Xs.^2.*wd_iwan2.^2*2*pi);
axes(hd); line(Xs.*wd_iwan2,zt_iwan2,'Color',[0,0.5,0],'LineWidth',2)
%}

return

%% Further test by running modal transient:
% WARNING: The Newmark integrator used below requires a fine timestep to
% accurately integrate the EOM. Typically this must be 200x the frequency
% of interest, and higher than the experimental sample rate.

phi_dp=0.35; % This should be known from a modal test
dt=fn_0.^-1/200; tnwmrk=[0:dt:ad.tds(end)];
% To use the unfiltered force:
    f_interp=interp1(t,force,tnwmrk); 
% % Apply decimation and filtering to force?
%     f_interp=interp1(ad.tds,filtfilt(ad.b,ad.a,decimate(force,ad.dec_fact)),tnwmrk); 
[xmi,xdmi,xddmi,admi] = iwan_modaltrans([p_est,K_inf,2*zt_material*fn_0*2*pi],...
    phi_dp*f_interp,dt);

% Plotting
figure(5); %subplot(1,4,2:3);
plot(ad.tds,ad.yfilt,tnwmrk,xddmi)
title('Modal Transient: Iwan vs. Measured'); legend('Measured','Modal Iwan');
xlabel('Time (s)'); ylabel('Response (m/s^2)');

[Xddmi,wsmi]=fft_easy(xddmi,tnwmrk);
    Xddmi=Xddmi*(2/length(xddmi));
[Yt,ws]=fft_easy(yt,ts);
    Yt=Yt*(2/length(yt));
    figure(6);
    semilogy(ws/2/pi,abs(Yt),wsmi/2/pi,abs(Xddmi));
    title('Modal Transient: Iwan vs. Measured');
    xlabel('Frequency (Hz)'); ylabel('FFT of Accel. Response (m/s^2)');
    legend('Measured','Modal Iwan');

%% Try a simpler model - just integrate a linear system with power-law damping
%
% To use the unfiltered force:
	fextfun=@(tval) interp1(t,phi_dp*force,tval);
% Apply decimation and filtering to force?
%   fextfun=@(tval) interp1(tnwmrk,phi_dp*f_interp,tval);

f=@(t,x) [0,1; -(K_inf+K_t) ...
    -2*(zt_material+C_zt*sqrt((K_inf+K_t)*x(1)^2+x(2)^2)^(1+chi_zt))*fn_0*2*pi]*x+[0; fextfun(t)];

[tode,yode]=ode45(f,t,[0;0]);

figure(5);
line(tode(1:end-1),(tode(2)-tode(1)).^-1*diff(yode(:,2)),'Color','r');
legend('Measured','Modal Iwan','Simple Amp. Dependent');
