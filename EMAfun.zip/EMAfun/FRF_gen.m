function H = FRF_gen(wn,zt,phi,omegas)

verbose = false;
nmodes = length(wn);
ndof = size(phi,1);
nlines = length(omegas);

tf_num = zeros(ndof,ndof,nmodes);
tf_den = zeros(nlines,1,nmodes);

tstart = tic;

for r = 1:nmodes
    tf_num(:,:,r) = phi(:,r)*phi(:,r).';
    tf_den(:,1,r) = wn(r)^2-2*1i*zt(r)*omegas-omegas.^2;
    if r == 5
        tel = toc(tstart);
        ttot = tel/5*nmodes;
        if ttot > 5;
            verbose = true;
        end
    end
    if verbose
        disp(['Calculating Numerator and Denominator for mode ',num2str(r)]);
    end
end

if verbose
    disp('Calculating FRF at each frequency line');
end
percent = 0;
percentinc = 0.01;

verbose = false;
tline = tic;
H = zeros(ndof,ndof,nlines);
for l = 1:nlines
    for r = 1:nmodes
        H(:,:,l) = H(:,:,l)+tf_num(:,:,r)/tf_den(l,1,r);
    end
    if l == 5
        tel = toc(tline);
        if tel/5*nlines > 10
            verbose = true;
        end
    end
    if verbose
        if l/nlines > percent;
            disp([num2str(percent*100),'% completed']);
            percent = percent + percentinc;
        end
    end
end