function [x] = mkreal(x);
% Checks that the imaginary parts of a matrix are small, and then
% eliminates them.  Useful to remove spurrious imaginary parts after
% computing modal solutions, etc...
%
% [xreal] = mkreal(xcomplex);
%

if abs(norm(imag(x))/norm(real(x))) > 1e-7
    errmsg{1} = 'Imaginary Parts are larger than 1e-5%';
    errmsg{2} = 'Are you sure you want to elimiate them?';
    warning(errmsg);
end

x = real(x);