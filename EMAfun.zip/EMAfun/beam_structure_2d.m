function [ss,beams] = beam_structure_2d(node,conn,props,varargin)


nametext = '';
lspc = '.-';
noplot = 0;

for i = 1:length(varargin)
    if strcmpi(varargin{i},'Name');
        nametext = varargin{i+1};
    end
    if strcmpi(varargin{i},'Linespec');
        lspc = varargin{i+1};
    end
    if strcmpi(varargin{i},'NoPlot');
        noplot = 1;
    end
end

nbeams = size(conn,1);

if length(props) == 1
    disp('Only 1 property structure given.  Assuming constant properties')
    disp('   for all beam segments');
    for i = 2:nbeams
        props(i) = props(1);
    end
end

if length(props) ~= nbeams
    error('Number of rows of connectivity map must be the same length as property structure');
end



beams = props;
for i = 1:nbeams
    beams(i).angle = atan2(node(conn(i,2),2)-node(conn(i,1),2),...
        node(conn(i,2),1)-node(conn(i,1),1));
end

%% Create each beam FE model
ss.nodedef = zeros(0,2);
for i = 1:nbeams
    v = node(conn(i,2),:) - node(conn(i,1),:);
    [K,M,~] = beamkm_ur(beams(i).nodes,norm(v),beams(i).b,beams(i).h,beams(i).E,beams(i).rho,beams(i).nu);
    DOF = sort([1:6:6*beams(i).nodes,5:6:6*beams(i).nodes,3:6:6*beams(i).nodes]);
    beams(i).K = K(DOF,DOF); beams(i).M = M(DOF,DOF);
    for j = 1:2;
        beams(i).nodedef(:,j) = linspace(node(conn(i,1),j),node(conn(i,2),j),beams(i).nodes);
    end
    ss.nodedef = [ss.nodedef;beams(i).nodedef];
    [beams(i).phi,beams(i).fn] = eig(beams(i).K,beams(i).M);
    beams(i).fn = sqrt(diag(beams(i).fn))/2/pi;
    beams(i).fn(1:3) = 0;
    beams(i).wn = beams(i).fn*2*pi;
    beams(i).zt = 0.001*ones(size(beams(i).fn));
    
    % Gram-Schmidt rbms into orthogonal motions in element coordinate
    % systems
    phi_rbm = beams(i).phi;
    phi_new = zeros(size(phi_rbm));
    phi_new(1:3:end,1) = 1;
    phi_new(2:3:end,2) = 1;
    % Find the last shape
    phi_new(:,3) = phi_rbm(:,3);
    v = phi_new;
    u = zeros(size(v,1),3);
    u(:,1) = v(:,1);
    u(:,2) = v(:,2) - dot(v(:,2),u(:,1))/dot(u(:,1),u(:,1))*u(:,1);
    u(:,3) = v(:,3) - dot(v(:,3),u(:,1))/dot(u(:,1),u(:,1))*u(:,1) - dot(v(:,3),u(:,2))/dot(u(:,2),u(:,2))*u(:,2);
    phi_new = u;
    % Mass normalize
    for j = 1:3
        phi_new(:,j) = phi_new(:,j)/sqrt(phi_new(:,j).'*beams(i).M*phi_new(:,j));
    end
    beams(i).phi(:,1:3) = phi_new;
    % Make Names
    for j = 1:beams(i).nodes;
        beams(i).names{3*(j-1)+1,1} = [nametext,num2str(j),'Y+'];
        beams(i).names{3*(j-1)+2,1} = [nametext,num2str(j),'X+'];
        beams(i).names{3*(j-1)+3,1} = [nametext,num2str(j),'R+'];
    end
end

for j = 1:sum([beams.nodes]);
    ss.names{3*(j-1)+1,1} = [nametext,num2str(j),'Y+'];
    ss.names{3*(j-1)+2,1} = [nametext,num2str(j),'X+'];
    ss.names{3*(j-1)+3,1} = [nametext,num2str(j),'R+'];
end

%% Create Constraints to tie the system together
% Find Constrained Nodes
constrainednodes = zeros(size(node,1),1);
for i = 1:length(constrainednodes)
    beamswiththisnode = 0;
    for j = 1:nbeams
        if any(conn(j,:)==i)
            beamswiththisnode = beamswiththisnode+1;
        end
    end
    if beamswiththisnode > 1
        constrainednodes(i) = 1;
    end
end

% Apply Constraints
carray = zeros(3,3,0);
cind = 0;
for i = 1:length(constrainednodes)
    if constrainednodes(i)
        % Find lines with that node
        for j = 1:nbeams
            inode{j,1} = find(conn(j,:) == i);
        end
        % Constrain each subsequent line with that node to the first line
        coef1 = -1; ss1 = find(~cellfun('isempty',inode),1,'first');
        if inode{ss1} == 1
            node1 = 1;
        else
            node1 = beams(ss1).nodes;
        end
        % Create the array
        for j = ss1+1:length(inode)
            % If the line doesn't touch it, continue to the next one.
            if ~isempty(inode{j})
                relangle = beams(j).angle-beams(ss1).angle;
                if inode{j} == 1
                    node2 = 1;
                else
                    node2 = beams(j).nodes;
                end
                % Create X constraint on the reference part
                cind = cind+1;
                carray(:,:,cind) = [coef1,(node1-1)*3+2,ss1; % Reference
                    cos(relangle),(node2-1)*3+2,j; % Other X
                    sin(relangle),(node2-1)*3+1,j]; % Other Y
                % Create Y constraint on the reference part
                cind = cind+1;
                carray(:,:,cind) = [coef1,(node1-1)*3+1,ss1;
                    cos(relangle),(node2-1)*3+1,j;
                    -sin(relangle),(node2-1)*3+2,j];
                % Create R constraint on the reference part
                cind = cind+1;
                carray(:,:,cind) = [coef1,(node1-1)*3+3,ss1;
                    1,(node2-1)*3+3,j;
                    0,1,ss1]; % Bogus constraint
            end
        end
    end
end

%% Create the system
[ss.wn,ss.zt,ss.phi,ss.beam_ind,coord_ind,M_hat,C_hat,K_hat,ad] = ...
    ritzscomb(beams,carray,ones(1,length(beams)));
ss.fn = ss.wn/2/pi;
ss.M=M_hat;
ss.K=K_hat;
ss.C=C_hat;


%% Perform Gram-Schmidt again to renormalize.
if length(beams)>1
    M_total = blockDiagonal(beams.M);
else
    M_total = beams(1).M;
end
phi_rbm = zeros(0,3);
% go through all dimensions assign x and y translations
for i = 1:length(beams)
    beam_rbm = zeros(size(beams(i).phi,1),3);
    th = beams(i).angle;
    for j = 1:size(beams(i).nodedef,1)
        % x translation
        beam_rbm(3*(j-1)+2,1) = cos(th);
        beam_rbm(3*(j-1)+1,1) = sin(th);
        % y translation
        beam_rbm(3*(j-1)+2,2) = -sin(th);
        beam_rbm(3*(j-1)+1,2) = cos(th);
    end
    phi_rbm = [phi_rbm;beam_rbm];
end

% Find the last shape
phi_rbm(:,3) = ss.phi(:,3);
v = phi_rbm;
u = zeros(size(v,1),3);
u(:,1) = v(:,1);
u(:,2) = v(:,2) - dot(v(:,2),u(:,1))/dot(u(:,1),u(:,1))*u(:,1);
u(:,3) = v(:,3) - dot(v(:,3),u(:,1))/dot(u(:,1),u(:,1))*u(:,1) - dot(v(:,3),u(:,2))/dot(u(:,2),u(:,2))*u(:,2);
phi_new = u;
% Mass normalize
for j = 1:3
    phi_new(:,j) = phi_new(:,j)/sqrt(phi_new(:,j).'*M_total*phi_new(:,j));
end
ss.phi(:,1:3) = phi_new;

if ~noplot
    figure;
    beam_structure_plotter(ss,beams,1,'Linespec',lspc,'Labels','Scale',0);
    if isempty(nametext)
        title(['System Nodes']);
    else
        title(['System ',nametext,' Nodes']);
    end
    figure;
    beam_structure_plotter(ss,beams,1:16,'Linespec',['b',lspc]);
end

end