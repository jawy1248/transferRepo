% Integrate EOM for 3DOF system with Iwan joints, to create "test" data to
% use to identify modal Iwan models.

clear; close all;


%% Build the Model

% Simulation Parameters
% Force level
    Am = [1e2];%[200,2.5e4, 2e7];%[200 2000 7000 15000 25000 100e3 225e3 675e3 2000e3]; % Impact Force Levels 
tsim = 4000;            % simulation duration
M0 = 10;               % Mass
Kinf = 5;              % stiffness of elastic spring
% zeta = .001;           % modal zeta

% Set up system parameters

% Nonlinear Iwan Joint parameters
% Fs   = 10;  % slip force
% Kt  = 1;    % stiffness of the joint
% beta  = 3;  % parameter that is associated with energy dissipation curve
% chi = -0.5; % parameter associate with slope of log(energy dissipation) vs. log(force)
% params = [Fs,Kt,chi,beta];
%         IwanPairs = [2,3]; % Iwan joint between masses 2 and 3
% Multiple Iwan joints
params=[10,5,-0.5, 0.1;
    1,4,-0.2, 0.01;
    100,3,-0.8,1];%
IwanPairs = [0,1; 1,2; 2,3];
Nj=50;

% Define matrices
N=3;
M = M0*diag([1,1,1]);
KINF = [2*Kinf -Kinf 0;
    -Kinf 2*Kinf -Kinf;
    0 -Kinf Kinf];
KT = [9    -4     0;
    -4     7    -3;
     0    -3     3];
K0 = KINF+KT;
    
% Eigen Analysis
[phi0,lam0] = eig(K0,M);      % mode shapes with joint stiffness (micro-slip)
[phiInf,lamInf] = eig(KINF,M);     % mode shapes without joint stiffness (macro-slip)

fn0 = sqrt(diag(lam0))/2/pi;  % natural frequencies calculated with joint stiffness
fnInf = sqrt(diag(lamInf))/2/pi; 

% Damping based on desired damping ratio
%   C = M*phi*2*zeta*sqrt(lam)*phi0'*M; % physical damping coeff matrix 
% Damping based on stiffness proportional, by directly assembly damping
% matrices.
    C = M*0.002+KINF*0.002;
    ztsInf=diag(phiInf.'*C*phiInf)./(2*sqrt(diag(lamInf)))
    zts0=diag(phi0.'*C*phi0)./(2*sqrt(diag(lam0)))
    
% Initialize variables
dt = 1/(max(fnInf)*200);   % defines a very small step size % Added factor of 10 smaller for mode 3
ts = 0:dt:tsim;         % defines time vector
Nt = length(ts);

f_m = cell(1,length(Am));
q_x = cell(1,length(Am));
q_v = cell(1,length(Am));
q_a = cell(1,length(Am));
f_jm = cell(1,length(Am));

tic
for ii = 1:length(Am)
    % External Force
    A=Am(ii);
        % Create Impact Force
        f_ext = zeros(1,Nt);   % allocate force vector
        T = 1/10;
        for k = 1:Nt
            if ts(k) <= T/2       % for half the period of a sine wave apply the force
                f_ext(k) = A*sin(2*pi/T*ts(k)); 
            else
                f_ext(k) = 0;
            end
        end
        fext = [0;0;1]*f_ext; % Force applied at DOF N % was [0;0;1]
%         fext = M*phi0(:,3)*f_ext; % Manually change here to set mode number
        % Discrete Integration
        ICs={zeros(N,1),zeros(N,1),zeros(Nj,3)};
        [x, v, a, f_joint,ad] = IwanIntegration(params,M,C,KINF,fext,ts,IwanPairs,ICs);
        
        % Transform Physical DOF into Modal DOF
        f_m{ii} = phi0.'*(fext(:,1:10:end));
        q_x{ii} = phi0.'*M*x(:,1:10:end);
        q_v{ii} = phi0.'*M*v(:,1:10:end);
        q_a{ii} = phi0.'*M*a(:,1:10:end);
        tsq=ts(1:10:end);
%         f_jm{ii} = phi0.'*f_joint; % need to compute mapping vector to fix this
        disp(['Impact force ',num2str(ii),' processed.']);
end
t_int=toc

figure(10)
plot(ts,x);
xylabels('\bfTime (s)','\bfResponse');

fft_easy(q_v{1},tsq);

% save 3DOF3Iwan_1e3_M2.mat

% figure(2); plot(ts,ad.K_joint) % This shows how the joint stiffness
% evolves with time.
return

%% Linear Response
[F_ext,ws]=fft_easy(f_ext.',ts);

H=cl_model(2*pi*fn0,zts0,{phi0,phi0(3,:)},ws,'V','s');
    for k=1:size(H,2);
        Yd(:,k)=H(:,k).*F_ext;
    end
    % Compare to Newmark Result
    [Xd,ws]=fft_easy(v,ts);
    
    figure(11);
    semilogy(ws/2/pi,abs(Yd)); hold on; semilogy(ws/2/pi,abs(Xd),'--'); hold off
    grid on;
    xlabel('Frequency'); ylabel('Respnonse (m/s)'); legend('Linear','Newmark');
    
%% Compute transfer function and find the response
[Xd,ws]=fft_easy(v,ts);
    for k=1:size(Xd,2);
        Hd(:,k)=Xd(:,k)./F_ext;
    end
    
    % Run AMI to fit a linear mode to this
    ami(Hd,ws)
    

