function [Bint] = ltpDiffFS(B,mB,wA,lam);
% Differentiates a Fourier Series model for a Linear Time-Periodic System
%
% [Bint] = ltpDiffFS(B,mB,lam);
%
% X(t) = sum_r sum_m [ B(:,r,m)*exp(i*wA*m*t)*exp(lam(r)*t) ]
%
% int(X(t),0,t) = sum_r sum_m [ BInt(:,r,m)*exp(i*wA*m*t)*exp(lam(r)*t) ]
%
% B is size (No,Nfs,N)
%       No - number outputs
%       Nfs - number Fourier Series Coefficients
%       N - number of modes
%   
% M.S. Allen, May 2010
%

[No,Nfs,N] = size(B);

% ADD: Check that mB is the same size as B
% ADD: Check that lam is the right size

Bint = zeros(size(B));
for m_num = 1:N;
    Bint(:,:,m_num) = B(:,:,m_num)./(i*wA*mB(:,:,m_num)+lam(m_num));%-B(:,:,m_num);
        % May need to check this.  Do we need to account for the IC's?
end


