% Modes of a Free-Free beam - Fixture design for Cummins
clear all; close all;

% Analytical Model
% Create variables for Ritz Series
syms y real;
tic
N = 10;
% Find Alpha Values using Ginsberg Reference, back cover
    ce = inline('cos(x) - 1/cosh(x)');
    an0 = [4.730, (2*[4:N+2]-3)/2*pi];
    for k = 1:length(an0);
        an(k) = fzero(ce,an0(k));
    end
    for j = 1:N;
        Rn(j) = -(sin(an(j)) - sinh(an(j)))/(cos(an(j)) - cosh(an(j)));
    end
% Generate Mode functions
for j = 1:N
    psi(j) = sin(an(j)*y) + sinh(an(j)*y) + Rn(j)*(cos(an(j)*y) + cosh(an(j)*y));
end

% Mass Normalize:
for j = 1:N;
    mu_nd(j) = double(int(psi(j)^2,0,1)); 
end % all end up being values near one.

%% For a real beam
E = 70e9;   % Pa Aluminum 
G = 26.8e9; % Norton
rho = 2700; % kg/m^3
L = 30*0.0254; %m
% b = 2*0.0254; %m
% h = 3/16*0.0254; %m
% I = b*h^3/12;
d = 1*0.0254; % 3 in circular solid shaft
I = (1/4)*pi*(d/2)^4 % m^4
A = pi*(d/2)^2; % area, m^2
rhoA = rho*A;
J = (1/2)*pi*(d/2)^4
gam = J

% Bending Factor
    BeamMult = (E*I/(rhoA*L^4))^(1/2);
    wn_b_an = BeamMult*(an.^2).';
    fn_b_an = wn_b_an/2/pi
    mu = mu_nd*rhoA*L;

% Torsion - from Inman, or have Ansys do cross section analysis.
    gam = 2*I % or from ANSYS Beam Tool (Section Analysis)
    anT = ([2:4].'-1)*pi; % Ginsberg
    wn_t_an = anT*(G*gam/(rho*J*L^2))^(1/2);
    fn_t_an = wn_t_an/2/pi

%% Plot mode shapes
xan = linspace(0,1,100).';

phib_an = zeros(length(xan),length(fn_b_an));
for k = 1:length(fn_b_an);
    phib_an(:,k) = subs(psi(k),'y',xan)/sqrt(rhoA*L*mu_nd(k));
end

phit_an = zeros(length(xan),length(fn_t_an));
for k = 1:length(fn_t_an);
    phit_an(:,k) = cos(k*pi*xan);
end

%% Create the same using Dorhman's beamkm program
Nelem = 20;

[K,M,nodedef_B] = beamkm_ua(Nelem,L,A*E,G*gam,E*I,E*I*1.0001,rhoA,rho*J);
% dof = [6:6:6*Nelem];
% K = K(dof,dof); M = M(dof,dof);

[phi_B,fn_B] = eig(K,M);
fn_B = sqrt(diag(fn_B))/2/pi;
fn_B(1:Nelem)

% Now we can see that these two give similar results
plot(nodedef_B(:,3),phi_B(1:6:end,7:Nelem));
xlabel('Position (m)'); ylabel('Deflection');
title('Mode Shapes');

bend1_ind = find(max(phi_B(1:6:end,:),[],1) > 1);
bend2_ind = find(max(phi_B(2:6:end,:),[],1) > 1);
ax_ind = find(max(phi_B(3:6:end,:),[],1) > 1);
torsion_ind = find(max(phi_B(6:6:end,:),[],1) > 1);


