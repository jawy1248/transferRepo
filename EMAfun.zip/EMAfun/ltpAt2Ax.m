function [fij] = ltpAt2Ax(x_bar,At)
% Calculate A(x) from estimate of A(t) when the system is linearized about
% a periodic orbit xbar.
%
% [fij] = ltpAt2Ax(x_bar,At)
%       At is a time varying state matrix of size [N,N,Nt]
%       x_bar is the corresponding state vector size [N,Nt]
%
% The output fij is an [N,N,Nt] matrix of force-displacment terms.
%
% This function integrates k(x)*dx and c(x_dot)*dx_dot, etc... to get the
% underlying nonlinear stiffness and damping functions.
%
% MSA, Oct. 2010

% Rigorous method to calculate f(x) from A(t)=df/dx
fij = zeros(size(At,1),size(At,2),length(x_bar));
for m = 1:size(At,1);
    for n = 1:size(At,2);
        fij(m,n,:) = cumtrapz(x_bar(n,:),squeeze(At(m,n,:))); 
    end
end


%% Old code from Duffing_FEMA_v2 - where this was worked out
% Computed above
% x_bar = [A*sin(Omega*tstart_dt);
%     A*Omega*cos(Omega*tstart_dt)];
% 
% fij = zeros(size(At_est_nl,1),size(At_est_nl,2),length(x_bar));
% for m = 1:size(At_est_nl,1);
%     for n = 1:size(At_est_nl,2);
%         fij(m,n,:) = cumtrapz(x_bar(n,:),squeeze(At_est_nl(m,n,:))); 
%     end
% end
% 
% line(x_bar(1,:),-squeeze(fij(2,1,:)),'Color','r','Marker','o');
% 
% Alternative - integrate over time instead.  Gives identical result.
% dx_bar = [A*Omega*cos(Omega*tstart_dt);
%     -A*Omega^2*sin(Omega*tstart_dt)];
% fij = zeros(size(At_est_nl,1),size(At_est_nl,2),length(x_bar));
% for m = 1:size(At_est_nl,1);
%     for n = 1:size(At_est_nl,2);
%         fij(m,n,:) = cumtrapz(tstart_dt,squeeze(At_est_nl(m,n,:)).*vec(dx_bar(n,:))); 
%     end
% end
%     line(x_bar(1,:),-squeeze(fij(2,1,:)),'Color','r','Marker','*');